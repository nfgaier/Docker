#!/usr/bin/env bash
###############################################################################
# Description :     Initialise le statut d un traitement
# Usage : 
# Parameters :      $1 Repertoire de configuration du traitement
#                   $2 Nom du traitement a initier
# Author :          LCO
# Updated :         20/11/2017
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d%H%M%S%N")                 #time stamp ex.20170804110741146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

if [[ -z ${WORKFLOW_ENV+x} ]]; then 
  WORKFLOW_ENV="OOZIE"; export WORKFLOW_ENV
fi

case "${WORKFLOW_ENV}" in 
  OOZIE) 
    if [[ $# != 3 ]] ; then
    echo "Ce traitement attend trois parametres : <ROOT> <NOM_TRAITEMENT> <APPLI_TRAITEMENT>"
    exit ${__FAILURE}
  fi
  
  ROOT="$1"
  NOM_TRAITEMENT="$2"
  APPLI_TRAITEMENT="$3"
  REP_CONF=""
  
  #load and apply specific oozie function
  hadoop fs -get "${ROOT}/common/.fonction_bastid_oozie"
  . .fonction_bastid_oozie 
    init_oozie_env "${ROOT}" "${APPLI_TRAITEMENT}"
  ;;
  *)
    if [[ $# != 2 ]] ; then
    echo "Ce traitement attend deux parametres : <REP_CONF> <NOM_TRAITEMENT>"
    exit ${__FAILURE}
  fi
  
  . $APPLI_HOME/appli/connexion/.fonction_bastid_spec        #source .fonction_*_spec 
  
  [[ "${1: -1}" == "/" ]] && REP_CONF="${1}" || REP_CONF="${1}/"
  NOM_TRAITEMENT="$2"  
  LOGDIR="${LST}"; export LOGDIR                             #log folder exported for use in .fonction_*_spec 
  ;;
esac

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

VAR_APPLI=''
VAR_PHASE=''
VAR_NB_DATEOPE=''
VAR_DEP_AMONT=''
VAR_DEP_AVAL=''

#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  START
  SETUP
    
    # Insertion d'une ligne de suivi En cours
    LOG_INFO "Lecture des parametres dans ${REP_CONF}${PARAM_BATCH}"
    
    READ_BATCH_PARAM "${REP_CONF}${PARAM_BATCH}" "APPLI" "VAR_APPLI"
    READ_BATCH_PARAM "${REP_CONF}${PARAM_BATCH}" "PHASE" "VAR_PHASE"
    READ_BATCH_PARAM "${REP_CONF}${PARAM_BATCH}" "NB_DATEOPE_${NOM_TRAITEMENT}" "VAR_NB_DATEOPE"
    if [[ -z $VAR_NB_DATEOPE ]];then VAR_NB_DATEOPE='Null';fi
    
    GET_LIST_TABLE "${NOM_TRAITEMENT}" "${REP_CONF}${DEPENDANCES}" "SOURCE" "TVAR_DEP_AMONT_DELTA" "TVAR_DEP_AMONT_FULL"
    GET_LIST_TABLE "${NOM_TRAITEMENT}" "${REP_CONF}${DEPENDANCES}" "CIBLE" "TVAR_DEP_AVAL_DELTA" "TVAR_DEP_AVAL_FULL"
    
    for DEP in ${TVAR_DEP_AMONT_DELTA[*]};do VAR_DEP_AMONT+="$DEP"',';done
    for DEP in ${TVAR_DEP_AMONT_FULL[*]};do VAR_DEP_AMONT+="$DEP"',';done
    
    for DEP in ${TVAR_DEP_AVAL_DELTA[*]};do VAR_DEP_AVAL+="$DEP"',';done
    for DEP in ${TVAR_DEP_AVAL_FULL[*]};do VAR_DEP_AVAL+="$DEP"',';done
    
    LOG_INFO "PROJET :                          ${PROJET}"
    LOG_INFO "APPLI :                           ${VAR_APPLI}"
    LOG_INFO "PHASE :                           ${VAR_PHASE}"
    LOG_INFO "TRAITEMENT :                      ${NOM_TRAITEMENT}"
    LOG_INFO "NOMBRE DE DATE_OPE A CHARGEES :   ${VAR_NB_DATEOPE}"
    LOG_INFO "DEPENDANCES AMONT :               ${VAR_DEP_AMONT}"
    LOG_INFO "DEPENDANCES AVAL :                ${VAR_DEP_AVAL}"
    
    LOG_INFO ""
    LOG_INFO "===================================================="
    LOG_INFO "Initialisation du traitement $NOM_TRAITEMENT a $ST_ENCOURS dans la table $TOT"
    LOG_INFO "===================================================="
    LOG_INFO ""
    
#    REQ="   insert into $TOT ("
#    REQ+="     id_job"
#    REQ+="     , type_suivi        "
#    REQ+="     , niveau_suivi      "
#    REQ+="     , projet            "
#    REQ+="     , application       "
#    REQ+="     , phase             "
#    REQ+="     , nom_traitement    "
#    REQ+="     , mode_alim         "
#    REQ+="     , nb_date_ope       "
#    REQ+="     , date_debut        "
#    REQ+="     , date_fin          "
#    REQ+="     , dependances_amont "
#    REQ+="     , dependances_aval  "
#    REQ+="     , status            "
#    REQ+="     , date_ope          "
#    REQ+="     , nom_table         "
#    REQ+="     , type_table        "
#    REQ+="     , borne_min         "
#    REQ+="     , borne_max         "
#    REQ+="     , nb_lignes         "
#    REQ+="     , type_log          "
#    REQ+="     , log               "
#    REQ+=" ) values (              "
#    REQ+="     to_char(now(), 'YYYYMMDDHH24MISSUS')"
#    REQ+="     , 'SUIVI'             "
#    REQ+="     , 'STATUT'            "
#    REQ+="     , '${PROJET}'         "
#    REQ+="     , '${VAR_APPLI}'      "
#    REQ+="     , '${VAR_PHASE}'      "
#    REQ+="     , '${NOM_TRAITEMENT}' "
#    REQ+="     , '${MODE_ALIM_QUOTI}'"
#    REQ+="     , ${VAR_NB_DATEOPE}   "
#    REQ+="     , now()               "
#    REQ+="     , Null                "
#    REQ+="     , '${VAR_DEP_AMONT}'  "
#    REQ+="     , '${VAR_DEP_AVAL}'   "
#    REQ+="     , '${ST_ENCOURS}'     "
#    REQ+="     , Null                "
#    REQ+="     , Null                "
#    REQ+="     , Null                "
#    REQ+="     , Null                "
#    REQ+="     , Null                "
#    REQ+="     , Null                "
#    REQ+="     , Null                "
#    REQ+="     , Null                "
#    REQ+=" )                         "
#    
#    LOG_INFO "REQ : $REQ"
#  
#    PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"
    
    LOG_EVENT "BLK" \
              "id_job;'$(date +'%Y%m%d%H%M%S%6N')'" \
              "type_suivi;'SUIVI'" \
              "niveau_suivi;'STATUT'" \
              "projet;'${PROJET}'" \
              "application;'${VAR_APPLI}'" \
              "phase;'${VAR_PHASE}'" \
              "nom_traitement;'${NOM_TRAITEMENT}'" \
              "mode_alim;'${MODE_ALIM_QUOTI}'" \
              "nb_date_ope;${VAR_NB_DATEOPE}" \
              "date_debut;'$(date +'%Y-%m-%d %H:%M:%S.%N')'" \
              "dependances_amont;'${VAR_DEP_AMONT}'" \
              "dependances_aval;'${VAR_DEP_AVAL}'" \
              "status;'${ST_ENCOURS}'" \
              "log;'Initialisation du statut'"

    
  END  
  exit ${__SUCCESS}
  
}

if [[ "${WORKFLOW_ENV}" == "OOZIE" ]] ; then 
  main "$@"
else
  main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
fi