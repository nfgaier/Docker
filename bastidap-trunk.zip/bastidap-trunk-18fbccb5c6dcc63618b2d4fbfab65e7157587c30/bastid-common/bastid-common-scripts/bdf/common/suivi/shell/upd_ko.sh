#!/usr/bin/env bash
###############################################################################
# Description :     Met à jour à KO les statuts des traitements non validés
# Usage : 
# Parameters :      
#      $1 Répertoire de conf ou répertoire de travail oozie
#      $2 Nom du traitement
#      $3 Nom d'application
# Author :          LCO
# Updated :         17/11/2017
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d%H%M%S%N")                 #time stamp ex.20170804110741146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

if [[ -z ${WORKFLOW_ENV+x} ]]; then 
  WORKFLOW_ENV="OOZIE"; export WORKFLOW_ENV
fi

case "${WORKFLOW_ENV}" in 
  OOZIE) 
    if [[ $# != 3 ]] ; then
		echo "Ce traitement attend trois parametres : <ROOT> <NOM_TRAITEMENT> <APPLI_TRAITEMENT>"
		exit ${__FAILURE}
	fi
	
	ROOT="$1"
	NOM_TRAITEMENT="$2"
	APPLI_TRAITEMENT="$3"
	REP_CONF=""
	LOGDIR="${ROOT}/log/${APPLI_TRAITEMENT}"; export LOGDIR    #log folder exported for use in .fonction_*_spec
	
	#load and apply specific oozie function
	hadoop fs -get "${ROOT}/common/.fonction_bastid_oozie"
	. .fonction_bastid_oozie 
    init_oozie_env "${ROOT}" "${APPLI_TRAITEMENT}" "${LOGDIR}"
	;;
  *)
    if [[ $# != 2 ]] ; then
		echo "Ce traitement attend deux parametres : <REP_CONF> <NOM_TRAITEMENT>"
		exit ${__FAILURE}
	fi
	
	. $APPLI_HOME/appli/connexion/.fonction_bastid_spec        #source .fonction_*_spec 
	
	[[ "${1: -1}" == "/" ]] && REP_CONF="${1}" || REP_CONF="${1}/"
	NOM_TRAITEMENT="$2"
	
	LOGDIR="${LST}"; export LOGDIR                             #log folder exported for use in .fonction_*_spec 
	;;
esac

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

VAR_APPLI=''
VAR_PHASE=''

#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  START
  SETUP
    
    LOG_INFO "Lecture des parametres dans ${REP_CONF}${PARAM_BATCH}"
    READ_BATCH_PARAM "${REP_CONF}${PARAM_BATCH}" "APPLI" "VAR_APPLI"
    READ_BATCH_PARAM "${REP_CONF}${PARAM_BATCH}" "PHASE" "VAR_PHASE"
    
    LOG_INFO "PROJET : $PROJET"
    LOG_INFO "APPLI : $VAR_APPLI"
    LOG_INFO "PHASE : $VAR_PHASE"
    LOG_INFO "TRAITEMENT : $NOM_TRAITEMENT"
    
    LOG_INFO ""
    LOG_INFO "===================================================="
    LOG_INFO "Mise a jour des statuts du traitement $NOM_TRAITEMENT de $ST_ENCOURS a $ST_KO dans la table $TOT"
    LOG_INFO "===================================================="
    LOG_INFO ""

    REQ="  update $TOT"
    REQ+=" set status = '${ST_KO}'"
    REQ+=" where"
    REQ+="     type_suivi = '${TYPE_SUIVI_SUIVI}'"
    REQ+="     and niveau_suivi in ('${NIVEAU_SUIVI_STATUT}', '${NIVEAU_SUIVI_CATALOGUE}')"
    REQ+="     and projet = '${PROJET}'"
    REQ+="     and application = '${VAR_APPLI}'"
    REQ+="     and phase = '${VAR_PHASE}'"
    REQ+="     and nom_traitement = '${NOM_TRAITEMENT}'"
    REQ+="     and status = '${ST_ENCOURS}'"
	
	LOG_INFO "REQ : $REQ"
    
    PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"

  END  
  exit ${__SUCCESS}
  
}

if [[ "${WORKFLOW_ENV}" == "OOZIE" ]] ; then 
  main "$@"
else
  main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
fi