#!/usr/bin/env bash
###############################################################################
# Description :     Construit le catalogue pour l'acquisition de fichiers
# Usage : 
# Parameters :      $1 Repertoire de configuration du traitement
#                   $2 Nom du traitement
# Author :          LCO
# Updated :         05/01/2018
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d%H%M%S%N")                 #time stamp ex.20170804110741146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 


# V�rification du nombre de param�tre attendu
if [[ $# != 2 ]] ; then
  LOG_ERROR "Ce traitement attend deux parametres : <REP_CONF> <NOM_TRAITEMENT>"
  exit $__FAILURE
fi

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec        #source .fonction_*_spec 

REP_CONF="$1"
NOM_TRAITEMENT="$2"

LOGDIR="${LST}"; export LOGDIR                                 #log folder exported for use in .fonction_*_spec 
SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

# Initialisation de variables
VAR_APPLI=''
VAR_PHASE=''


#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  START
  SETUP
    
    LOG_INFO "Lecture des parametres dans ${REP_CONF}/${PARAM_BATCH}"
    
    READ_BATCH_PARAM "${REP_CONF}/${PARAM_BATCH}" "APPLI" "VAR_APPLI"
    READ_BATCH_PARAM "${REP_CONF}/${PARAM_BATCH}" "PHASE" "VAR_PHASE"
    
    GET_LIST_TABLE "${NOM_TRAITEMENT}" "${REP_CONF}/${DEPENDANCES}" "CIBLE" "TVAR_DEP_AVAL_DELTA" "TVAR_DEP_AVAL_FULL"
    
    LOG_INFO "PROJET :                          ${PROJET}"
    LOG_INFO "APPLI :                           ${VAR_APPLI}"
    LOG_INFO "PHASE :                           ${VAR_PHASE}"
    LOG_INFO "TRAITEMENT :                      ${NOM_TRAITEMENT}"
    
    # R�cup�re l'ID_TRAITEMENT en cours
    GET_ID_TRT "$VAR_APPLI" "$VAR_PHASE" "$NOM_TRAITEMENT" "ID_TRAITEMENT"
    LOG_INFO ""
    
    LOG_INFO ""
    LOG_INFO "====================================================================================================="
    LOG_INFO "Construction du catalogue en statut ${ST_ENCOURS} pour le traitement $NOM_TRAITEMENT"
    LOG_INFO "====================================================================================================="
        
    CAT_VALUES=""
        
    LOG_INFO ""
    LOG_INFO "-----------------------------------------------------------------------------------------------------"
    LOG_INFO "Construction des ID_TRAITEMENT pour les tables cibles FULL"
    LOG_INFO ""
    
    for TABLE in ${TVAR_DEP_AVAL_FULL[*]}
    do
        LOG_INFO "G�n�ration de l'ID_TRAITEMENT pour la table cible $TABLE"
        CAT_VALUES=${CAT_VALUES}",('${ID_TRAITEMENT}', '${TYPE_SUIVI_SUIVI}', '${NIVEAU_SUIVI_CATALOGUE}', '${PROJET}', '${VAR_APPLI}', '${VAR_PHASE}', '${NOM_TRAITEMENT}', '${ST_ENCOURS}', Null, '${TABLE}', Null, Null, Null, Null)"
    done
    
    LOG_INFO ""
    LOG_INFO "-----------------------------------------------------------------------------------------------------"
    LOG_INFO "Construction des ID_TRAITEMENT / DATE_OPE pour les tables cibles DELTA"
    LOG_INFO ""
    
    LOG_INFO "Non impl�ment� pour l'instant"
    LOG_INFO ""
    
    # TO-DO
    #for TABLE in ${TVAR_DEP_AVAL_DELTA[*]}
    #do
    #    
    #done
    
    LOG_INFO ""
    LOG_INFO "===================================================================="
    LOG_INFO "Insertion des lignes de catalogue dans ${TOT}"
    LOG_INFO "===================================================================="
    LOG_INFO ""
    
    # insertion dans le catalogue de toutes les lignes
    REQ="insert into ${TOT} (id_job, type_suivi, niveau_suivi, projet, application, phase, nom_traitement, status, date_ope, nom_table, type_table, borne_min, borne_max, nb_lignes) values ${CAT_VALUES:1:$((${#CAT_VALUES}-1))}"
    LOG_INFO "REQ : $REQ"
	PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"
    
  END  
  exit ${__SUCCESS}
  
}

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
