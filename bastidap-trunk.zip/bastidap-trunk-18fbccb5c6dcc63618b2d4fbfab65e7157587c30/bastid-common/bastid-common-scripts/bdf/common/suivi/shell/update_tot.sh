#!/usr/bin/env bash
#####################################################################################
# Description :   mettre à jour la table TOT
# Usage :  mettre à jour le statut d'acquisition et ajouter les flag des traitements
# Parameters :      
#      $1 Répertoire de travail oozie
#      $2 Nom d'application
#      $3 Id de la ligne à mettre à jour dans la table TOT
#      $4 Date d'opération pour les traitements
#      $5 Nombre de jours à prendre en compte
# Author :          YBO
# Updated :         23/01/2018
#####################################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d%H%M%S%N")                 #time stamp ex.20170804110741146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

if [[ $# != 6 ]] ; then
  echo "Ce traitement attend trois parametres : <ROOT> <APPLI_TRAITEMENT> <ID_TOT> <ID_JOB> <DATE_OPE> <NB_DATE>"
  exit ${__FAILURE}
fi
	
ROOT="$1"
APPLI_TRAITEMENT="$2"
ID_TOT="$3"
ID_JOB="$4"
DATE_OPE="$5"
NB_DATE="$6"
REP_CONF=""
LOGDIR="${ROOT}/log/${APPLI_TRAITEMENT}"; export LOGDIR    #log folder exported for use in .fonction_*_spec
	
#load and apply specific oozie function
hadoop fs -get "${ROOT}/common/.fonction_bastid_oozie"
. .fonction_bastid_oozie 
init_oozie_env "${ROOT}" "${APPLI_TRAITEMENT}" "${LOGDIR}"

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

VAR_APPLI=''
VAR_PHASE=''

#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  START
  SETUP
    
    LOG_INFO "Lecture des parametres dans ${REP_CONF}${PARAM_BATCH}"
    READ_BATCH_PARAM "${REP_CONF}${PARAM_BATCH}" "APPLI" "VAR_APPLI"
    READ_BATCH_PARAM "${REP_CONF}${PARAM_BATCH}" "PHASE" "VAR_PHASE"
    
    LOG_INFO "PROJET : $PROJET"
    LOG_INFO "APPLI : $VAR_APPLI"
    LOG_INFO "PHASE : $VAR_PHASE"

	#update ingestion state
	REQ=" select count(id)"
    REQ+=" from ${TOT}"
    REQ+=" where id_job='${ID_JOB}'"
	REQ+=" and type_suivi='${TYPE_SUIVI_SUIVI}'"
	REQ+=" and niveau_suivi='${NIVEAU_SUIVI_CATALOGUE}'"
	REQ+=" and phase='${PHASE_ACQUISITION}'"
	REQ+=" and projet='${PROJET}'"
	REQ+=" and application='${APPLI_TRAITEMENT}'"
	REQ+=" and status='${ST_KO}'"
	
	LOG_INFO "REQ : $REQ"
		  
    resultReq=$(PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -t -c "$REQ")
	LOG_INFO "Nombre d'acquisition de tables en état ${ST_KO} : ${resultReq}"	
	
	if [[ ${resultReq} -eq 0 ]]; then
	
	  LOG_INFO ""
      LOG_INFO "========================================================================"
      LOG_INFO "L'acquisition valide, mettre à jour le statut à OK dans la table $TOT   "
      LOG_INFO "========================================================================"
      LOG_INFO ""
	
      REQ="update $TOT set status='${ST_OK}' where id=${ID_TOT}"
	  LOG_INFO "REQ : $REQ"   
      PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"
	
	  for NOM_TRAITEMENT in 'ACTION' 'ALERTE' 'HIT' 'COPIE_RAW_OPT' 
	  do
	
	    LOG_INFO ""
        LOG_INFO "========================================================================"
        LOG_INFO "Ajouter le flag de traitement pour ${NOM_TRAITEMENT} dans la table $TOT "
        LOG_INFO "========================================================================"
        LOG_INFO ""

	    REQ=" insert into ${TOT} (id_job, type_suivi, projet, application, phase, NOM_TRAITEMENT, status, date_ope, nb_date_ope)"
        REQ+=" values ( 'test','${TYPE_SUIVI_FLAG}','${PROJET}', '${VAR_APPLI}', '${VAR_PHASE}', '${NOM_TRAITEMENT}', '${ST_GO}','${DATE_OPE}',${NB_DATE})"
   
	    LOG_INFO "REQ : $REQ"  
	    PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"
	  done
	  
	else
	
	  LOG_INFO ""
      LOG_INFO "=========================================================================="
      LOG_INFO "L'acquisition non valide, mettre à jour le statut à KO dans la table $TOT "
      LOG_INFO "=========================================================================="
      LOG_INFO ""
	  
	  REQ="update $TOT set status='${ST_KO}' where id=${ID_TOT}"
	  LOG_INFO "REQ : $REQ"   
      PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"	
	  
	fi
	
  END  
  exit ${__SUCCESS}
  
}

main "$@"
