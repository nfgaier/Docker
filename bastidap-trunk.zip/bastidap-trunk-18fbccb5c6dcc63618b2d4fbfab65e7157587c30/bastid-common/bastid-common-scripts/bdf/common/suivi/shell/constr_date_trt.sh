#!/usr/bin/env bash
###############################################################################
# Description :     Construit et insere dans la table de suivi les date ope d un traitement
# Usage : 
# Parameters :      $1 Repertoire de configuration du traitement
#                   $2 Nom du traitement a initier
# Author :          MBO
# Updated :         22/11/2017
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d%H%M%S%N")                 #time stamp ex.20170804110741146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

if [[ -z ${WORKFLOW_ENV+x} ]]; then 
  WORKFLOW_ENV="OOZIE"; export WORKFLOW_ENV
fi

case "${WORKFLOW_ENV}" in 
  OOZIE) 
    if [[ $# != 3 ]] ; then
		echo "Ce traitement attend trois parametres : <ROOT> <NOM_TRAITEMENT> <APPLI_TRAITEMENT>"
		exit ${__FAILURE}
	fi
	
	ROOT="$1"
	NOM_TRAITEMENT="$2"
	APPLI_TRAITEMENT="$3"
	REP_CONF=""
	LOGDIR="${ROOT}/log/${APPLI_TRAITEMENT}"; export LOGDIR    #log folder exported for use in .fonction_*_spec
	
	#load and apply specific oozie function
	hadoop fs -get "${ROOT}/common/.fonction_bastid_oozie"
	. .fonction_bastid_oozie 
    init_oozie_env "${ROOT}" "${APPLI_TRAITEMENT}" "${LOGDIR}"
	;;
  *)
    if [[ $# != 2 ]] ; then
		echo "Ce traitement attend deux parametres : <REP_CONF> <NOM_TRAITEMENT>"
		exit ${__FAILURE}
	fi
	
	. $APPLI_HOME/appli/connexion/.fonction_bastid_spec        #source .fonction_*_spec 
	
	[[ "${1: -1}" == "/" ]] && REP_CONF="${1}" || REP_CONF="${1}/"
	NOM_TRAITEMENT="$2"
	
	LOGDIR="${LST}"; export LOGDIR                             #log folder exported for use in .fonction_*_spec 
	;;
esac

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

VAR_APPLI=''
VAR_PHASE=''
VAR_DEP_AVAL=''

REQ_TAB_CIBLE=''

#######################################
# Description: get the request for the target tables
# Arguments:
# Returns: 
#######################################
get_request_table_cible () {

  local list_tab_cible=("${@}")

  if [[ ${#list_tab_cible[@]} -ne 0 ]]; then
  
    if [[ ${#list_tab_cible[@]} -eq 1 ]]; then
      REQ_TAB_CIBLE+="(SELECT '${list_tab_cible[0]}' as nom_table) cible"
    else
      REQ_TAB_CIBLE+="(SELECT cib.nom_table FROM ("
      for (( i=0; i<${#list_tab_cible[@]}; i++ ));
      do
        if [[ ${i} -eq ${#list_tab_cible[@]}-1 ]]; then
          REQ_TAB_CIBLE+="SELECT '${list_tab_cible[${i}]}' as nom_table) cib) cible"
        else
          REQ_TAB_CIBLE+="SELECT '${list_tab_cible[${i}]}' as nom_table UNION "
        fi
      done
    fi
    
  fi
  LOG_INFO "Request table cible : ${REQ_TAB_CIBLE}"

}

#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  START
  SETUP
    
    READ_BATCH_PARAM "${REP_CONF}${PARAM_BATCH}" "APPLI" "VAR_APPLI"
    READ_BATCH_PARAM "${REP_CONF}${PARAM_BATCH}" "PHASE" "VAR_PHASE"
    READ_BATCH_PARAM "${REP_CONF}${PARAM_BATCH}" "NB_DATEOPE_${NOM_TRAITEMENT}" "NB_DATEOPE"
    
    LOG_INFO "PROJET : $PROJET"
    LOG_INFO "APPLI : $VAR_APPLI"
    LOG_INFO "PHASE : $VAR_PHASE"
    LOG_INFO "TRAITEMENT : $NOM_TRAITEMENT"
    LOG_INFO "NB_DATEOPE : $NB_DATEOPE"
    
    # Selection de la derniere date_ope chargee et active pour un traitement donne
    # Resultat enregistre dans $MAX_DATE_OPE
    MAX_DATE_OPE_OK "${VAR_APPLI}" "${VAR_PHASE}" "${NOM_TRAITEMENT}" 'RESULT'
    MAX_DATE_OPE=$(echo "${RESULT}" | cut -f1 -d',')
    
    LOG_INFO "derniere date_ope chargee et active pour ${NOM_TRAITEMENT} : $MAX_DATE_OPE"
    LOG_INFO ""
    
    LOG_INFO "Lecture des parametres dans ${REP_CONF}${PARAM_BATCH}"
    
    # fill the list of target tables
    GET_LIST_TABLE "${NOM_TRAITEMENT}" "${REP_CONF}${DEPENDANCES}" "CIBLE" "TVAR_DEP_AVAL_DELTA" "TVAR_DEP_AVAL_FULL"
    
    # constructs the request for target tables
    get_request_table_cible ${TVAR_DEP_AVAL_DELTA[@]}
    
    # Determination des prochaines date_opes disponibles dans le catalogue Acquisition, dans la limite de la config de nb dates par traitement
    LOG_INFO "===================================================="
    LOG_INFO "Insertion dans $TOT des date_ope à charger"
    LOG_INFO "===================================================="
    LOG_INFO ""
    
    REQ="   insert into $TOT (     "
    REQ+="     id_job              "
    REQ+="     , type_suivi        "
    REQ+="     , niveau_suivi      "
    REQ+="     , projet            "
    REQ+="     , application       "
    REQ+="     , phase             "
    REQ+="     , nom_traitement    "
    REQ+="     , mode_alim         "
    REQ+="     , nb_date_ope       "
    REQ+="     , date_debut        "
    REQ+="     , date_fin          "
    REQ+="     , dependances_amont "
    REQ+="     , dependances_aval  "
    REQ+="     , status            "
    REQ+="     , date_ope          "
    REQ+="     , nom_table         "
    REQ+="     , type_table        "
    REQ+="     , borne_min         "
    REQ+="     , borne_max         "
    REQ+="     , nb_lignes         "
    REQ+="     , type_log          "
    REQ+="     , log)              "
    REQ+="   (select                         " 
    REQ+="     id_trt.id_job                 "
    REQ+="     , '${TYPE_SUIVI_SUIVI}'       "
    REQ+="     , '${NIVEAU_SUIVI_CATALOGUE}' "
    REQ+="     , '${PROJET}'                 "
    REQ+="     , '${VAR_APPLI}'              "
    REQ+="     , '${VAR_PHASE}'              "
    REQ+="     , '${NOM_TRAITEMENT}'         "
    REQ+="     , Null                        "
    REQ+="     , Null                        "
    REQ+="     , Null                        "
    REQ+="     , Null                        "
    REQ+="     , Null                        "
    REQ+="     , Null                        "
    REQ+="     , '${ST_ENCOURS}'             "
    REQ+="     , CA.date_ope                 "
    REQ+="     , cible.nom_table             "
    REQ+="     , Null                        "
    REQ+="     , Null                        "
    REQ+="     , Null                        "
    REQ+="     , Null                        "
    REQ+="     , Null                        "
    REQ+="     , Null                        "
    REQ+="   from                            "
    REQ+="     (select ST.id_job from $TOT ST where ST.status = '${ST_ENCOURS}' and ST.nom_traitement = '${NOM_TRAITEMENT}' and ST.niveau_suivi = '${NIVEAU_SUIVI_STATUT}' and ST.phase = '${PHASE_TRAITEMENT}') id_trt,"
    REQ+="     ${REQ_TAB_CIBLE},     "
    REQ+="     (select cat.date_ope as date_ope, row_number() over () as rownum "
    REQ+="      from                 "
    REQ+="        (select distinct cat_acq.date_ope as date_ope "
    REQ+="         from $TOT cat_acq      "
    REQ+="         where             "
    REQ+="           cat_acq.application = '${VAR_APPLI}' and "
    REQ+="           cat_acq.date_ope > '${MAX_DATE_OPE}' and "
    REQ+="           cat_acq.status != '${ST_ENCOURS}' and    "
    REQ+="           cat_acq.niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}' and "
    REQ+="           cat_acq.phase = '${PHASE_ACQUISITION}' "
    REQ+="         order by cat_acq.date_ope asc "
    REQ+="        ) cat "
    REQ+="     ) CA "
    REQ+="   where CA.rownum <= $NB_DATEOPE "
    REQ+=") "                      
    
	LOG_INFO "REQ : $REQ"
	
    PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"
    
  END  
  exit ${__SUCCESS}
  
}

if [[ "${WORKFLOW_ENV}" == "OOZIE" ]] ; then 
  main "$@"
else
  main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
fi
