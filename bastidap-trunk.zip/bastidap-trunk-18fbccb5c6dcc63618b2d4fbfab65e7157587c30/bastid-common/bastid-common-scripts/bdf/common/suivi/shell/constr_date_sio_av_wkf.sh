#!/usr/bin/env bash
###############################################################################
# Description :     
# Usage : 
# Parameters :      
# Author :          
# Updated :         
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec            #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d%H%M%S%N")                 #time stamp ex.20170804110741146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

#######################################
# Description: Fonction qui génère les dates de début et de fin de chargement. 
#              !!! A remplacer par une lecture directe des sqoops de la table TOT !!!
# Arguments: rep de conf 
# Returns: 0 for success, 1 for failure
#######################################
gen_dates_tmp() {

  # Vérification des paramètres en entrée  
  if [[ $# != 3 ]] ; then
    LOG_ERROR "Cette fonction attend 3 parametres : <REP_CONF> <ID_TRAITEMENT> <NOM_TRAITEMENT>"
    exit ${__FAILURE}
  else   
    local rep_conf="${1}"
    local id_traitement="${2}"
    local nom_traitement="${3}"
  fi

  echo $(PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -A -F ',' -t -c " \
                    select min(borne_min)
                    from ${TOT} \
                    where type_suivi = '${TYPE_SUIVI_SUIVI}' \
                      and niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}' \
                      and projet = '${PROJET}' \
                      and application = '${VAR_APPLI}' \
                      and phase = '${VAR_PHASE}' \
                      and nom_traitement = '${nom_traitement}' \
                      and id_job = '${id_traitement}' \
                      and status = '${ST_ENCOURS}'") > "${rep_conf}/dt_deb_charg.tmp"

  echo $(PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -A -F ',' -t -c " \
                    select max(borne_max)
                    from ${TOT} \
                    where type_suivi = '${TYPE_SUIVI_SUIVI}' \
                      and niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}' \
                      and projet = '${PROJET}' \
                      and application = '${VAR_APPLI}' \
                      and phase = '${VAR_PHASE}' \
                      and nom_traitement = '${nom_traitement}' \
                      and id_job = '${id_traitement}' \
                      and status = '${ST_ENCOURS}'") > "${rep_conf}/dt_dern_charg.tmp"                      
}




main() {

  # Vérification des paramètres en entrée  
  if [[ $# != 2 ]] ; then
    LOG_ERROR "Ce traitement attend deux parametres : <REP_CONF> <NOM_TRAITEMENT>"
    exit ${__FAILURE}
  else   
    rep_conf="${1}"
    nom_traitement="${2}"
  fi

  START
  
  SETUP
  
  # Si le fichier de paramètrage existe, alors lire les paramètres
  if [[ -f ${rep_conf}/${PARAM_BATCH} ]]; then
    LOG_INFO "Lecture des parametres dans ${rep_conf}/${PARAM_BATCH}"
    READ_BATCH_PARAM "${rep_conf}/${PARAM_BATCH}" "APPLI" "VAR_APPLI"
    READ_BATCH_PARAM "${rep_conf}/${PARAM_BATCH}" "PHASE" "VAR_PHASE"
    READ_BATCH_PARAM "${rep_conf}/${PARAM_BATCH}" "NB_DATEOPE_${nom_traitement}" "VAR_NB_DATEOPE"
  else 
    LOG_ERROR "Le fichier de paramètrage ${rep_conf}/${PARAM_BATCH} n'existe pas  => exit Failure"
    exit ${__FAILURE}
  fi
  
  LOG_INFO "PROJET : $PROJET"
  LOG_INFO "APPLI : $VAR_APPLI"
  LOG_INFO "PHASE : $VAR_PHASE"
  LOG_INFO "TRAITEMENT : $nom_traitement"
  LOG_INFO "NB_DATEOPE : $VAR_NB_DATEOPE"

  # Véfification des parametres lus
  if [[ -z ${VAR_NB_DATEOPE} || ${VAR_NB_DATEOPE} -eq '0' ]]; then
    LOG_ERROR "Le nombre de DATE_OPE à charger n'est pas renseigné dans ${PARAM_BATCH} => exit Failure"
    exit ${__FAILURE}
  fi
  
  GET_ID_TRT "$VAR_APPLI" "$VAR_PHASE" "$nom_traitement" "RESULT"
  local id_traitement="$RESULT"
  
  # Lecture des dépendances
  LOG_INFO ""
  LOG_INFO "Lecture des dépendances amont"
  LOG_INFO ""
  GET_LIST_TABLE "${nom_traitement}" "${rep_conf}/${DEPENDANCES}" "SOURCE" "TVAR_DEP_AMONT_DELTA" "TVAR_DEP_AMONT_FULL"
  
  LOG_INFO "Détermination de la max date_ope active parmi les chargements OK"
  MAX_DATE_OPE_OK "${VAR_APPLI}" "${VAR_PHASE}" "${nom_traitement}" 'RESULT'
  
  date_ope_max=$(echo ${RESULT} | cut -f1 -d',')
  
  insert_values=""
  # Boucle sur chaque table des dépendances amont DELTA
  if [[ ${TVAR_DEP_AMONT_DELTA} ]] ; then
    LOG_INFO ""
    LOG_INFO "===================================================================="
    LOG_INFO "Construction des DATE_OPE "
    LOG_INFO "===================================================================="
    LOG_INFO ""
    
    if [[ -z ${date_ope_max} ]]; then
      LOG_ERROR "Date_ope non disponible dans la table ${TOT} pour type_suivi = ${TYPE_SUIVI_SUIVI}; niveau_suivi = ${NIVEAU_SUIVI_CATALOGUE}; projet = ${PROJET}; application = ${VAR_APPLI}; nom_traitement = ${nom_traitement}; phase = ${VAR_PHASE}; status = ${ST_OK}; => exit Failure"
      exit ${__FAILURE}    
    else
      LOG_INFO "DATE_OPE max en statut ${ST_OK} : "${date_ope_max}""
    fi
    
    if [[ $VAR_APPLI == "EVOLMPM" ]] 
    then
      LOG_INFO "Lecture de la table de suivi SIO ${EVO_TAB_SUIVI_SIO} des DATE_OPE disponibles"
      dates_a_charger=$(echo $(sqoop eval --connect "${EVO_ORA_CXN}" \
                                        --username ${EVO_ORA_USER} \
                                        --password ${EVO_ORA_PAS} \
                                        --query "select T.DTJCO from ( select '1900-01-01' DTJCO from dual union select '2100-01-01' DTJCO from dual union select to_char(DTJCO,'YYYY-MM-DD') DTJCO from  ${EVO_TAB_SUIVI_SIO} where DTJCO > to_date('"${date_ope_max}"','YYYY-MM-DD') and ROWNUM <= ${VAR_NB_DATEOPE} order by DTJCO desc) T order by DTJCO asc") | sed 's/\(.*\)\(1900-01-01\)\(.*\)\(2100-01-01\).*/\3/' | sed 's/[|]//g')
           if [[ -z ${dates_a_charger} ]]; then
	         LOG_ERROR "Aucune DATE_OPE trouvée dans la table table de suivi SIO ${EVO_TAB_SUIVI_SIO} telle que DTJCO > $date_ope_max => exit Failure"
		 exit ${__FAILURE}
		 else
		       LOG_INFO ""
		       LOG_INFO "DATE_OPE à charger : ""${dates_a_charger}"
		       LOG_INFO ""
	         fi
          lst_dates_a_charger=($dates_a_charger)
          for idx_date_ope in "${lst_dates_a_charger[@]}"                                                                                                                                                  
	     do
                 LOG_INFO ""
	         LOG_INFO "Lecture de la table de suivi SIO ${EVO_TAB_SUIVI_SIO} des bornes min et max  pour la DATE_OPE = $idx_date_ope"                                                                 
	         bornes_min_max=$(echo $(sqoop eval --connect "${EVO_ORA_CXN}" \                                                                                                                          
	        --username ${EVO_ORA_USER} \
                --password ${EVO_ORA_PAS} \
                --query "select 'BORNES_START' || to_char(min(XTIMTS_DEB),'YYYY-MM-DD HH24:MI:SS.FF') || '#' || to_char(max(XTIMTS_FIN),'YYYY-MM-DD HH24:MI:SS.FF') ||'BORNES_END'
		   from  ${EVO_TAB_SUIVI_SIO} where DTJCO = to_date('"${idx_date_ope}"','YYYY-MM-DD')") | sed 's/\(.*\)\(BORNES_START\)\(.*#.*\)\(BORNES_END\).*/\3/')                     
         
	       LOG_INFO "Bornes : ""${bornes_min_max}"
	       borne_min=$(echo ${bornes_min_max} | cut -f1 -d'#')
               borne_max=$(echo ${bornes_min_max} | cut -f2 -d'#')
               if [[ -z ${borne_min} || -z ${borne_max} ]]; then
	           LOG_ERROR "Les bornes max et/ou min (min(XTIMTS_DEB),max(XTIMTS_FIN)) n'existent pas dans la table ${EVO_TAB_SUIVI_SIO} pour DTJCO = "${idx_date_ope}"  => exit Failure"               
	           exit ${__FAILURE}
	       else
	            LOG_INFO ""
	            LOG_INFO "Borne min : ""${borne_min}"                                                                                                                                                
		    LOG_INFO "Borne max : ""${borne_max}"
	       fi       
              for nom_table in ${TVAR_DEP_AMONT_DELTA[@]}
				do  		   
	            insert_values="${insert_values},('${id_traitement}', '${TYPE_SUIVI_SUIVI}', '${NIVEAU_SUIVI_CATALOGUE}', '${PROJET}', '${VAR_APPLI}', '${VAR_PHASE}', '${nom_traitement}', '${ST_ENCOURS}', '${idx_date_ope}', '${nom_table}', '${TYPE_TABLE_DELTA}', '${borne_min}', '${borne_max}', null)"
			   done
       done   
    elif [[ $VAR_APPLI == "ATENA" ]] ; then 

       LOG_INFO "Lecture de la table de suivi SIO ${ATE_TAB_SUIVI_SIO} des DATE_OPE disponibles"
       dates_a_charger=$(echo $(sqoop eval --connect "${ATE_ORA_CXN}" \
	                                    --username ${ATE_ORA_USER} \
	                                    --password ${ATE_ORA_PWD} \
	                                    --query "select * from (select BD from ( select BUSINESSDATE_,to_char(BUSINESSDATE_,'YYYY-MM-DD') || '#' ||LAG(to_char(UPDATEDATE_,'YYYY-MM-DDHH24:MI:SS.FF6'), 1,'1900-01-0100:00:00.000000')     OVER (ORDER BY BUSINESSDATE_) || '#' ||to_char(UPDATEDATE_,'YYYY-MM-DDHH24:MI:SS.FF6') as BD from  ${ATE_TAB_SUIVI_SIO}   ) where BUSINESSDATE_ > to_date('"${date_ope_max}"','YYYY-MM-DD') and ROWNUM <=     ${VAR_NB_DATEOPE}   union select '1900-01-01'   as BD  from dual union select '2100-01-01'   as BD  from dual ) T  order by BD asc") | sed 's/\(.*\)\(1900-01-01\)\(.*\)\(2100-01-01\).*/\3/' | sed 's/[|]//g')
      
    LOG_INFO "DATE_OPE à charger : ""${dates_a_charger}"  
    if [[ -z ${dates_a_charger} ]]; then
      LOG_ERROR "Aucune DATE_OPE trouvée dans la table table de suivi SIO ${ATE_TAB_SUIVI_SIO} telle que BUSINESSDATE_ > $date_ope_max => exit Failure"
      exit ${__FAILURE}
    else 
      LOG_INFO ""
      LOG_INFO "DATE_OPE à charger : ""${dates_a_charger}"
      LOG_INFO ""      
    fi

    lst_dates_a_charger=($dates_a_charger)

    for idx_date_ope in "${lst_dates_a_charger[@]}"
    do
      LOG_INFO ""
      LOG_INFO "Bornes : ""${idx_date_ope}"
      date_ope_ate=$(echo ${idx_date_ope} | cut -f1 -d'#')
      borne_min=$(echo ${idx_date_ope} | cut -f2 -d'#' | sed  's/\(.\{10\}\)/\1 /')
      borne_max=$(echo ${idx_date_ope} | cut -f3 -d'#' | sed  's/\(.\{10\}\)/\1 /')

      
      if [[ -z ${borne_min} || -z ${borne_max} ]]; then
        LOG_ERROR "Les bornes max et/ou min UPDATEDATE_  n'existent pas dans la table ${ATE_TAB_SUIVI_SIO} pour BUSINESSDATE_ = "${date_ope_ate}"  => exit Failure"
        exit ${__FAILURE}    
      else
        LOG_INFO ""
        LOG_INFO "Borne min : ""${borne_min}"
        LOG_INFO "Borne max : ""${borne_max}"
      fi
        for nom_table in ${TVAR_DEP_AMONT_DELTA[@]}
				do     
				insert_values="${insert_values},('${id_traitement}', '${TYPE_SUIVI_SUIVI}', '${NIVEAU_SUIVI_CATALOGUE}', '${PROJET}', '${VAR_APPLI}', '${VAR_PHASE}', '${nom_traitement}', '${ST_ENCOURS}', '${date_ope_ate}', '${nom_table}', '${TYPE_TABLE_DELTA}', '${borne_min}', '${borne_max}', null)"
				done
	 done
    
        elif [[ $VAR_APPLI == "MAEVA" ]]; then
           LOG_INFO "Lecture de la table de suivi SIO ${MAE_TAB_SUIVI_SIO} des DATE_OPE disponibles"
	   dates_a_charger=$(echo $(sqoop eval --connect "${MAE_ORA_CXN}"  --username ${MAE_ORA_USER} --password ${MAE_ORA_PWD} --query "select DATE_RECEPT from (select to_char(DATE_RECEPT,'YYYY-MM-DD') || '#' ||to_char(DATE_RECEPT,'YYYY-MM-DD')|| '#'||to_char(DATE_RECEPT+1,'YYYY-MM-DD')  as DATE_RECEPT from  ${MAE_TAB_SUIVI_SIO}    where DATE_RECEPT > to_date('"${date_ope_max}"','YYYY-MM-DD')   group by DATE_RECEPT ) where rownum <= ${VAR_NB_DATEOPE} union select '1900-01-01'   as DATE_RECEPT  from dual union select '2100-01-01'   as DATE_RECEPT  from dual order by DATE_RECEPT asc") | sed 's/\(.*\)\(1900-01-01\)\(.*\)\(2100-01-01\).*/\3/' | sed 's/[|]//g')
	   LOG_INFO "DATE_OPE à charger : ""${dates_a_charger}"
           if [[ -z ${dates_a_charger} ]]; then
	      LOG_ERROR "Aucune DATE_OPE trouvée dans la table table de suivi SIO ${MAE_TAB_SUIVI_SIO} telle que DATE_RECEPT > $date_ope_max => exit Failure"
              exit ${__FAILURE}
           else
	      LOG_INFO ""
              LOG_INFO "DATE_OPE à charger : ""${dates_a_charger}"
              LOG_INFO ""
           fi
          lst_dates_a_charger=($dates_a_charger)

          for idx_date_ope in "${lst_dates_a_charger[@]}"
            do
	        LOG_INFO ""
       	        LOG_INFO "Bornes : ""${idx_date_ope}"
                date_ope_mae=$(echo ${idx_date_ope} | cut -f1 -d'#')
                borne_min=$(echo ${idx_date_ope} | cut -f2 -d'#' | sed  's/\(.\{10\}\)/\1 /')
	        borne_max=$(echo ${idx_date_ope} | cut -f3 -d'#' | sed  's/\(.\{10\}\)/\1 /')


               if [[ -z ${borne_min} || -z ${borne_max} ]]; then
	              LOG_ERROR "Les bornes max et/ou min DATE_RECEPT  n'existent pas dans la table ${MAE_TAB_SUIVI_SIO} pour DATE_RECEPT = "${date_ope_mae}"  => exit Failure"
	              exit ${__FAILURE}
               else
	            LOG_INFO ""
	            LOG_INFO "Borne min : ""${borne_min}"
	            LOG_INFO "Borne max : ""${borne_max}"
	       fi
	       for nom_table in ${TVAR_DEP_AMONT_DELTA[@]}
	          do
		     insert_values="${insert_values},('${id_traitement}', '${TYPE_SUIVI_SUIVI}', '${NIVEAU_SUIVI_CATALOGUE}', '${PROJET}', '${VAR_APPLI}', '${VAR_PHASE}', '${nom_traitement}','${ST_ENCOURS}', '${date_ope_mae}', '${nom_table}', '${TYPE_TABLE_DELTA}', '${borne_min}', '${borne_max}', null)"
		  done
	    done
  fi
  fi 
  LOG_INFO ""
  LOG_INFO "===================================================================="
  LOG_INFO "Construction du catalogue d'id_traitement pour les tables FULL"
  LOG_INFO "===================================================================="
  LOG_INFO ""
    
  for nom_table in ${TVAR_DEP_AMONT_FULL[@]}
  do
    LOG_INFO "Une ligne pour ${nom_table} avec l'id_traitement ${id_traitement}"
    insert_values="${insert_values},('${id_traitement}', '${TYPE_SUIVI_SUIVI}', '${NIVEAU_SUIVI_CATALOGUE}', '${PROJET}', '${VAR_APPLI}', '${VAR_PHASE}', '${nom_traitement}', '${ST_ENCOURS}', Null, '${nom_table}', '${TYPE_TABLE_FULL}', Null, Null, Null)"
  done  
  
  LOG_INFO ""
  LOG_INFO "===================================================================="
  LOG_INFO "Insertion des DATE_OPE dans ${TOT}"
  LOG_INFO "===================================================================="
  LOG_INFO ""
  
  # insertion dans le catalogue de toutes les lignes
  requete="insert into ${TOT} (id_job, type_suivi, niveau_suivi, projet, application, phase, nom_traitement, status, date_ope, nom_table, type_table, borne_min, borne_max, nb_lignes) values ${insert_values:1:$((${#insert_values}-1))}"
  PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -e -c "${requete}" 
  LOG_INFO "Query : ""${requete}"
  
  #génération des fichiers dt_deb_charg.tmp et dt_dern_charg.tmp dans ${rep_conf}
  #TODO : à enlever et remplacer par une lecture directe des sqoops dans la table TOT
  gen_dates_tmp "${rep_conf}" "${id_traitement}" "${nom_traitement}"
    
  END
  exit ${__SUCCESS}

}


main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1

