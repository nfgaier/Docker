#!/usr/bin/env bash
###############################################################################
# Description :     Construit les date_ope dans le catalogue
#                   Constructeur sp�cifique � un SIO sans Workflow (pas de date op�rationnelle avec bornes techniques)
# Usage :           
# Parameters :      
#      $1 R�pertoire de conf
#      $2 Nom du traitement
# Author :          LCO
# Updated :         17/11/2017
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec            #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d%H%M%S%N")                 #time stamp ex.20170804110741146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  


if [[ $# != 2 ]] ; then
    LOG_ERROR "Ce traitement attend deux parametres : <REP_CONF> <NOM_TRAITEMENT>"
    exit $__FAILURE
fi

REP_CONF=$1
NOM_TRAITEMENT=$2

VAR_APPLI=''
VAR_PHASE=''
CAT_VALUES=''
CURRDATE=$(date "+%Y-%m-%d %H:%M:%S")


#######################################
# Description: 
# Arguments: <Variable contenant le r�sultat d'une requ�te> <nom du tableau>
# Returns: 
#######################################
TO_ARRAY () {

    local res="$1"
    local __resultvar=$2
    local array=()
    
    # l'IFS par d�faut est (espace ou tab ou retour_chariot)
    # on le change pour la fonction pour ne pas tenir compte des espaces ou tab dans les r�sultats de requ�te
    local IFS=$'\n'

    for LINE in $res
    do
        array+=("${LINE}")
    done
    
    # Afin de ne pas faire planter l'eval si tableau vide
    if [[ ${#array[@]} == 0 ]]; then array+='';fi
    
    # On annule compl�tement l'IFS afin de que le tableau soit recopier tel quel
    local IFS=''
    eval $__resultvar='("${array[@]}")'

}

#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  START
  SETUP
    
    LOG_INFO "Lecture des parametres dans ${REP_CONF}${PARAM_BATCH}"
    READ_BATCH_PARAM "${REP_CONF}/${PARAM_BATCH}" "APPLI" "VAR_APPLI"
    READ_BATCH_PARAM "${REP_CONF}/${PARAM_BATCH}" "PHASE" "VAR_PHASE"
    READ_BATCH_PARAM "${REP_CONF}/${PARAM_BATCH}" "NB_DATEOPE_${NOM_TRAITEMENT}" "VAR_NB_DATEOPE"
    READ_BATCH_PARAM "${REP_CONF}/${PARAM_BATCH}" "SEUIL_GEN_DATE_OPE" "VAR_SEUIL_GEN_DATE_OPE"
    
    LOG_INFO "PROJET : $PROJET"
    LOG_INFO "APPLI : $VAR_APPLI"
    LOG_INFO "PHASE : $VAR_PHASE"
    LOG_INFO "TRAITEMENT : $NOM_TRAITEMENT"
    LOG_INFO "NB_DATEOPE : $VAR_NB_DATEOPE"
    LOG_INFO "VAR_SEUIL_GEN_DATE_OPE : $VAR_SEUIL_GEN_DATE_OPE"
    
    # Check le nombre de param�tres
    if [[ -z $VAR_NB_DATEOPE || $VAR_NB_DATEOPE -eq '0' ]]
    then
        LOG_INFO "Le nombre de DATE_OPE � charger n'est pas renseign� dans ${PARAM_BATCH} => exit Failure"
        exit $__FAILURE
    fi
    
    # R�cup�re l'ID_TRAITEMENT en cours
    GET_ID_TRT "$VAR_APPLI" "$VAR_PHASE" "$NOM_TRAITEMENT" "ID_TRAITEMENT"
    
    # Lecture des d�pendances amont
    LOG_INFO ""
    LOG_INFO "Lecture des d�pendances amont"
    LOG_INFO ""
    GET_LIST_TABLE "${NOM_TRAITEMENT}" "${REP_CONF}/${DEPENDANCES}" "SOURCE" "TVAR_DEP_AMONT_DELTA" "TVAR_DEP_AMONT_FULL"

    # Lecture de la date technique Max dans le SIO
    LOG_INFO ""
    LOG_INFO "Lecture de la date technique Max dans le SIO"
    
    case $VAR_APPLI in
        "${EMB_APPLI_NAME}")
                MaxSIO=$(echo $(sqoop eval --connect "${EMB_ORA_CXN}" --username ${EMB_ORA_USER} --password ${EMB_ORA_PAS} --query "select 'DATE_START' || to_char(to_date(max(t_completed), 'yyyy/mm/dd hh24:mi:ss'), 'yyyy-mm-dd_hh24:mi:ss') || 'DATE_END' from fofa_hist_message")  \
                | sed 's/\(.*\)\(DATE_START\)\(.*\)\(DATE_END\).*/\3/') ;;
    esac
    
    LOG_INFO ""
    LOG_INFO "MaxSIO : $MaxSIO"
    LOG_INFO ""
    
    LOG_INFO "D�termination de la max date_ope active parmi les chargements OK"
    MAX_DATE_OPE_OK "${VAR_APPLI}" "${VAR_PHASE}" "${NOM_TRAITEMENT}" 'RESULT'
    
    DateOpOK=$(echo ${RESULT} | cut -f1 -d',')
    BorneMaxOK=$(echo ${RESULT} | cut -f3 -d',')
    
    LOG_INFO "DATE_OPE max : ${DateOpOK}"
    LOG_INFO "Borne Max associ�e : ${BorneMaxOK}"
    
    # Boucle sur chaque table des d�pendances amont DELTA
    for TABLE in ${TVAR_DEP_AMONT_DELTA[@]}
    do
        
        LOG_INFO ""
        LOG_INFO "===================================================================="
        LOG_INFO "Construction des date_ope � acqu�rir pour la table DELTA $TABLE"
        LOG_INFO "===================================================================="
        LOG_INFO ""
        
        # Lecture du REF_TEMPS
        LOG_INFO ""
        LOG_INFO "Liste des DATE_OPE suivantes dans le r�f�rentiel"
        
        REQ=" select date"
        REQ+=" from ref_temps"
        REQ+=" where"
        REQ+="     date > '${DateOpOK}'"
        REQ+="     and week_end = 'Non'"
        REQ+="     and jour_ferie = 'Non'"
        REQ+=" order by date"
        REQ+=" limit (( ${VAR_NB_DATEOPE}+1 ))"
        DateOpCatNext=$(PGPASSWORD="${BASTID_PG_PWD}" psql -h "${BASTID_PG_ServerAddress}" -p "${BASTID_PG_Port}" "${BASTID_PG_Name}" "${BASTID_PG_UserName}" -A -t -c "${REQ}")
        TO_ARRAY "$DateOpCatNext" "ListDateOpCatNext"
        
        LOG_INFO "Liste des dates :"
        for ((i=0 ; i < ${#ListDateOpCatNext[@]}; i++))
        do
            LOG_INFO "${ListDateOpCatNext[i]}"
        done
        
        
        # Recherche des DATE_OPE d�j� construites dans le CATALOGUE
        LOG_INFO ""
        LOG_INFO "Extraction des N dates suivantes du catalogue (en statut non ${ST_OK} par cons�quent) pour $TABLE"
        
        REQ=" select distinct"
        REQ+="     date_ope,"
        REQ+="     borne_min,"
        REQ+="     borne_max"
        REQ+=" from ${TOT}"
        REQ+=" where "
        REQ+="     type_suivi = '${TYPE_SUIVI_SUIVI}'"
        REQ+="     and niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}'"
        REQ+="     and projet = '${PROJET}'"
        REQ+="     and application = '${VAR_APPLI}'"
        REQ+="     and phase = '${VAR_PHASE}'"
        REQ+="     and nom_table = '${TABLE}'"
        # on r�cup�re les infos des date_ope ult�rieures, au cas o� elles existent
        # limite le calcul, pour les perfs
        REQ+="     and date_ope > '${DateOpOK}'"
        REQ+=" order by date_ope"
        REQ+=" limit ${VAR_NB_DATEOPE}"
        DateOpRecharge=$(PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -A -t -F ',' -c "${REQ}")
        TO_ARRAY "$DateOpRecharge" "ListDateOpRecharge"
        # On r�initialise le tableau s'il contient une cha�ne vide, afin qu'un count soit �gal � 0
        if [[ ${ListDateOpRecharge[@]} == '' ]]; then ListDateOpRecharge=();fi
        
        LOG_INFO "Liste des dates et bornes MIN et MAX associ�es:"
        for ((i=0 ; i < ${#ListDateOpRecharge[@]}; i++))
        do
            LOG_INFO "${ListDateOpRecharge[i]}"
        done
        
        
        LOG_INFO ""
        LOG_INFO "---------------------------------------------------------------"
        LOG_INFO "D�but de la construction des $VAR_NB_DATEOPE prochaines DATE_OPE � charger"
        
        # R�init pour chaque table
        ALIM_OK=''
        j=1
        # Pour chaque table, on repart de la derni�re borne Max en statut OK
        BORNE_MAX="$BorneMaxOK"
        
        # On boucle tant qu'on n'a pas construit les X dates pr�vues
        # Pour chaque it�ration, on va red�finir DATE_OPE/BORNE_MIN/BORNE_MAX en fonction de diff�rents cas
        # Note : Tant que BORNE_MAX n'est pas red�fini, il garde la valeur de la DATE_OPE pr�c�dente, qui d�finira la BORNE_MIN suivante
        
        while (( j <= $VAR_NB_DATEOPE )) && [[ $ALIM_OK != 'OK' ]]
        do
            
            LOG_INFO ""
            LOG_INFO "Construction de la DATE_OPE J+$j"
                        
            # CAS une date sup�rieure existe dans le catalogue, en statut diff�rent de OK
            # => on la recharge
            if (( j <= ${#ListDateOpRecharge[@]} ))
            then
                LOG_INFO "Une date � recharger existe dans le catalogue"
                
                DATE_OPE=$(echo ${ListDateOpRecharge[j-1]} | cut -f1 -d',')
                BORNE_MIN=$(echo ${ListDateOpRecharge[j-1]} | cut -f2 -d',')
                BORNE_MAX=$(echo ${ListDateOpRecharge[j-1]} | cut -f3 -d',')
                
                LOG_INFO "DATE_OPE : $DATE_OPE"
                LOG_INFO "BORNE_MIN : $BORNE_MIN"
                LOG_INFO "BORNE_MAX : $BORNE_MAX"
                
                CAT_VALUES="${CAT_VALUES},('${ID_TRAITEMENT}', '${TYPE_SUIVI_SUIVI}', '${NIVEAU_SUIVI_CATALOGUE}', '${PROJET}', '${VAR_APPLI}', '${VAR_PHASE}', '${NOM_TRAITEMENT}', '${ST_ENCOURS}', '${DATE_OPE}', '${TABLE}', '${TYPE_TABLE_DELTA}', '${BORNE_MIN}', '${BORNE_MAX}', Null)"
            
            else
                LOG_INFO "Pas de date � recharger dans le catalogue, on pioche la suivante dans REF_TEMPS"
                
                DATE_OPE=${ListDateOpCatNext[j-1]}
                LOG_INFO "DATE_OPE : $DATE_OPE"
                
                # ATTENTION : on compare la date courante au seuil, en format texte ! Ne fonctionne que si l'on garde ce formatage
                if [[ "${MaxSIO}" > "${DATE_OPE}_${VAR_SEUIL_GEN_DATE_OPE}" ]]
                then
                    
                    # CAS pas de date sup�rieure dans le catalogue, et rattrapage toujours en cours,
                    # ou CAS Quotidien (une acquisition d'une date_ope par jour, d�clench� � partir d'une certaine heure au del� du seuil pr�vu)
                    # => On construit une nouvelle DATE_OPE en piochant la prochaine dans REF_TEMPS
                    
                    BORNE_MIN="$BORNE_MAX"
                    LOG_INFO "BORNE_MIN : $BORNE_MIN"
                    
                    # ATTENTION : on compare la date courante au seuil, en format texte ! Ne fonctionne que si l'on garde ce formatage
                    if [[ "${MaxSIO}" > "${ListDateOpCatNext[j]}_00:00:00" ]]
                    then
                        LOG_INFO "Le SIO contient une tranche compl�te de donn�es de J 00h00 � J+1 00h00"
                        BORNE_MAX="${ListDateOpCatNext[j]} 00:00:00"
                    else
                        LOG_INFO "Mode quotidien : on r�cup�re la derni�re journ�e fonctionnelle disponible dans le SIO"
                        BORNE_MAX="${CURRDATE}"
                    fi
                    LOG_INFO "BORNE_MAX : $BORNE_MAX"
                    
                    CAT_VALUES="${CAT_VALUES},('${ID_TRAITEMENT}', '${TYPE_SUIVI_SUIVI}', '${NIVEAU_SUIVI_CATALOGUE}', '${PROJET}', '${VAR_APPLI}', '${VAR_PHASE}', '${NOM_TRAITEMENT}', '${ST_ENCOURS}', '${DATE_OPE}', '${TABLE}', '${TYPE_TABLE_DELTA}', '${BORNE_MIN}', '${BORNE_MAX}', Null)"

                else
                    #CAS Toutes les donn�es du SIO sont acquises, et il est trop t�t pour repartir sur une nouvelle DATE_OPE
                    LOG_WARN "La fra�cheur du SIO (${MaxSIO}) est inf�rieure au seuil de g�n�ration d'une nouvelle DATE_OPE (Seuil = ${DATE_OPE} ${VAR_SEUIL_GEN_DATE_OPE})"
                    ALIM_OK='OK'
                fi
                
            fi
        # DATE_OPE construite, on passe � la suivante
        let j=j+1
        
        done
        
    done
    
    LOG_INFO ""
    LOG_INFO "===================================================================="
    LOG_INFO "Construction du catalogue d'id_traitement pour les tables FULL"
    LOG_INFO "===================================================================="
    LOG_INFO ""
    
    for TABLE in ${TVAR_DEP_AMONT_FULL[@]}
    do
        LOG_INFO "Une ligne pour ${TABLE} avec l'ID_TRAITEMENT ${ID_TRAITEMENT}"
        CAT_VALUES="${CAT_VALUES},('${ID_TRAITEMENT}', '${TYPE_SUIVI_SUIVI}', '${NIVEAU_SUIVI_CATALOGUE}', '${PROJET}', '${VAR_APPLI}', '${VAR_PHASE}', '${NOM_TRAITEMENT}', '${ST_ENCOURS}', Null, '${TABLE}', '${TYPE_TABLE_FULL}', Null, Null, Null)"
        
    done
    
    LOG_INFO ""
    LOG_INFO "===================================================================="
    LOG_INFO "Insertion des DATE_OPE dans ${TOT}"
    LOG_INFO "===================================================================="
    LOG_INFO ""
    
    # insertion dans le catalogue de toutes les lignes
    REQ="insert into ${TOT} (id_job, type_suivi, niveau_suivi, projet, application, phase, nom_traitement, status, date_ope, nom_table, type_table, borne_min, borne_max, nb_lignes) values ${CAT_VALUES:1:$((${#CAT_VALUES}-1))}"
    PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -e -c "$REQ" 
    
  END  
  exit ${__SUCCESS}
  
}

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
