#!/usr/bin/env bash
###############################################################################
# Description :  Read LOG records from TOT table and insert them in ES   
# Usage : The script can be launched via oozie or on the local machine shell
# Parameters :      
# Author :          
# Updated :         
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d%H%M%S%N")                 #time stamp ex.20170804110741146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  


if [[ -z ${WORKFLOW_ENV+x} ]]; then 
  WORKFLOW_ENV="OOZIE"; export WORKFLOW_ENV
fi

case "${WORKFLOW_ENV}" in 
  OOZIE) 
    if [[ $# != 3 ]] ; then
      echo "Ce traitement attend trois parametres : <ROOT> <NOM_TRAITEMENT> <APPLI_TRAITEMENT>"
      exit ${__FAILURE}
    fi
  
    ROOT="${1}"
    NOM_TRAITEMENT="${2}"
    APPLI_TRAITEMENT="${3}"
    REP_CONF=""
    LOGDIR="${ROOT}/log/${APPLI_TRAITEMENT}"; export LOGDIR    #log folder exported for use in .fonction_*_spec
  
    #load and apply specific oozie function
    hadoop fs -get "${ROOT}/script/common/.fonction_bastid_oozie"
    . .fonction_bastid_oozie 
    init_oozie_env "${ROOT}" "${APPLI_TRAITEMENT}" "${LOGDIR}"
  ;;
  *)
    if [[ $# != 2 ]] ; then
      echo "Ce traitement attend deux parametres : <REP_CONF> <NOM_TRAITEMENT>"
      exit ${__FAILURE}
    fi
  
    . $APPLI_HOME/appli/connexion/.fonction_bastid_spec        #source .fonction_*_spec 
  
    [[ "${1: -1}" == "/" ]] && REP_CONF="${1}" || REP_CONF="${1}/"
    NOM_TRAITEMENT="${2}"
    LOGDIR="${LST}"; export LOGDIR                             #log folder exported for use in .fonction_*_spec 
  ;;
esac

main () {

  START
  SETUP
  
  LOG_INFO "PROJET : ${PROJET}"
  LOG_INFO "TRAITEMENT : ${NOM_TRAITEMENT}"
  
  local type_suivi="LOG"
  local id_traitement="20171219161237701135"
  local es_service_url="http://10.88.0.246:8080/datalake/api/event/bastid"
  local header1="accept: application/json"
  local header2="Content-Type: application/json"
  
  LOG_INFO ""
  LOG_INFO "===================================================="
  LOG_INFO "Lecture des lignes de type ${type_suivi} pour id_traitement $id_traitement de la table $TOT"
  LOG_INFO "===================================================="
  LOG_INFO ""
 
  
  # example de message 
  #{
  #  "context": {
  #    "jobid": "20171219161237701135",
  #    "application": "EMBARGO",
  #    "phase": "ACQUISITION",
  #    "tablein": "FMF_RIGHTS",
  #    "tabletype": "COMPLET",
  #    "logtype": "COUNT SIO"
  #  },
  #  "name": "acq_sqoop_fmf_rights.sh",
  #  "message": "Nombre de ligne côté SIO pour cette acquisition",
  #  "status": null,
  #  "freeZone": ""
  #}
 
  local messages_log=$(PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -A -t -c " \
                    select replace(replace(row_to_json(tab)||'','freezone','freeZone'), '\"', E'\\\"') \
                    from (select( select row_to_json(tmp)  \
                                  from (select id_job as jobId,  \
                                               application, \
                                               phase, \
                                               nom_table as tableIn, \
                                               type_table as tableType,  \
                                               type_log as logType \
                                         from tot_bastid td where tb.id = td.id ) tmp ) as context, \
                                nom_traitement as name, \
                                log as message, \
                                status, \
                                '' as freeZone \
                          from tot_bastid tb \
                          where tb.type_suivi in ('${type_suivi}') \
                            and tb.id_job in ('${id_traitement}') \
                    ) tab ")
                    
  #LOG_INFO "Res : ""${messages_log}"
  
  #TODO : ES bulk insert
  
  while read -r log_line; do
    LOG_INFO  "Inserting : ${log_line}"
    ret_val=$(curl -XPOST "${es_service_url}" -H  "${header1}" -H  "${header2}" -d "${log_line}")
    LOG_INFO  "ret_val : ${ret_val}"
  done <<< "$messages_log"
  
  
  END  
  exit ${__SUCCESS}
  
}

if [[ "${WORKFLOW_ENV}" == "OOZIE" ]] ; then 
  main "$@"
else
  main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
fi

