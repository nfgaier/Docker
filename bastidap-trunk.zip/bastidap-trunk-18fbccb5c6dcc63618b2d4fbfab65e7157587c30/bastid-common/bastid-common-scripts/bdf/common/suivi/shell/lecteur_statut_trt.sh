#!/usr/bin/env bash
###############################################################################
# Description : 
# Usage : 
# Author : 
# Updated : 
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 


if [[ -z ${WORKFLOW_ENV+x} ]]; then 
  WORKFLOW_ENV="OOZIE"; export WORKFLOW_ENV
fi

case "${WORKFLOW_ENV}" in 
  OOZIE) 
    if [[ $# != 3 ]] ; then
		echo "Ce traitement attend trois parametres : <ROOT> <NOM_TRAITEMENT> <APPLI_TRAITEMENT>"
		exit ${__FAILURE}
	fi
	
	ROOT="$1"
	NOM_TRAITEMENT="$2"
	APPLI_TRAITEMENT="$3"
	REP_CONF=""
	LOGDIR="${ROOT}/log/${APPLI_TRAITEMENT}"; export LOGDIR         #log folder exported for use in .fonction_*_spec
	readonly __HDFS_CONF_FOLDER="${ROOT}/${APPLI_TRAITEMENT}/traitement/conf"  #folder for tmp conf files
	
	#load and apply specific oozie function
	hadoop fs -get "${ROOT}/common/.fonction_bastid_oozie"
	. .fonction_bastid_oozie 
    init_oozie_env "${ROOT}" "${APPLI_TRAITEMENT}" "${LOGDIR}"
	;;
  *)
    if [[ $# != 2 ]] ; then
		echo "Ce traitement attend deux parametres : <REP_CONF> <NOM_TRAITEMENT>"
		exit ${__FAILURE}
	fi
	
	. $APPLI_HOME/appli/connexion/.fonction_bastid_spec        #source .fonction_*_spec 

	[[ "${1: -1}" == "/" ]] && REP_CONF="${1}" || REP_CONF="${1}/"
	NOM_TRAITEMENT="$2"
	
	LOGDIR="${LST}"; export LOGDIR                             #log folder exported for use in .fonction_*_spec 
	;;
esac

readonly __PARAMFILE="${REP_CONF}${DEPENDANCES}"               #permanent configuration file containing the dependances 
readonly __SEPARATOR=","                                       #separator in config file     

RESULT_FILE=id_${NOM_TRAITEMENT}.tmp
SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

# remove tmp file containing id_acq and date_ope to load
#   /\   
#  /  \  set -o nounset option is a security to prevent from removing / if $RESULT_FILE is not set
# /_!!_\ 
if [[ -f ${REP_CONF}${RESULT_FILE} ]];then rm ${REP_CONF}${RESULT_FILE}; fi

if [[ "${WORKFLOW_ENV}" == "OOZIE" ]] ; then 
  hadoop fs -test -e ${__HDFS_CONF_FOLDER}/${RESULT_FILE} && hadoop fs -rm ${__HDFS_CONF_FOLDER}/${RESULT_FILE}
fi

#######################################
# Description: Checks the structure of a configuration file
# Arguments: A configuration file
# Returns: 
#######################################
validate_param_file () {

  LOG_START_FUNC "${FUNCNAME[0]}"
  
  #arguments check
  if [[ "$#" -ne 1 ]]; then
    LOG_ERROR "${FUNCNAME[0]} : Usage : validate_param_file <param file path and file name>"
    exit ${__FAILURE} 
  fi  

  #file name passed as parameter
  local paramfile="${1}"
  
  #check if the file exists
  if [[ -f ${paramfile} ]]; then
  
    #read the file passed as parameter
    while IFS= read -r line 
    do
      #get the carac table (SOURCE or CIBLE) from the first column
      carac_table=$(echo ${line} | cut -d${__SEPARATOR} -f1)
      #get the table type from the 4th column
      table_type=$(echo ${line} | cut -d${__SEPARATOR} -f4)
	  
	  #LOG_INFO "carac_table : ${carac_table}"
	  #LOG_INFO "table_type : ${table_type}"
	  
	  #check if the table type is correct (it can be only delta, full or param)
	  if [[ "${carac_table}" == "SOURCE" ]] && [[ "${table_type}" != "delta" ]] && [[ "${table_type}" != "full" ]] && [[ "${table_type}" != "param" ]]; then
        LOG_ERROR "${FUNCNAME[0]} : Error in configuration file : table type is not correct"
        exit ${__FAILURE}
	  fi
	done < ${paramfile}
	
	LOG_INFO "${FUNCNAME[0]} : Configuration file ${paramfile} validated"
  
  else
    #the configuration file does not exist
    LOG_ERROR "${FUNCNAME[0]} : No configuration file (${paramfile} found"
    exit ${__FAILURE}
  fi
  
}

#######################################
# Description: check if the acquisition is OK for the tables needed by the treatment
# Arguments: 
# Returns: 
#######################################
main () {

  START
  
  SETUP
  
  #check if the param file ${DEPENDANCES} is correct
  validate_param_file ${__PARAMFILE}
  
  #fill the list of tables needed by the treatment (delta and full tables)
  GET_LIST_TABLE "${NOM_TRAITEMENT}" ${__PARAMFILE} "SOURCE" 'LIST_TABLE_SOURCE_DELTA' 'LIST_TABLE_SOURCE_FULL'
  
  STATUT_GENERAL="OK"
  
  LOG_INFO "Lecture des parametres dans ${REP_CONF}${PARAM_BATCH}"
  
  VAR_APPLI=''
  VAR_PHASE=''
  
  READ_BATCH_PARAM "${REP_CONF}${PARAM_BATCH}" "APPLI" "VAR_APPLI"
  READ_BATCH_PARAM "${REP_CONF}${PARAM_BATCH}" "PHASE" "VAR_PHASE"
  
  LOG_INFO "PROJET :                          ${PROJET}"
  LOG_INFO "APPLI :                           ${VAR_APPLI}"
  LOG_INFO "PHASE :                           ${VAR_PHASE}"
  LOG_INFO "TRAITEMENT :                      ${NOM_TRAITEMENT}"
  LOG_INFO ""
  
  # Liste des DATE_OPE à charger pour le traitement en cours
  REQ="  select distinct date_ope from ${TOT}"
  REQ+=" where"
  REQ+="    type_suivi = '${TYPE_SUIVI_SUIVI}'"
  REQ+="    and niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}'"
  REQ+="    and projet = '${PROJET}'"
  REQ+="    and application = '${VAR_APPLI}'"
  REQ+="    and phase = '${VAR_PHASE}'"
  REQ+="    and nom_traitement = '${NOM_TRAITEMENT}'"
  REQ+="    and status = '${ST_ENCOURS}'"
  
  LOG_INFO "REQ : $REQ"
  
  LIST_JOURS=$(PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -A -R ' ' -t -c "$REQ")
  LOG_INFO "Liste jours : ${LIST_JOURS}"
  LOG_INFO ""
  
  for table in ${LIST_TABLE_SOURCE_DELTA[*]}
  do
    if [[ ${STATUT_GENERAL} == "OK" ]]; then
      LOG_INFO "Delta table : ${table}"
      LOG_INFO ""
      for jour in ${LIST_JOURS}
	  do
	    if [[ ${STATUT_GENERAL} == "OK" ]]; then

	      LOG_INFO "Jour : ${jour}"

          # Vérification du statut de l'acquisition/du traitement pour une table et une DATE_OPE, sur son dernier id_traitement
          REQ="  select"
          REQ+="     concat_ws('${__SEPARATOR}', SA.id_job, SA.status)"
          REQ+=" from"
          # Pour une table et une DATE_OPE, on récupère l'id de l'id_traitement le plus récent, pour ensuite récupérer les infos de cette ligne (dont le statut à vérifier)
          REQ+="     (SELECT distinct"
          REQ+="         first_value(id) over(order by id_job desc) as max_id_acq"
          REQ+="     FROM ${TOT}"
          REQ+="     where"
          REQ+="        type_suivi = '${TYPE_SUIVI_SUIVI}'"
          REQ+="        and niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}'"
          REQ+="        and projet = '${PROJET}'"
          REQ+="        and application = '${VAR_APPLI}'"
          REQ+="        and phase = 'TRAITEMENT'"
          # REQ+="        and nom_traitement = '${NOM_TRAITEMENT}'"
          REQ+="        and UPPER(nom_table) = UPPER('${table}')"
          REQ+="        and date_ope = '${jour}'"
          REQ+="     ) MA,"
          REQ+="     ${TOT} SA"
          REQ+=" where MA.max_id_acq = SA.id"
          
		  LOG_INFO "REQ : $REQ"
		  
          resultReq=$(PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -F "${__SEPARATOR}" -t -c "$REQ")
	      LOG_INFO "Dernier ID Traitement pour ${table} et la date ${jour} : ${resultReq}"	

          #cut statut from the result of the request
	      statut=$(echo ${resultReq} | cut -d${__SEPARATOR} -f2)
	      LOG_INFO "Statut : ${statut}"
	      if [[ ${statut} == "${ST_OK}" ]]; then
		    #cut id acquisition from the result of the request
	        id_acq=$(echo ${resultReq} | cut -d${__SEPARATOR} -f1)
		    LOG_INFO "Id Acq : ${id_acq}"
		    LOG_INFO "Line in the file : ${table},${id_acq},${jour}"
            LOG_INFO ""
			
			if [[ "${WORKFLOW_ENV}" == "OOZIE" ]] ; then 
			  echo "${table},${id_acq},${jour}" | hadoop fs -appendToFile - "${__HDFS_CONF_FOLDER}/${RESULT_FILE}"
			else
			  echo "${table},${id_acq},${jour}" >> ${REP_CONF}${RESULT_FILE}
			fi
			
	      else
	        STATUT_GENERAL="KO"
	      fi
	    fi
	  done
	fi
  done
  
  LOG_INFO ""
  if [[ ${STATUT_GENERAL} == "OK" ]]; then
    for table in ${LIST_TABLE_SOURCE_FULL[*]}
    do
      if [[ ${STATUT_GENERAL} == "OK" ]]; then

        LOG_INFO "Full table : ${table}"
        LOG_INFO ""

        # Vérification du statut de l'acquisition pour une table, sur son dernier id_traitement
        REQ="  select"
        REQ+="     concat_ws('${__SEPARATOR}', SA.id_job, SA.status)"
        REQ+=" from"
        # Pour une table, on récupère l'id de l'id_traitement le plus récent, pour ensuite récupérer les infos de cette ligne (dont le statut à vérifier)
        REQ+="     (SELECT distinct"
        REQ+="         first_value(id) over(order by id_job desc) as max_id_acq"
        REQ+="     FROM ${TOT}"
        REQ+="     where"
        REQ+="        type_suivi = '${TYPE_SUIVI_SUIVI}'"
        REQ+="        and niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}'"
        REQ+="        and projet = '${PROJET}'"
        REQ+="        and application = '${VAR_APPLI}'"
        REQ+="        and phase = 'ACQUISITION'"
        # Acquisition en un bloc par application => pas besoin de filtrer sur le NOM_TRAITEMENT
        # REQ+="        and nom_traitement = '${NOM_TRAITEMENT}'"
        REQ+="        and UPPER(nom_table) = UPPER('${table}')"
        # Ajout de filtre sur le statut En cours car pour les Full on ne base pas sur la ${LIST_JOURS} qui élimine l'acquisition en cours
        REQ+="        and status != '${ST_ENCOURS}'"
        # Pas de date_ope sur les tables Full
        # REQ+="        and date_ope = '${jour}'"
        REQ+="     ) MA,"
        REQ+="     ${TOT} SA"
        REQ+=" where MA.max_id_acq = SA.id"
		
        LOG_INFO "REQ : $REQ"
		
        resultReq=$(PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -F "${__SEPARATOR}" -t -c "$REQ")
	    LOG_INFO "Dernier ID Traitement pour ${table} : ${resultReq}"

        #cut statut from the result of the request
	    statut=$(echo ${resultReq} | cut -d${__SEPARATOR} -f2)
	    LOG_INFO "statut : ${statut}"
	    if [[ ${statut} == "${ST_OK}" ]]; then
		  #cut id acquisition from the result of the request
	      id_acq=$(echo ${resultReq} | cut -d${__SEPARATOR} -f1)
	      LOG_INFO "Id Acq : ${id_acq}"
          LOG_INFO "Line in the file : ${table},${id_acq}"
          LOG_INFO ""
	      
		  if [[ "${WORKFLOW_ENV}" == "OOZIE" ]] ; then 
			echo "${table},${id_acq}" | hadoop fs -appendToFile - "${__HDFS_CONF_FOLDER}/${RESULT_FILE}"
		  else
			echo "${table},${id_acq}" >> ${REP_CONF}${RESULT_FILE}
		  fi
	    else
	      STATUT_GENERAL="KO"
	    fi
	  fi
    done
  fi
  
  if [[ $STATUT_GENERAL != "OK" ]]
  then
    LOG_ERROR "L'acquisition pour une des tables sources n'est pas valide";
    exit ${__FAILURE};
  fi
  
  END
  
  
}

if [[ "${WORKFLOW_ENV}" == "OOZIE" ]] ; then 
  main "$@"
else
  main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
fi
