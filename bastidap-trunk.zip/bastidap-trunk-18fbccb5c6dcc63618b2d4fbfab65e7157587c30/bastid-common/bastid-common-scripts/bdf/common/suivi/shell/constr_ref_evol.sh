#!/usr/bin/env bash
###############################################################################
# Description :     Met à jour à KO les statuts des traitements non validés
# Usage : 
# Parameters :      
#      $1 Répertoire de conf
#      $2 Nom du traitement
#      $3 File de ressource TEZ
# Author :          LCO
# Updated :         17/11/2017
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
#set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec            #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d%H%M%S%N")                 #time stamp ex.20170804110741146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  


if [[ $# != 2 ]] ; then
    LOG_ERROR "Ce traitement attend deux parametres : <REP_CONF> <NOM_TRAITEMENT>"
    exit $__FAILURE
fi

REP_CONF=$1
NOM_TRAITEMENT=$2

VAR_APPLI=''
VAR_PHASE=''
CAT_VALUES=''
CURRDATE=$(date "+%Y-%m-%d %H:%M:%S")


#######################################
# Description: 
# Arguments: <Variable contenant le résultat d'une requête> <nom du tableau>
# Returns: 
#######################################
TO_ARRAY () {

    local res="$1"
    local __resultvar=$2
    local array=()
    # l'IFS par défaut est (espace ou tab ou retour_chariot)
    # on le change pour la fonction pour ne pas tenir compte des espaces ou tab dans les résultats de requête
    local IFS=$'\n'

    for LINE in $res
    do
        array+=("${LINE}")
    done
    
    # On annule complètement l'IFS afin de que le tableau soit recopier tel quel
    local IFS=''
    eval $__resultvar='("${array[@]}")'

}
#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  START
  SETUP
    
    LOG_INFO "Lecture des parametres dans ${REP_CONF}${PARAM_BATCH}"
    READ_BATCH_PARAM "${REP_CONF}/${PARAM_BATCH}" "APPLI" "VAR_APPLI"
    READ_BATCH_PARAM "${REP_CONF}/${PARAM_BATCH}" "PHASE" "VAR_PHASE"

    
    LOG_INFO "PROJET : $PROJET"
    LOG_INFO "APPLI : $VAR_APPLI"
    LOG_INFO "PHASE : $VAR_PHASE"
    LOG_INFO "TRAITEMENT : $NOM_TRAITEMENT"

   

    
    # Récupère l'ID_TRAITEMENT en cours
    ID_TRAITEMENT=$(PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -A -t -c " \
                        select id_job \
                        from ${TOT} \
                        where \
                            type_suivi = '${TYPE_SUIVI_SUIVI}' \
                            and niveau_suivi = '${NIVEAU_SUIVI_STATUT}' \
                            and projet = '${PROJET}' \
                            and application = '${VAR_APPLI}' \
                            and phase = '${VAR_PHASE}' \
							and nom_traitement = '${NOM_TRAITEMENT}' \
                            and status = '${ST_ENCOURS}' \
                        ")
    LOG_INFO ""
    LOG_INFO "ID_TRAITEMENT en cours : $ID_TRAITEMENT"
	
	
	    # Lecture des dépendances amont
    LOG_INFO ""
    LOG_INFO "Lecture des dépendances amont"
    LOG_INFO ""
    GET_LIST_TABLE "${NOM_TRAITEMENT}" "${REP_CONF}/${DEPENDANCES}" "CIBLE" "TVAR_DEP_AMONT_DELTA" "TVAR_DEP_AMONT_FULL"
	
 LOG_INFO ""
    LOG_INFO "===================================================================="
    LOG_INFO "Construction du catalogue d'id_traitement pour les tables FULL"
    LOG_INFO "===================================================================="
    LOG_INFO ""
    
    for TABLE in ${TVAR_DEP_AMONT_FULL[@]}
    do
        LOG_INFO "Une ligne pour ${TABLE} avec l'ID_TRAITEMENT ${ID_TRAITEMENT}"
        CAT_VALUES="${CAT_VALUES},('${ID_TRAITEMENT}', '${TYPE_SUIVI_SUIVI}', '${NIVEAU_SUIVI_CATALOGUE}', '${PROJET}', '${VAR_APPLI}', '${VAR_PHASE}', '${NOM_TRAITEMENT}', '${ST_ENCOURS}', Null, '${TABLE}', '${TYPE_TABLE_FULL}', Null, Null, Null)"
        
    done
    
    LOG_INFO ""
    LOG_INFO "===================================================================="
    LOG_INFO "Insertion des DATE_OPE dans ${TOT}"
    LOG_INFO "===================================================================="
    LOG_INFO ""
    
    # insertion dans le catalogue de toutes les lignes
    REQ="insert into ${TOT} (id_job, type_suivi, niveau_suivi, projet, application, phase, nom_traitement, status, date_ope, nom_table, type_table, borne_min, borne_max, nb_lignes) values ${CAT_VALUES:1:$((${#CAT_VALUES}-1))}"
    PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -e -c "$REQ" 
    
  END  
  exit ${__SUCCESS}
  
  }

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
	
	