#!/usr/bin/env bash
###############################################################################
# Description :     Construit des date_ope sur une tranche de dates sp�cifi�es
# Usage : 
# Parameters :      $1 Repertoire de configuration du traitement
#                   $2 Nom du traitement
# Author :          LCO
# Updated :         08/12/2017
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d%H%M%S%N")                 #time stamp ex.20170804110741146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

if [[ -z ${WORKFLOW_ENV+x} ]]; then 
  WORKFLOW_ENV="OOZIE"; export WORKFLOW_ENV
fi

case "${WORKFLOW_ENV}" in 
  OOZIE) 
    if [[ $# != 5 ]] ; then
		echo "Ce traitement attend cinq parametres : <ROOT> <NOM_TRAITEMENT> <APPLI_TRAITEMENT> <DATE_DEBUT> <DATE_FIN>"
		exit ${__FAILURE}
	fi
	
	ROOT="$1"
	NOM_TRAITEMENT="$2"
	APPLI_TRAITEMENT="$3"
	DATE_DEBUT="$4"
    DATE_FIN="$5"
	REP_CONF=""
	LOGDIR="${ROOT}/log/${APPLI_TRAITEMENT}"; export LOGDIR    #log folder exported for use in .fonction_*_spec
	
	#load and apply specific oozie function
	hadoop fs -get "${ROOT}/script/common/.fonction_bastid_oozie"
	. .fonction_bastid_oozie 
    init_oozie_env "${ROOT}" "${APPLI_TRAITEMENT}" "${LOGDIR}"
	;;
  *)
    # V�rification du nombre de param�tre attendu
    if [[ $# != 3 ]] ; then
      LOG_ERROR "Ce traitement attend trois parametres : <REP_CONF> <NOM_TRAITEMENT> <LIST_DATE separees par des espaces>"
      exit $__FAILURE
    fi
	
	. $APPLI_HOME/appli/connexion/.fonction_bastid_spec        #source .fonction_*_spec 
	
	[[ "${1: -1}" == "/" ]] && REP_CONF="${1}" || REP_CONF="${1}/"
	NOM_TRAITEMENT="$2"
    LIST_DATE="$3"
	
	LOGDIR="${LST}"; export LOGDIR                             #log folder exported for use in .fonction_*_spec 
	;;
esac

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

for DATE_OPE in $LIST_DATE
do
    if [[ ! ( "$DATE_OPE" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}$ && $(date -d "${DATE_OPE}" 2>/dev/null) ) ]]
    then
        LOG_ERROR "Format de date de ${DATE_OPE} invalide (YYYY-MM-DD attendu)"
        exit $__FAILURE
    fi
done
    
# Initialisation de variables
VAR_APPLI=''
VAR_PHASE=''


#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  START
  SETUP
    
    LOG_INFO "Lecture des parametres dans ${REP_CONF}${PARAM_BATCH}"
    
    READ_BATCH_PARAM "${REP_CONF}${PARAM_BATCH}" "APPLI" "VAR_APPLI"
    READ_BATCH_PARAM "${REP_CONF}${PARAM_BATCH}" "PHASE" "VAR_PHASE"
    
    GET_LIST_TABLE "${NOM_TRAITEMENT}" "${REP_CONF}${DEPENDANCES}" "CIBLE" "TVAR_DEP_AVAL_DELTA" "TVAR_DEP_AVAL_FULL"
    
    LOG_INFO "PROJET :                          ${PROJET}"
    LOG_INFO "APPLI :                           ${VAR_APPLI}"
    LOG_INFO "PHASE :                           ${VAR_PHASE}"
    LOG_INFO "TRAITEMENT :                      ${NOM_TRAITEMENT}"
    
    GET_ID_TRT "$VAR_APPLI" "$VAR_PHASE" "$NOM_TRAITEMENT" "ID_TRAITEMENT"
    
    LOG_INFO ""
    LOG_INFO "====================================================================================================="
    LOG_INFO "                  MODE ALIMENTATION PAR LISTE de DATE_OPE (sp�cifique DEV REC)"
    LOG_INFO "Insertion dans le catalogue des DATE_OPE en statut ${ST_ENCOURS} pour le traitement $NOM_TRAITEMENT"
    LOG_INFO "====================================================================================================="
    
    LOG_INFO ""
    LOG_INFO "-----------------------------------------------------------------------------------------------------"
    LOG_INFO "Construction des ID_TRAITEMENT / DATE_OPE pour les tables DELTA"
    
    CAT_VALUES=""
    
    for TABLE in ${TVAR_DEP_AVAL_DELTA[*]}
    do
        LOG_INFO ""
        LOG_INFO "G�n�ration des ID_TRAITEMENT / DATE_OPE pour la table $TABLE"        
        for DATE_OPE in $LIST_DATE
        do
            LOG_INFO ""
            LOG_INFO "DATE_OPE : ${DATE_OPE}"
            
            BORNE_MIN="$(date +%Y-%m-%d -d "${DATE_OPE}") 00:00:00.0"
            BORNE_MAX="$(date +%Y-%m-%d -d "${DATE_OPE} +1 day") 00:00:00.0"
            
            LOG_INFO "BORNE_MIN : ${BORNE_MIN}"
            LOG_INFO "BORNE_MAX : ${BORNE_MAX}"
            
            CAT_VALUES=${CAT_VALUES}",('${ID_TRAITEMENT}', '${TYPE_SUIVI_SUIVI}', '${NIVEAU_SUIVI_CATALOGUE}', '${PROJET}', '${VAR_APPLI}', '${VAR_PHASE}', '${NOM_TRAITEMENT}', '${ST_ENCOURS}', '${DATE_OPE}', '${TABLE}', Null, '${BORNE_MIN}', '${BORNE_MAX}', Null)"
        done
    done
    
    LOG_INFO ""
    LOG_INFO "-----------------------------------------------------------------------------------------------------"
    LOG_INFO "Construction des ID_TRAITEMENT pour les tables FULL"
    LOG_INFO ""
    
    for TABLE in ${TVAR_DEP_AVAL_FULL[*]}
    do
        LOG_INFO "G�n�ration de l'ID_TRAITEMENT pour la table $TABLE"
        CAT_VALUES=${CAT_VALUES}",('${ID_TRAITEMENT}', '${TYPE_SUIVI_SUIVI}', '${NIVEAU_SUIVI_CATALOGUE}', '${PROJET}', '${VAR_APPLI}', '${VAR_PHASE}', '${NOM_TRAITEMENT}', '${ST_ENCOURS}', Null, '${TABLE}', Null, Null, Null, Null)"
    done
    
    LOG_INFO ""
    LOG_INFO "===================================================================="
    LOG_INFO "Insertion des DATE_OPE dans ${TOT}"
    LOG_INFO "===================================================================="
    LOG_INFO ""
    
    # insertion dans le catalogue de toutes les lignes
    REQ="insert into ${TOT} (id_job, type_suivi, niveau_suivi, projet, application, phase, nom_traitement, status, date_ope, nom_table, type_table, borne_min, borne_max, nb_lignes) values ${CAT_VALUES:1:$((${#CAT_VALUES}-1))}"
    LOG_INFO "REQ : $REQ"
	PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"
    
  END  
  exit ${__SUCCESS}
  
}

if [[ "${WORKFLOW_ENV}" == "OOZIE" ]] ; then 
  main "$@"
else
  main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
fi
