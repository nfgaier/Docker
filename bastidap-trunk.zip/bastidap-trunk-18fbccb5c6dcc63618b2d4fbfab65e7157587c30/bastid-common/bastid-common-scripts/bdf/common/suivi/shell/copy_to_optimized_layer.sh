#!/usr/bin/env bash
###############################################################################
# Description : Copier de données de work_layer à optimized_layer (oozie only)
# Usage : 
# Parameters :      
#      $1 Répertoire de travail oozie
#      $2 Nom du traitement
#      $3 Nom d'application
#      $4 Nom de queue
#      $5 Nom du script hql
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d%H%M%S%N")                 #time stamp ex.20170804110741146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

if [[ $# != 5 ]] ; then
  echo "Ce traitement attend cinq parametres : <ROOT> <NOM_TRAITEMENT> <APPLI_TRAITEMENT> <QUEUE> <SCRIPT_COPY_HQL>"
  exit ${__FAILURE}
fi
	
ROOT="$1"
NOM_TRAITEMENT="$2"
APPLI_TRAITEMENT="$3"
QUEUE="$4"
SCRIPT_HQL="$5"
LOGDIR="${ROOT}/log/${APPLI_TRAITEMENT}"; export LOGDIR    #log folder exported for use in .fonction_*_spec
	
#load and apply specific oozie function
hadoop fs -get "${ROOT}/common/.fonction_bastid_oozie"
. .fonction_bastid_oozie 
init_oozie_env "${ROOT}" "${APPLI_TRAITEMENT}" "${LOGDIR}"

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

COPY_WORK_TO_OPT () {

    LOG_START_FUNC "${FUNCNAME[0]}"
    
    local nom_traitement="$1"
    local hql_path="${ROOT}/${APPLI_TRAITEMENT}/traitement/load/hql/"

    local req="select id_job from ${TOT} \
                where
                    status = '${ST_ENCOURS}' \
                    and type_suivi='${TYPE_SUIVI_SUIVI}' \
                    and niveau_suivi='${NIVEAU_SUIVI_STATUT}' \
                    and application = '${APPLI_TRAITEMENT^^}'  \
                    and phase = '${PHASE_TRAITEMENT}'  \
                    and nom_traitement = '${nom_traitement}'"
					
    LOG_INFO "REQ : $req"
	
    local id_traitement=$(PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -t -A -c "${req}")
    
	LOG_INFO "Id_traitement=${id_traitement}"

    LOG_INFO "Copie de work_layer à optimized_layer pour le traitement $nom_traitement :"
	
    LOG_INFO "hive --hiveconf mapreduce.job.credentials.binary=${HADOOP_TOKEN_FILE_LOCATION} --hiveconf tez.credentials.path=${HADOOP_TOKEN_FILE_LOCATION} --hiveconf tez.queue.name=${QUEUE} --hiveconf id_traitement=${id_traitement} -f ${hql_path}${SCRIPT_HQL}"
	
    hive --hiveconf mapreduce.job.credentials.binary="${HADOOP_TOKEN_FILE_LOCATION}" \
      --hiveconf tez.credentials.path="${HADOOP_TOKEN_FILE_LOCATION}" \
      --hiveconf tez.queue.name="${QUEUE}" \
      --hiveconf id_traitement="${id_traitement}" \
      -f "${hql_path}${SCRIPT_HQL}"
	
    LOG_INFO "Exécution OK"
}

#######################################
# Description:  Fonction principale, appelée dans le corps du script
# Arguments:    Pas d'argument
# Returns:      
#######################################
main () {

  START
  SETUP
    
  COPY_WORK_TO_OPT "${NOM_TRAITEMENT^^}"
  
  END
  exit ${__SUCCESS}
  
}

main "$@"
