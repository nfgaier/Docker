#!/usr/bin/env bash
###############################################################################
# Description :"Pilot"(launcher) script used to execute groups of scripts defined in a configuration file __PARAMFILE.
#               Each line of the configuration file contains a group id and the script's path+file name separated by a __SEPARATOR.
#               The order of appearance of the group ids is not significant.
#
#               Example : 1,/path/to/the/script/le_script01.sh
#                         2,/path/to/the/script/le_script03.sh
#                         2,/path/to/the/script/le_script07.sh
#                         3,/path/to/the/script/le_script02.sh
#
#               The pilot(launcher) script executes the scripts with the same group id in parallel
#               and the groups themselves in sequence sorted by ascending order :
#
#               With the example above:
#               Are executed first (group 1) : le_script01.sh 
#               Then (group 2): le_script03.sh and le_script07.sh (in paralell)
#               Then (group 3): le_script02.sh
#
# Failure :     If a script's execution fails, the pilot script continues with the execution of the rest of the scripts  
#               from the configuration file, until all scripts are launched.    
#                
#               Each failed script, is added to a new temporary configuration file __KO_PARAMFILE (creatd by the fist failed script) in the __CONF_FOLDER.
#               The new temporary configuration file has the same structure as the original (__PARAMFILE) one.
#               This way, at the end of the execution of all scritps from a configuration file, 
#               all failed scripts will be listed in the new temporary configuration file __KO_PARAMFILE.
#
#               At this point there will be 2 configuration files available : the permanent __PARAMFILE and the temporary __KO_PARAMFILE.
#               The pilot script contains a loop which tries __NB_TRIES times to execute the scripts from a configuration file. 
#               At the begining of the loop it looks for a temporary configuration file __KO_PARAMFILE.
#               If found, the pilot script executes all script from the temporary configuration file __KO_PARAMFILE.
#               If not, the pilot script executes all script from the permanent configuration file __PARAMFILE.
#               The temporary configuration file __KO_PARAMFILE is deleted at the end of the execution if no failed scritps are detected.
#               (or it is not created at all if no scripts have failed)
#
# Recovery :    If after the __NB_TRIES executions there are still failed scripts, the execution eventually halts with exit __FAILURE.
#               The temporary configuration file __KO_PARAMFILE is not deleted and is present in __CONF_FOLDER.
#               (another temporary file __TMP_PROCFILE will also be present in __CONF_FOLDER but it not relevent to the recovery)
#               If the pilot script is relaunched at this stage (with the __KO_PARAMFILE present), only the files in __KO_PARAMFI will be executed.
#               In order to execute all files from the permanent configuration file __PARAMFILE, the __KO_PARAMFILE file must be deleted.
#       
# Usage :  Execution without arguments     
# Author : Umanis for BDF
# Updated : 22/01/2018
#           LCO 22/01/2018 : first Bastid release will implement a full restart function (even failed shells)
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec            #source .fonction_bastid_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

readonly __TMP_PROCFILE=${__BASE}"_lst_prc_pid.tmp"            #temporary configuration file associating a script with its PID 
#readonly __KO_PARAMFILE=${__BASE}"_param_KO.tmp"               #configuration file containing the KO scripts to re-execute 
#readonly __TMP_KO_PARAMFILE=${__BASE}"_param_TMP_KO.tmp"       #temporary configuration file containing the KO scripts to execute
readonly __DUMMY_INIT=99999
readonly __SEPARATOR=","

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

#######################################
# Description: Checks if a temporary configuration __TMP_KO_PARAMFILE
#              is present in the __CONF_FOLDER folder and sets the __TMP_PARAMFILE variable
# Arguments: -
# Returns: 
#######################################
get_param_file () {

  #LCO 22/01/2018 : first Bastid release will implement a full restart function (even failed shells)
  #if [[ -f ${__CONF_FOLDER}/${__KO_PARAMFILE} ]]; then
  #  __TMP_PARAMFILE=${__CONF_FOLDER}/${__KO_PARAMFILE}
  #elif [[ -f ${__PARAMFILE} ]]; then
  if [[ -f ${__PARAMFILE} ]]; then
    __TMP_PARAMFILE=${__PARAMFILE}
  else
    LOG_ERROR "${FUNCNAME[0]} : No configuration file ${__PARAMFILE}) found"
    #LOG_ERROR "${FUNCNAME[0]} : No configuration file (${__CONF_FOLDER}/${__KO_PARAMFILE} or ${__PARAMFILE}) found"
    exit ${__FAILURE}     
  fi
  
  LOG_INFO "${FUNCNAME[0]} : Parameter file : ${__TMP_PARAMFILE}"

}
     

#######################################
# Description: Checks the structure of a configuration file
# Arguments: A configuration file
# Returns: 
#######################################
validate_param_file () {

  #arguments check
  if [[ "$#" -ne 1 ]]; then
    LOG_ERROR "${FUNCNAME[0]} : Usage : validate_param_file <param file path and file name>"
    exit ${__FAILURE} 
  fi  

  #file name passed as parameter
  local paramfile="${1}"
  #regular expression of testing a number 
  local reg_exp_nbr='^[0-9]+$'
  local scriptfile=""
  local group_id=""
  
  #read the file passed as parameter
  while IFS= read -r line 
  do
    #get the group id from the fist column
    group_id=$(eval echo ${line} | cut -d${__SEPARATOR} -f1)
    #get the file name + path id from the second column
    scriptfile=$(eval echo ${line} | cut -d${__SEPARATOR} -f2)
   
    #test the goup id
    if ! [[ ${group_id} =~ $reg_exp_nbr ]] ; then
      LOG_ERROR "${FUNCNAME[0]} : Error in configuration file ${paramfile} : group ID ${group_id} is not a number"
      exit ${__FAILURE}
    fi
    
    #test if the file exists
    if [[ ! -f "${scriptfile}" ]]; then
      LOG_ERROR "${FUNCNAME[0]} : Error in configuration file ${paramfile} : file ${scriptfile} does not exist"
      exit ${__FAILURE}    
    #test if the file is executable
    elif [[ ! -x "${scriptfile}" ]]; then
      LOG_ERROR "${FUNCNAME[0]} : Error in configuration file ${paramfile} : file ${scriptfile} is not executable"
      exit ${__FAILURE}        
    fi  

  done < ${paramfile}
    
  LOG_INFO "${FUNCNAME[0]} : Configuration file ${paramfile} validated"
  
}


#######################################
# Description: Extracts unique group ids from a configuration file
# Arguments: A configuration file
# Returns: fills the global array __GROUPS_ARRAY with the group ids
#######################################
get_group_ids () {

  #arguments check
  if [[ "$#" -ne 1 ]]; then
    LOG_ERROR "${FUNCNAME[0]} : Usage : get_group_ids <param file path and file name>"
    exit ${__FAILURE} 
  fi  

  #file name passed as parameter
  local paramfile="${1}"
  #init group id with a dummy value
  local group_id=${__DUMMY_INIT}
  
  #init array used to store the result
  __GROUPS_ARRAY=() 
  
  #read a line from the file
  while IFS= read -r line 
  do
    #cut group id from the first column of the line
    group_id=$(eval echo ${line} | cut -d${__SEPARATOR} -f1)
    #apppend the group id to the array
    __GROUPS_ARRAY+=("${group_id}") 
  done < ${paramfile}

  #sort group ids and take only distinct values
  __GROUPS_ARRAY=($(echo "${__GROUPS_ARRAY[@]}" | tr ' ' '\n' | sort -u | tr '\n' ' '))
  
  #print array for info
  LOG_INFO "${FUNCNAME[0]} : Group ids found : "
  #remove last character (new line)
  truncate -s $(($(stat -c '%s' "${LOGDIR}/${LOGFILE}")-1)) "${LOGDIR}/${LOGFILE}"  
  printf "%s " "${__GROUPS_ARRAY[@]}"
  printf "\n"
 
}

#######################################
# Description: Executes all groups listed in __GROUPS_ARRAY
# Arguments: A configuration file
# Returns: 
#######################################
execute_all_groups () {

  #parameter file name passed as first parameter
  local paramfile="${1}"
  
  for group in "${__GROUPS_ARRAY[@]}"
  do
    LOG_INFO "${FUNCNAME[0]} : Start group "${group}
    execute_one_group "${paramfile}" "${group}"
    LOG_INFO "${FUNCNAME[0]} : End group "${group}
  done
  
  #LCO 22/01/2018 : first Bastid release will implement a full restart function (even failed shells)
  #if [[ -f "${__CONF_FOLDER}/${__TMP_KO_PARAMFILE}" ]]; then
  #  mv ${__CONF_FOLDER}/${__TMP_KO_PARAMFILE} ${__CONF_FOLDER}/${__KO_PARAMFILE}
  #fi  

}

#######################################
# Description: Executes a group of scripts in paralell
#              Each executed script with its PID is listed in a __TMP_PROCFILE file
#              The __TMP_PROCFILE has the same structure as a configuration, but with its PID at the end
#              The __TMP_PROCFILE file is used to create the temporary configuration with all failed scritps
# Arguments: A configuration file and a group id
# Returns: 
#######################################
execute_one_group () {

  if [[ "$#" -ne 2 ]]; then
    LOG_ERROR "${FUNCNAME[0]} : Usage : execute_one_group <param file path and file name> <group id>"
    exit ${__FAILURE} 
  fi 
  
  #parameter file name passed as first parameter
  local paramfile="${1}"
  #group id passed as second parameter
  local group_id=${2}
  #variable used to hold the script path and name
  local scriptfile=""
  

  #read a line from the file
  while IFS= read -r line 
  do
    #cut script name and path from the second column of the line
    scriptfile=$(eval echo ${line} | cut -d${__SEPARATOR} -f2)
    #if the first column corresponds to the group id passed as parameter 
    if [[ $(eval echo ${line} | cut -d${__SEPARATOR} -f1) -eq ${group_id} ]]; then
      #LOG_INFO "${FUNCNAME[0]} : Group "${group_id}" : File found "${scriptfile}
      #then execute in background the script in $scriptfile
      ${scriptfile} >  "${LST}/$(basename ${scriptfile} | cut -f 1 -d '.')_${__TIMESTAMP}.log" 2>&1 &
      #print the PID
      LOG_INFO "${FUNCNAME[0]} : Executing ${scriptfile} with PID : "$!
      #write the group id, the script and the PID to a tmp file 
      echo ${group_id}",${scriptfile},"$! >> ${__CONF_FOLDER}/${__TMP_PROCFILE}
    fi
  done < ${paramfile}
  
  #wait until all the executed scritps finish
  wait_group_execution

}


#######################################
# Description: Waits for the execution of all subshells of the current shell
#              or in other words, waits for the execution of all scritps launched in the background from the current shell
#              If a script fails, increments __FAILED and adds the failed script to the temporary configuration file __TMP_KO_PARAMFILE
#              The __TMP_PROCFILE file is used to get the path and name of the failed script from its PID 
# Arguments: -
# Returns: 
#######################################
wait_group_execution () {

  #for all subshells of the current shell
  for job in $(jobs -p)
  do
    #print the PID
    local script=$(ps -p ${job} -o args --no-headers)
    LOG_INFO "${FUNCNAME[0]} : Waiting job : ${script} : PID : "${job}
    #wait until the current job (process) ends
    #LCO 22/01/2018 : first Bastid release will implement a full restart function (even failed shells)
    wait ${job} || { let "__FAILED+=1" ; #if it fails then increment the variable __FAILED 
                     LOG_ERROR "${FUNCNAME[0]} : ======> PID : "${job}" <====== FAILED !"  #print its PID
                #     grep "${job}" ${__CONF_FOLDER}/${__TMP_PROCFILE} >> ${__CONF_FOLDER}/${__TMP_KO_PARAMFILE};   #create a KO param file  
                } 
  done
  
}

#######################################
# Description: Deletes temporary files
# Arguments: -
# Returns: 
#######################################
purge_tmp_files () {

  LOG_INFO "${FUNCNAME[0]} : Deleting ${__CONF_FOLDER}/${__TMP_PROCFILE}" 
  #LOG_INFO "${FUNCNAME[0]} : Deleting ${__CONF_FOLDER}/${__KO_PARAMFILE}" 

  rm -f ${__CONF_FOLDER}/${__TMP_PROCFILE}
  #LCO 22/01/2018 : first Bastid release will implement a full restart function (even failed shells)
  #rm -f ${__CONF_FOLDER}/${__KO_PARAMFILE}

}


#######################################
# Description: Deletes temporary pid file
# Arguments: -
# Returns: 
#######################################
purge_pid_file () {

  LOG_INFO "${FUNCNAME[0]} : Deleting ${__CONF_FOLDER}/${__TMP_PROCFILE}" 
  rm -f ${__CONF_FOLDER}/${__TMP_PROCFILE}
  
}

#######################################
# Description: Main function
# Arguments: -
# Returns: 
#######################################
main () {

  if [[ "$#" -ne 2 ]]; then
    LOG_ERROR "${FUNCNAME[0]} : Usage : acq_pilote.sh <folder containing acq_pilot_param.csv file> <folder containing dt_*_charg.tmp files>"
    exit ${__FAILURE} 
  else 
    __CONF_FOLDER="${1}"                                 #folder with configuration files
    __TMP_FOLDER="${2}"                                  #temp folder
    __PARAMFILE="${__CONF_FOLDER}/${__BASE}_param.csv"   #permanent configuration file containing the scripts to execute 
    __TMP_PARAMFILE=${__PARAMFILE}                       #variable used to pass the configuration file to a function
    __FAILED=0                                           #failed scritps counter
    __GROUPS_ARRAY=()                                    #global array used to store the groups ID 
    __NB_TRIES=1                                         #number of re-tries 
    
    #read the application name from the param_batch.conf file
    READ_BATCH_PARAM "${__CONF_FOLDER}/${PARAM_BATCH}" "APPLI" "APPLI_NAME"
    
    LOG_INFO "${FUNCNAME[0]} : Parameter read __CONF_FOLDER : ${__CONF_FOLDER}" 
    LOG_INFO "${FUNCNAME[0]} : Parameter read __TMP_FOLDER : ${__TMP_FOLDER}" 
    LOG_INFO "${FUNCNAME[0]} : Application name read from param_batch.conf APPLI_NAME : ${APPLI_NAME}" 
  fi 

  START

  SETUP
    
  LOG_INFO "${FUNCNAME[0]} : Number of tries : ${__NB_TRIES}" 
  
  purge_pid_file
  
  #try to execute the scripts __NB_TRIES times
  for i in `seq 1 ${__NB_TRIES}`;
  do
  
    LOG_INFO "${FUNCNAME[0]} : TRY $i"
  
    __FAILED=0
  
    #look for a temporary configuration file __TMP_KO_PARAMFILE
    get_param_file
  
    #check the format of the configuration file
    validate_param_file "${__TMP_PARAMFILE}"

    #extract group ids from the configuration file    
    get_group_ids "${__TMP_PARAMFILE}"
    
    #execute all groups found in the  configuration file
    execute_all_groups "${__TMP_PARAMFILE}"
    
    #if all scripts got executed successfully then delete all temporary files and exit the loop
    if [[ ${__FAILED} -eq 0 ]]; then
      purge_tmp_files
      break
    fi
    
    LOG_INFO ""
    
  done
 
  END
  
  #if all scripts got executed successfully then exit __SUCCESS if not exit __FAILURE
  if [[ ${__FAILED} -eq 0 ]]; then
    LOG_INFO "${FUNCNAME[0]} : Exit SUCCESS"
    exit ${__SUCCESS}
  else 
    LOG_ERROR "${FUNCNAME[0]} : ${__FAILED} process(es) failed."
    LOG_ERROR "${FUNCNAME[0]} : Exit FAILURE"
    exit ${__FAILURE}
  fi  
}


main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1

