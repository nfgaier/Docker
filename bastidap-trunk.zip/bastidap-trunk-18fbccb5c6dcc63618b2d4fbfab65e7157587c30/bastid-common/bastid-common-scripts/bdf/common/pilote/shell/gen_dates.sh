#!/usr/bin/env bash
###############################################################################
# Description : generate dt_deb_charg and dt_dern_charg
# Usage : 
# Author : 
# Updated : 
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

#. $APPLI_HOME/appli/connexion/.param
. $APPLI_HOME/appli/connexion/.fonction                        #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d%H%M%S")                   #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  



# config dates et mode_alim : renseigner ici les bornes et le mode_alim ("QUOTIDIEN"/"REPRISE HISTORIQUE")
DT_DEB_CHARG=$(date '+%Y-%m-%d %H:%M:%S')
DT_DERN_CHARG=$(date --date='1 days ago' '+%Y-%m-%d %H:%M:%S')
export MODE_ALIM="QUOTIDIEN"

# pour reprise historique : rentrer ici les bornes souhaitées
#DT_DEB_CHARG=$(date --date='2017-08-25 21:05:00' '+%Y-%m-%d %H:%M:%S')
#DT_DERN_CHARG=$(date --date='2017-08-23 23:05:00' '+%Y-%m-%d %H:%M:%S')
#export MODE_ALIM="REPRISE HISTORIQUE"

#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
generate_dt_deb_charg () {

  local file_name=${1}

  LOG_INFO "génération une date de début de chargement nommée ${file_name} dans ${__TMP_FOLDER}"
  
  echo ${DT_DEB_CHARG} > "${__TMP_FOLDER}/${file_name}"
  
}

generate_dt_dern_charg () {

  local file_name=${1}

  LOG_INFO "génération une date de dernier chargement nommée ${file_name} dans ${__TMP_FOLDER}"
  
  echo ${DT_DERN_CHARG} > "${__TMP_FOLDER}/${file_name}"
  
}




#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  if [[ "$#" -ne 1 ]]; then
    LOG_ERROR "${FUNCNAME[0]} : Usage : gen_dates.sh <folder where to create dt_deb_charg.tmp and dt_dern_charg.tmp files>"
    exit ${__FAILURE} 
  else 
    __TMP_FOLDER="${1}"
  fi

  START
  
  SETUP
  
  generate_dt_deb_charg "dt_deb_charg.tmp"
  generate_dt_dern_charg "dt_dern_charg.tmp"
  
  END
  
  exit ${__SUCCESS}
  
}

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
