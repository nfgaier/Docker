# $1 : <dossier dans lequel sont g�n�r�s les shell sqoop>
# $1 : <chemin complet du fichier xml de conf du g�n�rateur>
# $1 : <nom de la base Landing>
# $1 : <cha�ne de connection SIO pour les instructions sqoop>
# $1 : <nom de l'appli tel que renseign� dans la TOT>

acq_generateur_sqoop.pl     "${MAE_SQOOP_SCR_PATH}" \
                            "./conf/maeva.xml" \
                            "$MAE_HIVEDB_LDL" \
                            "--connect \"\${MAE_ORA_CXN}\" --username \${MAE_ORA_USER} --password \${MAE_ORA_PWD}" \
                            "$MAE_APPLI_NAME" \
                            "\"\$MAE_SRC_HDFS_LDL\""
