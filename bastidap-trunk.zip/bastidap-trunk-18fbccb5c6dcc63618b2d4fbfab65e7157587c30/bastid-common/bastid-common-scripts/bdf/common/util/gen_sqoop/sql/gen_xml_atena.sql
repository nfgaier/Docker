SELECT
   XMLELEMENT
   (
      "SGBD", 
      XMLFOREST('ORC' "FORMAT_SORTIE"),
      XMLAGG
      (
         XMLELEMENT
         (
            "TABLE",
            XMLATTRIBUTES(table_name "NOM",
                                                               'OUI' "EVAL",
                                                               '1' "NBR_MAPPER",
                (
                select c.column_name as column_name from (
                  select 
                      a.table_name,
                      FIRST_VALUE(a.column_name) over (partition by a.table_name ORDER BY a.constraint_name ASC ROWS UNBOUNDED PRECEDING) as column_name
                  from all_cons_columns a
                  inner join all_constraints b on a.constraint_name= b.constraint_name
                  where b.constraint_type = 'P') c
                  where c.table_name = all_tab_cols.table_name
                  group by c.column_name
                  )
             "CLE",
          CASE
                      WHEN all_tab_cols.table_name like  'NOMENCLATURES_%' OR all_tab_cols.table_name like 'CATALOGUE_%' OR all_tab_cols.table_name like 'CATEGORIE%'
					      OR all_tab_cols.table_name like 'CLATURES_%' OR all_tab_cols.table_name like 'ENCLATURES_%' OR all_tab_cols.table_name like 'MENCLATURES_%'
						  OR all_tab_cols.table_name like 'NCLATURES_%' OR all_tab_cols.table_name like 'OMENCLATURES_%' OR all_tab_cols.table_name like 'S_CATEGORIE%'
						  OR all_tab_cols.table_name like 'TURES_%' OR all_tab_cols.table_name like 'ATURES_%' OR all_tab_cols.table_name like 'ACQ_%' OR all_tab_cols.table_name in ('VIR_OPERATIONVIREMENT','PE_OPERATIONIMPUTATIONINTERETS','PARAM_DETERMINERCODEIMPUTATION','STRUCTCOMMERCE_CLIENT','STRUCTCOMMERCE_GROUPECLIENTELE','STRUCTCOMMERCE_CLIENTHISTORY','PARAM_CODEREJETCFONB')
						  THEN 'COMPLET'
                      ELSE 'DELTA'
                      END  "MODE_ALIM"
            ,
			
					 CASE
                        WHEN all_tab_cols.table_name not like  'NOMENCLATURES_%' and all_tab_cols.table_name not like 'CATALOGUE_%' and all_tab_cols.table_name not like 'CATEGORIE%'
					      and all_tab_cols.table_name not like 'CLATURES_%' and all_tab_cols.table_name not like 'ENCLATURES_%' and all_tab_cols.table_name not like 'MENCLATURES_%'
						  and all_tab_cols.table_name not like 'NCLATURES_%' and all_tab_cols.table_name not like 'OMENCLATURES_%' and all_tab_cols.table_name not like 'S_CATEGORIE%'
						  and all_tab_cols.table_name not like 'TURES_%' and all_tab_cols.table_name not like 'ATURES_%'  and all_tab_cols.table_name not like 'ACQ_%' and all_tab_cols.table_name not in ('VIR_OPERATIONVIREMENT','PE_OPERATIONIMPUTATIONINTERETS','PARAM_DETERMINERCODEIMPUTATION','STRUCTCOMMERCE_CLIENT','STRUCTCOMMERCE_GROUPECLIENTELE','STRUCTCOMMERCE_CLIENTHISTORY','PARAM_CODEREJETCFONB')
						  THEN 'TIMESTAMP' 
                     END  "TYPE"
		    ,
			
					CASE
                      WHEN all_tab_cols.table_name not like  'NOMENCLATURES_%' and all_tab_cols.table_name not like 'CATALOGUE_%' and all_tab_cols.table_name not like 'CATEGORIE%'
					      and all_tab_cols.table_name not like 'CLATURES_%' and all_tab_cols.table_name not like 'ENCLATURES_%' and all_tab_cols.table_name not like 'MENCLATURES_%'
						  and all_tab_cols.table_name not like 'NCLATURES_%' and all_tab_cols.table_name not like 'OMENCLATURES_%' and all_tab_cols.table_name not like 'S_CATEGORIE%'
						  and all_tab_cols.table_name not like 'TURES_%' and all_tab_cols.table_name not like 'ATURES_%'  and all_tab_cols.table_name not like 'ACQ_%' and all_tab_cols.table_name not in ('VIR_OPERATIONVIREMENT','PE_OPERATIONIMPUTATIONINTERETS','PARAM_DETERMINERCODEIMPUTATION','STRUCTCOMMERCE_CLIENT','STRUCTCOMMERCE_GROUPECLIENTELE','STRUCTCOMMERCE_CLIENTHISTORY','PARAM_CODEREJETCFONB')
						 THEN 'INSERT' 
                       END  "MODE"
		        ,
			
					CASE
					   WHEN (table_name = 'IMP_OPERATIONIMPUTATION') THEN  'DATEREGLEMENTINITIAL_' 	 
					   WHEN (table_name = 'OPDIV_OPERATIONDIVERSE') THEN  'DATEORDRE_' 
                       WHEN (table_name = 'STRUCTCOMMERCE_COMPTEHISTORY') THEN  'CREATIONDATE_' 
                       WHEN all_tab_cols.table_name not like  'NOMENCLATURES_%' and all_tab_cols.table_name not like 'CATALOGUE_%' and all_tab_cols.table_name not like 'CATEGORIE%'
					      and all_tab_cols.table_name not like 'CLATURES_%' and all_tab_cols.table_name not like 'ENCLATURES_%' and all_tab_cols.table_name not like 'MENCLATURES_%'
						  and all_tab_cols.table_name not like 'NCLATURES_%' and all_tab_cols.table_name not like 'OMENCLATURES_%' and all_tab_cols.table_name not like 'S_CATEGORIE%'
						  and all_tab_cols.table_name not like 'TURES_%' and all_tab_cols.table_name not like 'ATURES_%'  and all_tab_cols.table_name not like 'ACQ_%' and all_tab_cols.table_name not in ('VIR_OPERATIONVIREMENT','PE_OPERATIONIMPUTATIONINTERETS','PARAM_DETERMINERCODEIMPUTATION','STRUCTCOMMERCE_CLIENT','STRUCTCOMMERCE_GROUPECLIENTELE','STRUCTCOMMERCE_CLIENTHISTORY','PARAM_CODEREJETCFONB')
						 THEN  'UPDATEDATE_' 	
                       END "CHAMP_SRC"
			),
			 XMLAGG(
                      CASE
					     WHEN (table_name = 'IMP_OPERATIONIMPUTATION' and column_name = 'DATEREGLEMENTINITIAL_') THEN  XMLELEMENT("CRITERE",XMLATTRIBUTES('DATEREGLEMENTINITIAL_ BETWEEN to_timestamp(''$TIMESTAMP_MIN'', ''YYYY-MM-DD HH24:MI:SS.FF6'') AND to_timestamp(''$TIMESTAMP_MAX'', ''YYYY-MM-DD HH24:MI:SS.FF6'')' "CONDITION"))	 	 
						WHEN (table_name = 'OPDIV_OPERATIONDIVERSE' and column_name = 'DATEORDRE_' ) THEN  XMLELEMENT("CRITERE",XMLATTRIBUTES('DATEORDRE_ BETWEEN to_timestamp(''$TIMESTAMP_MIN'', ''YYYY-MM-DD HH24:MI:SS.FF6'') AND to_timestamp(''$TIMESTAMP_MAX'', ''YYYY-MM-DD HH24:MI:SS.FF6'')' "CONDITION"))	
						WHEN (table_name = 'STRUCTCOMMERCE_COMPTEHISTORY' and column_name = 'CREATIONDATE_') THEN  XMLELEMENT("CRITERE",XMLATTRIBUTES('CREATIONDATE_ BETWEEN to_timestamp(''$TIMESTAMP_MIN'', ''YYYY-MM-DD HH24:MI:SS.FF6'') AND to_timestamp(''$TIMESTAMP_MAX'', ''YYYY-MM-DD HH24:MI:SS.FF6'')' "CONDITION"))	
						WHEN all_tab_cols.table_name not like  'NOMENCLATURES_%' and all_tab_cols.table_name not like 'CATALOGUE_%' and all_tab_cols.table_name not like 'CATEGORIE%'
					      and all_tab_cols.table_name not like 'CLATURES_%' and all_tab_cols.table_name not like 'ENCLATURES_%' and all_tab_cols.table_name not like 'MENCLATURES_%'
						  and all_tab_cols.table_name not like 'NCLATURES_%' and all_tab_cols.table_name not like 'OMENCLATURES_%' and all_tab_cols.table_name not like 'S_CATEGORIE%'
						  and all_tab_cols.table_name not like 'TURES_%' and all_tab_cols.table_name not like 'ATURES_%'  and all_tab_cols.table_name not like 'ACQ_%' and all_tab_cols.table_name not in ('VIR_OPERATIONVIREMENT','PE_OPERATIONIMPUTATIONINTERETS','PARAM_DETERMINERCODEIMPUTATION','STRUCTCOMMERCE_CLIENT','STRUCTCOMMERCE_GROUPECLIENTELE','STRUCTCOMMERCE_CLIENTHISTORY','PARAM_CODEREJETCFONB')
						   and column_name = 'UPDATEDATE_'
						   THEN  XMLELEMENT("CRITERE",XMLATTRIBUTES('UPDATEDATE_ BETWEEN to_timestamp(''$TIMESTAMP_MIN'', ''YYYY-MM-DD HH24:MI:SS.FF6'') AND to_timestamp(''$TIMESTAMP_MAX'', ''YYYY-MM-DD HH24:MI:SS.FF6'')' "CONDITION"))	
                     END
		    ),
            XMLAGG(XMLELEMENT("COLONNE",XMLATTRIBUTES(
                      replace(column_name,'$','\$') "NOM",
                      data_type "TYPE_SRC",
                      CASE
                        WHEN (data_type = 'VARCHAR2') THEN 'STRING'
                        WHEN (data_type = 'CLOB') THEN 'STRING'
                        WHEN (data_type = 'BLOB') THEN 'BINARY'
                        WHEN (data_type = 'CHAR') THEN 'STRING'
						WHEN (data_type = 'TIMESTAMP(6)') THEN 'TIMESTAMP'
						WHEN (data_type = 'NUMBER') AND (data_scale !='0') THEN concat('DECIMAL(',concat(data_precision,concat(',',concat(data_scale,')'))))
						WHEN (data_type = 'NUMBER') AND (data_scale ='0') AND (data_precision < 10) THEN 'INT'
						WHEN (data_type = 'NUMBER') AND (data_scale ='0') AND (data_precision > 9 ) AND (data_precision < 19 ) THEN 'BIGINT'
						WHEN (data_type = 'NUMBER') AND (data_scale ='0') AND (data_precision > 18 ) THEN concat('DECIMAL(',concat(data_precision,',0)'))
                        WHEN (data_type = 'FLOAT') THEN 'double'
                      ELSE data_type
                      END as TYPE_DEST

              ))),CHR(10),' '
         )
      )
  )
  
  
FROM
   all_tab_cols
where table_name in
('ATURES_GROUPEDECONFIDENTIALITE',
'CATALOGUE_FORMATRESTITUTION',
'CATALOGUE_TYPERESTITUTION',
'CATEGORIEPRODUITDEFACTURATION',
'CLATURES_LIEUDERESIDENCEFICOBA',
'ENCLATURES_CATEGORIEECONOMIQUE',
'ENCLATURES_UNITEADMINISTRATIVE',
'ENCLATURES_UTILISATIONDUCOMPTE',
'MENCLATURES_CATEGORIEJURIDIQUE',
'NCLATURES_CLASSIFICATIONCLIENT',
'NCLATURES_CODELIBELLEMOUVEMENT',
'NCLATURES_PRODUITDEFACTURATION',
'NOMENCLATURES_APPLICATION',
'NOMENCLATURES_CODEAPE',
'NOMENCLATURES_CODEAPU',
'NOMENCLATURES_CODEBANQUE',
'NOMENCLATURES_CODECFONB',
'NOMENCLATURES_CODEFLUX',
'NOMENCLATURES_CODEMOUVEMENT',
'NOMENCLATURES_CODEOPERATION',
'NOMENCLATURES_CODETVA',
'NOMENCLATURES_DELAIDEREGLEMENT',
'NOMENCLATURES_DEVISE',
'NOMENCLATURES_FAMILLEOPERATION',
'NOMENCLATURES_FORMULEDETAUX',
'NOMENCLATURES_MODEDEREGLEMENT',
'NOMENCLATURES_NATURECOMPTE',
'NOMENCLATURES_PAYS',
'NOMENCLATURES_PAYSDELAZONE',
'NOMENCLATURES_POLEOPERATIONNEL',
'NOMENCLATURES_ROLECONTACT',
'NOMENCLATURES_SUPERREMETTANT',
'NOMENCLATURES_TAUXDEREFERENCE',
'NOMENCLATURES_TAUXMARGE',
'NOMENCLATURES_TYPEOPERATION',
'NOMENCLATURES_TYPEROLEADRESSE',
'NOMENCLATURES_ZONEDERESIDENCE',
'OMENCLATURES_BANQUECOMMERCIALE',
'OMENCLATURES_CATEGORIEDECLIENT',
'OMENCLATURES_CATEGORIEDECOMPTE',
'OMENCLATURES_DIRECTIONDUTRESOR',
'OMENCLATURES_TYPEDERESTRICTION',
'PARAM_CODEREJETCFONB',
'S_CATEGORIEECONOMIQUENATIONALE',
'TURES_MOTIFOPPOSITIONSURCHEQUE',
'TURES_TYPEAUTRESERVICEBANCAIRE',
'ACQ_FLUXOPERATIONEMIS',
'ACQ_FLUXOPERATIONRECU',
'IMP_OPERATIONIMPUTATION',
'OPCORE_CHARGEEMETTEUR',
'OPCORE_CONTREPARTIE',
'OPCORE_DONNEESORIGINE',
'OPCORE_DONNEESREGLEMENT',
'OPCORE_ERREUR',
'OPCORE_LISTEDOUBLON',
'OPCORE_OPERATION',
'OPCORE_PARTICIPANTOPERATION',
'OPCORE_TRANSACTION',
'OPCORE_TRANSACTIONFRAIS',
'OPDIV_OPERATIONDIVERSE',
'PARAM_CODELIBELLEERREUR',
'PCORE_CODEINSTRUCTIONOPERATION',
'PE_OPERATIONIMPUTATIONINTERETS',
'TENUEDEPOSITION_MOUVEMENT',
'VIR_OPERATIONVIREMENT',
'COMMERCE_ENTITENIVEAUCLIENTELE',
'CONSOLIDATIONCONTROLEPROVISION',
'CTCOMMERCE_DONNEESBENIFICIAIRE',
'CTCOMMERCE_ENTITEPRINCIPALEBDF',
'MERCE_IDENTIFIANTINTERNATIONAL',
'RCE_GROUPEDECONSOLIDATIONSIBLE',
'STRUCTCOMMERCE_AUTRESNUMEROS',
'STRUCTCOMMERCE_BICSAUTORISES',
'STRUCTCOMMERCE_CLIENT',
'STRUCTCOMMERCE_CODEREMETTANT',
'STRUCTCOMMERCE_COMPTE',
'STRUCTCOMMERCE_GROUPECLIENTELE',
'STRUCTCOMMERCE_ROLEADRESSE',
'STRUCTCOMMERCE_SERVICEBANCAIRE',
'TRUCTCOMMERCE_CTEPARGPEDECONSO',
'TRUCTCOMMERCE_DEMANDEDECLOTURE',
'UCTCOMMERCE_PERIMETREEXTENSION',
'EF_COORDONNEESBENEFICIAIREVSOT',
'EMENT_INSTRUCTIONORDREVIREMENT',
'E_PROCESSPARCPTEETTARIFICATION',
'ESSCES_AUTRESSERVICESBANCAIRES',
'ION_CONTRATSERVICEREMUNERATION',
'N_COMPTEAREMUNERERREMUNERATION',
'OPE_DONNEESSOCLECALCULINTERETS',
'SCEBQREF_CUTOFF',
'SCEBQREF_FACTURATION',
'SCEBQREF_MODEDEFACTURATION',
'SCEBQREF_OPPOSITIONSDD',
'SCEBQREF_OPPOSITIONSURCHEQUE',
'SCEBQREF_REROUTAGE',
'SCEBQREF_RESTRICTIONS',
'SCEBQREF_SUPERVALIDATION',
'SCEBQREF_VSOT',
'ANSVERSES_FORMATSPARABONNEMENT',
'ENTTRANSVERSES_ADRESSE',
'ENTTRANSVERSES_ADRESSEPOSTALE',
'ENTTRANSVERSES_CONTACT',
'ENTTRANSVERSES_PERIODICITECRON',
'ENTTRANSVERSES_SWIFT',
'ENTTRANSVERSES_TARIFICATION',
'NSVERSES_ABONNEMENTRESTITUTION',
'RANSVERSES_FREQUENCEGENERATION',
'TRANSVERSES_ADRESSESEXPEDITION',
'TTRANSVERSES_ADRESSESDUCONTACT',
'CASHII_CONTRATSERVICECASH2',
'CASHII_DONNEESPARBANQUE',
'CASHII_DONNEESPARCLIENT',
'CASHII_DONNEESPARCOMPTE',
'CASHII_OPEARRONDIINTERETS',
'CASHII_OPEPAIEMENTINTERETS',
'CASHII_OPEPERCEPTIONMARGEBDF',
'CASHII_OPEPLACEMENT',
'CASHII_OPEREMBOURSEMENT',
'CASHII_PARTITIONPARBANQUE',
'CASHII_SUPRAOPERATIONTIER2',
'SHII_DONNEESPARCOMPTEPARBANQUE',
'AUTRESSCES_LIMITE',
'COMPTABILITE_CRO',
'COMPTABILITE_EVENEMENTGESTION',
'COMPTABILITE_FICHIERDECRO',
'DAT_EVENEMENTDAT',
'DAT_OPERATIONDAT',
'DAT_SUPRAOPERATIONDAT',
'DECISIONNEL_UPDATEDECISIONNEL',
'DIQUE_CARACTERISTIQUESVIREMENT',
'IQUE_CONTRATVIREMENTPERIODIQUE',
'IQUE_PROCESSUSFRAISPERIODIQUES',
'MUNERATION_TRANCHEREMUNERATION',
'NIVELLEMENT_COMPTEANIVELER',
'NIVELLEMENT_CONTRATNIVELLEMENT',
'NIVELLEMENT_ETAPECONTRACTUELLE',
'NIVELLEMENT_ETAPENIVELLEMENT',
'NIVELLEMENT_NIVELLEMENT',
'NOTIFICATION_FLOWIN',
'NOTIFICATION_FLOWINMESSAGE',
'NOTIFICATION_FLOWOUT',
'ONDITIONTEMPORAIREREMUNERATION',
'PERIODIQUE_PARTICIPANTVIREMENT',
'REMENTPERIODIQUE_VIREMENTFINAL',
'RIODECONTRACTUELLEREMUNERATION',
'SCEOPE_DONNEESCALCULQUOTIDIEN',
'SCEOPE_DONNEESCALCULTRANCHE',
'VELLEMENT_PROCESSUSNIVELLEMENT',
'PARAM_DETERMINERCODEIMPUTATION',
'STRUCTCOMMERCE_NUMERODECOMPTE',
'STRUCTCOMMERCE_COMPTEHISTORY',
'STRUCTCOMMERCE_CLIENTHISTORY'
)
and column_id is not null 
GROUP BY
   table_name;