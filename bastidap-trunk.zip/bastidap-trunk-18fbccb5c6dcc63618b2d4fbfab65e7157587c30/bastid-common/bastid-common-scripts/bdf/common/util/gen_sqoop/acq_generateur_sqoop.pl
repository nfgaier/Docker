#!/usr/bin/perl -w
##########################################
#Description: Script perl de création de requêtes                
#             pour l'acquisition SQOOP à partir du fichier XML   
#Créé par:    Umanis                                             
#Version:                                       
#	v0    25/07/2017                            
#   v0.1  31/07/2017	                        
#	v1.0  11/08/2017
#   v1.1  07/09/2017 Gestion table de suivi
#   v1.2  13/10/2017
#   v1.3  17/10/2017 Ajout gestion Workflow
#   v1.4  16/11/2017 Ajout gestion DATE_INSERT
#   v2.0  26/11/2017 Refonte générateur unique + migration Postgres
###############################################

#Option PERL
use strict;
use warnings;
use XML::LibXML;

#Recuperation des parametres d'appel
my ($repsqoop, $fichierxml, $db, $connexion, $appli, $hdfsldl) = @ARGV;

#Lecture du fichier XML
my $parser = XML::LibXML->new;
my $struct = $parser->parse_file($fichierxml);


#Gestion des tables
foreach my $TABLE ($struct->findnodes('//TABLE')) 
{   
    #Récupération des balises globales de la table
    my $NOM_TABLE = $TABLE->getAttribute('NOM');
    my $MODE_ALIM = $TABLE->getAttribute('MODE_ALIM');
    my $TYPE = $TABLE->getAttribute('TYPE');
    my $CHAMP_DELTA = $TABLE->getAttribute('CHAMP_SRC');
    my $FORMAT_DATE = $TABLE->getAttribute('FORMAT_DATE');
    my $EVAL = $TABLE->getAttribute('EVAL');
    my $CLE = $TABLE->getAttribute('CLE');
    my $NBR_MAPPER = $TABLE->getAttribute('NBR_MAPPER');
    my $REQUETE_MANUELLE = $TABLE->getAttribute('REQUETE');
    
    # ----------------------------------------------------------------------------------------
    # Header
    # ----------------------------------------------------------------------------------------
   
    #my @atenatables = ("ACQ_FLUXOPERATIONEMIS","ACQ_FLUXOPERATIONRECU","VIR_OPERATIONVIREMENT","STRUCTCOMMERCE_NUMERODECOMPTE",
    #           "OPCORE_PARTICIPANTOPERATION","STRUCTCOMMERCE_SERVICEBANCAIRE","PCORE_TRANSACTION","TENUEDEPOSITION_MOUVEMENT",
    #           "OPCORE_CONTREPARTIE","OPCORE_DONNEESREGLEMENT","OPCORE_OPERATION","OPCORE_DONNEESORIGINE");  
    #my $NBR_MAPPER=1;
    #if ( not $NOM_TABLE ~~ @atenatables ) {
    #    $NBR_MAPPER=1;
    #} elsif ( $NOM_TABLE=$atenatables [0] or $NOM_TABLE=$atenatables [1] ) {
    #    $NBR_MAPPER=6; 
    #} elsif ( $NOM_TABLE=$atenatables [2] or $NOM_TABLE=$atenatables [3] ) {
    #   $NBR_MAPPER=4;
    #} elsif ( $NOM_TABLE ~~ $atenatables [-8 .. -1] ) {
    #    $NBR_MAPPER=2;
    #}
   
    my $header = "\n";
    $header =  $header . "#!/usr/bin/env bash\n";
    $header =  $header . "set -o errexit    # Exits when a command fails\n";
    $header =  $header . "set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.\n";
    $header =  $header . "#set -o nounset    # Exits when script tries to use undeclared variables\n";
    $header =  $header . "#set -o xtrace    # Debug\n\n";
    
    $header =  $header . ". \$APPLI_HOME\/appli/connexion/.fonction_bastid_spec \n\n";
    $header =  $header . "if [[ -z \$LOGDIR ]]" . "\n" . "then\n" . "LOGDIR=\$LST" . "\n" . "fi\n\n";
    $header =  $header . "if [[ -z \$LOGFILE ]]" . "\n" . "then\n" . "LOGFILE=\$(basename \"\${BASH_SOURCE[0]}\" | cut -f 1 -d \'.\')_\$(date +\"\%Y\%m\%d_\%H\%M\%S_\%N\").log" . "\n" . "fi\n\n";
    $header =  $header . "#Variables \n";
    
    #$header =  $header . "LAYER=$db; echo \"LAYER=\$LAYER\"\n";
    $header =  $header . "START_DATE=`date +%Y%m%d_%H%M%S`; echo \"START_DATE=\$START_DATE\" \n";
    $header =  $header . "TABLE_NAME=$NOM_TABLE ; echo \"TABLE_NAME=\$TABLE_NAME\"\n";
    $header =  $header . "declare -a __LIST_DATE_OPE=(\'\')\n";
    
    $header =  $header . "echo \"TABLE_NAME : \${TABLE_NAME}\"\n";
    $header =  $header . "echo \"\"\n";
    $header =  $header . "\n";
    
    
    # ----------------------------------------------------------------------------------------
    # Workflow (construction du case when pour alimentation du champ DATE_OPE)
    # ----------------------------------------------------------------------------------------
    
	#Gestion du workflow v1.3
    
    my $work_flow_acq =  "\n\n";
    
    $work_flow_acq =  $work_flow_acq . "echo \"Sélection de l'ID_TRAITEMENT en cours et des timestamp pour construction de la clause where des sqoop en DELTA\"\n";
    $work_flow_acq =  $work_flow_acq . "\n";
    
    $work_flow_acq = $work_flow_acq . "RES=\$(PGPASSWORD=\"\${DL_PG_PWD}\" ON_ERROR_STOP='1' psql -h \"\${DL_PG_ServerAddress}\" -p \"\${DL_PG_Port}\" \"\${DL_PG_Name}\" \"\${DL_PG_UserName}\" -t -A -F',' -c \\\n";
    $work_flow_acq = $work_flow_acq . "\"select max(id_job), min(borne_min), max(borne_max) from \${TOT} \\\n";
    $work_flow_acq = $work_flow_acq . " where projet = '\$PROJET' \\\n";
    $work_flow_acq = $work_flow_acq . "   and application = '$appli' \\\n";
    $work_flow_acq = $work_flow_acq . "   and type_suivi = '\$TYPE_SUIVI_SUIVI' \\\n";
    $work_flow_acq = $work_flow_acq . "   and niveau_suivi = '\$NIVEAU_SUIVI_CATALOGUE' \\\n";
    $work_flow_acq = $work_flow_acq . "   and phase = '\$PHASE_ACQUISITION' \\\n";
    $work_flow_acq = $work_flow_acq . "   and status = '\$ST_ENCOURS' \\\n";
    $work_flow_acq = $work_flow_acq . "   and nom_table = '$NOM_TABLE'\")\n\n";
    
    $work_flow_acq = $work_flow_acq . "ID_TRAITEMENT=\$(echo \"\$RES\" | cut -f1 -d',')\n";
    $work_flow_acq = $work_flow_acq . "TIMESTAMP_MIN=\$(echo \"\$RES\" | cut -f2 -d',')\n";
    $work_flow_acq = $work_flow_acq . "TIMESTAMP_MAX=\$(echo \"\$RES\" | cut -f3 -d',')\n\n";

    $work_flow_acq =  $work_flow_acq . "if [[ -z \$ID_TRAITEMENT ]]" . "\n" . "then\n" . "LOG_ERROR \"Variable ID_TRAITEMENT non positionnée\"" . "\n" . "exit 1". "\n" . "fi\n\n";
    
    $work_flow_acq =  $work_flow_acq . "echo \"ID_TRAITEMENT : \$ID_TRAITEMENT\"\n";
    $work_flow_acq =  $work_flow_acq . "echo \"TIMESTAMP_MIN : \$TIMESTAMP_MIN\"\n";
    $work_flow_acq =  $work_flow_acq . "echo \"TIMESTAMP_MAX : \$TIMESTAMP_MAX\"\n\n";

	$work_flow_acq =  $work_flow_acq . "DATE_INSERT=\$(echo \${ID_TRAITEMENT} | cut -c1-4)\"\-\"\$\(echo \${ID_TRAITEMENT} | cut -c5-6)\"\-\"\$(echo \${ID_TRAITEMENT} | cut -c7-8); echo \"DATE_INSERT=\$DATE_INSERT\" \n";
	$work_flow_acq =  $work_flow_acq . "DATE_INSERT=\$(date -d \"\${DATE_INSERT}\" +\'%Y-%m-%d\'); echo \"DATE_INSERT=\$DATE_INSERT\" \n";
    
    $work_flow_acq =  $work_flow_acq . "echo \"DATE_INSERT : \${DATE_INSERT}\"\n\n";
    
    $work_flow_acq =  $work_flow_acq . "echo \"Sélection des bornes MIN et MAX de chaque DATE_OPE pour construction du CASE WHEN dans le SQOOP Import\"\n";
    $work_flow_acq =  $work_flow_acq . "\n";
    
    $work_flow_acq = $work_flow_acq . "PGPASSWORD=\"\${DL_PG_PWD}\" ON_ERROR_STOP='1' psql -h \"\${DL_PG_ServerAddress}\" -p \"\${DL_PG_Port}\" \"\${DL_PG_Name}\" \"\${DL_PG_UserName}\" -t -A -c \\\n";
    $work_flow_acq = $work_flow_acq . "\"select distinct concat_ws('~', borne_min, borne_max, date_ope) from \${TOT} \\\n";
    $work_flow_acq = $work_flow_acq . " where projet = '\$PROJET' \\\n";
    $work_flow_acq = $work_flow_acq . "   and application = '$appli' \\\n";
    $work_flow_acq = $work_flow_acq . "   and type_suivi = '\$TYPE_SUIVI_SUIVI' \\\n";
    $work_flow_acq = $work_flow_acq . "   and niveau_suivi = '\$NIVEAU_SUIVI_CATALOGUE' \\\n";
    $work_flow_acq = $work_flow_acq . "   and phase = '\$PHASE_ACQUISITION' \\\n";
    $work_flow_acq = $work_flow_acq . "   and status = '\$ST_ENCOURS' \\\n";
    $work_flow_acq = $work_flow_acq . "   and nom_table = '$NOM_TABLE' \\\n";
    $work_flow_acq = $work_flow_acq . " order by 1\" \\\n";
    $work_flow_acq = $work_flow_acq . "> \$LST/catalogue_acq_\$(basename \"\${BASH_SOURCE[0]}\" | cut -f 1 -d \'.\').txt\n\n";
    
    $work_flow_acq =  $work_flow_acq . "echo \"Construction du CASE WHEN dans le SQOOP Import\"\n";
    $work_flow_acq =  $work_flow_acq . "\n";
    
    my $between_condition = "" ;
    my $first_case_cond = "" ;
	if(defined $TYPE && $TYPE eq 'TIMESTAMP')
	  {
	      $between_condition = "to_timestamp(\'\"\$BORNE_MIN\"\', \'YYYY-MM-DD HH24:MI:SS.FF\')  and to_timestamp(\'\"\$BORNE_MAX\"\', \'YYYY-MM-DD HH24:MI:SS.FF\') then \'\"\$VAL_DATE_OPE\"\'\"\n";
	       $first_case_cond = " to_timestamp(\'\"\$FIRST_BORNE_MIN\"\', \'YYYY-MM-DD HH24:MI:SS.FF\') " ;
	  }
	else
	  {
	     $between_condition = "to_date(\'\"\$BORNE_MIN\"\', \'YYYY-MM-DD HH24:MI:SS\')  and to_date(\'\"\$BORNE_MAX\"\', \'YYYY-MM-DD HH24:MI:SS\') then \'\"\$VAL_DATE_OPE\"\'\"\n";
	     $first_case_cond = " to_date(\'\"\$FIRST_BORNE_MIN\"\', \'YYYY-MM-DD HH24:MI:SS\') " ;
	  }

	if($MODE_ALIM eq 'DELTA') {
		$work_flow_acq = $work_flow_acq . "FIRST_BORNE_MIN=\"\$(head -n 1 \$LST/catalogue_acq_\$(basename \"\${BASH_SOURCE[0]}\" | cut -f 1 -d \'.\').txt |  cut -d\"~\" -f1)\"\n";
		$work_flow_acq = $work_flow_acq . "FIRST_DATE_OPE=\"\$(head -n 1 \$LST/catalogue_acq_\$(basename \"\${BASH_SOURCE[0]}\" | cut -f 1 -d \'.\').txt |  cut -d\"~\" -f3)\"\n";
		$work_flow_acq = $work_flow_acq . "NOM_COM=\"$CHAMP_DELTA\"\n";
		$work_flow_acq = $work_flow_acq . "COL_DATE_OPE=\"CASE WHEN \"\$NOM_COM\" \< ". $first_case_cond ." then \'\"\$FIRST_DATE_OPE\"\'\"\n";
		$work_flow_acq = $work_flow_acq . "while read line  \n";
		$work_flow_acq = $work_flow_acq . "do  \n";	
		
		$work_flow_acq = $work_flow_acq . "   BORNE_MIN=\$(echo \$line | cut -d\"~\" -f1)\n";
		$work_flow_acq = $work_flow_acq . "   BORNE_MAX=\$(echo \$line | cut -d\"~\" -f2)\n";	
		$work_flow_acq = $work_flow_acq . "   VAL_DATE_OPE=\$(echo \$line | cut -d\"~\" -f3)\n";
		$work_flow_acq = $work_flow_acq . "   __LIST_DATE_OPE=(\"\${__LIST_DATE_OPE[@]}\" \"\${VAL_DATE_OPE}\")\n";
		$work_flow_acq = $work_flow_acq . "   COL_DATE_OPE=\$COL_DATE_OPE\" WHEN \"\$NOM_COM\" BETWEEN ".$between_condition ;
		$work_flow_acq = $work_flow_acq . "done < \$LST/catalogue_acq_\$(basename \"\${BASH_SOURCE[0]}\" | cut -f 1 -d \'.\').txt\n";
		$work_flow_acq = $work_flow_acq . "COL_DATE_OPE=\$COL_DATE_OPE\" end as DATE_OPE\"\n\n\n";	
	}
	else {
        $work_flow_acq = $work_flow_acq . "COL_DATE_OPE=\"Null as DATE_OPE\"\n\n\n";
	}	
    $work_flow_acq = $work_flow_acq . "echo \"COL_DATE_OPE :\"\n";
    $work_flow_acq = $work_flow_acq . "echo \"\$COL_DATE_OPE\"\n\n";

    
    # ----------------------------------------------------------------------------------------
    # table_suivi1 (count du nombre de ligne à charger pour une table donnée du SIO)
    # ----------------------------------------------------------------------------------------
    
    my $table_suivi1 = "# variable nombre de lignes SQOOP \n";
    
    $table_suivi1 =  $table_suivi1 . "echo \"Calcul du nombre de ligne côté SOURCE\"\n";
    $table_suivi1 =  $table_suivi1 . "\n";

    #Gestion du mode manuel
    if(defined $TYPE && $TYPE eq 'MANUEL')
    {
      $table_suivi1 =  $table_suivi1 . "export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom \n" ;
     $table_suivi1 =  $table_suivi1 . "NB_LIGNES_SQOOP=\$\(echo \$\(sqoop eval -Dmapred.child.java.opts=\"-Djava.security.egd=file:/dev/../dev/urandom\"  $connexion --query \"SELECT 'COUNT_START'||COUNT(*)||'COUNT_END' FROM (";
     $table_suivi1 = $table_suivi1 . $REQUETE_MANUELLE.")";
    }
    #Gestion des balise optionelle pour la clause WHERE
    else
    {
     $table_suivi1 =  $table_suivi1 . "export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom \n" ;
    $table_suivi1 =  $table_suivi1 . "NB_LIGNES_SQOOP=\$\(echo \$\(sqoop eval -Dmapred.child.java.opts=\"-Djava.security.egd=file:/dev/../dev/urandom\"  $connexion --query \"SELECT 'COUNT_START'||COUNT(*)||'COUNT_END' FROM $NOM_TABLE"." WHERE 1=1";
	
	foreach my $CRITERE_CPT ($TABLE->findnodes('CRITERE')) 
        {
            my $CONDITION_CRITERE_CPT = $CRITERE_CPT->getAttribute('CONDITION');
            $table_suivi1 = $table_suivi1 . " AND " . $CONDITION_CRITERE_CPT;
        }
        if(defined $TYPE && $TYPE eq 'DATE')
        {
            $table_suivi1 = $table_suivi1 . " AND to_date(" . $CHAMP_DELTA . ',\'' . $FORMAT_DATE . '\') BETWEEN to_date(\'$TIMESTAMP_MIN\', \'YYYY-MM-DD HH24:MI:SS\') AND to_date(\'$TIMESTAMP_MAX\', \'YYYY-MM-DD HH24:MI:SS\')';
        }
    }

    $table_suivi1 =  $table_suivi1 . "\") |  sed 's/\\(.*\\\)\\\(COUNT_START\\\)\\\([0-9]*\\\)\\\(COUNT_END\\\).*/\\3/')\n";
    
    $table_suivi1 =  $table_suivi1 . "if [[ \$NB_LIGNES_SQOOP == *\"ACCUMULO_HOME\"* ]]" . "\n" . "then\n" . "NB_LIGNES_SQOOP=0" . "\n" . "fi";
    $table_suivi1 =  $table_suivi1 . "\n";
    
    $table_suivi1 =  $table_suivi1 . "echo \"nb lignes sqoop : \${NB_LIGNES_SQOOP}\" \n";
    $table_suivi1 =  $table_suivi1 . "echo \"Log du nombre de lignes sqoop\"\n";
    $table_suivi1 =  $table_suivi1 . "\n";
    $table_suivi1 =  $table_suivi1 . "\n";
    
    $table_suivi1 = $table_suivi1 . "PGPASSWORD=\"\${DL_PG_PWD}\" ON_ERROR_STOP='1' psql -h \"\${DL_PG_ServerAddress}\" -p \"\${DL_PG_Port}\" \"\${DL_PG_Name}\" \"\${DL_PG_UserName}\" -e -c \" \\\n";
    $table_suivi1 = $table_suivi1 . " insert into \$TOT (id_job, type_suivi, projet, application, phase, nom_traitement, nom_table, type_table, nb_lignes, type_log, log) \\\n";
    $table_suivi1 = $table_suivi1 . " values ('\$ID_TRAITEMENT', '\$TYPE_SUIVI_LOG', '\$PROJET', '$appli', '\$PHASE_ACQUISITION', '\$(basename \"\${BASH_SOURCE[0]}\")', '\$TABLE_NAME', '$MODE_ALIM', '\$NB_LIGNES_SQOOP', 'COUNT SIO', 'Nombre de ligne côté SIO pour cette acquisition')\"\n";
    
    # ----------------------------------------------------------------------------------------
    # Réinitialisation de la table de la Landing Layer
    # ----------------------------------------------------------------------------------------

    my $commande_hive = "#Commande hive pour réinitialiser la table " . lc($NOM_TABLE) . " de chargement\n";
    $commande_hive =  $commande_hive . "echo \"Drop et recréation de la table cible \"\n";
    $commande_hive =  $commande_hive . "\n";
    
    my $drop_table  =  "    DROP TABLE IF EXISTS $db\." . $NOM_TABLE . ";\n\n";
    my $create_table = "    CREATE TABLE IF NOT EXISTS $db\." . $NOM_TABLE . "\n    (\n";
    
    #Gestion des colonnes de la table
    foreach my $COLONNE ($TABLE->findnodes('COLONNE')) 
    {
        #Récupération des balises globales de la colonne
        my $NOM_COLONNE = "\\`".$COLONNE->getAttribute('NOM')."\\`";
        my $TYPE_COLONNE = $COLONNE->getAttribute('TYPE_DEST');
        
        #Complétion du create et de la requete avec les informations de la colonne
        $create_table = $create_table . "        " . $NOM_COLONNE . " " . $TYPE_COLONNE . ",\n";
    }
    
	$create_table = $create_table . "        DATE_OPE DATE, ";
    $create_table = $create_table . "        DATE_INSERT DATE " . "\n";
    
    #Completion des variables HIVE
    $create_table = substr($create_table,0,length($create_table) - 2);
    $create_table = $create_table . "\n    )\n    PARTITIONED BY (ID_TRAITEMENT STRING)\n    STORED AS ORC\n    LOCATION '$hdfsldl" . lc($NOM_TABLE) . "';\n\n";
    
    $commande_hive = $commande_hive . "hive -hiveconf tez.queue.name=\$ACQ_QUEUE -hiveconf hive.cli.errors.ignore=true \\\n-e \"\n\n";
    $commande_hive = $commande_hive . $drop_table . $create_table . "\"\n\n";
    
    
    # ----------------------------------------------------------------------------------------
    # Import des données du SIO dans la Landing
    # ----------------------------------------------------------------------------------------

    #Initialisation de la de construction de la requete SQL
    my $requete = 'SELECT ';
    
	#Gestion des colonnes de la table
    foreach my $COLONNE ($TABLE->findnodes('COLONNE')) 
    {
        #Récupération des balises globales de la colonne
	my $NOM_COLONNE = "\"".$COLONNE->getAttribute('NOM')."\"";
        my $TYPE_COLONNE = $COLONNE->getAttribute('TYPE_DEST');
	 my $NOM_SOURCE=$COLONNE->getAttribute('NOM_SRC');
        
        #Complétion du create et de la requete avec les informations de la colonne
	if(defined $NOM_SOURCE)
         {
	    $requete = $requete . $NOM_SOURCE ." as ".$NOM_COLONNE. ", "}
	else {
	  $requete = $requete . $NOM_COLONNE . ", "
	}
    }

	#Gestion des 2 colonnes fixes ID_TRAITEMENT, DATE_OPE, DATE_INSERT	
    $requete = $requete . "\$COL_DATE_OPE" . ", ";
	$requete = $requete . "'\${DATE_INSERT}' as DATE_INSERT, ";
	$requete = $requete . "'\${ID_TRAITEMENT}' as ID_TRAITEMENT   ";	
	
    #Completion de la requete avec les clauses FROM et WHERE 
    $requete = substr($requete,0,length($requete) - 2);
    $requete = $requete . "\n         FROM $NOM_TABLE\n         WHERE 1=1";
    
    #Gestion du mode manuel
    if(defined $TYPE && $TYPE eq 'MANUEL')
    {
        $requete = $REQUETE_MANUELLE;
        $NBR_MAPPER = 1;
    }
    #Gestion des balise optionelle pour la clause WHERE
    else
    {
        #
        foreach my $CRITERE ($TABLE->findnodes('CRITERE')) 
        {
            my $CONDITION_CRITERE = $CRITERE->getAttribute('CONDITION');
            $requete = $requete . "\n         AND " . $CONDITION_CRITERE;
        }
        if(defined $TYPE && $TYPE eq 'DATE')
        {
            $requete = $requete . "\n         AND to_date(" . $CHAMP_DELTA . ',\'' . $FORMAT_DATE . '\') BETWEEN to_date(\'$TIMESTAMP_MIN\', \'YYYY-MM-DD HH24:MI:SS\') AND to_date(\'$TIMESTAMP_MAX\', \'YYYY-MM-DD HH24:MI:SS\')';
        }
		
    }
    

    #Initialisation des variables de construction des commandes SQOOP (eval qui teste la validité de la requete et import qui importe des données du SIO vers le cluster)
    my $sqoop_eval = "sqoop eval  \\\n" . $connexion;  

    #Completion des variables SQOOP
    $sqoop_eval = $sqoop_eval . "--query \"$requete\"" ;

    my $sqoop_import = "sqoop import -Dmapred.child.java.opts=\"-Djava.security.egd=file:/dev/../dev/urandom\" -Dmapred.job.queue.name=\$ACQ_QUEUE $connexion \\\n"; 
    $sqoop_import = $sqoop_import . "--query \"$requete\n         AND \\\$CONDITIONS\" \\\n" ;
    $sqoop_import = $sqoop_import . "--hcatalog-table $NOM_TABLE \\\n" ;
     if(defined $CLE )
     {
       $sqoop_import = $sqoop_import . "--split-by $CLE \\\n" ;
     }
    $sqoop_import = $sqoop_import . "--hcatalog-database $db \\\n" ;
    $sqoop_import = $sqoop_import . "--hive-partition-key id_traitement \\\n" ;
    $sqoop_import = $sqoop_import . "--hive-partition-value \${ID_TRAITEMENT} \\\n" ;
    $sqoop_import = $sqoop_import . "--num-mappers $NBR_MAPPER \n\n";


    # ----------------------------------------------------------------------------------------
    # table_suivi2 (Log du nombre de lignes côté Landing Layer)
    # ----------------------------------------------------------------------------------------

	my $table_suivi2 = "\n";
	
	$table_suivi2 =  $table_suivi2 . "#INITIALISATION END_DATE \n";
	$table_suivi2 =  $table_suivi2 . "END_DATE=`date +%Y%m%d_%H%M%S` \n";
	
	$table_suivi2 =  $table_suivi2 . "\n";
	
	$table_suivi2 =  $table_suivi2 . "# Variable nb lignes HIVE \n";
	$table_suivi2 =  $table_suivi2 . "NB_LIGNES_HIVE=\$(hive --hiveconf tez.queue.name=\$ACQ_QUEUE -S -e \"SELECT count(*) from $db\.$NOM_TABLE"."\") \n";
	$table_suivi2 =  $table_suivi2 . "\n\n";

    $table_suivi2 = $table_suivi2 . "PGPASSWORD=\"\${DL_PG_PWD}\" ON_ERROR_STOP='1' psql -h \"\${DL_PG_ServerAddress}\" -p \"\${DL_PG_Port}\" \"\${DL_PG_Name}\" \"\${DL_PG_UserName}\" -c \" \\\n";
    $table_suivi2 = $table_suivi2 . " insert into \$TOT (id_job, type_suivi, projet, application, phase, nom_traitement, nom_table, type_table, nb_lignes, type_log, log) \\\n";
    $table_suivi2 = $table_suivi2 . " values ('\$ID_TRAITEMENT', '\$TYPE_SUIVI_LOG', '\$PROJET', '$appli', '\$PHASE_ACQUISITION', '\$(basename \"\${BASH_SOURCE[0]}\")', '\$TABLE_NAME', '$MODE_ALIM', '\$NB_LIGNES_HIVE', 'COUNT BASTID Landing Layer', 'Nombre de ligne côté BASTID Landing Layer pour cette acquisition')\"\n";
    
    # ----------------------------------------------------------------------------------------
    # table_ok (ne gere plus que le cas NB_LIGNES_SQOOP != NB_LIGNES_HIVE => ERREUR)
    # ----------------------------------------------------------------------------------------
    
    my $table_ok = "# Gestion du cas NB_LIGNES_SQOOP != NB_LIGNES_HIVE => ERREUR\n";
	$table_ok = $table_ok . "echo \"NB LIGNES HIVE = \${NB_LIGNES_HIVE}\"";
    $table_ok = $table_ok . "\n";
    $table_ok = $table_ok . "if [[ \$NB_LIGNES_SQOOP != \$NB_LIGNES_HIVE ]]\n";
    $table_ok = $table_ok . "then \n";
        
    # Mise à jour du statut des DATE_OPE dans le catalogue à ERREUR
    $table_ok = $table_ok . "    REQ=\"  update \$TOT\"\n";
    $table_ok = $table_ok . "    REQ+=\" set status = '\${ST_ERROR}'\"\n";
    $table_ok = $table_ok . "    REQ+=\" where\"\n";
    $table_ok = $table_ok . "    REQ+=\"     type_suivi = '\${TYPE_SUIVI_SUIVI}'\"\n";
    $table_ok = $table_ok . "    REQ+=\"     and niveau_suivi = '\${NIVEAU_SUIVI_CATALOGUE}'\"\n";
    $table_ok = $table_ok . "    REQ+=\"     and projet = '\${PROJET}'\"\n";
    $table_ok = $table_ok . "    REQ+=\"     and application = '$appli'\"\n";
    $table_ok = $table_ok . "    REQ+=\"     and phase = '\${PHASE_ACQUISITION}'\"\n";
    $table_ok = $table_ok . "    REQ+=\"     and nom_table = '${NOM_TABLE}'\"\n";
    $table_ok = $table_ok . "    REQ+=\"     and status = '\${ST_ENCOURS}'\"\n";
    $table_ok = $table_ok . "    PGPASSWORD=\"\${DL_PG_PWD}\" ON_ERROR_STOP='1' psql -h \"\${DL_PG_ServerAddress}\" -p \"\${DL_PG_Port}\" -e \"\${DL_PG_Name}\" \"\${DL_PG_UserName}\" -c \"\$REQ\"\n";
    $table_ok = $table_ok . "    exit 1\n";	
    $table_ok = $table_ok . "fi \n";	
    $table_ok = $table_ok . "\n";
	
   
#Ecriture dans un .sh des commandes construite si l'évaluation de la requete a été un succès ou en écriture forcé (balise EVAL='NON')
#    if($EVAL eq 'OUI' && system("$sqoop_eval"))
    {
        open (FICHIER, ">" , $repsqoop . "acq_sqoop_" . lc($NOM_TABLE) . ".sh") || die ("Vous ne pouvez pas créer le fichier ");
		
		print FICHIER $header;
		print FICHIER $work_flow_acq;
		print FICHIER $table_suivi1;
        print FICHIER $commande_hive;
		print FICHIER $sqoop_import;
		print FICHIER $table_suivi2;
		print FICHIER $table_ok;

        close (FICHIER);
    }
#    else
#    {
#    
#    }

}
