SELECT
   XMLELEMENT
   (
      "SGBD", 
      XMLFOREST('ORC' "FORMAT_SORTIE"),
      XMLAGG
      (
         XMLELEMENT
         (
            "TABLE",
            XMLATTRIBUTES(table_name "NOM",
                                                               'OUI' "EVAL",
                                                               '1' "NBR_MAPPER",
                (
                select c.column_name as column_name from (
                  select 
                      a.table_name,
                      FIRST_VALUE(a.column_name) over (partition by a.table_name ORDER BY a.constraint_name ASC ROWS UNBOUNDED PRECEDING) as column_name
                  from all_cons_columns a
                  inner join all_constraints b on a.constraint_name= b.constraint_name
                  where b.constraint_type = 'P') c
                  where c.table_name = all_tab_cols.table_name
                  group by c.column_name
                  )
             "CLE",
                CASE
                     WHEN table_name like  'FAIT_%'  THEN 'DELTA'
                     ELSE 'COMPLET'
                     END  "MODE_ALIM"
			,
				CASE
					 WHEN table_name like  'FAIT_%'  
					 THEN 'to_date(NUM_FICH,''YYYYMMDD'')'
                     END "CHAMP_SRC"
            ,
				CASE
					 WHEN table_name like  'FAIT_%'  
					 THEN 'MANUEL'
                     END "TYPE"
			,
				CASE
					 WHEN table_name =  'FAIT_MINOS_OPERATIONS'  
					 THEN ' FAIT_MINOS_OPERATIONS M INNER JOIN 
							(select distinct DATE_RGLMT
								from SUIVI_MAEVA_RECAP
								WHERE DATE_RECEPT >=to_date(''$TIMESTAMP_MIN'', ''YYYY-MM-DD HH24:MI:SS'') AND DATE_RECEPT <to_date(''$TIMESTAMP_MAX'', ''YYYY-MM-DD HH24:MI:SS'')
							    AND TYPE_FICHIER=''OM'') S 
								ON 
								(M.DATE_REGLMT=S.DATE_RGLMT)
						WHERE to_date(M.NUM_FICH,''YYYYMMDD'')>=to_date(''$TIMESTAMP_MIN'', ''YYYY-MM-DD HH24:MI:SS'') AND to_date(M.NUM_FICH,''YYYYMMDD'')<to_date(''$TIMESTAMP_MAX'', ''YYYY-MM-DD HH24:MI:SS'')' 
					 WHEN table_name =  'FAIT_SEPA_OPERATION'  
					 THEN ' FAIT_MINOS_OPERATIONS M INNER JOIN 
							(select distinct DATE_RGLMT
								from SUIVI_MAEVA_RECAP
								WHERE DATE_RECEPT >=to_date(''$TIMESTAMP_MIN'', ''YYYY-MM-DD HH24:MI:SS'') AND DATE_RECEPT <to_date(''$TIMESTAMP_MAX'', ''YYYY-MM-DD HH24:MI:SS'')
							    AND TYPE_FICHIER=''OS'') S 
								ON
								(M.DATE_REGLMT=S.DATE_RGLMT)
						WHERE to_date(M.NUM_FICH,''YYYYMMDD'')>=to_date(''$TIMESTAMP_MIN'', ''YYYY-MM-DD HH24:MI:SS'') AND to_date(M.NUM_FICH,''YYYYMMDD'')<to_date(''$TIMESTAMP_MAX'', ''YYYY-MM-DD HH24:MI:SS'')' 
                     END "REQUETE"
		    
            ),
            XMLAGG(XMLELEMENT("COLONNE",XMLATTRIBUTES(
                      replace(decode(column_name,'DATE_INSERT','DATE_INSERT_INGRE',column_name),'$','\$') "NOM", 
                      data_type "TYPE_SRC",
                      CASE
                        WHEN (data_type = 'VARCHAR2') THEN 'STRING'
						WHEN (data_type = 'CHAR') THEN 'STRING'
                        WHEN (data_type = 'CLOB') THEN 'STRING'
                        WHEN (data_type = 'BLOB') THEN 'BINARY'
                       	WHEN (data_type = 'TIMESTAMP(6)') THEN 'TIMESTAMP'
						WHEN (data_type = 'NUMBER') AND (data_scale !='0') THEN concat('DECIMAL(',concat(data_precision,concat(',',concat(data_scale,')'))))
						WHEN (data_type = 'NUMBER') AND (data_scale ='0') AND (data_precision < 10) THEN 'INT'
						WHEN (data_type = 'NUMBER') AND (data_scale ='0') AND (data_precision > 9 ) AND (data_precision < 19 ) THEN 'BIGINT'
						WHEN (data_type = 'NUMBER') AND (data_scale ='0') AND (data_precision > 18 ) THEN concat('DECIMAL(',concat(data_precision,',0)'))
                        WHEN (data_type = 'FLOAT') THEN 'double'
                      ELSE data_type
                      END as TYPE_DEST

              ))),CHR(10),' '
         )
      )
  )
FROM
   all_tab_cols
where table_name in
                ('DIM_MAEVA_TYPE_OPERATION',
				 'REF_INGRE_FAM_OPERATION',
				 'DIM_MAEVA_COMPTE',
				 'DIM_MAEVA_CLIENT',
				 'REF_INGRE_GRP_REMETTANT',
				 'FAIT_SEPA_OPERATION' , 
				 'FAIT_MINOS_OPERATIONS'
				 )
and column_id is not null 
GROUP BY
   table_name;


