# $1 : <dossier dans lequel sont g�n�r�s les shell sqoop>
# $1 : <chemin complet du fichier xml de conf du g�n�rateur>
# $1 : <nom de la base Landing>
# $1 : <cha�ne de connection SIO pour les instructions sqoop>
# $1 : <nom de l'appli tel que renseign� dans la TOT>

#acq_generateur_sqoop.pl    "$EVO_SQOOP_SCR_PATH" \
#                           "$EVO_XML_SIO_PATH" \
#                           "$EVO_HIVEDB_LDL" \
#                           "--connect ${EVO_ORA_CXN} --username ${EVO_ORA_USER} --password ${EVO_ORA_PAS}" \
#                           "$EVO_APPLI_NAME"
acq_generateur_sqoop.pl     "${EVO_SQOOP_SCR_PATH}" \
                            "./conf/evolmpm.xml" \
                            "$EVO_HIVEDB_LDL" \
                            "--connect \"\${EVO_ORA_CXN}\" --username \${EVO_ORA_USER} --password \${EVO_ORA_PWD}" \
                            "$EVO_APPLI_NAME" \
                            "\"\$EVO_SRC_HDFS_LDL\""
