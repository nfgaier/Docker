#!/usr/bin/env bash
###############################################################################
# Description : any empty file on hdfs in a partiton will make a spark traitment fail.
#               As a sqoop import with 0 line create an empty file in the table partition, we need to scan and remove those files after an acquisition. 
# Usage : To be launch after the pilot on any acquisition
# Author : LCO
# Updated : 11/01/2018
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec            #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  


if [[ $# != 2 ]] ; then
    echo "Ce traitement attend deux parametres : <REP_CONF> <NOM_TRAITEMENT>"
    exit ${__FAILURE}
fi

REP_CONF="$1"
NOM_TRAITEMENT="$2"

REP_TMP="$REPBDF/common/tmp"
VAR_APPLI=''
VAR_PHASE=''


SCAN_HDFS () {

    # lister les fichiers dans la partition en cours
    REP_PART_HDFS="${REP_DB_HDFS}$(echo ${TABLE} | tr [:upper:] [:lower:])/id_traitement=${ID_TRAITEMENT}"
    LOG_INFO "Scan de $REP_PART_HDFS"
    hdfs dfs -ls -C "${REP_PART_HDFS}"  >> "${FIC_LIST_TMP}"
    
}

#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  START
  
  SETUP
  
    LOG_INFO "Lecture des parametres dans ${REP_CONF}/${PARAM_BATCH}"
    
    READ_BATCH_PARAM "${REP_CONF}/${PARAM_BATCH}" "APPLI" "VAR_APPLI"
    READ_BATCH_PARAM "${REP_CONF}/${PARAM_BATCH}" "PHASE" "VAR_PHASE"
    
    LOG_INFO "PROJET :                          ${PROJET}"
    LOG_INFO "APPLI :                           ${VAR_APPLI}"
    LOG_INFO "PHASE :                           ${VAR_PHASE}"
    LOG_INFO "TRAITEMENT :                      ${NOM_TRAITEMENT}"
    
    LOG_INFO ""
    LOG_INFO "==================================================================="
    LOG_INFO "Nettoyage des partitions hdfs apr�s le traitement $NOM_TRAITEMENT "
    LOG_INFO "==================================================================="
    LOG_INFO ""
    
    # ID_TRAITEMENT en cours
    GET_ID_TRT "$VAR_APPLI" "$VAR_PHASE" "$NOM_TRAITEMENT" "ID_TRAITEMENT"
    LOG_INFO ""
    
    # Liste des tables cibles du traitement
    GET_LIST_TABLE "${NOM_TRAITEMENT}" "${REP_CONF}/${DEPENDANCES}" "CIBLE" "TVAR_DEP_AVAL_DELTA" "TVAR_DEP_AVAL_FULL"
    LOG_INFO ""
    
    # En fonction de l'appli, dossier HDFS � nettoyer
    case $VAR_APPLI in
        'EMBARGO') REP_DB_HDFS="$EMB_SRC_HDFS_LDL" ;;
        'EVOLMPM') REP_DB_HDFS="$EVO_SRC_HDFS_LDL" ;;
        *)
            LOG_ERROR "Le path HDFS de $VAR_APPLI n'est pas configur�"
            exit ${__FAILURE}
            ;;
    esac
    
    # Si un dossier tmp n'existe pas, on le cr�e
    if [[ ! -d $REP_TMP ]]
    then
        mkdir $REP_TMP
        chmod 750 $REP_TMP
    fi
    
    # R�init du fichier tmp contenant la liste des fichiers � analyser
    FIC_LIST_TMP="${REP_TMP}/${VAR_APPLI}_${VAR_PHASE}_${NOM_TRAITEMENT}_lst.tmp"
    cat /dev/null > "$FIC_LIST_TMP"
    
    for TABLE in ${TVAR_DEP_AVAL_DELTA[*]}
    do
        SCAN_HDFS $TABLE
    done

    for TABLE in ${TVAR_DEP_AVAL_FULL[*]}
    do
        SCAN_HDFS $TABLE
    done
    
    # pour chaque fichier
    set +o errexit
    while read FILE
    do
        # plante si dossier
        hdfs dfs -test -d $FILE
        if [[ $? == 0 ]]
        then
            LOG_ERROR "$FILE est un dossier"
            exit ${__FAILURE}
        fi
        # v�rification taille
        hdfs dfs -test -z $FILE
        if [[ $? == 0 ]]
        then
            LOG_INFO "$FILE est vide : suppression"
            hdfs dfs -rm $FILE
        else
            LOG_INFO "$FILE n'est pas vide"
        fi
    done < $FIC_LIST_TMP
    set -o errexit
    
  END
  
  exit ${__SUCCESS}
  
}

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
