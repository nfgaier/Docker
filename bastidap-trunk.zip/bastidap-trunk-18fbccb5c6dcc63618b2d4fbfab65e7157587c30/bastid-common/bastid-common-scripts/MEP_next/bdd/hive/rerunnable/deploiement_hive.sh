#!/usr/bin/env bash
###############################################################################
# Description : launch hive deploiement of BASTD MEP V1.0
# Usage : 
# Author : L.COQUET
# Updated : 
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec                        #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  


#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  START
  
  SETUP
  
    REPLIV=${__DIR}

#    LOG_INFO "-------------------------------------------------------------------------"
#    LOG_INFO "   Execution de create_suivi_acq.hql"
#    LOG_INFO "-------------------------------------------------------------------------"

#    hive    -f ${REPLIV}/create_suivi_acq_test.hql \
#            -hiveconf tez.queue.name=${TRT_QUEUE} \
#            -hiveconf database=${EMB_HIVEDB_COM} \
#            -hiveconf rep_hdfs=${EMB_SRC_HDFS_WKL}/bastid_common
		
			
  END
  
  exit ${__SUCCESS}
  
}

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
