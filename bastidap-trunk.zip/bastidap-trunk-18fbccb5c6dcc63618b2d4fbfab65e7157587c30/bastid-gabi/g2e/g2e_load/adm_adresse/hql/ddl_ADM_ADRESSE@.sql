! echo "DDL table g2e_shared_layer.adm_adresse";

DROP TABLE IF EXISTS g2e_shared_layer.adm_adresse;

CREATE EXTERNAL TABLE IF NOT EXISTS g2e_shared_layer.adm_adresse (
    ID_ADM_ADRESSE STRING COMMENT 'Clé primaire',
    ID_ADM_PERSONNE STRING COMMENT 'Clé étrangère (ADM_PERSONNE)',
    TYPE_ADRESSE STRING COMMENT 'Type d''adresse',
    DESTINATAIRE STRING COMMENT 'Destinataire',
    SUITE_IDENTIFICATION STRING COMMENT 'Complément d''identification',
    DT_DEBUT_VALIDITE DATE COMMENT 'Date de début de validité',
    DT_FIN_VALIDITE DATE COMMENT 'Date de fin de validité',
    VERSION TIMESTAMP COMMENT 'Version',
    T_NOM_SOURCE STRING COMMENT 'G2E',
    T_DT_SOURCE TIMESTAMP COMMENT 'Date systme au format AAAA-MM-JJ HH:MM:SS',
    T_ID_FICHIER_SOURCE STRING COMMENT 'Numro de fichier du premier enregistrement de lentte.',
    T_NB_FICHIERS_ARCHIVE_SOURCE STRING COMMENT 'Nombre de fichiers dans larchive',
    T_NOM_TABLE_SOURCE STRING COMMENT 'Nom de la table extraite.',
    T_NB_LIGNES_SOURCE INT COMMENT 'Nombre denregistrements du fichier (y compris les enregistrements dentte et de fin)',
    T_TS_DEB_EXTRACTION_SOURCE TIMESTAMP COMMENT 'Date et heure de dbut dextraction au format AAAA-MM-JJ HH:MM:SS. Cette zone est renseigne y compris pour les fichiers dextraction en mode total.',
    T_TS_FIN_EXTRACTION_SOURCE TIMESTAMP COMMENT 'Date et heure de fin dextraction au format AAAA-MM-JJ HH:MM:SS. Cette zone est renseigne y compris pour les fichiers dextraction en mode total.',
    T_NOM_FICHIER_SOURCE STRING COMMENT 'Nom du fichier de données'
    ) 
PARTITIONED BY (
    T_CD_DATE_PART_SOURCE STRING COMMENT 'Date de cration du fichier utilis pour le partitionnement de la table cible AAAA-MM-JJ',
    T_NOM_ARCHIVE_SOURCE STRING COMMENT 'Nom de larchive  contenant le fichier de donnes'
 )
STORED AS ORC 
    LOCATION '/data/source/${G2E_SRC_FOLDER}/work_layer/g2e_shared/adm_adresse';

    
! echo "DDL table g2e_shared_layer.adm_adresse_hist";
    
DROP TABLE IF EXISTS g2e_shared_layer.adm_adresse_hist;

CREATE EXTERNAL TABLE IF NOT EXISTS g2e_shared_layer.adm_adresse_hist (
    ID_ADM_ADRESSE_HIST STRING COMMENT 'Clé primaire',
    ID_ADM_PERSONNE STRING COMMENT 'Clé étrangère (ADM_PERSONNE)',
    TYPE_ADRESSE STRING COMMENT 'Type d''adresse',
    DESTINATAIRE STRING COMMENT 'Destinataire',
    SUITE_IDENTIFICATION STRING COMMENT 'Complément d''identification',
    DT_DEBUT_VALIDITE DATE COMMENT 'Date de début de validité',
    DT_FIN_VALIDITE DATE COMMENT 'Date de fin de validité',
    VERSION TIMESTAMP COMMENT 'Version',
    T_NOM_SOURCE STRING COMMENT 'G2E',
    T_DT_SOURCE TIMESTAMP COMMENT 'Date systme au format AAAA-MM-JJ HH:MM:SS',
    T_ID_FICHIER_SOURCE STRING COMMENT 'Numro de fichier du premier enregistrement de lentte.',
    T_NB_FICHIERS_ARCHIVE_SOURCE STRING COMMENT 'Nombre de fichiers dans larchive',
    T_NOM_TABLE_SOURCE STRING COMMENT 'Nom de la table extraite.',
    T_NB_LIGNES_SOURCE INT COMMENT 'Nombre denregistrements du fichier (y compris les enregistrements dentte et de fin)',
    T_TS_DEB_EXTRACTION_SOURCE TIMESTAMP COMMENT 'Date et heure de dbut dextraction au format AAAA-MM-JJ HH:MM:SS. Cette zone est renseigne y compris pour les fichiers dextraction en mode total.',
    T_TS_FIN_EXTRACTION_SOURCE TIMESTAMP COMMENT 'Date et heure de fin dextraction au format AAAA-MM-JJ HH:MM:SS. Cette zone est renseigne y compris pour les fichiers dextraction en mode total.',
    T_NOM_FICHIER_SOURCE STRING COMMENT 'Nom du fichier de données'
    ) 
PARTITIONED BY (
    T_CD_DATE_PART_SOURCE STRING COMMENT 'Date de cration du fichier utilis pour le partitionnement de la table cible AAAA-MM-JJ',
    T_NOM_ARCHIVE_SOURCE STRING COMMENT 'Nom de larchive  contenant le fichier de donnes'
 )
STORED AS ORC 
    LOCATION '/data/source/${G2E_SRC_FOLDER}/work_layer/g2e_shared/adm_adresse_hist';
    