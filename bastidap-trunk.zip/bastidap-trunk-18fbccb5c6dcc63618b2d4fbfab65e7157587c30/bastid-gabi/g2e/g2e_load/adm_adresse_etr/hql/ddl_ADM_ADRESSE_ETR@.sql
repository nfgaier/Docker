! echo "DDL table adm_adresse_etr";

DROP TABLE IF EXISTS g2e_shared_layer.adm_adresse_etr;

CREATE EXTERNAL TABLE IF NOT EXISTS g2e_shared_layer.adm_adresse_etr(
    ID_ADM_ADRESSE STRING COMMENT 'Clé étrangère (ADM_ADRESSE)',
    COMPLEMENT_1 STRING COMMENT 'Complément d''adresse 1',
    COMPLEMENT_2 STRING COMMENT 'Complément d''adresse 2',
    VOIE STRING COMMENT 'Nom de la voie',
    LOCALITE STRING COMMENT 'Localité',
    PAYS STRING COMMENT 'Pays',
    ID_PAYS STRING COMMENT 'Identifiant technique du pays (destiné à l''alimentation de STAR2)',
    CODE_INSEE STRING COMMENT 'Code INSEE',
    PAYS_FICOBA STRING COMMENT 'Libellé du pays associé au code INSEE (destiné à l''alimentation de FICOBA)',
    CD_PAYS STRING COMMENT 'Code ISO du pays (destiné à l''alimentation du fichier TREFLE)',
    VERSION TIMESTAMP COMMENT 'Champ version de la table ADM_ADRESSE',
    T_NOM_SOURCE STRING COMMENT  'Application émettrice',
    T_DT_SOURCE TIMESTAMP COMMENT  'Date de création du fichier + heure',
    T_ID_FICHIER_SOURCE STRING COMMENT  'Numéro fichier',
    T_NB_FICHIERS_ARCHIVE_SOURCE STRING COMMENT  'Nombre de fichiers',
    T_NOM_TABLE_SOURCE STRING COMMENT  'Libellé valeur',
    T_NB_LIGNES_SOURCE INT COMMENT  'Nombre de données extraites',
    T_TS_DEB_EXTRACTION_SOURCE TIMESTAMP COMMENT  'Date début extraction',
    T_TS_FIN_EXTRACTION_SOURCE TIMESTAMP COMMENT  'Date fin extraction',
    T_NOM_FICHIER_SOURCE STRING COMMENT  'Nom du fichier ' ) 
PARTITIONED BY (
    T_CD_DATE_PART_SOURCE STRING COMMENT 'Date de cration du fichier utilis pour le partitionnement de la table cible AAAA-MM-JJ',    
    T_NOM_ARCHIVE_SOURCE STRING COMMENT 'Nom de larchive  contenant le fichier de donnes'
 )
STORED AS ORC LOCATION '/data/source/${G2E_SRC_FOLDER}/work_layer/g2e_shared/adm_adresse_etr';


! echo "DDL table adm_adresse_etr_hist";

DROP TABLE IF EXISTS g2e_shared_layer.adm_adresse_etr_hist;

CREATE EXTERNAL TABLE IF NOT EXISTS g2e_shared_layer.adm_adresse_etr_hist(
    ID_ADM_ADRESSE STRING COMMENT 'Clé étrangère (ADM_ADRESSE)',
    COMPLEMENT_1 STRING COMMENT 'Complément d''adresse 1',
    COMPLEMENT_2 STRING COMMENT 'Complément d''adresse 2',
    VOIE STRING COMMENT 'Nom de la voie',
    LOCALITE STRING COMMENT 'Localité',
    PAYS STRING COMMENT 'Pays',
    ID_PAYS STRING COMMENT 'Identifiant technique du pays (destiné à l''alimentation de STAR2)',
    CODE_INSEE STRING COMMENT 'Code INSEE',
    PAYS_FICOBA STRING COMMENT 'Libellé du pays associé au code INSEE (destiné à l''alimentation de FICOBA)',
    CD_PAYS STRING COMMENT 'Code ISO du pays (destiné à l''alimentation du fichier TREFLE)',
    VERSION TIMESTAMP COMMENT 'Champ version de la table ADM_ADRESSE',
    T_NOM_SOURCE STRING COMMENT  'Application émettrice',
    T_DT_SOURCE TIMESTAMP COMMENT  'Date de création du fichier + heure',
    T_ID_FICHIER_SOURCE STRING COMMENT  'Numéro fichier',
    T_NB_FICHIERS_ARCHIVE_SOURCE STRING COMMENT  'Nombre de fichiers',
    T_NOM_TABLE_SOURCE STRING COMMENT  'Libellé valeur',
    T_NB_LIGNES_SOURCE INT COMMENT  'Nombre de données extraites',
    T_TS_DEB_EXTRACTION_SOURCE TIMESTAMP COMMENT  'Date début extraction',
    T_TS_FIN_EXTRACTION_SOURCE TIMESTAMP COMMENT  'Date fin extraction',
    T_NOM_FICHIER_SOURCE STRING COMMENT  'Nom du fichier ' ) 
PARTITIONED BY (
     T_CD_DATE_PART_SOURCE STRING COMMENT 'Date de cration du fichier utilis pour le partitionnement de la table cible AAAA-MM-JJ', 
     T_NOM_ARCHIVE_SOURCE STRING COMMENT 'Nom de larchive  contenant le fichier de donnes'
 )
STORED AS ORC LOCATION '/data/source/${G2E_SRC_FOLDER}/work_layer/g2e_shared/adm_adresse_etr_hist';
