#!/usr/bin/env bash

###############################################################################
# Description : chain script adm_personne_gabi
# Usage : adm_personne_gabi.sh <file_name> <file_dir> <archive_name>
# Author : Umanis for BDF
# Updated : 01/10/2016
###############################################################################
set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

__DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" 
__FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")" 
__BASE="$(basename ${__FILE} .sh)"                    

#######################################
# Description: setup function setting variables
# Arguments: <file_name> <file_dir> <archive_name>
# Returns: 0 for success, 1 for failure
#######################################
setup () {

  table_name='adm_personne_gabi'
  pig_script_name='load_ADM_PERSONNE_GABI@.pig'
  hive_script_name=''

  log_dir="${ETLLOADLOG}/"
  table_hist_name=${table_name}'_hist'
  pig_script_dir="${ETLLOADHOME}/${table_name}/pig/"
  hive_script_dir="${ETLLOADHOME}/${table_name}/hql/"
  hive_database_name=${GABISL}
  queue_name=${ACQ_QUEUE}
 GABI_SRC_FOLDER=${GABI_SRC_FOLDER}
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : table_name : "${table_name}
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : table_hist_name : "${table_hist_name}
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : hive_database_name : "${hive_database_name}
    
}

#######################################
# Description: chain function executing scripts
# Arguments: none
# Returns: 0 for success, 1 for failure
#######################################
chain() {
  
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Running pig -useHCatalog -l ${log_dir} -f ${pig_script_dir}${pig_script_name}"
  export PIG_OPTS="-Dmapred.job.queue.name=$queue_name"
  pig -useHCatalog -l "${log_dir}"  -f "${pig_script_dir}""${pig_script_name}" -param table_name=${table_name} \
                                                                               -param table_hist_name=${table_hist_name} \
								               -param GABI_SRC_FOLDER=${GABI_SRC_FOLDER} \
                                                                               -param database_name=${hive_database_name}
    
}          

#######################################
# Description: main function
# Arguments: <file_name> <file_dir> <archive_name>
# Returns: 0 for success, 1 for failure
#######################################
main () {

  setup 
  
  chain
}
                                                          
main "$@"                                                                    

