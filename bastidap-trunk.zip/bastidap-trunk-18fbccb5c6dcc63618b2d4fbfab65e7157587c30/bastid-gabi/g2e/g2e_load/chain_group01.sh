#!/usr/bin/env bash
###############################################################################
# Description : 
# Usage : 
# Author : Umanis for BDF
# Updated : 01/08/2016
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
#set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

__DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" 
__FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")" 
__BASE="$(basename ${__FILE} .sh)"  
__FAIL=0                  
readonly global_timestamp=$(date +"%Y%m%d_%H%M%S_%N")

#######################################
# Description: 
# Arguments: 
# Returns: 0 for success, 1 for failure
#######################################
setup () {

  hdfs_data_file="${ETLLOADLOG}/hdfs_datafiles_${global_timestamp}.tmp"
  
  tmp_count_archives=$(hadoop fs -ls ${HDFSG2ETP} 2>/dev/null | grep -o -e "${HDFSG2ETP}.*zip" | wc -l)  
  
  if [[ ${tmp_count_archives} -eq 1 ]]; then
    echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Listing data files in folder ${HDFSG2ETP} and file "${hdfs_data_file}  
    tmp_archive_dir=$(hadoop fs -ls ${HDFSG2ETP} 2>/dev/null | grep -o -e "${HDFSG2ETP}.*zip")
    hadoop fs -ls "${tmp_archive_dir}/files/*" 2>/dev/null > ${hdfs_data_file}
  elif [[ ${tmp_count_archives} -gt 1 ]]; then
    echo "ERROR: ${__BASE} : ${FUNCNAME[0]} : More than one archive folders found in ${HDFSG2ETP}"
    exit 1;
  else 
    echo "ERROR: ${__BASE} : ${FUNCNAME[0]} : No archive folder found in ${HDFSG2ETP}"
    exit 1;
  fi
  
}

#######################################
# Description: 
# Arguments: 
# Returns: 0 for success, 1 for failure
#######################################
get_params () {

  if [[ "$#" -ne 2 ]]; then
    echo "ERROR: ${__BASE} : ${FUNCNAME[0]} : Usage : get_params <file_prefix> <data_dir>"
    exit 1  
  else   
    file_name="";file_dir="";archive_name=""
  fi  

  file_name=$(cat "${hdfs_data_file}"  | grep ${1} | grep -o -e "${2}.*" | xargs  basename) 
  file_dir=$(cat "${hdfs_data_file}"   | grep ${1} | grep -o -e "${2}.*" | xargs  dirname)"/" 
  archive_name=$(cat ${hdfs_data_file} | grep ${1} | grep -o -e "${2}.*" | xargs  dirname | sed  's/\(.*\)\/files/\1/' |  xargs basename ) 
  
 }

#######################################
# Description: 
# Arguments: 
# Returns: 0 for success, 1 for failure
#######################################
chain () {

  [[ -d ${ETLLOADLOG}/g2e_load ]] || mkdir  ${ETLLOADLOG}/g2e_load

  group01_data_flows=(adm_adresse adm_adresse_etr adm_adresse_interne adm_virement_etr_sedre adm_adresse_nationale \
                      adm_benef_bade adm_cb_admin adm_cb_comptable adm_cb_mvt_debit_differe adm_lnk_cpte_contentieux \
                      adm_lnk_pers_contentieux adm_lnk_titulaire_cpte adm_mandat adm_provision_reservee adm_usage_client_adresse \
                      lnk_nationalite_pers_pays ope_cheque_banque ope_evdev ope_eichq ope_fregate ope_imputation ope_mouvement_client ope_operation \
                      ope_sepa ope_setec ope_type_operation ope_virement_etr_segps ope_virement_sepa ope_virement_vcc ref_bic_swift \
                      ref_categorie_client ref_categorie_juridique ref_fgd ref_ficroco ref_pays ref_pays_insee ref_produit ref_type_enum ref_type_enum_val ref_ua \
                      ope_mouvement ope_mouvement_bade ope_mouvement_dap ope_mouvement_eichq ope_mouvement_evdev ope_mouvement_fregate ope_mouvement_sepa ope_mouvement_setec )
  
  for flow_name in  "${group01_data_flows[@]}" ; do
  
    get_params "${flow_name^^}""@" "${HDFSG2ETP}/"
    ${ETLLOADHOME}/${flow_name}/${flow_name}_chain.sh ${file_name} ${file_dir} ${archive_name} >  "${ETLLOADLOG}/g2e_load/${flow_name}_chain_${global_timestamp}.log" 2>&1 &
    echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Executing ${ETLLOADHOME}/${flow_name}/${flow_name}_chain.sh with PID : "$!
  done
  
}

#######################################
# Description: 
# Arguments: 
# Returns: 0 for success, 1 for failure
#######################################
wait_chain () {

  for job in $(jobs -p)
  do
    echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Waiting job : "$(ps -p ${job} -o args --no-headers)" : PID : "${job}
    wait ${job} || { let "__FAIL+=1" ; echo "ERROR: ${__BASE} : ${FUNCNAME[0]} : ======> PID : "${job}" <====== FAILED !" ; }  
  done
}

#######################################
# Description: 
# Arguments: 
# Returns: 0 for success, 1 for failure
#######################################
main () {

  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Executing group01"
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Execution timestamp : $global_timestamp"
  
  setup
  chain 
  start=$(date +%s.%N)
  wait_chain
  end=$(date +%s.%N)
  
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Waited for : "$(echo "$end - $start" | bc)" sec"
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Execution return code : "${__FAIL}
  
  exit ${__FAIL}
  
}
                                                          
main "$@" > "${ETLLOADLOG}/${__BASE}_${global_timestamp}.log"

