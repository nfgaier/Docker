#!/usr/bin/env bash

###############################################################################
# Description : chain script adm_compte_especes_gabi_hist
# Usage : adm_compte_especes_chain_gabi.sh 
# Author : Umanis for BDF
# Updated : 01/10/2016
###############################################################################
set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

__DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" 
__FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")" 
__BASE="$(basename ${__FILE} .sh)"                    
readonly global_timestamp=$(date +"%Y%m%d_%H%M%S_%N")

#######################################
# Description: setup function setting variables
# Arguments: <file_name> <file_dir> <archive_name>
# Returns: 0 for success, 1 for failure
#######################################
setup () {

  table_name='adm_compte_especes_gabi'
  pig_script_name='load_ADM_COMPTE_ESPECES_GABI@.pig'
  hive_script_name=''

  log_dir="${ETLLOADLOG}/"
  table_hist_name=${table_name}'_hist'
  pig_script_dir="${ETLLOADHOME}/${table_name}/pig/"
  hive_script_dir="${ETLLOADHOME}/${table_name}/hql/"
  hive_database_name=${GABISL}
  queue_name=${ACQ_QUEUE}
  zip_date_dir="${REPBDF}/gabi/common/tmp/"
  zip_date=$((cat "${zip_date_dir}date_archive_source.tmp")| sed 's/\./\\\./g')
 
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : table_hist_name : "${table_hist_name}
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : hive_database_name : "${hive_database_name}
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : zip_date : "${zip_date}
  
  if [[ -z "${zip_date}" ]] ; then  
    echo "ERROR: ${__BASE} : ${FUNCNAME[0]} : Variables not set." 
    exit 1  
  fi
    
}

#######################################
# Description: chain function executing scripts
# Arguments: none
# Returns: 0 for success, 1 for failure
#######################################
chain() {
PIG_OPTS="tez.queue.name=$queue_name"
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Running pig -useHCatalog -l ${log_dir} -x tez -f ${pig_script_dir}${pig_script_name}"
  pig -useHCatalog -l "${log_dir}" -x tez -f "${pig_script_dir}""${pig_script_name}" -param zip_date=${zip_date} -param queue_name=${queue_name}
                                                                                     
}          

#######################################
# Description: main function
# Arguments: <file_name> <file_dir> <archive_name>
# Returns: 0 for success, 1 for failure
#######################################
main () {
  
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Chargement table adm_compte_especes_gabi_hist ..." 
  start=$(date +%s.%N)
  setup
  chain
  end=$(date +%s.%N)
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Waited for : "$(echo "$end - $start" | bc)" sec"
}
                                                          
main "$@" > "${ETLLOADLOG}/${__BASE}_${global_timestamp}.log" 2>&1 

