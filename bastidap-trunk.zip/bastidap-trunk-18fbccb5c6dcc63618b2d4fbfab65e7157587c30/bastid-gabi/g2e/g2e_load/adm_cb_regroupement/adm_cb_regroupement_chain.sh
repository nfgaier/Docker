#!/usr/bin/env bash

###############################################################################
# Description : chain script adm_cb_regroupement_juridique
# Usage : adm_cb_regroupement_chain.sh 
# Author : Umanis for BDF
# Updated : 01/10/2016
###############################################################################
set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

__DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" 
__FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")" 
__BASE="$(basename ${__FILE} .sh)"                    

#######################################
# Description: setup function setting variables
# Arguments: none
# Returns: 0 for success, 1 for failure
#######################################
setup () {

  table_name='adm_cb_regroupement'
  pig_script_name=''
  hive_script_name='load_ADM_CB_REGROUPEMENT.hql'

  log_dir="${ETLLOADLOG}/"
  pig_script_dir="${ETLLOADHOME}/${table_name}/pig/"
  hive_script_dir="${ETLLOADHOME}/${table_name}/hql/"
  hive_database_name=${G2ESL} 
  queue_name=${ACQ_QUEUE}
  
 
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : table_name : "${table_name}
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : hive_database_name : "${hive_database_name}
    
}

#######################################
# Description: chain function executing scripts
# Arguments: none
# Returns: 0 for success, 1 for failure
#######################################
chain() {
  
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Running hive -f ${hive_script_dir}${hive_script_name}"
  hive -f "${hive_script_dir}""${hive_script_name}"  -hiveconf tez.queue.name=${queue_name}  \
                                                     -hiveconf table_name=${table_name} \
                                                     -hiveconf hive_database_name=${hive_database_name}
 
}          

#######################################
# Description: main function
# Arguments: <file_name> <file_dir> <archive_name>
# Returns: 0 for success, 1 for failure
#######################################
main () {

  setup 
  
  chain
}
                                                          
main "$@"                                                                    

