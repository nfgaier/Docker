#!/usr/bin/env bash

###############################################################################
# Description : chain script adm_provision_reservee
# Usage : adm_provision_reservee_chain.sh <file_name> <file_dir> <archive_name>
# Author : Umanis for BDF
# Updated : 01/10/2016
###############################################################################
set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

__DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" 
__FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")" 
__BASE="$(basename ${__FILE} .sh)"                    

#######################################
# Description: setup function setting variables
# Arguments: <file_name> <file_dir> <archive_name>
# Returns: 0 for success, 1 for failure
#######################################
setup () {

  file_name="${1}"
  file_dir="${2}"
  archive_name="${3}"
  
  table_name='adm_provision_reservee'
  pig_script_name='load_ADM_PROVISION_RESERVEE@.pig'
  hive_script_name=''

  log_dir="${ETLLOADLOG}/"
  pig_script_dir="${ETLLOADHOME}/${table_name}/pig/"
  hive_script_dir="${ETLLOADHOME}/${table_name}/hql/"
  hive_database_name=${G2ESL} 
 queue_name=${ACQ_QUEUE}
 G2E_SRC_FOLDER=${G2E_SRC_FOLDER}
  
 
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : table_name : "${table_name}
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : hive_database_name : "${hive_database_name}
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : file_name : "${file_name}
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : file_dir : "${file_dir}
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : archive_name : "${archive_name}
  
  if [[ -z "${file_name}" ]] || [[ -z "${file_dir}" ]] || [[ -z "${archive_name}" ]] ; then  
    echo "ERROR: ${__BASE} : ${FUNCNAME[0]} : Variables not set." 
    exit 1  
  fi
    
}

#######################################
# Description: chain function executing scripts
# Arguments: none
# Returns: 0 for success, 1 for failure
#######################################
chain() {
  PIG_OPTS="tez.queue.name=$queue_name"
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Running pig -useHCatalog -l ${log_dir} -x tez -f ${pig_script_dir}${pig_script_name}"
  pig -useHCatalog -l "${log_dir}" -x tez -f "${pig_script_dir}""${pig_script_name}" -param file_dir=${file_dir} \
                                                                                     -param file_name=${file_name} \
                                                                                     -param archive_name=${archive_name} \
                                                                                     -param table_name=${table_name} \
                                                                                     -param G2E_SRC_FOLDER=${G2E_SRC_FOLDER} \
                                                                                     -param database_name=${hive_database_name} \
																					 -param queue_name=${queue_name}
}          

#######################################
# Description: main function
# Arguments: <file_name> <file_dir> <archive_name>
# Returns: 0 for success, 1 for failure
#######################################
main () {

  # Check the number of arguments
  if [[ "$#" -ne 3 ]]; then
    echo "ERROR: ${__BASE} : ${FUNCNAME[0]} : Usage : ${table_name}_chain.sh <file_name> <file_dir> <archive_name>"
    exit 1  
  fi  
  
  setup "${1}" "${2}" "${3}"
  
  chain
}
                                                          
main "$@"                                                                    

