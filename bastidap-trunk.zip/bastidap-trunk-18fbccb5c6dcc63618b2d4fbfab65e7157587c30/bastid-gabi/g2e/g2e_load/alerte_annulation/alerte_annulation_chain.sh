#!/usr/bin/env bash

###############################################################################
# Description : chain script ope_operation_regroupement_gabi
# Usage : ope_operation_regroupement_gabi.sh <file_name> <file_dir> <archive_name>
# Author : Umanis for BDF
# Updated : 15/12/2016
###############################################################################
set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

__DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" 
__FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")" 
__BASE="$(basename ${__FILE} .sh)"                    
readonly global_timestamp=$(date +"%Y%m%d_%H%M%S_%N")

#######################################
# Description: setup function setting variables
# Arguments: <file_name> <file_dir> <archive_name>
# Returns: 0 for success, 1 for failure
#######################################
setup () {

  table_quot='alerte_annulation'
  table_wkf='alerte_annulation_wkf'
  pig_script_name='alerte_annulation@.pig'
  hive_script_name=''

  log_dir="${ETLLOADLOG}/"
  pig_script_dir="${ETLLOADHOME}/${table_quot}/pig/"
  hive_database_name=${GABIOL}
  current_zip_id_traitement_dir="${REPBDF}/common/tmp/"
  current_zip=$((cat "${current_zip_id_traitement_dir}t_nom_archive_source.tmp")| sed 's/\./\\\./g') 
  id_traitement=$(cat "${current_zip_id_traitement_dir}id_traitement.tmp")  
  
  hive -hiveconf tez.queue.name=${TRT_QUEUE}  --hiveconf hive.cli.errors.ignore=true -S -e "use $hive_database_name; select COALESCE(max(id_alerte), CAST(0 AS BIGINT)) from $table_wkf;" > ${current_zip_id_traitement_dir}max_id_alerte.tmp
 
  last_id_alerte=$(cat "${current_zip_id_traitement_dir}max_id_alerte.tmp") 
 

  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : hive_database_name : "${hive_database_name}${id_traitement}${last_id_alerte}
    
}

#######################################
# Description: chain function executing scripts
# Arguments: none
# Returns: 0 for success, 1 for failure
#######################################
chain() {
  
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Running pig -useHCatalog -l ${log_dir} -f ${pig_script_dir}${pig_script_name}"
  export PIG_OPTS="-Dmapred.job.queue.name=${TRT_QUEUE}"
  pig -useHCatalog -l "${log_dir}"  -f "${pig_script_dir}""${pig_script_name}" -param table_quot=${table_quot} \
                                                                               -param table_wkf=${table_wkf} \
                                                                               -param database_name=${hive_database_name} \
                                                                               -param last_partition=${current_zip} \
                                                                               -param id_traitement=${id_traitement} \
				                                                   -param last_id_alerte=${last_id_alerte}
    
}          

#######################################
# Description: main function
# Arguments: <file_name> <file_dir> <archive_name>
# Returns: 0 for success, 1 for failure
#######################################
main () {

  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Chargement table alerte_annulation ..." 

  start=$(date +%s.%N)

  setup 
  
  chain
  
  end=$(date +%s.%N)
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Waited for : "$(echo "$end - $start" | bc)" sec"
}
                                                          
main "$@" > "${ETLLOADLOG}/${__BASE}_${global_timestamp}.log" 2>&1