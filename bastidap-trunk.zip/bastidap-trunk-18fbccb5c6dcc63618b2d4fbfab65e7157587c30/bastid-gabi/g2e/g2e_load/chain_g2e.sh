#!/usr/bin/env bash
###############################################################################
# Description : 
# Usage : 
# Author : Umanis for BDF
# Updated : 01/08/2016
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
#set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

__DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" 
__FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")" 
__BASE="$(basename ${__FILE} .sh)"  
__FAIL=0                  


#######################################
# Description: 
# Arguments: 
# Returns: 0 for success, 1 for failure
#######################################
chain () {

  g2e_data_flows_groups=(chain_group01 chain_group02 chain_group03 chain_group04)
  
  for flow_group in  "${g2e_data_flows_groups[@]}" ; do
    echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Executing ${ETLLOADHOME}/${flow_group}.sh"
    ${ETLLOADHOME}/${flow_group}.sh >  "${ETLLOADLOG}/${flow_group}_${global_timestamp}.log" 2>&1 
  done  
  
}

#######################################
# Description: 
# Arguments: 
# Returns: 0 for success, 1 for failure
#######################################
wait_chain () {

  for job in $(jobs -p)
  do
    echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Waiting job : "$(ps -p ${job} -o args --no-headers)" : PID : "${job}
    wait ${job} || let "__FAIL+=1"
  done
}

#######################################
# Description: 
# Arguments: 
# Returns: 0 for success, 1 for failure
#######################################
main () {

  readonly global_timestamp=$(date +"%Y%m%d_%H%M%S_%N")
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Loading g2e data"
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Execution timestamp : $global_timestamp"
  
  
  start=$(date +%s.%N)
  chain 
  end=$(date +%s.%N)
  
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Waited for : "$(echo "$end - $start" | bc)" sec"
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Execution return code : "${__FAIL}
  
  exit ${__FAIL}
  
}
                                                          
main "$@"                                                                    

