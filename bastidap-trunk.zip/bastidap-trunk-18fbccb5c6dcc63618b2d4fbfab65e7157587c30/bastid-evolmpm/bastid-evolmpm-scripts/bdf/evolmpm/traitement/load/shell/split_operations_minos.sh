#!/usr/bin/env bash
###############################################################################
# Description : 
# Usage : 
# Author : 
# Updated : 
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction                        #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

#######################################
# Description: setup function setting variables
# Arguments: 
# Returns: 0 for success, 1 for failure
#######################################
prepare() {

  jar_dir="${REPBDF}/evolmpm/traitement/jar"
  config_dir="${REPBDF}/evolmpm/config/"
  jar_name="spark-evolmpm-decoupage-minos-1.0.0-SNAPSHOT.jar"
  idTrt="20171031113015"
  #ajouter les fichier de properties dans la variable files pour la passer en parametre au spark-submit  
  files=${EVO_TRT_CONF_PATH}/decoupage_minos.properties,/etc/spark/conf/hive-site.xml
}

#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
run() {

  LOG_INFO "INFO: Running  spark-submit --class org.spark.evolmpm.decoupage.minos.DecoupageMinosMain \
               --master yarn-cluster  \
               --queue ${TRT_QUEUE} \
               --driver-memory 4g \
               --executor-memory 2g \
                --keytab ${HOME}/.keytabs/bastidap1asv.keytab \
                --principal BASTIDAP1ASV/lxdv304a.unix-int.intra-int.bdf-int.local@INTRA-DEV01.BDF-DEV01.LOCAL \ 
               --num-executors 3 \
               --files $files \
               ${jar_dir}/${jar_name} \
               ${config_dir}hadoop-local.xml \
               ${idTrt}"
  

  
  # On quitte le mode Exit on Error pour pouvoir capter le code retour du spark-submit
  set +o errexit
  spark-submit --class org.spark.evolmpm.decoupage.minos.DecoupageMinosMain \
               --master yarn-cluster \
               --queue ${TRT_QUEUE} \
               --driver-memory 4g \
               --executor-memory 2g \
               --keytab ${HOME}/.keytabs/bastidap1asv.keytab \
 			   --principal BASTIDAP1ASV/lxdv304a.unix-int.intra-int.bdf-int.local@INTRA-DEV01.BDF-DEV01.LOCAL \
               --num-executors 3 \
               --files $files \
              	${jar_dir}/${jar_name} \
              	${config_dir}hadoop-local.xml \
                ${idTrt} 
 
  if [ $? -eq $__SUCCESS ]
  then
    STATUT_TRT="Succes"
  else
    STATUT_TRT="Echec"
  fi
  
  # On retablit le mode Exit on Error
  set -o errexit

}

#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  START
  
  SETUP
  
  LOG_INFO "INFO: Executing spark-evolmpm-decoupage-minos"
  
  start=$(date +%s.%N)  
  
  prepare
  
  run
  
  if [[ $STATUT_TRT == "Echec" ]]
  then
    exit $__FAILURE
  fi
  
  end=$(date +%s.%N)
  
  LOG_INFO "INFO: Waited for : "$(echo "$end - $start" | bc)" sec"
  
  END
  
}
main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
