#!/usr/bin/env bash
###############################################################################
# Description : 
# Usage : 
# Author : 
# Updated : 
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction                        #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

#######################################
# Description: setup function setting variables
# Arguments: 
# Returns: 0 for success, 1 for failure
#######################################
prepare() {

  jar_dir="${REPBDF}/evolmpm/traitement/jar"
  config_dir="${REPBDF}/evolmpm/config"
  jar_name_parse="spark-evolmpm-parse-minos-1.0.0-SNAPSHOT.jar"
  idTrt="20171220173015"
  jar_name_decoupage="spark-evolmpm-decoupage-minos-1.0.0-SNAPSHOT.jar"
   #ajouter les fichier de properties dans la variable files pour la passer en parametre au spark-submit  
   files="${EVO_TRT_CONF_PATH}/decoupage_minos.properties,/etc/spark/conf/hive-site.xml"
  GET_ID_TRT "$EVO_APPLI_NAME" "$PHASE_TRAITEMENT" "OPERATIONS_MINOS" 'idTrt'
  hql_path="${REPBDF}/evolmpm/traitement/load/hql/"
  script_copy="copy_work_to_optimized_layer.hql"
  
}



#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
run() {

  LOG_START_FUNC "${FUNCNAME[0]}"
  # On pousse l'evenement Debut de chargement dans la table de suivi
 
  LOG_INFO "Start Event logging into ${TOT}"
  INSERT_LOG_DEB_TRT "${idTrt}" "Debut de traitement OPERATIONS_MONOS"
 


  LOG_INFO "Running  spark-submit --class org.spark.evolmpm.parse.minos.ParseMinosMain \
               --master yarn  \
               --queue ${TRT_QUEUE} \
               --driver-memory 4g \
               --executor-memory 2g \
               --num-executors 3 \
               ${jar_dir}/${jar_name_parse} \
               ${config_dir}/hadoop-local.xml \
               ${EVO_TRT_CONF_PATH}/id_MINOS.tmp \
               ${idTrt} \
               ${EVO_SRC_FOLDER}"
  
 
  # On quitte le mode Exit on Error pour pouvoir capter le code retour du spark-submit
  set +o errexit
  
  spark-submit --class org.spark.evolmpm.parse.minos.ParseMinosMain \
               --master yarn  \
               --queue ${TRT_QUEUE} \
               --driver-memory 4g \
               --executor-memory 2g \
               --num-executors 3 \
               --keytab ${KERBEROS_KEYTAB} \
               --principal ${KERBEROS_PRINCIPAL} \
               ${jar_dir}/${jar_name_parse} \
               "${config_dir}/hadoop-local.xml" \
               "${EVO_TRT_CONF_PATH}/id_MINOS.tmp" \
               "${idTrt}" \
               "${EVO_SRC_FOLDER}"
 
  if [[ $? -eq ${__SUCCESS} ]]; then
    STATUT_TRT="Succes"
  else
    STATUT_TRT="Echec"
  fi

  if [[ ${STATUT_TRT} == "Succes" ]]; then
      LOG_INFO "INFO: Running  spark-submit --class org.spark.evolmpm.decoupage.minos.DecoupageMinosMain \
                  --master yarn-cluster  \
                  --queue ${TRT_QUEUE} \
                  --driver-memory 4g \
                  --executor-memory 2g \
                  --num-executors 3 \
                  --files $files \
 	          --keytab ${KERBEROS_KEYTAB} \
	          --principal ${KERBEROS_PRINCIPAL} \
	          ${jar_dir}/${jar_name_decoupage} \
	          ${config_dir}hadoop-local.xml \
	          ${idTrt}"
   
        spark-submit --class org.spark.evolmpm.decoupage.minos.DecoupageMinosMain \
	             --master yarn-cluster \
	             --queue ${TRT_QUEUE} \
	             --driver-memory 4g \
	             --keytab ${KERBEROS_KEYTAB} \
	             --principal ${KERBEROS_PRINCIPAL} \
	             --executor-memory 2g \
	             --num-executors 3 \
	             --files $files \
	             ${jar_dir}/${jar_name_decoupage} \
                     ${config_dir}hadoop-local.xml \
                     ${idTrt}
        if [[ $? -eq ${__SUCCESS} ]]; then
              STATUT_TRT="Succes"
        else
	      STATUT_TRT="Echec"
        fi
  fi

  # On rétablit le mode Exit on Error
  set -o errexit
  
  # On pousse l'evenement Fin de chargement dans la table de suivi
  LOG_INFO "End Event logging into ${TOT}"
 
  INSERT_LOG_FIN_TRT "${idTrt}" "Fin de traitement OPERATIONS_MINOS" "${STATUT_TRT}"
 


}


#######################################
# Description: 
# Arguments: none
# Returns: 0 for success, 1 for failure
#######################################
copy_to_optimized_layer() {

  LOG_INFO "Copy to Optimized layer"

	hive -hiveconf tez.queue.name=${EXP_QUEUE} -hiveconf id_traitement=${idTrt} -f ${hql_path}${script_copy}
}



#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  START
  
  SETUP
  LOG_INFO "Executing spark-evolmpm-parse-minos and spark-evolmpm-split-minos"
  
  prepare
  
  run
  
  copy_to_optimized_layer
  
  if [[ $STATUT_TRT == "Echec" ]];  then
    exit ${__FAILURE}
  fi
  
  END
  
  exit ${__SUCCESS}
  
}
main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
