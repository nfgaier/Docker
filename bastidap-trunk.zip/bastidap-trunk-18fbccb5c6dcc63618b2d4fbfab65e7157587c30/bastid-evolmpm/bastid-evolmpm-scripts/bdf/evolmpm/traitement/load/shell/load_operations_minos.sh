#!/usr/bin/env bash
###############################################################################
# Description : 
# Usage : 
# Author : 
# Updated : 
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction                        #source .fonction_*_spec
. $APPLI_HOME/appli/connexion/.fonction_bastid_spec
. $APPLI_HOME/appli/connexion/.param_evolmpm
. $APPLI_HOME/appli/connexion/.param

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

#######################################
# Description: setup function setting variables
# Arguments: 
# Returns: 0 for success, 1 for failure
#######################################
prepare() {

  if [[ "${WORKFLOW_ENV}" != "OOZIE" ]]; then
     jar_dir="${REPBDF}/evolmpm/traitement/jar"
     config_dir="${REPBDF}/evolmpm/config"
     jar_name="spark-evolmpm-parse-minos.jar"
     GET_ID_TRT "$EVO_APPLI_NAME" "$PHASE_TRAITEMENT" "PARSING_MINOS" 'idTrt'
  else
     GET_ID_TRT "${APPLI_TRAITEMENT}" "$PHASE_TRAITEMENT" "PARSING_MINOS" 'idTrt'
  fi

  LOG_INFO "ID TRAITEMENT pour le chargement de la table OPERATIONS_MINOS: $idTrt"

  #ajouter les fichier de properties dans la variable files pour la passer en parametre au spark-submit
  files=/etc/spark/conf/hive-site.xml
}



#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
run() {

  LOG_INFO "Running  spark-submit --class org.spark.evolmpm.parse.minos.ParseMinosMain \
               --master yarn  \
               --queue ${TRT_QUEUE} \
               --driver-memory 4g \
               --executor-memory 2g \
               --num-executors 3 \
               ${jar_dir}/${jar_name} \
               ${config_dir}/hadoop-local.xml \
               ${EVO_TRT_CONF_PATH}/id_PARSING_MINOS.tmp \
               ${idTrt} \
               ${EVO_SRC_FOLDER}"
  
 
  # On quitte le mode Exit on Error pour pouvoir capter le code retour du spark-submit
  set +o errexit
  
  spark-submit --class org.spark.evolmpm.parse.minos.ParseMinosMain \
               --master yarn  \
               --queue ${TRT_QUEUE} \
               --driver-memory 4g \
               --executor-memory 2g \
               --num-executors 3 \
               --keytab ${KERBEROS_KEYTAB} \
               --principal ${KERBEROS_PRINCIPAL} \
               ${jar_dir}/${jar_name} \
               "${config_dir}/hadoop-local.xml" \
               "${EVO_TRT_CONF_PATH}/id_PARSING_MINOS.tmp" \
               "${idTrt}" \
               "${EVO_SRC_FOLDER}"
 
  if [[ $? -eq ${__SUCCESS} ]]; then
    STATUT_TRT="Succes"
  else
    STATUT_TRT="Echec"
  fi
  
  # On rétablit le mode Exit on Error
  set -o errexit

}

#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  START
  
  SETUP
  
  LOG_INFO "Executing spark-evolmpm-parse-minos"
  
  prepare
  
  run
    
  if [[ $STATUT_TRT == "Echec" ]];  then
    exit ${__FAILURE}
  fi
  
  END
  
  exit ${__SUCCESS}
  
}
main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
