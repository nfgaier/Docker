#!/usr/bin/env bash
###############################################################################
# Description :
# Usage : 
# Author : 
# Updated : 
###############################################################################

#set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec                        #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

do_copy() {

  LOG_INFO "HDFS copy ..."

  #REFERENTIELS
  LOG_INFO "ref_motif_annulation"
  hdfs dfs -mkdir -p /data/source/${EVO_SRC_FOLDER}/raw_layer/ref_motif_annulation/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${EVO_SRC_FOLDER}/landing_layer/ref_motif_annulation/id_traitement=${ID_TRAITEMENT}/* /data/source/${EVO_SRC_FOLDER}/raw_layer/ref_motif_annulation/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "ref_motif_rejet"
  hdfs dfs -mkdir -p /data/source/${EVO_SRC_FOLDER}/raw_layer/ref_motif_rejet/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${EVO_SRC_FOLDER}/landing_layer/ref_motif_rejet/id_traitement=${ID_TRAITEMENT}/* /data/source/${EVO_SRC_FOLDER}/raw_layer/ref_motif_rejet/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "ref_pays_euro"
  hdfs dfs -mkdir -p /data/source/${EVO_SRC_FOLDER}/raw_layer/ref_pays_euro/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${EVO_SRC_FOLDER}/landing_layer/ref_pays_euro/id_traitement=${ID_TRAITEMENT}/* /data/source/${EVO_SRC_FOLDER}/raw_layer/ref_pays_euro/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "ref_pays_iso"
  hdfs dfs -mkdir -p /data/source/${EVO_SRC_FOLDER}/raw_layer/ref_pays_iso/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${EVO_SRC_FOLDER}/landing_layer/ref_pays_iso/id_traitement=${ID_TRAITEMENT}/* /data/source/${EVO_SRC_FOLDER}/raw_layer/ref_pays_iso/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "ref_pays_territoire_sepa"
  hdfs dfs -cp -f /data/source/${EVO_SRC_FOLDER}/landing_layer/ref_pays_territoire_sepa/* /data/source/${EVO_SRC_FOLDER}/raw_layer/ref_pays_territoire_sepa/
  LOG_INFO "ref_type_operation"
  hdfs dfs -mkdir -p /data/source/${EVO_SRC_FOLDER}/raw_layer/ref_type_operation/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${EVO_SRC_FOLDER}/landing_layer/ref_type_operation/id_traitement=${ID_TRAITEMENT}/* /data/source/${EVO_SRC_FOLDER}/raw_layer/ref_type_operation/id_traitement=${ID_TRAITEMENT}
  
  
  LOG_INFO "MSCK REPAIR TABLE"
  hive -hiveconf tez.queue.name=${TRT_QUEUE}  -e "MSCK REPAIR TABLE evolmpm_raw_layer.ref_motif_annulation;
                                                  MSCK REPAIR TABLE evolmpm_raw_layer.ref_motif_rejet;
                                                  MSCK REPAIR TABLE evolmpm_raw_layer.ref_pays_euro;
                                                  MSCK REPAIR TABLE evolmpm_raw_layer.ref_pays_iso;
                                                  MSCK REPAIR TABLE evolmpm_raw_layer.ref_pays_territoire_sepa;
                                                  MSCK REPAIR TABLE evolmpm_raw_layer.ref_type_operation;"
}                                                  


main () {
  
  if [[ "$#" -ne 1 ]]; then
    LOG_ERROR "${FUNCNAME[0]} : Usage : copy_land_row.sh <id_traitement> "
    exit ${__FAILURE} 
  else 
    ID_TRAITEMENT="${1}" 
    LOG_INFO "ID_TRAITEMENT=$ID_TRAITEMENT"    
  fi 
  
  START
  
  SETUP

  do_copy
   #
   # REQ="update $TOT"                                     
   # REQ+=" set status = '${ST_OK}'"
   # REQ+=" where"                                             
   # REQ+="     type_suivi = '${TYPE_SUIVI_SUIVI}'"            
   # REQ+="     and niveau_suivi = '${NIVEAU_SUIVI_STATUT}'"
   # REQ+="     and id_job = '${ID_TRAITEMENT}'"            
   # REQ+="     and status = '${ST_DISPO_COPIE_LAND_ROW}'"            
   # REQ+=" ;"                                                 
   # PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" -e "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"
   #
  #LOG_INFO "Copy OK, STATUT of ID_TRAITEMENT ${ID_TRAITEMENT} updated"
  
  END
  
  exit ${__SUCCESS}

}                                                
                                                
main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1

