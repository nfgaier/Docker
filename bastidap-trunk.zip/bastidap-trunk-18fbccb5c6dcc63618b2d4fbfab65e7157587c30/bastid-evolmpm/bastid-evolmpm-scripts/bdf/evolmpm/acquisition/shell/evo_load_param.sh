#!/usr/bin/env bash
###############################################################################
# Description :
# - Load csv ref_param files into TEXT tables and then ORC tables
#
# Usage : 
# Author : 
# Updated : 01/09/2017
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction                        #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  
APPLICATION=${EVO_APPLI_NAME}
LAYER=${EMB_HIVEDB_LDL}

INFOS=infos
DATA_FILE_PATH="${REP_BDF}/evolmpm/acquisition/referentiel"
HQL_PATH="${REP_BDF}/evolmpm/acquisition/hql"
MODE_ALIM="Quotidien"

#######################################
# Description: Check the existence of id_traitement_acq.tmp
# Arguments: 
# Returns: 
#######################################
  
get_id_traitement(){

  # Récupère l'ID_TRAITEMENT en cours
  ID_TRAITEMENT=$(PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -A -t -c " \
                        select id_job \
                        from ${TOT} \
                        where \
                            type_suivi = '${TYPE_SUIVI_SUIVI}' \
                            and niveau_suivi = '${NIVEAU_SUIVI_STATUT}' \
                            and projet = '${PROJET}' \
                            and application = 'EVOLMPM' \
                            and phase = 'ACQUISITION' \
                            and nom_traitement = 'ACQUISITION_EVOLMPM_REF' \
                            and status = '${ST_ENCOURS}' \
                        ")
            
            
  LOG_INFO ""
  LOG_INFO "ID_TRAITEMENT en cours : $ID_TRAITEMENT"

}


#######################################
# Description: Check the existence of the source file
# Arguments: 
# Returns: 
#######################################
check_file() {

  local file="${1}"

  if [[ ! -f ${DATA_FILE_PATH}/${file} ]] ; then  
    LOG_ERROR "File ${DATA_FILE_PATH}/${file} not found."
    exit 1
  else
    LOG_INFO "Source file ${DATA_FILE_PATH}/${file} found."
  fi
  
  
  if [[ ${file} == "PAYS0101.TXT" ]] ; then  
    while read -r line; do
      if [ ${#line} -gt 68 ]; then 
        LOG_ERROR "Line size > 68 for PAYS0101.TXT"
        exit ${__FAILURE}
      fi
    done < ${DATA_FILE_PATH}/${file}
    LOG_INFO "Source file ${DATA_FILE_PATH}/${file} well formatted"
  fi
   
   if [[ ${file} == "PAYS0201.TXT" ]] ; then  
      while read -r line; do
        if [ ${#line} -gt 157 ]; then 
          LOG_ERROR "Line size > 157 for PAYS0201.TXT"
          exit ${__FAILURE}
        fi
      done < ${DATA_FILE_PATH}/${file}
      LOG_INFO "Source file ${DATA_FILE_PATH}/${file} well formatted"
   fi
}


#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  if [[ "$#" -ne 2 ]]; then
    LOG_ERROR "${FUNCNAME[0]} : Usage : evo_load_param.sh <target table name> <source file name>"
    exit ${__FAILURE} 
  else 
    local table_name=${1}
    local filename=${2}
    LOG_ERROR "${FUNCNAME[0]} : Loading  file $filename in table $table_name"
  fi 

  START
  
  SETUP

  get_id_traitement
  
  check_file "${filename}"
  
  # Recuperation du nombre de lignes du CSV
  local nb_lignes_csv=$(wc -l < "${DATA_FILE_PATH}/$filename")
  nb_lignes_csv=$(($nb_lignes_csv-1))
  
  LOG_INFO "NB LIGNES CSV = ${nb_lignes_csv}"
  local start_date=`date +%Y%m%d_%H%M%S`
  
  # Insertion du traitement dans la table de suivi avec le statut en cours
  #INSERT_SUIVI "${ID_TRAITEMENT}" "${BST_PRO_NAME}" "${APPLICATION}" "${EMB_SER}" "${LAYER}" "${start_date}" "${start_date}" "${DATE_OPE}" "${table_name}" "${nb_lignes_csv}" "En cours" "${INFOS}" "${MODE_ALIM}"
  # TODO à supprimer car le statut est mis à jour par le constructeur (car NIVEAU_SUIVI_CATALOGUE) : constr_catalogue_acq_fichier.sh/constr_ref_evol.sh
  REQ="  update $TOT set status = '${ST_ENCOURS}' "
  REQ+="                ,nb_lignes = '${nb_lignes_csv}' "
  REQ+="                ,date_debut = '${start_date}' "
  REQ+=" where" 
  REQ+="     id_job = '${ID_TRAITEMENT}'"
  REQ+="     and  type_suivi = '${TYPE_SUIVI_SUIVI}'"
  REQ+="     and niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}'"
  REQ+="     and projet = '${PROJET}'"
  REQ+="     and application = 'EVOLMPM'"
  REQ+="     and phase = '${PHASE_ACQUISITION}'"
  REQ+="     and nom_table = '${table_name}'"
  REQ+="     and status = '${ST_ENCOURS}'"

  PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" -e "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"

  
  # chargement du contenu du CSV dans la table de parametrage
  LOG_INFO "Chargement de $filename"
  hive --hiveconf tez.queue.name=${ACQ_QUEUE} -f "${HQL_PATH}/${table_name}.hql" \
        -hiveconf id_traitement=${ID_TRAITEMENT}  \
        -hiveconf file_path="${DATA_FILE_PATH}/${filename}"
  
  LOG_INFO "Supression de $filename"   
  rm -f ${DATA_FILE_PATH}/${filename}
  
  # Initialisation end_date
  local end_date=`date +%Y%m%d_%H%M%S`
  
  # Recuperation du nombre de lignes dans la table de parametrage
  if [[ $table_name == "REF_PAYS_TERRITOIRE_SEPA" ]]; then 
    local nb_lignes_hive=$(hive --hiveconf tez.queue.name=${ACQ_QUEUE} -S -e "SELECT count(*) from evolmpm_landing_layer.${table_name}")
  else 
    local nb_lignes_hive=$(hive --hiveconf tez.queue.name=${ACQ_QUEUE} -S -e "SELECT count(1) from evolmpm_landing_layer.${table_name} where id_traitement = '${ID_TRAITEMENT}'")
  fi
   #Si le chargement de la table s'est bien passe
  if [[ $? -eq 0 ]]; then
    if [[ $nb_lignes_csv == $nb_lignes_hive ]]; then
    # Si la table et le CSV ont le meme nombre de lignes, on insere le traitement dans la table de suivi avec le statut success

      REQ="  update $TOT"
      REQ+=" set status = '${ST_OK}'"
      REQ+=" ,nb_lignes = '${nb_lignes_hive}'"
      REQ+=" ,date_fin = '${end_date}'"
      REQ+=" where"
      REQ+="     id_job = '${ID_TRAITEMENT}'"
      REQ+="    and type_suivi = '${TYPE_SUIVI_SUIVI}'"
      REQ+="     and niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}'"
      REQ+="     and projet = '${PROJET}'"
      REQ+="     and application = 'EVOLMPM'"
      REQ+="     and phase = '${PHASE_ACQUISITION}'"
      REQ+="     and nom_table = '${table_name}'"
      REQ+="     and status = '${ST_ENCOURS}'"
    
      PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" -e "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"
    else
      # Si la table et le CSV n'ont pas le meme nombre de lignes, on insere le traitement dans la table de suivi avec le statut erreur
      
      REQ="  update $TOT"
      REQ+=" set status = '${ST_ERROR}'"
      REQ+=" ,nb_lignes = '${nb_lignes_hive}'"
      REQ+=" ,date_fin = '${end_date}'"
      REQ+=" where"
      REQ+="     id_job = '${ID_TRAITEMENT}'"
      REQ+="    and type_suivi = '${TYPE_SUIVI_SUIVI}'"
      REQ+="     and niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}'"
      REQ+="     and projet = '${PROJET}'"
      REQ+="     and application = 'EVOLMPM'"
      REQ+="     and phase = '${PHASE_ACQUISITION}'"
      REQ+="     and nom_table = '${table_name}'"
      REQ+="     and status = '${ST_ENCOURS}'"
  
      PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" -e "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"
   
      exit ${__FAILURE}  
    fi
  else
    # Si le chargement de la table s'est termine en erreur, on insere le traitement dans la table de suivi avec le statut echec
    REQ="  update $TOT"
    REQ+=" set status = '${ST_KO}'"
    REQ+=" ,nb_lignes = '${nb_lignes_hive}'"
    REQ+=" ,date_fin = '${end_date}'"
    REQ+=" where"
    REQ+="     id_job = '${ID_TRAITEMENT}'"
    REQ+="     and  type_suivi = '${TYPE_SUIVI_SUIVI}'"
    REQ+="     and niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}'"
    REQ+="     and projet = '${PROJET}'"
    REQ+="     and application = 'EVOLMPM'"
    REQ+="     and phase = '${PHASE_ACQUISITION}'"
    REQ+="     and nom_table = '${table_name}'"
    REQ+="     and status = '${ST_ENCOURS}'"
  
    PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" -e "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"

   exit ${__FAILURE}
  fi
  
  END
  
  exit ${__SUCCESS}
  
}

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
