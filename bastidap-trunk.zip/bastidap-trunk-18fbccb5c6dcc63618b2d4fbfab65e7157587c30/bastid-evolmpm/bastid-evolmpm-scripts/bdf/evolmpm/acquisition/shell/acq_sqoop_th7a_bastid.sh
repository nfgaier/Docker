#!/usr/bin/env bash


#!/usr/bin/env bash
set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
#set -o nounset    # Exits when script tries to use undeclared variables
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec 

if [[ -z $LOGDIR ]]
then
LOGDIR=$LST
fi

if [[ -z $LOGFILE ]]
then
LOGFILE=$(basename "${BASH_SOURCE[0]}" | cut -f 1 -d '.')_$(date +"%Y%m%d_%H%M%S_%N").log
fi

#Variables 
LAYER=${EVO_HIVEDB_LDL}; LOG_INFO "LAYER=$LAYER"
START_DATE=`date +%Y%m%d_%H%M%S`; LOG_INFO "START_DATE=$START_DATE" 
TABLE_NAME=TH7A_BASTID ; LOG_INFO "TABLE_NAME=$TABLE_NAME"
MODE_ALIM="Quotidien"; LOG_INFO "MODE_ALIM=$MODE_ALIM" 
ID_TRAITEMENT=$(cat "${EVO_ACQ_CONF_PATH}/id_traitement_acq.tmp"); LOG_INFO "ID_TRAITEMENT=$ID_TRAITEMENT" 
DATE_INSERT=$(echo ${ID_TRAITEMENT} | cut -c1-4)"-"$(echo ${ID_TRAITEMENT} | cut -c5-6)"-"$(echo ${ID_TRAITEMENT} | cut -c7-8); LOG_INFO "DATE_INSERT=$DATE_INSERT" 
DATE_INSERT=$(date -d "${DATE_INSERT}" +'%Y-%m-%d'); LOG_INFO "DATE_INSERT=$DATE_INSERT" 


DT_DERN_CHARG=$(cat "${EVO_ACQ_CONF_PATH}/dt_dern_charg.tmp"); LOG_INFO "DT_DERN_CHARG=$DT_DERN_CHARG" 
DT_DEB_CHARG=$(cat "${EVO_ACQ_CONF_PATH}/dt_deb_charg.tmp"); LOG_INFO "DT_DEB_CHARG=$DT_DEB_CHARG" 


DT_DERN_CHARG=$(date -d "${DT_DERN_CHARG}" +'%d/%m/%y %H:%M:%S,%3N'); LOG_INFO "DT_DERN_CHARG=$DT_DERN_CHARG" 
DT_DEB_CHARG=$(date -d "${DT_DEB_CHARG}" +'%d/%m/%y %H:%M:%S,%3N'); LOG_INFO "DT_DEB_CHARG=$DT_DEB_CHARG" 
DT_DERN_CHARG=$(echo \'"${DT_DERN_CHARG}"\'); LOG_INFO "DT_DERN_CHARG=$DT_DERN_CHARG" 
DT_DEB_CHARG=$(echo \'"${DT_DEB_CHARG}"\'); LOG_INFO "DT_DEB_CHARG=$DT_DEB_CHARG" 


if [[ -z $ID_TRAITEMENT ]]
then
LOG_ERROR "Variable ID_TRAITEMENT non positionnꦜ"
exit 1
fi

LOG_INFO "TABLE_NAME : ${TABLE_NAME}"
LOG_INFO "MODE_ALIM : ${MODE_ALIM}"
LOG_INFO "ID_TRAITEMENT : ${ID_TRAITEMENT}"
LOG_INFO "DATE_INSERT : ${DATE_INSERT}"
LOG_INFO "DT_DEB_CHARG : ${DT_DEB_CHARG}"
LOG_INFO "DT_DERN_CHARG : ${DT_DERN_CHARG}"
LOG_INFO ""

# variable nombre de lignes SQOOP 
LOG_INFO "Calcul du nombre de ligne côté SOURCE"

NB_LIGNES_SQOOP=$(echo $(sqoop eval --connect "${EVO_ORA_CXN}" --username ${EVO_ORA_USER} --password ${EVO_ORA_PAS} --query "SELECT 'COUNT_START'||COUNT(*)||'COUNT_END' FROM TH7A_BASTID WHERE 1=1 AND (TO_TIMESTAMP($DT_DERN_CHARG,'DD/MM/YY HH24:MI:SS,FF') < XTIMTS AND XTIMTS <= TO_TIMESTAMP($DT_DEB_CHARG,'DD/MM/YY HH24:MI:SS,FF'))") |  sed 's/\(.*\)\(COUNT_START\)\([0-9]*\)\(COUNT_END\).*/\3/')
if [[ $NB_LIGNES_SQOOP == *"ACCUMULO_HOME"* ]]
then
NB_LIGNES_SQOOP=0
fi
LOG_INFO "Log du nombre de lignes sqoop"
LOG_INFO "nb lignes sqoop : ${NB_LIGNES_SQOOP}" 


PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -e -c " \
 insert into $TOT (id_job, type_suivi, projet, application, phase, nom_traitement, nom_table, type_table, nb_lignes, type_log, log) \
 values ('$ID_TRAITEMENT', '$TYPE_SUIVI_LOG', '$PROJET', '$EVO_APPLI_NAME', '$PHASE_ACQUISITION', '$(basename "${BASH_SOURCE[0]}")', '$TABLE_NAME', '$MODE_ALIM', '$NB_LIGNES_SQOOP', 'COUNT SIO', 'Nombre de ligne côté SIO pour cette acquisition')"

#Commande hive pour réinitialiser la table th7a_bastid de chargement
LOG_INFO "Drop et recréation de la table cible "

hive -hiveconf tez.queue.name=$ACQ_QUEUE -hiveconf hive.cli.errors.ignore=true \
-e "

    DROP TABLE IF EXISTS evolmpm_landing_layer.TH7A_BASTID;

    CREATE TABLE IF NOT EXISTS evolmpm_landing_layer.TH7A_BASTID
    (
        DEBEMB STRING,
        RFOPI STRING,
        TYEGS STRING,
        COOPS STRING,
        XPARTT STRING,
        DTJCO TIMESTAMP,
        XTIMTS TIMESTAMP,
        NOPART STRING,
        DATE_INSERT DATE
    )
    PARTITIONED BY (ID_TRAITEMENT STRING)
    STORED AS ORC
    LOCATION '${EVO_SRC_HDFS_LDL}th7a_bastid';

"

sqoop import -Dmapred.job.queue.name=$ACQ_QUEUE \
--connect "${EVO_ORA_CXN}" \
--username ${EVO_ORA_USER} \
--password ${EVO_ORA_PAS}  \
--query "SELECT DEBEMB, RFOPI, TYEGS, COOPS, XPARTT, DTJCO, XTIMTS, NOPART, '${DATE_INSERT}' as DATE_INSERT, '$ID_TRAITEMENT' as ID_TRAITEMENT 
         FROM TH7A_BASTID
         WHERE 1=1 AND (TO_TIMESTAMP($DT_DERN_CHARG,'DD/MM/YY HH24:MI:SS,FF') < XTIMTS AND XTIMTS <= TO_TIMESTAMP($DT_DEB_CHARG,'DD/MM/YY HH24:MI:SS,FF'))
         AND \$CONDITIONS" \
--hcatalog-table TH7A_BASTID \
--split-by RFOPI \
--hcatalog-database ${EVO_HIVEDB_LDL} \
--hive-partition-key id_traitement \
--hive-partition-value ${ID_TRAITEMENT} \
--num-mappers 1 


#INITIALISATION END_DATE 
END_DATE=`date +%Y%m%d_%H%M%S` 

# Variable nb lignes HIVE 
NB_LIGNES_HIVE=$(hive --hiveconf tez.queue.name=$TRT_QUEUE -S -e "SELECT count(*) from evolmpm_landing_layer.TH7A_BASTID") 


PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -c " \
 insert into $TOT (id_job, type_suivi, projet, application, phase, nom_traitement, nom_table, type_table, nb_lignes, type_log, log) \
 values ('$ID_TRAITEMENT', '$TYPE_SUIVI_LOG', '$PROJET', '$EVO_APPLI_NAME', '$PHASE_ACQUISITION', '$(basename "${BASH_SOURCE[0]}")', '$TABLE_NAME', '$MODE_ALIM', '$NB_LIGNES_HIVE', 'COUNT BASTID Landing Layer', 'Nombre de ligne côté BASTID Landing Layer pour cette acquisition')"
#Si la table th7a_bastid s'est crꩠcorectement, alors on envoi dans le sas HDFS un fichier ok sinon un fichier ko
if [[ $? -eq 0 ]]
then
    LOG_INFO "NB LIGNES HIVE = ${NB_LIGNES_HIVE}"
    if [ $NB_LIGNES_SQOOP = $NB_LIGNES_HIVE ]
    then 
       REQ="  update $TOT"
       REQ+=" set status = '${ST_OK}'"
       REQ+=" where"
       REQ+="     type_suivi = '${TYPE_SUIVI_SUIVI}'"
       REQ+="     and niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}'"
       REQ+="     and projet = '${PROJET}'"
       REQ+="     and application = '${EVO_APPLI_NAME}'"
       REQ+="     and phase = '${PHASE_ACQUISITION}'"
       REQ+="     and nom_table = 'TH7A_BASTID'"
       REQ+="     and status = '${ST_ENCOURS}'"
       PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" -e "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"
    else   
       REQ="  update $TOT"
       REQ+=" set status = '${ST_ERROR}'"
       REQ+=" where"
       REQ+="     type_suivi = '${TYPE_SUIVI_SUIVI}'"
       REQ+="     and niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}'"
       REQ+="     and projet = '${PROJET}'"
       REQ+="     and application = '${EVO_APPLI_NAME}'"
       REQ+="     and phase = '${PHASE_ACQUISITION}'"
       REQ+="     and nom_table = 'TH7A_BASTID'"
       REQ+="     and status = '${ST_ENCOURS}'"
       PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" -e "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"
       exit 1
    fi 

   exit 0
else

    REQ="  update $TOT"
    REQ+=" set status = '${ST_KO}'"
    REQ+=" where"
    REQ+="     type_suivi = '${TYPE_SUIVI_SUIVI}'"
    REQ+="     and niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}'"
    REQ+="     and projet = '${PROJET}'"
    REQ+="     and application = '${EVO_APPLI_NAME}'"
    REQ+="     and phase = '${PHASE_ACQUISITION}'"
    REQ+="     and nom_table = 'TH7A_BASTID'"
    REQ+="     and status = '${ST_ENCOURS}'"
    PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" -e "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"

    exit 1
fi
