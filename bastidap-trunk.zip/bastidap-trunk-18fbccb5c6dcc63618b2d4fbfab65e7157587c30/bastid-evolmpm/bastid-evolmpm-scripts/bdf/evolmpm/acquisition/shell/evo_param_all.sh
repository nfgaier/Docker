#!/usr/bin/env bash
###############################################################################
# Description :
# Usage : 
# Author : 
# Updated : 
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction                        #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

do_ref_pays_territoire_sepa="yes"
do_ref_pays_iso="yes"
do_ref_pays_euro="yes"
do_ref_type_operation="yes"
do_ref_motif_annulation="yes"
do_ref_motif_rejet="yes"
do_ref_code_ope_evolmpm="yes"
do_ref_param_repim="yes"

#######################################
# Description:  Série de fonctions permettant de lancer les scripts d'acquisition des referentiels pays 
# Arguments:    Pas d'argument
# Returns:      
#######################################

f_ref_pays_territoire_sepa () {
  LOG_INFO "Acquisition REF_PAYS_TERRITOIRE_SEPA"
  $REPBDF/evolmpm/acquisition/shell/evo_load_param.sh REF_PAYS_TERRITOIRE_SEPA pays-territoires-SEPA.csv
}

f_ref_pays_iso () {
  LOG_INFO "Acquisition REF_PAYS_ISO"
  $REPBDF/evolmpm/acquisition/shell/evo_load_param.sh REF_PAYS_ISO PAYS0101.TXT
}

f_ref_pays_euro () {
  LOG_INFO "Acquisition REF_PAYS_EURO"
  $REPBDF/evolmpm/acquisition/shell/evo_load_param.sh REF_PAYS_EURO PAYS0201.TXT
}

f_ref_type_operation () {
  LOG_INFO "Acquisition REF_TYPE_OPERATION"
  $REPBDF/evolmpm/acquisition/shell/evo_load_param.sh REF_TYPE_OPERATION REF_TYPE_OPERATION.csv
}

f_ref_motif_annulation () {
  LOG_INFO "Acquisition REF_MOTIF_ANNULATION"
  $REPBDF/evolmpm/acquisition/shell/evo_load_param.sh REF_MOTIF_ANNULATION ref_motif_annulation.csv
}

f_ref_motif_rejet () {
  LOG_INFO "Acquisition REF_MOTIF_REJET"
  $REPBDF/evolmpm/acquisition/shell/evo_load_param.sh REF_MOTIF_REJET ref_motif_rejet.csv  
}

f_ref_code_ope_evolmpm () {
  LOG_INFO "Acquisition REF_CODE_OPE_EVOLMPM"
  $REPBDF/evolmpm/acquisition/shell/evo_load_param.sh REF_CODE_OPE_EVOLMPM REF_CODE_OPE_EVOLMPM.csv  
}

f_ref_param_repim () {
  LOG_INFO "Acquisition PARAMETRE_REPIM.TXT"
  $REPBDF/evolmpm/acquisition/shell/evo_load_param.sh REF_PARAM_REPIM PARAMETRE_REPIM.csv  
}

main () {

  START
  
  SETUP

  if [[ ${do_ref_pays_territoire_sepa} == "yes" ]] ; then f_ref_pays_territoire_sepa; fi
  
  if [[ ${do_ref_pays_iso} == "yes" ]] ; then f_ref_pays_iso; fi
  
  if [[ ${do_ref_pays_euro} == "yes" ]] ; then f_ref_pays_euro; fi
  
  if [[ ${do_ref_type_operation} == "yes" ]] ; then f_ref_type_operation; fi
  
  if [[ ${do_ref_motif_annulation} == "yes" ]] ; then f_ref_motif_annulation; fi
  
  if [[ ${do_ref_motif_rejet} == "yes" ]] ; then f_ref_motif_rejet; fi
  
  if [[ ${do_ref_code_ope_evolmpm} == "yes" ]] ; then f_ref_code_ope_evolmpm; fi
  
  if [[ ${do_ref_param_repim} == "yes" ]] ; then f_ref_param_repim; fi
  
  END
  
  exit ${__SUCCESS}

}
main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
