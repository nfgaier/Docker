#!/usr/bin/env bash
###############################################################################
# Description :     Simulation de l'ordonnancement de la cha�ne d'acquisition Evolmpm SIO
# Usage :           Pas de param�tre
#                   Les variables do_* (yes/no) permettent d'activer ou non chaque module
# Author :          LCO
# Updated :         20/02/2018
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec            #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

REP_CONF="$EVO_ACQ_CONF_PATH"
NOM_TRAITEMENT="ACQUISITION_EVOLMPM"

# D�finition du mode : $MODE_ALIM_INTERVAL (dev et rec)
#                   ou $MODE_ALIM_INTERVAL_SUP (dev et rec)
#                   ou $MODE_ALIM_LIST_DATE (dev et rec)
#                   ou $MODE_ALIM_QUOTI (tout env)
MODE="$MODE_ALIM_INTERVAL"

# Param�tres pour le mode $MODE_ALIM_INTERVAL ou $MODE_ALIM_INTERVAL_SUP
# Pour l'acquisition d'une seule date_ope, INTERVAL_DEBUT = INTERVAL_FIN = date_ope
INTERVAL_DEBUT="2019-01-01"
INTERVAL_FIN="2019-01-02"

# Param�tres pour le mode $MODE_ALIM_LIST_DATE (� s�parer par des espaces)
LIST_DATE="2019-01-01 2019-01-05 2019-01-10"

do_upd_ko="yes"
do_init_statut="yes"
do_constr_date_ope="yes"
do_pilot="yes"
do_rm_fic_vide="yes"
do_valid="yes"
#do_copy_land_raw="yes"

#######################################
# Description:  S�rie de fonctions appelant les shells avec les bons param�tres
# Arguments:    Pas d'argument
# Returns:      
#######################################
UPD_KO () {

    LOG_INFO "Mise � jour des statuts En cours � KO pour ${NOM_TRAITEMENT}"
    $REPBDF/common/suivi/shell/upd_ko.sh "${REP_CONF}" "${NOM_TRAITEMENT}"
}

INIT_STATUT () {

    LOG_INFO "Initialisation du chargement de ${NOM_TRAITEMENT}"
    $REPBDF/common/suivi/shell/init_statut.sh "${REP_CONF}" "${NOM_TRAITEMENT}"
}

CONSTR_DATE_OPE_SIO_AV_WKF () {

    LOG_INFO "Alimentation du catalogue en mode ${MODE} pour ${NOM_TRAITEMENT}"
    $REPBDF/common/suivi/shell/constr_date_sio_av_wkf.sh "${REP_CONF}" "${NOM_TRAITEMENT}"
}

CONSTR_INTERVAL_DATE () {

    LOG_INFO "Alimentation du catalogue en mode ${MODE} pour ${NOM_TRAITEMENT}"
    $REPBDF/common/suivi/shell/constr_interval_date.sh "${REP_CONF}" "${NOM_TRAITEMENT}" "${INTERVAL_DEBUT}" "${INTERVAL_FIN}"
}

CONSTR_INTERVAL_DATE_SUP () {

    LOG_INFO "Alimentation du catalogue en mode ${MODE} pour ${NOM_TRAITEMENT}"
    $REPBDF/common/suivi/shell/constr_interval_date_sup.sh "${REP_CONF}" "${NOM_TRAITEMENT}" "${INTERVAL_DEBUT}" "${INTERVAL_FIN}"
}

CONSTR_LIST_DATE () {

    LOG_INFO "Alimentation du catalogue en mode ${MODE} pour ${NOM_TRAITEMENT}"
    $REPBDF/common/suivi/shell/constr_list_date.sh "${REP_CONF}" "${NOM_TRAITEMENT}" "${LIST_DATE}"
}

PILOT () {

    LOG_INFO "Lancement du script pilote"
    $REPBDF/common/pilote/shell/acq_pilot.sh  "${REP_CONF}" "${REP_CONF}"
}

RM_FICHIER_VIDE () {
    
    LOG_INFO "Nettoyage des partitions (suppression des fichiers vides)"
    $REPBDF/common/util/shell/hdfs_rm_fichier_vide.sh  "${REP_CONF}" "${NOM_TRAITEMENT}"
}

VALID () {

    LOG_INFO "Validation du chargement de ${NOM_TRAITEMENT}"
    $REPBDF/common/suivi/shell/valid.sh "${REP_CONF}" "${NOM_TRAITEMENT}"
}

#COPY_LAND_RAW () {
#
#    REQ="select max(id_job) from ${TOT} where status = '${ST_DISPO_COPIE_LAND_ROW}'"                                     
#    ID_TRT_TO_COPY=$(PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -t -A -c "$REQ")
#    
#    LOG_INFO "copie des donn�es de la LANDING vers la RAW Layer"
#    $REPBDF/embargo/acquisition/shell/copy_land_raw.sh "$ID_TRT_TO_COPY" "$ENVAPPLI"
#}



#######################################
# Description:  Fonction principale, appel�e dans le corps du script
# Arguments:    Pas d'argument
# Returns:      
#######################################
main () {

  START
  SETUP
    
    if [[ ( $MODE == "$MODE_ALIM_INTERVAL" || $MODE == "$MODE_ALIM_INTERVAL_SUP" || $MODE == "$MODE_ALIM_LIST_DATE" ) && ( $ENVAPPLI == 'INT' || $ENVAPPLI == 'PRD' ) ]]
    then
        LOG_ERROR "Mode ${MODE} non autoris� en INT ou PROD"
        exit $__FAILURE
    fi
    
    
    case $MODE in
        "${MODE_ALIM_QUOTI}") CONSTR_DATE_OPE='CONSTR_DATE_OPE_SIO_SS_WKF' ;;
        "${MODE_ALIM_INTERVAL}") CONSTR_DATE_OPE='CONSTR_INTERVAL_DATE' ;;
        "${MODE_ALIM_INTERVAL_SUP}") CONSTR_DATE_OPE='CONSTR_INTERVAL_DATE_SUP' ;;
        "${MODE_ALIM_LIST_DATE}") CONSTR_DATE_OPE='CONSTR_LIST_DATE' ;;
    esac
    
    if [[ ${do_upd_ko} == "yes" ]] ; then UPD_KO; fi
    
    if [[ ${do_init_statut} == "yes" ]] ; then INIT_STATUT; fi
    
    if [[ ${do_constr_date_ope} == "yes" ]] ; then eval $CONSTR_DATE_OPE; fi
    
    if [[ ${do_pilot} == "yes" ]] ; then PILOT; fi
    
    if [[ ${do_rm_fic_vide} == "yes" ]] ; then RM_FICHIER_VIDE; fi
    
    if [[ ${do_valid} == "yes" ]] ; then VALID; fi
    
#    if [[ ${do_copy_land_raw} == "yes" ]] ; then COPY_LAND_RAW; fi

  END
  exit ${__SUCCESS}
  
}

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
