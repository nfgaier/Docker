#!/usr/bin/env bash
###############################################################################
# Description :     Simulation de l'ordonnancement de la chaîne d'acquisition Embargo
# Usage :           Pas de paramètre
#                   Les variables do_* (yes/no) permettent d'activer ou non chaque module
# Author :          LCO
# Updated :         28/11/2017
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec            #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

REP_CONF="$EVO_ACQ_CONF_PATH"
NOM_TRAITEMENT="ACQUISITION_EVOLMPM_REF"

do_upd_ko="yes"
do_init_statut="yes"
do_constr_date_ope="yes"
do_load_param="yes"
do_valid="yes"
do_copy_land_row="yes"
do_copy_row_optimized="yes"

#######################################
# Description:  Série de fonctions appelant les shells avec les bons paramètres
# Arguments:    Pas d'argument
# Returns:      
#######################################
upd_ko () {
  LOG_INFO "Mise à jour des statuts En cours à KO pour ${NOM_TRAITEMENT}"
  $REPBDF/common/suivi/shell/upd_ko.sh "${REP_CONF}" "${NOM_TRAITEMENT}"
}

init_statut () {
  LOG_INFO "Initialisation du chargement de ${NOM_TRAITEMENT}"
  $REPBDF/common/suivi/shell/init_statut.sh "${REP_CONF}" "${NOM_TRAITEMENT}"
}

constr_ref_evol () { # TODO remplacer par un appel à constr_catalogue_acq_fichier.sh
  LOG_INFO "Alimentation du catalogue  ${NOM_TRAITEMENT}"
  $REPBDF/common/suivi/shell/constr_ref_evol.sh "${REP_CONF}" "${NOM_TRAITEMENT}"
}

load_param () { # todo renommer (pas pilote)
  LOG_INFO "Lancement du script pilote"
  $REPBDF/evolmpm/acquisition/shell/evo_param_all.sh  
}

valid () {
  LOG_INFO "Validation du chargement de ${NOM_TRAITEMENT}"
  $REPBDF/common/suivi/shell/valid.sh "${REP_CONF}" "${NOM_TRAITEMENT}"
}

copy_land_row () {
# REQ="select id_job from ${TOT} where status = '${ST_DISPO_COPIE_LAND_ROW}' and "                                     
# ID_TRT_TO_COPY=$(PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -t -A -c "$REQ")

# Récupère l'ID_TRAITEMENT en cours
  ID_TRAITEMENT=$(PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -A -t -c " \
                        select max(id_job) \
                        from ${TOT} \
                        where nom_traitement = 'ACQUISITION_EVOLMPM_REF' \
                          and status = '${ST_DISPO_COPIE_LAND_ROW}' ")
  
  LOG_INFO "copie des données de la LANDING vers la RAW Layer"
  $REPBDF/evolmpm/acquisition/shell/copy_land_row_evol_ref.sh "$ID_TRAITEMENT" 
}

copy_row_optimized () {
# REQ="select id_job from ${TOT} where status = '${ST_DISPO_COPIE_LAND_ROW}'"                                     
# ID_TRT_TO_COPY=$(PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -t -A -c "$REQ")
  LOG_INFO "copie des données de la RAW Layer vers la OPTIMIZED Layer"
  $REPBDF/evolmpm/acquisition/shell/copy_row_optmized_evol_ref.sh "$ID_TRAITEMENT" 
}


#######################################
# Description:  Fonction principale, appelée dans le corps du script
# Arguments:    Pas d'argument
# Returns:      
#######################################
main () {

  START
  SETUP
    
  if [[ ${do_upd_ko} == "yes" ]] ; then upd_ko; fi
    
  if [[ ${do_init_statut} == "yes" ]] ; then init_statut; fi
  
  if [[ ${do_constr_date_ope} == "yes" ]] ; then eval constr_ref_evol; fi
    
  if [[ ${do_load_param} == "yes" ]] ; then load_param; fi
    
  if [[ ${do_valid} == "yes" ]] ; then valid; fi
    
  if [[ ${do_copy_land_row} == "yes" ]] ; then copy_land_row; fi
  
  if [[ ${do_copy_row_optimized} == "yes" ]] ; then copy_row_optimized; fi
  
  END
  exit ${__SUCCESS}
  
}

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
