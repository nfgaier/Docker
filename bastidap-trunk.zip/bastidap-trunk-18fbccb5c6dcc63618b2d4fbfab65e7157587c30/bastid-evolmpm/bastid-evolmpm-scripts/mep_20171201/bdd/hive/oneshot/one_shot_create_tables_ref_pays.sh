#!/bin/ksh

# Script en one shot par défaut, mais peut être relancé sans planter, mais perte de données si des chargements ont eu lieu entre temps


set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.param                        #source .param_*_spec
. $APPLI_HOME/appli/connexion/.fonction                        #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

#----------------------------------------------------------------------------------------------------------------------------------
#  MISE EN PLACE DES VARIABLES D'ENVIRONNEMENT
#----------------------------------------------------------------------------------------------------------------------------------
NOM_SCRIPT=`basename $0`
DIR_SCRIPT=`dirname $0`

export DATE=`date +%Y%m%d_%H%M%S`
export JOUR=`date +%Y%m%d`
NOM_SCRIPT=`basename $0`

JOURNAL=journal ; export JOURNAL
LOGFILE=${NOM_SCRIPT}.lst.${DATE} ; export LOGFILE

# Initialisation de variable de fin d'execution
typeset -R6 PID=$$
FIN=0 ; export FIN

#-----------------------------------------------------------------------------
#  FONCTIONS LOCALES
#-----------------------------------------------------------------------------

#-----------------------------------------------------------------------------
#  DEBUT DE LA PROCEDURE
#-----------------------------------------------------------------------------

{
DEBUT

REPLIV=$DIR_SCRIPT

LOG "-------------------------------------------------------------------------"
LOG "Lancement de la cr�ation des tables REF_PAYS_ISO et REF_PAYS_EURO"
LOG "-------------------------------------------------------------------------"

hive --hiveconf tez.queue.name=${ACQ_QUEUE} -f "${REPLIV}/create_tables_ref_pays.hql"

LOG ""
LOG "-------------------------------------------------------------------------"
LOG "Fin de la cr�ation des tables REF_PAYS_ISO et REF_PAYS_EURO"
LOG "-------------------------------------------------------------------------"

FIN
} >>$LST/$LOGFILE 2>&1
