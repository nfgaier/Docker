/**
 * 
 */
package org.spark.evolmpm.agrbible.minos.constant;

import java.io.Serializable;

public class AgrBibleMinosConstant implements Serializable {

    private static final long serialVersionUID = -964672425313628787L;
    
	//hive databases
    public static final String HIVE_WRK_LAYER = "evolmpm_work_layer";
    
    //hive tables
    public static final String MINOS_IC_TABLE = "operations_minos_ic";
    public static final String TARGET_AGR_MINOS_BIBLE_TABLE = "operations_minos_agr_bible";
    
}
