package org.spark.evolmpm.agrbible.minos;

import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.fs.Path;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.spark.evolmpm.agrbible.minos.data.ReadData;
import org.spark.evolmpm.agrbible.minos.data.WriteData;
import org.spark.evolmpm.agrbible.minos.constant.*;


import fr.bdf.bastid.util.bean.LineAcqFile;
import fr.bdf.bastid.util.filereader.AcqFileReader;


public class AgrBibleMinosMain implements Serializable {

    private static final long serialVersionUID = -1038992202477473392L;
    
    public static String getTime() {
        return "[" + new SimpleDateFormat("HH:mm:ss" ).format(new Date()) + "] - ";
    }   
  
    public static void main( String[] args ) {
    	
    	String argument="VIDE";
    	//test
    	for (int i=0;i<args.length;i++)
    	{
    		argument=args[i];
    		System.out.println("Element "+ i +" : "+argument);
    	}
    	
    	//	
    		
    	if(args.length != 4){
    		System.out.println("INFO:" + AgrBibleMinosMain.getTime() + " Missing arguments. Usage: " + 
                    new java.io.File(AgrBibleMinosMain.class.getProtectionDomain().
                            getCodeSource().
                            getLocation().
                            getPath()).getName() 
                    + " <pathToConfigFile>"
					+ " <acqFilePath>"
					+ " <idTrt>"
                    + " <hdfsPath>");
            System.exit(0);
        }
        
        String pathToConfigFile = args[0];
        String acqFilePath = args[1];
        String idTrt = args[2];
        String hdfsPath= args[3]; //hdfs path is different in DEV and the others envs
        
        System.out.println("INFO:" + AgrBibleMinosMain.getTime() + " pathToConfigFile " + pathToConfigFile);
        System.out.println("INFO:" + AgrBibleMinosMain.getTime() + " acqFilePath " + acqFilePath);
        System.out.println("INFO:" + AgrBibleMinosMain.getTime() + " idTrt " + idTrt);
        System.out.println("INFO:" + AgrBibleMinosMain.getTime() + " hdfsPath " + hdfsPath);
        
		final SparkSession session = SparkSession.builder()
				.appName("ParseAgrBibleMinosMain")
				.config("spark.sql.warehouse.dir", "/apps/hive/warehouse")
				.config("spark.sql.hive.convertMetastoreOrc", "false")
				.config("hive.fetch.task.conversion", "none")
				.enableHiveSupport()
				.getOrCreate();
		
        session.sparkContext().hadoopConfiguration().addResource(new Path(pathToConfigFile));
		
        AcqFileReader afr = new AcqFileReader(acqFilePath);
        
        Map<String, List<LineAcqFile>> mapAcqFileLines = getMapAcqFileLines(afr);
		
        String idAcqOperationdsMinosIC = afr.getIdAcqParamOrFull(mapAcqFileLines, AgrBibleMinosConstant.MINOS_IC_TABLE.toUpperCase());
		System.out.println("idAcqOperationdsMinosIC: " + idAcqOperationdsMinosIC);
		
		List<LineAcqFile> listIdAcq = mapAcqFileLines.get(AgrBibleMinosConstant.MINOS_IC_TABLE.toUpperCase());
		
		//List<String> listIdAcq = new ArrayList<>();
		//listIdAcq.add(idAcqOperationdsMinosIC);

		if (!validAcqDelta(listIdAcq)) {
			Logger.getRootLogger().error(
					"At least one of the delta acquisition ids is missing");
			System.exit(0);
		}
        
	    Logger.getRootLogger().setLevel(Level.WARN);
	    
		//List<LineAcqFile> listIdAcq = mapAcqFileLines.get(AgrBibleMinosConstant.MINOS_IC_TABLE.toUpperCase());
               
        
		//reading source data
        ReadData reader = new ReadData(session,idTrt);
        //writing to target table
        WriteData writer = new WriteData(session);
        
        //read data from minos_IC table
        Dataset<Row> operationsMinosICDF = reader.getMinosICAgr(idAcqOperationdsMinosIC);       
        System.out.println("INFO:" + AgrBibleMinosMain.getTime() + "minosAggBibleTableDF : " + operationsMinosICDF.count());
        //operationdsMinosICDF.printSchema();
        
        Dataset<Row> agrBibleMinosCibleDF = writer.prepareAgrBibleMinos(operationsMinosICDF);
		System.out.println("AgrBibleMinosDF : " + agrBibleMinosCibleDF.count());
		
		//write to target table operations_minos
		writer.writeAggBibleMinosData(hdfsPath,agrBibleMinosCibleDF,idTrt);
        
        
        session.close();
        
    }
    
	/**
	 * Method that gets the acquisition ids needed for the treatment.
	 * 
	 * @param afr
	 *            the acquisition file reader
	 * @return the map that contains the acquisition ids needed for the
	 *         treatment
	 */
	private static Map<String, List<LineAcqFile>> getMapAcqFileLines(
			AcqFileReader afr) {
		Map<String, List<LineAcqFile>> mapAcqFileLines = null;
		try {
			mapAcqFileLines = afr.getAcqFileLines();
		} catch (IOException e) {
			Logger.getRootLogger().error(
					"An error occured when reading the file", e);
			System.exit(0);
		}

		if (mapAcqFileLines == null || mapAcqFileLines.isEmpty()) {
			Logger.getRootLogger().error(
					"The acquisition id map is null or empty");
			System.exit(0);
		}
		return mapAcqFileLines;
	}
	
	/**
	 * Method that verifies if the acquisition ids for delta tables are valid.
	 * 
	 * @param listIdAcqHistMess
	 *            the list of acquisition ids 
	 * @return true if all the acquisition ids are valid, false if not
	 */
	private static boolean validAcqDelta(List<LineAcqFile> listIdAcqHistMess) {
		return listIdAcqHistMess != null && !listIdAcqHistMess.isEmpty();
	}
}