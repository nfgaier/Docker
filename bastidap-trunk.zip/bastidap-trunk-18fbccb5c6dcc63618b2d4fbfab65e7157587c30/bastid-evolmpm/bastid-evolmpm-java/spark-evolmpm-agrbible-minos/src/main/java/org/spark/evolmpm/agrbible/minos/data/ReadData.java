package org.spark.evolmpm.agrbible.minos.data;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.spark.evolmpm.agrbible.minos.constant.AgrBibleMinosConstant;

/**import fr.bdf.bastid.util.bean.LineAcqFile;*/

public class ReadData implements Serializable {

	private static final long serialVersionUID = 1643057746251108370L;

	private SparkSession sqlContext;
	String idTrt;
	//private List<LineAcqFile> listIdAcq;

	/**
	 * @param sqlContext
	 */
	public ReadData(SparkSession sqlContext, String idTrt) {
		super();
		this.sqlContext = sqlContext;
		this.idTrt = idTrt;
	}

    /**
     * Reads the data from the table operation_minos_ic 
     * Aggregates the data.
     * Calculate two indicators
     * cast the results of each returned columns
     * @return Dataset<Row>
     */
	
    public Dataset<Row> getMinosICAgr(String idAcqOperationsMinosIC ) {
        
    	String req = "select cast(date_format(date_echange,'yyyy') as int) as annee_date_echange, "
			                + "cast(date_format(date_echange,'MM') as int) as mois_date_echange, "
			                + "cast(date_echange as date), "
			                + "cast(code_type_client as string), "
			                + "cast(compte_encaissement as string), "
			                + "cast(compte_encaissement_a as string), "
			                + "cast(code_guichet_encaissement as string), "
			                + "cast(compte_encaissement_client as string), "
			                + "cast(code_guichet_encaissement_a as string), "
			                + "cast(compte_encaissement_client_a as string), "
			                + "cast(s8_id_etblt_dest as string) as cib_destinataire, "
			                + "cast(ref_op_debut as string), "
			                + "cast(numero_tr as string), "
			                + "cast(b_ic_indice_circulation as string) as indice_circulation, "
			                + "cast(delai_credit as string), "
			                + "cast(count(id_operation) as int) as nb_ope, "
			                + "cast(sum(s11_mnt_compense) as decimal(18,2)) as mnt_ope, "
			                + "from_unixtime(unix_timestamp(substring('" + idTrt + "',0,8), 'yyyyMMdd'),'yyyy-MM-dd') as date_insert, "
			 			    + "cast('" + idTrt + "' as string) as id_traitement "
                   + "from " + AgrBibleMinosConstant.HIVE_WRK_LAYER+"."+ AgrBibleMinosConstant.MINOS_IC_TABLE 
                   + " where id_traitement = '"+ idAcqOperationsMinosIC +"' " 
          /*           + "and sens_echange='E' "
                     + "and s6_id_etblt_do=30001 "   filtre pour avoir un resultat*/
                   + "group by "
		           + "cast(date_format(date_echange,'yyyy') as int), "
		           + "cast(date_format(date_echange,'MM') as int), "
		           + "date_echange, "
		           + "code_ope, "
		           + "sens_echange, "
		           + "s6_id_etblt_do, "
		           + "code_type_client, "
		           + "compte_encaissement, "
		           + "compte_encaissement_a, "
		           + "code_guichet_encaissement, "
		           + "compte_encaissement_client, "
		           + "code_guichet_encaissement_a, "
		           + "compte_encaissement_client_a, "
		           + "s8_id_etblt_dest, "
		           + "ref_op_debut, "
		           + "numero_tr, "
		           + "b_ic_indice_circulation, "
		           + "delai_credit, "
		           + "date_insert "
		           ; 
    	
           /*ajouter le filtre sur la date dechange*/
           /*   + "and date_echange=from_unixtime(unix_timestamp(substring('" + idTrt + "',0,8), 'yyyyMMdd'),'yyyy-MM-dd') "*/
            
		System.out.println("INFO:" + "[" + new SimpleDateFormat("HH:mm:ss" ).format(new Date()) + "] - " 
				+ "getMinosICAgr query : " + req );

    	
        return sqlContext.sql(req);
    }
    
}
