package org.spark.evolmpm.agrbible.minos.data;

import static org.apache.spark.sql.functions.col;

import java.io.Serializable;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.spark.evolmpm.agrbible.minos.constant.*;


public class WriteData implements Serializable {

    private static final long serialVersionUID = -789223906365051372L;

    private SparkSession sqlContext;
    private String idtrt;
        
    /**
	 * @param sqlContext
	 * @param idtrt
	 */
	public WriteData(SparkSession sqlContext) {
		super();
		this.sqlContext = sqlContext;
	}

   
	/**
	 * Apply transformations to the source data
	 * Sort columns before insertion in target table 
	 * @param data
	 * @return DataFrame
	 */
	public Dataset<Row> prepareAgrBibleMinos(Dataset<Row> data) {

		return data.select(
				col("annee_date_echange").cast("int"),
				col("mois_date_echange").cast("int"),
				col("date_echange").cast("date"),
			    col("code_type_client").cast("string"),
				col("compte_encaissement").cast("string"),
				col("compte_encaissement_a").cast("string"),
				col("code_guichet_encaissement").cast("string"),
				col("compte_encaissement_client").cast("string"),
				col("code_guichet_encaissement_a").cast("string"),
				col("cib_destinataire").cast("string"),
				col("ref_op_debut").cast("string"),
				col("numero_tr").cast("string"),
				col("indice_circulation").cast("string"),
				col("delai_credit").cast("string"),
				col("nb_ope").cast("int"),
				col("mnt_ope").cast("decimal(18,2)"),
				col("date_insert").cast("date"),
				col("id_traitement").cast("string")
				)
				;
	}
	
    /**
     * Write Dataset<Row> as orc file in the HDFS path of the target table
     * Add partition to target table.
     * @param data
     */
    public void writeAggBibleMinosData (String path,Dataset<Row> data,String idTraitement) {
        
        //write to path
    	data.write().partitionBy("id_traitement")
        		    .format("orc")
        		    .mode("append")
        		    .save(path +  AgrBibleMinosConstant.TARGET_AGR_MINOS_BIBLE_TABLE);
    	 System.out.println("chemin :" + path +  AgrBibleMinosConstant.TARGET_AGR_MINOS_BIBLE_TABLE);
       //add partition
    	String alterTableStmt = "ALTER TABLE " + AgrBibleMinosConstant.HIVE_WRK_LAYER+"." + AgrBibleMinosConstant.TARGET_AGR_MINOS_BIBLE_TABLE 
                			 + " ADD IF NOT EXISTS PARTITION (id_traitement='"+ idTraitement +"') location '"+ path + AgrBibleMinosConstant.TARGET_AGR_MINOS_BIBLE_TABLE  + "/id_traitement="+ idTraitement +"'" ;
        System.out.println("INFO: " +  alterTableStmt);
        sqlContext.sql(alterTableStmt);
    }

			
}