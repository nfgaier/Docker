package org.spark.evolmpm.agrbible.minos;

import junit.framework.TestCase;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.security.UserGroupInformation;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.spark.evolmpm.agrbible.minos.data.ReadData;
import org.spark.evolmpm.agrbible.minos.data.WriteData;
import org.spark.evolmpm.agrbible.minos.constant.*;

import fr.bdf.bastid.util.bean.LineAcqFile;
import fr.bdf.bastid.util.filereader.AcqFileReader;



@SuppressWarnings("unused")
public class AgrBibleMinosMainTest  extends TestCase {
	
	
	private String getWhereClause(List<LineAcqFile> listIdAcq) {
		StringBuilder sb = new StringBuilder(" WHERE");
		for (LineAcqFile line : listIdAcq) {
			sb.append(" (dtjco = '").append(line.getJourFonc())
			.append("' AND id_traitement = '").append(line.getIdAcq()).append("') OR");
		}
		
		System.out.println(sb.substring(0, sb.length() - 3));
		
		return sb.substring(0, sb.length() - 3);
	}
    
    
    public void testApp() {
        /*
        String pathDiff= "s_devolmpm";
        String acqFilePath = "src/test/resources/id_MINOS.tmp";
        String idTrt ="20171107170425";
                
        System.out.println("INFO:" + ParseMinosMain.getTime() + " acqFilePath " + acqFilePath);
        System.out.println("INFO:" + ParseMinosMain.getTime() + " idTrt " + idTrt);
        System.out.println("INFO:" + ParseMinosMain.getTime() + " pathDiff " + pathDiff);
        //System.setProperty("sun.security.krb5.debug","true");
        
        System.setProperty("hive.metastore.execute.setugi", "true");
        //System.setProperty("hive.server2.enable.doAs", "true");
        
		System.setProperty("hadoop.home.dir","C:\\DEV\\hadoop");
		System.setProperty("dfs.nameservices","trump");
        
        org.apache.hadoop.conf.Configuration conf = new org.apache.hadoop.conf.Configuration();
        conf.set("hadoop.security.authentication", "Kerberos");
        UserGroupInformation.setConfiguration(conf);
        try {

        	File targetFile = new File("src/main/resources/bastidap1asv.keytab");
        	System.out.println(UserGroupInformation.getLoginUser().toString());
        	UserGroupInformation.loginUserFromKeytab("BASTIDAP1ASV/lxdv304a.unix-int.intra-int.bdf-int.local@INTRA-DEV01.BDF-DEV01.LOCAL", targetFile.getAbsolutePath() 
        	// "C:\\tmp\\keytab\\bastidap1asv.keytab"
        	  );



        } catch (IOException e) {
        	// TODO Auto-generated catch block
        	e.printStackTrace();
        }

        		
       
		final SparkSession session = SparkSession.builder()
				.master("local[*]")
				.appName("ParseMinosMaintest")
				.config("spark.sql.warehouse.dir", "C:\\tmp\\hive")
				.config("spark.sql.hive.convertMetastoreOrc", "false")
				.enableHiveSupport().getOrCreate();
		
		
        //sc.setLogLevel("WARN");
        //sqlContext.sql("show databases").show();
        session.sql("show databases").show();
        session.sql("show tables").show();
        
        //session.sql(" select * from evolmpm_raw_layer.th70  WHERE (dtjco = '2017-10-27' AND id_traitement = '20171108154854') limit 10").show();
        
        AcqFileReader afr = new AcqFileReader(acqFilePath);
        
        Map<String, List<LineAcqFile>> mapAcqFileLines = getMapAcqFileLines(afr);
		
		List<LineAcqFile> listIdAcqMinos = mapAcqFileLines
				.get(ParseMinosConstant.MINOS_TABLE.toUpperCase());

		if (!validAcqDelta(listIdAcqMinos)) {
			Logger.getRootLogger().error(
					"At least one of the delta acquisition ids is missing");
			System.exit(0);
		}

		getWhereClause(listIdAcqMinos);
		
		
		/*
		//reading source data
        ReadData reader = new ReadData(session,listIdAcqMinos);
        
        //writing to target table
        WriteData writer = new WriteData(session,idTrt,pathDiff);
        
        //read data from th70 table
        Dataset<Row> minosTableDF = reader.getMinosData();
        
       //minosTableDF.printSchema();
        System.out.println("INFO:" + ParseMinosMain.getTime() + "minosTableDF : " + minosTableDF.count());
        
        //make transformations, select columns in the correct order
        Dataset<Row> minosTablePrepDF = writer.prepareMinosData(minosTableDF);
        
        System.out.println("INFO:" + ParseMinosMain.getTime() + "minosTablePrepDF : " + minosTablePrepDF.count());
        //minosTablePrepDF.printSchema();
     
        //wirte to target table operations_minos
        writer.writeMinosData(minosTablePrepDF);
        
        session.close();

   */
        
        assertTrue( true );
    }
    
    
   	/**
   	 * Method that gets the acquisition ids needed for the treatment.
   	 * 
   	 * @param afr
   	 *            the acquisition file reader
   	 * @return the map that contains the acquisition ids needed for the
   	 *         treatment
   	 */
   	private static Map<String, List<LineAcqFile>> getMapAcqFileLines(
   			AcqFileReader afr) {
   		Map<String, List<LineAcqFile>> mapAcqFileLines = null;
   		try {
   			mapAcqFileLines = afr.getAcqFileLines();
   		} catch (IOException e) {
   			Logger.getRootLogger().error(
   					"An error occured when reading the file", e);
   			System.exit(0);
   		}

   		if (mapAcqFileLines == null || mapAcqFileLines.isEmpty()) {
   			Logger.getRootLogger().error(
   					"The acquisition id map is null or empty");
   			System.exit(0);
   		}
   		return mapAcqFileLines;
   	}
   	
   	/**
   	 * Method that verifies if the acquisition ids for delta tables are valid.
   	 * 
   	 * @param listIdAcqHistMess
   	 *            the list of acquisition ids 
   	 * @return true if all the acquisition ids are valid, false if not
   	 */
   	private static boolean validAcqDelta(List<LineAcqFile> listIdAcqHistMess) {
   		return listIdAcqHistMess != null && !listIdAcqHistMess.isEmpty();
   	}
}



