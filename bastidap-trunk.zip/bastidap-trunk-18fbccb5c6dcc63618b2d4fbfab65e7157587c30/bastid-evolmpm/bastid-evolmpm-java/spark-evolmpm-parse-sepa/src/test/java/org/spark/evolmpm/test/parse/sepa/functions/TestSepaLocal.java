package org.spark.evolmpm.test.parse.sepa.functions;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.api.java.UDF2;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.spark.evolmpm.parse.sepa.constant.ParseSepaConstant;

import scala.collection.Seq;
import scala.collection.immutable.Set;

/** gestion des LOGs */
import org.apache.log4j.Logger;

import static org.apache.spark.sql.functions.callUDF;
import static org.apache.spark.sql.functions.col;
import static org.apache.spark.sql.functions.concat;
import static org.apache.spark.sql.functions.date_format;
import static org.apache.spark.sql.functions.lit;
import static org.apache.spark.sql.functions.substring;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Level;




public class TestSepaLocal {

	

	
	/** 
	 * function for getting orc data in a dataframe
	 */
	public static Dataset<Row> getOrcData (SparkSession session) {
      	
		Dataset<Row> table =  session.read()
      			         .format("orc")
      			         .load("src/test/resources/000000_0");
      	
		return table
		.select(
       			
				col("_col0").as("debemb"),
				col("_col1").as("rfopi"),
				col("_col2").as("tyopec"),
				col("_col3").as("seopec"),
				col("_col4").as("ddops2"),
				col("_col5").as("mtopa2"),
				col("_col6").as("coops"),
				col("_col7").as("cofamo"),
				col("_col8").as("nuprm"),
				col("_col9").as("coclc"),
				col("_col10").as("idees4"),
				col("_col11").as("idiba1"),
				col("_col12").as("iddss2"),
				col("_col13").as("idiba2"),
				col("_col14").as("e8rme"),
				col("_col15").as("ddpre"),
				col("_col16").as("hepre"),
				col("_col17").as("nurms1"),
				col("_col18").as("ddpre1"),
				col("_col19").as("hepre1"),
				col("_col20").as("e8trav"),
				col("_col21").as("idefe"),
				col("_col22").as("xtimts"),
				col("_col23").as("cocll"),
				col("_col24").as("rfopsc"),
				col("_col25").as("codoar"),
				col("_col26").as("inopr"),
				col("_col27").as("nopart"),
				col("_col28").as("xpart1"),
				col("_col29").as("xpartt"),
				col("_col30").as("rfopso"),
				col("_col31").as("rfeeso"),
				col("_col32").as("idopso"),
				col("_col33").as("dtjco"),
				col("_col34").as("date_ope"),
				col("_col35").as("date_insert")

          		)
				;
	}
	
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Logger.getLogger("org").setLevel(Level.ERROR);
		
		 /** Init configuration and contexts */		
      	final SparkSession session = SparkSession.builder()
      				.appName("ParseSepa")
      				.master("local[*]")       			
      				.getOrCreate();      
         	
    
    	

//        List<String[]> stringAsList = new ArrayList<>();
//        stringAsList.add(new String[] { "2017-12-07", "120000" });
//        stringAsList.add(new String[] { "2017-12-07", "164345" });
//        stringAsList.add(new String[] { "2017-12-07", "000000" });
//        JavaSparkContext sparkContext = new JavaSparkContext(session.sparkContext());



     //   JavaRDD<Row> rowRDD = sparkContext.parallelize(stringAsList).map((String[] row) -> RowFactory.create(row));

        
        // Creates schema
        StructType schema = DataTypes
                .createStructType(new StructField[] { DataTypes.createStructField("ddpre1", DataTypes.StringType, false),
                        DataTypes.createStructField("hepre1", DataTypes.StringType, false) });

      //  Dataset<Row> df = session.createDataFrame(rowRDD, schema).toDF();
       
      //  df.show();
//        Dataset<Row> dfFinal = df.select(
//        		date_format(concat(date_format(col("depre1"),"yyyy-MM-dd"), lit(" "), substring(col("hepre1"), 0, 2), lit(":"),substring(col("hepre1"), 3, 2), lit(":"),substring(col("hepre1"), 5, 2)),"yyyy-MM-dd HH:mm:ss" ).as("date_pec_amont"),
//        	    		concat(date_format(col("depre1"),"yyyy-MM-dd"), lit(" "), substring(col("hepre1"), 1, 2), lit(":"),substring(col("hepre1"), 3, 2), lit(":"),substring(col("hepre1"), 5, 2)).cast(DataTypes.TimestampType).as("date_presentation_remise")
//       );
//        
//        dfFinal.show(10, 100);
	
        /**
         * Format an 8 character string YYYYMMDD to an java.sql.Date 
         * @param input
         * @return java.sql.Date
         */
        UDF2 <java.sql.Date ,String ,java.sql.Timestamp > fromStringtoDate = new UDF2<java.sql.Date ,String, java.sql.Timestamp >() {
            /**
    		 * 
    		 */
    		private static final long serialVersionUID = -2195142808032642264L;

    		/**,
             * 
             */
            public java.sql.Timestamp call(final java.sql.Date  date,final String heures ) throws Exception {
                if (date != null &&  heures != null && heures.trim() != null && heures.length() == 6) {
                    
                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    format.setLenient(false) ;
                    String dateComplete=date.toString()+" "+ StringUtils.substring(heures, 0,2)+":"+StringUtils.substring(heures, 2, 4)+":"+StringUtils.substring(heures, 4, 6);
                    System.out.println(dateComplete);
                    try {
                    	 java.util.Date  timestamp = format.parse(dateComplete);
                        return new java.sql.Timestamp(timestamp.getTime());  
                    } catch (ParseException e) {
                       e.printStackTrace();
                       return null;
                    }
                }
                else {
                    return null;
                }
            }
        };
        
        session.udf().register("fromStringtoDate", fromStringtoDate, DataTypes.TimestampType);
        
        Dataset<Row> df =  getOrcData(session) ; 
        df.printSchema();
        Dataset<Row> dfFinal = df.select(
    		  callUDF("fromStringtoDate",col("ddpre1"),col("hepre1")).as("date_presentation_remise")
    		  );

      	dfFinal.show(10, 100);
      	
//      	dfFinal.write()	    
//		    .format("com.databricks.spark.csv")
//		    .mode("append")
//		    .save("C:\\tmp\\hive\\th70");  
	}
	
}
