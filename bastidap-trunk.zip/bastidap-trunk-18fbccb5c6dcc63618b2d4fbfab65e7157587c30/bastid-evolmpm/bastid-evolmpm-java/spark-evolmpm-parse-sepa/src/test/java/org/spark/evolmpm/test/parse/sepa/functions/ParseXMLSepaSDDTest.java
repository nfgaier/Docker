package org.spark.evolmpm.test.parse.sepa.functions;

import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import junit.framework.Assert;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.spark.evolmpm.parse.sepa.functions.ParseXMLSepaSDD;
import org.w3c.dom.Document;
import org.w3c.dom.Element;



public class ParseXMLSepaSDDTest {

	
	
	private ParseXMLSepaSDD parser;

	@Before
	public void init() {
		this.parser = new ParseXMLSepaSDD();
	}
	
	
	
	@Test
	public void testCodeOpe321() throws Exception {
		
		/** Initialisation du XML */
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = builderFactory.newDocumentBuilder();
		InputStream input = getClass().getClassLoader().getResourceAsStream("example-code-381.xml");
		Document xml = builder.parse(input);
		Element root = xml.getDocumentElement();
		XPathFactory xpf = XPathFactory.newInstance();
		XPath path = xpf.newXPath();
		
		/** TESTS */
		Assert.assertEquals(parser.getTagNUM_ICS(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagPMTID_TXID(path, root), "5337-B2BSDD-17304-501-00000114");
		Assert.assertEquals(parser.getTagPMTID_INSTRID(path, root), "17304-5337-PSR-B2B-01-00000316");
		Assert.assertEquals(parser.getTagPMTID_ENDTOENDID(path, root), "220270550700055324504");
		Assert.assertEquals(parser.getTagPMTTPI_SVCLVL_CD(path, root), "SEPA");
		Assert.assertEquals(parser.getTagPMTTPI_LCLINS_CD(path, root), "B2B");
		Assert.assertEquals(parser.getTagPMTTPILCLINS_PRTRY(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagPMTTPI_SEQTP(path, root), "RCUR");
		Assert.assertEquals(parser.getTagPMTTPI_CTGYPURP(path, root), "TAXS");
		Assert.assertEquals(parser.getTagINTRBKSTTLMAMT(path, root), "81.00");
		Assert.assertEquals(parser.getTagINTRBKSTTLMAMTC(path, root), "EUR");
		Assert.assertEquals(parser.getTagCHRGBR(path, root), "SLEV");
		Assert.assertEquals(parser.getTagREQDCOLLTNDT(path, root), "2017-11-02");
		Assert.assertEquals(parser.getTagM_MNDTID(path, root), "++449067479DGFIP20150IHNAUIG9N84CX");
		Assert.assertEquals(parser.getTagM_DTOFSGNTR(path, root), "2015-10-27");
		Assert.assertEquals(parser.getTagM_AMDMNTIND(path, root), "false");
		Assert.assertEquals(parser.getTagM_A_ORGNLMNDTID(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagM_A_S_NM(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagM_A_S_ID_PROID(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagM_A_S_ID_PRO_SCH_CD(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagM_A_S_ID_PRO_SCH_PRTRY(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagM_A_S_ID_PRO_ISSR(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagM_A_ODAC_ID_IBAN(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagM_A_ODAG_FI_OTHR_ID(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagM_ELCTRNCSGNT(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagCSCH_IDPROI(path, root), "FR46ZZZ005002");
		Assert.assertEquals(parser.getTagCSCH_IDPROI_CD(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagCSCH_IDPROI_PRTRY(path, root), "SEPA");
		Assert.assertEquals(parser.getTagCSCH_IDPROI_ISSR(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUCDT_NAME(path, root), "DGFIP IMPOT");
		Assert.assertEquals(parser.getTagUCDT_ID_ORG_BIC_BEI(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUCDT_ID_ORG_OTHR_ID(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUCDT_ID_ORG_OTHR_SCH_CD(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUCDT_ID_ORG_OTHR_SCH_PRTRY(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUCDT_ID_ORG_OTHR_ISSR(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUCDT_ID_PR_DPBI_DA(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUCDT_ID_PR_DPBI_PRV(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUCDT_ID_PR_DPBI_CT(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUCDT_ID_PR_DPBI_CR(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUCDT_ID_PRV_OTHR_ID(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUCDT_ID_PRV_OTHR_SCH_CD(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUCDT_ID_PRV_OTHR_SCH_PRTR(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUCDT_ID_PRV_OTHR_ISSR(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagDBT_NAME(path, root), "SARL FRANCOIS GENTY");
		Assert.assertEquals(parser.getTagDBT_PADR_ADRLINE(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagDBT_PADR_CTRY(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagDBT_ID_ORG_BIC_BEI(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagDBT_ID_ORG_OTHR_ID(path, root), "449067479");
		Assert.assertEquals(parser.getTagDBT_ID_ORG_OTHR_SCH_CD(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagDBT_ID_ORG_OTHR_SCH_PRTRY(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagDBT_ID_ORG_OTHR_ISSR(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagDBT_ID_PR_DPBI_DAT(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagDBT_ID_PR_DPBI_PRV(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagDBT_ID_PR_DPBI_CTY(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagDBT_ID_PR_DPBI_CR(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagDBT_ID_PRV_OTHR_ID(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagDBT_ID_PRV_OTHR_SCH_CD(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagDBT_ID_PRV_OTHR_SCH_PRTR(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagDBT_ID_PRV_OTHR_ISSR(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagDBTACC_ID_IBAN(path, root), "FR6030002083310000071183Q47");
		Assert.assertEquals(parser.getTagDBTAGT_FI_BIC(path, root), "CRLYFRPP");
		Assert.assertEquals(parser.getTagCDTACC_ID_IBAN(path, root), "FR4430001003764277M05001579");
		Assert.assertEquals(parser.getTagCDTAGT_FI_BIC(path, root), "BDFEFRPPCCT");
		Assert.assertEquals(parser.getTagCDT_NAME(path, root), "DGFIP");
		Assert.assertEquals(parser.getTagCDT_PADR_ADRLINE(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagCDT_PADR_CTRY(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUDBT_NAME(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUDBT_ID_ORG_BIC_BEI(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUDBT_ID_ORG_OTHR_ID(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUDBT_ID_ORG_OTHR_SCH_CD(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUDBT_ID_ORG_OTHR_SCH_PRTR(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUDBT_ID_ORG_OTHR_SCH_ISSR(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUDBT_ID_PR_DPBI_DAT(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUDBT_ID_PR_DPBI_PRV(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUDBT_ID_PR_DPBI_CTY(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUDBT_ID_PR_DPBI_CRY(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUDBT_ID_PRV_OTHR_ID(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUDBT_ID_PRV_OTHR_SCH_CD(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUDBT_ID_PRV_OTHR_SCH_PRTR(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagUDBT_ID_PRV_OTHR_ISSR(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagINSGAGT_FI_BIC(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagINSDAGT_FI_BIC(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagRMTINF_USTRD(path, root), "IS-102017-2572");
		Assert.assertEquals(parser.getTagRMTINF_STRD_TYPE_CODE(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagRMTINF_STRD_TYPE_REF(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagPUR_CD(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagBIC_ID_Debitor(path, root), "BDFEFRPPCCT");
		Assert.assertEquals(parser.getTagBIC_ID_Creditor(path, root), "CRLYFRPP");
		Assert.assertEquals(parser.getTagIBAN_DEBTOR (path, root), "FR6030002083310000071183Q47");
		Assert.assertEquals(parser.getTagIBAN_CREDITOR (path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagM_A_ODAC_V9_ID_OTHR_ID(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagM_A_ODAC_V9_FI_BIC(path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagBIC_ID_DO(path, root), "BDFEFRPPCCT");
		Assert.assertEquals(parser.getTagIBAN_DO  (path, root), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTagBIC_ID_BENEFICIAIRE(path, root), "CRLYFRPP");
		Assert.assertEquals(parser.getTagIBAN_BENEFICIAIRE(path, root), "FR6030002083310000071183Q47");


		
	}
	
	
	
}
