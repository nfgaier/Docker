package org.spark.evolmpm.parse.sepa.beans;

import java.io.Serializable;

public class DataInputBean implements Serializable {

	
	/**
	 * 
	 */
	/**
	 * 
	 */
	private static final long serialVersionUID = -5338306231440032721L;

	
	private String id_operation;
	private String code_operation;
	private String code_client_conventionne;
	private String id_systeme_echange;
	private String iban_debitor_sr;
	private String bic_id_debitor_sr;
	private String bic_id_creditor_sr;
	private String iban_creditor_sr;
	private String code_famille_operation;
	private String type_operation;
	private String sens_echange;
	private String num_remise;
	private String num_remise_tech;
	private java.sql.Timestamp date_pec_amont;
	private String heure_pec_amont;
	private java.sql.Timestamp date_presentation_remise;
	private String heure_presentation_remise;
	private String rio;
	private java.sql.Date date_echange;
	private java.sql.Date date_reglement;
	private java.sql.Date date_traitement_aval_recu;
	private String etblt_concerne;
	private String ind_rejet;
	private String flag_debrayage_embargo;
	private java.sql.Timestamp xtimts;
	private String ref_operation_origine;
	private java.sql.Date date_comptable_evolmpm;
	private String pmtid_txid_src;
	private java.math.BigDecimal mnt_compense_sit;
	private String code_flux_arch;
	private String num_partition;
	private String orgnltxid_src;
	private String type_enregistrement;
	private String orgnlinstrid_src;
	private String orgnlendtoendid_src;
	private Integer delai_reglement;
	private String iban_do_sr;
	private String bic_id_do_sr;
	private String bic_id_beneficiaire_sr;
	private String iban_beneficiaire_sr;
	private String code_pays_do_sr;
	private String cle_iban_do_sr;
	private String code_banque_do_sr;
	private String code_guichet_do_sr;
	private String num_cpte_do_sr;
    private String cle_rib_do_sr;
	private String code_pays_beneficiaire_sr;
	private String cle_iban_beneficiaire_sr;
	private String code_banque_beneficiaire_sr;
	private String code_guichet_beneficiaire_sr;
	private String num_cpte_beneficiaire_sr;
	private String cle_rib_beneficiaire_sr;
	private String code_pays_debitor_sr;
	private String cle_iban_debitor_sr;
	private String code_banque_debitor_sr;
	private String code_guichet_debitor_sr;
	private String num_cpte_debitor_sr;
	private String cle_rib_debitor_sr;
	private String code_pays_creditor_sr;
	private String cle_iban_creditor_sr;
	private String code_banque_creditor_sr;
	private String code_guichet_creditor_sr;
	private String num_cpte_creditor_sr;
	private String cle_rib_creditor_sr;
	private java.sql.Date date_insert;
	private java.sql.Date date_ope;
	private Integer id_type_operation;
	private Integer id_client;
	private String code_grp_remettant;
	private String lib_grp_remettant;
	private Integer id_ics;
	private Integer id_compte_do_sr;
	private Integer id_client_do_sr;
	private Integer id_compte_beneficiaire_sr;
	private Integer id_client_beneficiaire_sr;
	private String xpartt;
	private String id_traitement;
	/**
	 * @return the id_operation
	 */
	public String getId_operation() {
		return id_operation;
	}
	/**
	 * @param id_operation the id_operation to set
	 */
	public void setId_operation(String id_operation) {
		this.id_operation = id_operation;
	}
	/**
	 * @return the code_operation
	 */
	public String getCode_operation() {
		return code_operation;
	}
	/**
	 * @param code_operation the code_operation to set
	 */
	public void setCode_operation(String code_operation) {
		this.code_operation = code_operation;
	}
	/**
	 * @return the code_client_conventionne
	 */
	public String getCode_client_conventionne() {
		return code_client_conventionne;
	}
	/**
	 * @param code_client_conventionne the code_client_conventionne to set
	 */
	public void setCode_client_conventionne(String code_client_conventionne) {
		this.code_client_conventionne = code_client_conventionne;
	}
	/**
	 * @return the id_systeme_echange
	 */
	public String getId_systeme_echange() {
		return id_systeme_echange;
	}
	/**
	 * @param id_systeme_echange the id_systeme_echange to set
	 */
	public void setId_systeme_echange(String id_systeme_echange) {
		this.id_systeme_echange = id_systeme_echange;
	}
	/**
	 * @return the iban_debitor_sr
	 */
	public String getIban_debitor_sr() {
		return iban_debitor_sr;
	}
	/**
	 * @param iban_debitor_sr the iban_debitor_sr to set
	 */
	public void setIban_debitor_sr(String iban_debitor_sr) {
		this.iban_debitor_sr = iban_debitor_sr;
	}
	/**
	 * @return the bic_id_debitor_sr
	 */
	public String getBic_id_debitor_sr() {
		return bic_id_debitor_sr;
	}
	/**
	 * @param bic_id_debitor_sr the bic_id_debitor_sr to set
	 */
	public void setBic_id_debitor_sr(String bic_id_debitor_sr) {
		this.bic_id_debitor_sr = bic_id_debitor_sr;
	}
	/**
	 * @return the bic_id_creditor_sr
	 */
	public String getBic_id_creditor_sr() {
		return bic_id_creditor_sr;
	}
	/**
	 * @param bic_id_creditor_sr the bic_id_creditor_sr to set
	 */
	public void setBic_id_creditor_sr(String bic_id_creditor_sr) {
		this.bic_id_creditor_sr = bic_id_creditor_sr;
	}
	/**
	 * @return the iban_creditor_sr
	 */
	public String getIban_creditor_sr() {
		return iban_creditor_sr;
	}
	/**
	 * @param iban_creditor_sr the iban_creditor_sr to set
	 */
	public void setIban_creditor_sr(String iban_creditor_sr) {
		this.iban_creditor_sr = iban_creditor_sr;
	}
	/**
	 * @return the code_famille_operation
	 */
	public String getCode_famille_operation() {
		return code_famille_operation;
	}
	/**
	 * @param code_famille_operation the code_famille_operation to set
	 */
	public void setCode_famille_operation(String code_famille_operation) {
		this.code_famille_operation = code_famille_operation;
	}
	/**
	 * @return the type_operation
	 */
	public String getType_operation() {
		return type_operation;
	}
	/**
	 * @param type_operation the type_operation to set
	 */
	public void setType_operation(String type_operation) {
		this.type_operation = type_operation;
	}
	/**
	 * @return the sens_echange
	 */
	public String getSens_echange() {
		return sens_echange;
	}
	/**
	 * @param sens_echange the sens_echange to set
	 */
	public void setSens_echange(String sens_echange) {
		this.sens_echange = sens_echange;
	}
	/**
	 * @return the num_remise
	 */
	public String getNum_remise() {
		return num_remise;
	}
	/**
	 * @param num_remise the num_remise to set
	 */
	public void setNum_remise(String num_remise) {
		this.num_remise = num_remise;
	}
	/**
	 * @return the num_remise_tech
	 */
	public String getNum_remise_tech() {
		return num_remise_tech;
	}
	/**
	 * @param num_remise_tech the num_remise_tech to set
	 */
	public void setNum_remise_tech(String num_remise_tech) {
		this.num_remise_tech = num_remise_tech;
	}
	/**
	 * @return the date_pec_amont
	 */
	public java.sql.Timestamp getDate_pec_amont() {
		return date_pec_amont;
	}
	/**
	 * @param date_pec_amont the date_pec_amont to set
	 */
	public void setDate_pec_amont(java.sql.Timestamp date_pec_amont) {
		this.date_pec_amont = date_pec_amont;
	}
	/**
	 * @return the heure_pec_amont
	 */
	public String getHeure_pec_amont() {
		return heure_pec_amont;
	}
	/**
	 * @param heure_pec_amont the heure_pec_amont to set
	 */
	public void setHeure_pec_amont(String heure_pec_amont) {
		this.heure_pec_amont = heure_pec_amont;
	}
	/**
	 * @return the date_presentation_remise
	 */
	public java.sql.Timestamp getDate_presentation_remise() {
		return date_presentation_remise;
	}
	/**
	 * @param date_presentation_remise the date_presentation_remise to set
	 */
	public void setDate_presentation_remise(java.sql.Timestamp date_presentation_remise) {
		this.date_presentation_remise = date_presentation_remise;
	}
	/**
	 * @return the heure_presentation_remise
	 */
	public String getHeure_presentation_remise() {
		return heure_presentation_remise;
	}
	/**
	 * @param heure_presentation_remise the heure_presentation_remise to set
	 */
	public void setHeure_presentation_remise(String heure_presentation_remise) {
		this.heure_presentation_remise = heure_presentation_remise;
	}
	/**
	 * @return the rio
	 */
	public String getRio() {
		return rio;
	}
	/**
	 * @param rio the rio to set
	 */
	public void setRio(String rio) {
		this.rio = rio;
	}
	/**
	 * @return the date_echange
	 */
	public java.sql.Date getDate_echange() {
		return date_echange;
	}
	/**
	 * @param date_echange the date_echange to set
	 */
	public void setDate_echange(java.sql.Date date_echange) {
		this.date_echange = date_echange;
	}
	/**
	 * @return the date_reglement
	 */
	public java.sql.Date getDate_reglement() {
		return date_reglement;
	}
	/**
	 * @param date_reglement the date_reglement to set
	 */
	public void setDate_reglement(java.sql.Date date_reglement) {
		this.date_reglement = date_reglement;
	}
	/**
	 * @return the date_traitement_aval_recu
	 */
	public java.sql.Date getDate_traitement_aval_recu() {
		return date_traitement_aval_recu;
	}
	/**
	 * @param date_traitement_aval_recu the date_traitement_aval_recu to set
	 */
	public void setDate_traitement_aval_recu(java.sql.Date date_traitement_aval_recu) {
		this.date_traitement_aval_recu = date_traitement_aval_recu;
	}
	/**
	 * @return the etblt_concerne
	 */
	public String getEtblt_concerne() {
		return etblt_concerne;
	}
	/**
	 * @param etblt_concerne the etblt_concerne to set
	 */
	public void setEtblt_concerne(String etblt_concerne) {
		this.etblt_concerne = etblt_concerne;
	}
	/**
	 * @return the ind_rejet
	 */
	public String getInd_rejet() {
		return ind_rejet;
	}
	/**
	 * @param ind_rejet the ind_rejet to set
	 */
	public void setInd_rejet(String ind_rejet) {
		this.ind_rejet = ind_rejet;
	}
	/**
	 * @return the flag_debrayage_embargo
	 */
	public String getFlag_debrayage_embargo() {
		return flag_debrayage_embargo;
	}
	/**
	 * @param flag_debrayage_embargo the flag_debrayage_embargo to set
	 */
	public void setFlag_debrayage_embargo(String flag_debrayage_embargo) {
		this.flag_debrayage_embargo = flag_debrayage_embargo;
	}
	/**
	 * @return the xtimts
	 */
	public java.sql.Timestamp getXtimts() {
		return xtimts;
	}
	/**
	 * @param xtimts the xtimts to set
	 */
	public void setXtimts(java.sql.Timestamp xtimts) {
		this.xtimts = xtimts;
	}
	/**
	 * @return the ref_operation_origine
	 */
	public String getRef_operation_origine() {
		return ref_operation_origine;
	}
	/**
	 * @param ref_operation_origine the ref_operation_origine to set
	 */
	public void setRef_operation_origine(String ref_operation_origine) {
		this.ref_operation_origine = ref_operation_origine;
	}
	/**
	 * @return the date_comptable_evolmpm
	 */
	public java.sql.Date getDate_comptable_evolmpm() {
		return date_comptable_evolmpm;
	}
	/**
	 * @param date_comptable_evolmpm the date_comptable_evolmpm to set
	 */
	public void setDate_comptable_evolmpm(java.sql.Date date_comptable_evolmpm) {
		this.date_comptable_evolmpm = date_comptable_evolmpm;
	}
	/**
	 * @return the pmtid_txid_src
	 */
	public String getPmtid_txid_src() {
		return pmtid_txid_src;
	}
	/**
	 * @param pmtid_txid_src the pmtid_txid_src to set
	 */
	public void setPmtid_txid_src(String pmtid_txid_src) {
		this.pmtid_txid_src = pmtid_txid_src;
	}
	/**
	 * @return the mnt_compense_sit
	 */
	public java.math.BigDecimal getMnt_compense_sit() {
		return mnt_compense_sit;
	}
	/**
	 * @param mnt_compense_sit the mnt_compense_sit to set
	 */
	public void setMnt_compense_sit(java.math.BigDecimal mnt_compense_sit) {
		this.mnt_compense_sit = mnt_compense_sit;
	}
	/**
	 * @return the code_flux_arch
	 */
	public String getCode_flux_arch() {
		return code_flux_arch;
	}
	/**
	 * @param code_flux_arch the code_flux_arch to set
	 */
	public void setCode_flux_arch(String code_flux_arch) {
		this.code_flux_arch = code_flux_arch;
	}
	/**
	 * @return the num_partition
	 */
	public String getNum_partition() {
		return num_partition;
	}
	/**
	 * @param num_partition the num_partition to set
	 */
	public void setNum_partition(String num_partition) {
		this.num_partition = num_partition;
	}
	/**
	 * @return the orgnltxid_src
	 */
	public String getOrgnltxid_src() {
		return orgnltxid_src;
	}
	/**
	 * @param orgnltxid_src the orgnltxid_src to set
	 */
	public void setOrgnltxid_src(String orgnltxid_src) {
		this.orgnltxid_src = orgnltxid_src;
	}
	/**
	 * @return the type_enregistrement
	 */
	public String getType_enregistrement() {
		return type_enregistrement;
	}
	/**
	 * @param type_enregistrement the type_enregistrement to set
	 */
	public void setType_enregistrement(String type_enregistrement) {
		this.type_enregistrement = type_enregistrement;
	}
	/**
	 * @return the orgnlinstrid_src
	 */
	public String getOrgnlinstrid_src() {
		return orgnlinstrid_src;
	}
	/**
	 * @param orgnlinstrid_src the orgnlinstrid_src to set
	 */
	public void setOrgnlinstrid_src(String orgnlinstrid_src) {
		this.orgnlinstrid_src = orgnlinstrid_src;
	}
	/**
	 * @return the orgnlendtoendid_src
	 */
	public String getOrgnlendtoendid_src() {
		return orgnlendtoendid_src;
	}
	/**
	 * @param orgnlendtoendid_src the orgnlendtoendid_src to set
	 */
	public void setOrgnlendtoendid_src(String orgnlendtoendid_src) {
		this.orgnlendtoendid_src = orgnlendtoendid_src;
	}
	/**
	 * @return the delai_reglement
	 */
	public Integer getDelai_reglement() {
		return delai_reglement;
	}
	/**
	 * @param delai_reglement the delai_reglement to set
	 */
	public void setDelai_reglement(Integer delai_reglement) {
		this.delai_reglement = delai_reglement;
	}
	/**
	 * @return the iban_do_sr
	 */
	public String getIban_do_sr() {
		return iban_do_sr;
	}
	/**
	 * @param iban_do_sr the iban_do_sr to set
	 */
	public void setIban_do_sr(String iban_do_sr) {
		this.iban_do_sr = iban_do_sr;
	}
	/**
	 * @return the bic_id_do_sr
	 */
	public String getBic_id_do_sr() {
		return bic_id_do_sr;
	}
	/**
	 * @param bic_id_do_sr the bic_id_do_sr to set
	 */
	public void setBic_id_do_sr(String bic_id_do_sr) {
		this.bic_id_do_sr = bic_id_do_sr;
	}
	/**
	 * @return the bic_id_beneficiaire_sr
	 */
	public String getBic_id_beneficiaire_sr() {
		return bic_id_beneficiaire_sr;
	}
	/**
	 * @param bic_id_beneficiaire_sr the bic_id_beneficiaire_sr to set
	 */
	public void setBic_id_beneficiaire_sr(String bic_id_beneficiaire_sr) {
		this.bic_id_beneficiaire_sr = bic_id_beneficiaire_sr;
	}
	/**
	 * @return the iban_beneficiaire_sr
	 */
	public String getIban_beneficiaire_sr() {
		return iban_beneficiaire_sr;
	}
	/**
	 * @param iban_beneficiaire_sr the iban_beneficiaire_sr to set
	 */
	public void setIban_beneficiaire_sr(String iban_beneficiaire_sr) {
		this.iban_beneficiaire_sr = iban_beneficiaire_sr;
	}
	/**
	 * @return the code_pays_do_sr
	 */
	public String getCode_pays_do_sr() {
		return code_pays_do_sr;
	}
	/**
	 * @param code_pays_do_sr the code_pays_do_sr to set
	 */
	public void setCode_pays_do_sr(String code_pays_do_sr) {
		this.code_pays_do_sr = code_pays_do_sr;
	}
	/**
	 * @return the cle_iban_do_sr
	 */
	public String getCle_iban_do_sr() {
		return cle_iban_do_sr;
	}
	/**
	 * @param cle_iban_do_sr the cle_iban_do_sr to set
	 */
	public void setCle_iban_do_sr(String cle_iban_do_sr) {
		this.cle_iban_do_sr = cle_iban_do_sr;
	}
	/**
	 * @return the code_banque_do_sr
	 */
	public String getCode_banque_do_sr() {
		return code_banque_do_sr;
	}
	/**
	 * @param code_banque_do_sr the code_banque_do_sr to set
	 */
	public void setCode_banque_do_sr(String code_banque_do_sr) {
		this.code_banque_do_sr = code_banque_do_sr;
	}
	/**
	 * @return the code_guichet_do_sr
	 */
	public String getCode_guichet_do_sr() {
		return code_guichet_do_sr;
	}
	/**
	 * @param code_guichet_do_sr the code_guichet_do_sr to set
	 */
	public void setCode_guichet_do_sr(String code_guichet_do_sr) {
		this.code_guichet_do_sr = code_guichet_do_sr;
	}
	/**
	 * @return the num_cpte_do_sr
	 */
	public String getNum_cpte_do_sr() {
		return num_cpte_do_sr;
	}
	/**
	 * @param num_cpte_do_sr the num_cpte_do_sr to set
	 */
	public void setNum_cpte_do_sr(String num_cpte_do_sr) {
		this.num_cpte_do_sr = num_cpte_do_sr;
	}
	/**
	 * @return the code_pays_beneficiaire_sr
	 */
	public String getCode_pays_beneficiaire_sr() {
		return code_pays_beneficiaire_sr;
	}
	/**
	 * @param code_pays_beneficiaire_sr the code_pays_beneficiaire_sr to set
	 */
	public void setCode_pays_beneficiaire_sr(String code_pays_beneficiaire_sr) {
		this.code_pays_beneficiaire_sr = code_pays_beneficiaire_sr;
	}
	/**
	 * @return the cle_iban_beneficiaire_sr
	 */
	public String getCle_iban_beneficiaire_sr() {
		return cle_iban_beneficiaire_sr;
	}
	/**
	 * @param cle_iban_beneficiaire_sr the cle_iban_beneficiaire_sr to set
	 */
	public void setCle_iban_beneficiaire_sr(String cle_iban_beneficiaire_sr) {
		this.cle_iban_beneficiaire_sr = cle_iban_beneficiaire_sr;
	}
	/**
	 * @return the code_banque_beneficiaire_sr
	 */
	public String getCode_banque_beneficiaire_sr() {
		return code_banque_beneficiaire_sr;
	}
	/**
	 * @param code_banque_beneficiaire_sr the code_banque_beneficiaire_sr to set
	 */
	public void setCode_banque_beneficiaire_sr(String code_banque_beneficiaire_sr) {
		this.code_banque_beneficiaire_sr = code_banque_beneficiaire_sr;
	}
	/**
	 * @return the code_guichet_beneficiaire_sr
	 */
	public String getCode_guichet_beneficiaire_sr() {
		return code_guichet_beneficiaire_sr;
	}
	/**
	 * @param code_guichet_beneficiaire_sr the code_guichet_beneficiaire_sr to set
	 */
	public void setCode_guichet_beneficiaire_sr(String code_guichet_beneficiaire_sr) {
		this.code_guichet_beneficiaire_sr = code_guichet_beneficiaire_sr;
	}
	/**
	 * @return the num_cpte_beneficiaire_sr
	 */
	public String getNum_cpte_beneficiaire_sr() {
		return num_cpte_beneficiaire_sr;
	}
	/**
	 * @param num_cpte_beneficiaire_sr the num_cpte_beneficiaire_sr to set
	 */
	public void setNum_cpte_beneficiaire_sr(String num_cpte_beneficiaire_sr) {
		this.num_cpte_beneficiaire_sr = num_cpte_beneficiaire_sr;
	}
	/**
	 * @return the code_pays_debitor_sr
	 */
	public String getCode_pays_debitor_sr() {
		return code_pays_debitor_sr;
	}
	/**
	 * @param code_pays_debitor_sr the code_pays_debitor_sr to set
	 */
	public void setCode_pays_debitor_sr(String code_pays_debitor_sr) {
		this.code_pays_debitor_sr = code_pays_debitor_sr;
	}
	/**
	 * @return the cle_iban_debitor_sr
	 */
	public String getCle_iban_debitor_sr() {
		return cle_iban_debitor_sr;
	}
	/**
	 * @param cle_iban_debitor_sr the cle_iban_debitor_sr to set
	 */
	public void setCle_iban_debitor_sr(String cle_iban_debitor_sr) {
		this.cle_iban_debitor_sr = cle_iban_debitor_sr;
	}
	/**
	 * @return the code_banque_debitor_sr
	 */
	public String getCode_banque_debitor_sr() {
		return code_banque_debitor_sr;
	}
	/**
	 * @param code_banque_debitor_sr the code_banque_debitor_sr to set
	 */
	public void setCode_banque_debitor_sr(String code_banque_debitor_sr) {
		this.code_banque_debitor_sr = code_banque_debitor_sr;
	}
	/**
	 * @return the code_guichet_debitor_sr
	 */
	public String getCode_guichet_debitor_sr() {
		return code_guichet_debitor_sr;
	}
	/**
	 * @param code_guichet_debitor_sr the code_guichet_debitor_sr to set
	 */
	public void setCode_guichet_debitor_sr(String code_guichet_debitor_sr) {
		this.code_guichet_debitor_sr = code_guichet_debitor_sr;
	}
	/**
	 * @return the num_cpte_debitor_sr
	 */
	public String getNum_cpte_debitor_sr() {
		return num_cpte_debitor_sr;
	}
	/**
	 * @param num_cpte_debitor_sr the num_cpte_debitor_sr to set
	 */
	public void setNum_cpte_debitor_sr(String num_cpte_debitor_sr) {
		this.num_cpte_debitor_sr = num_cpte_debitor_sr;
	}
	/**
	 * @return the code_pays_creditor_sr
	 */
	public String getCode_pays_creditor_sr() {
		return code_pays_creditor_sr;
	}
	/**
	 * @param code_pays_creditor_sr the code_pays_creditor_sr to set
	 */
	public void setCode_pays_creditor_sr(String code_pays_creditor_sr) {
		this.code_pays_creditor_sr = code_pays_creditor_sr;
	}
	/**
	 * @return the cle_iban_creditor_sr
	 */
	public String getCle_iban_creditor_sr() {
		return cle_iban_creditor_sr;
	}
	/**
	 * @param cle_iban_creditor_sr the cle_iban_creditor_sr to set
	 */
	public void setCle_iban_creditor_sr(String cle_iban_creditor_sr) {
		this.cle_iban_creditor_sr = cle_iban_creditor_sr;
	}
	/**
	 * @return the code_banque_creditor_sr
	 */
	public String getCode_banque_creditor_sr() {
		return code_banque_creditor_sr;
	}
	/**
	 * @param code_banque_creditor_sr the code_banque_creditor_sr to set
	 */
	public void setCode_banque_creditor_sr(String code_banque_creditor_sr) {
		this.code_banque_creditor_sr = code_banque_creditor_sr;
	}
	/**
	 * @return the code_guichet_creditor_sr
	 */
	public String getCode_guichet_creditor_sr() {
		return code_guichet_creditor_sr;
	}
	/**
	 * @param code_guichet_creditor_sr the code_guichet_creditor_sr to set
	 */
	public void setCode_guichet_creditor_sr(String code_guichet_creditor_sr) {
		this.code_guichet_creditor_sr = code_guichet_creditor_sr;
	}
	/**
	 * @return the num_cpte_creditor_sr
	 */
	public String getNum_cpte_creditor_sr() {
		return num_cpte_creditor_sr;
	}
	/**
	 * @param num_cpte_creditor_sr the num_cpte_creditor_sr to set
	 */
	public void setNum_cpte_creditor_sr(String num_cpte_creditor_sr) {
		this.num_cpte_creditor_sr = num_cpte_creditor_sr;
	}
	/**
	 * @return the date_insert
	 */
	public java.sql.Date getDate_insert() {
		return date_insert;
	}
	/**
	 * @param date_insert the date_insert to set
	 */
	public void setDate_insert(java.sql.Date date_insert) {
		this.date_insert = date_insert;
	}
	/**
	 * @return the id_type_operation
	 */
	public Integer getId_type_operation() {
		return id_type_operation;
	}
	/**
	 * @param id_type_operation the id_type_operation to set
	 */
	public void setId_type_operation(Integer id_type_operation) {
		this.id_type_operation = id_type_operation;
	}
	/**
	 * @return the id_client
	 */
	public Integer getId_client() {
		return id_client;
	}
	/**
	 * @param id_client the id_client to set
	 */
	public void setId_client(Integer id_client) {
		this.id_client = id_client;
	}
	/**
	 * @return the code_grp_remettant
	 */
	public String getCode_grp_remettant() {
		return code_grp_remettant;
	}
	/**
	 * @param code_grp_remettant the code_grp_remettant to set
	 */
	public void setCode_grp_remettant(String code_grp_remettant) {
		this.code_grp_remettant = code_grp_remettant;
	}
	/**
	 * @return the lib_grp_remettant
	 */
	public String getLib_grp_remettant() {
		return lib_grp_remettant;
	}
	/**
	 * @param lib_grp_remettant the lib_grp_remettant to set
	 */
	public void setLib_grp_remettant(String lib_grp_remettant) {
		this.lib_grp_remettant = lib_grp_remettant;
	}
	/**
	 * @return the id_ics
	 */
	public Integer getId_ics() {
		return id_ics;
	}
	/**
	 * @param id_ics the id_ics to set
	 */
	public void setId_ics(Integer id_ics) {
		this.id_ics = id_ics;
	}
	/**
	 * @return the id_compte_do_sr
	 */
	public Integer getId_compte_do_sr() {
		return id_compte_do_sr;
	}
	/**
	 * @param id_compte_do_sr the id_compte_do_sr to set
	 */
	public void setId_compte_do_sr(Integer id_compte_do_sr) {
		this.id_compte_do_sr = id_compte_do_sr;
	}
	/**
	 * @return the id_client_do_sr
	 */
	public Integer getId_client_do_sr() {
		return id_client_do_sr;
	}
	/**
	 * @param id_client_do_sr the id_client_do_sr to set
	 */
	public void setId_client_do_sr(Integer id_client_do_sr) {
		this.id_client_do_sr = id_client_do_sr;
	}
	/**
	 * @return the id_compte_beneficiaire_sr
	 */
	public Integer getId_compte_beneficiaire_sr() {
		return id_compte_beneficiaire_sr;
	}
	/**
	 * @param id_compte_beneficiaire_sr the id_compte_beneficiaire_sr to set
	 */
	public void setId_compte_beneficiaire_sr(Integer id_compte_beneficiaire_sr) {
		this.id_compte_beneficiaire_sr = id_compte_beneficiaire_sr;
	}
	/**
	 * @return the id_client_beneficiaire_sr
	 */
	public Integer getId_client_beneficiaire_sr() {
		return id_client_beneficiaire_sr;
	}
	/**
	 * @param id_client_beneficiaire_sr the id_client_beneficiaire_sr to set
	 */
	public void setId_client_beneficiaire_sr(Integer id_client_beneficiaire_sr) {
		this.id_client_beneficiaire_sr = id_client_beneficiaire_sr;
	}
	/**
	 * @return the xpartt
	 */
	public String getXpartt() {
		return xpartt;
	}
	/**
	 * @param xpartt the xpartt to set
	 */
	public void setXpartt(String xpartt) {
		this.xpartt = xpartt;
	}
	/**
	 * @return the id_traitement
	 */
	public String getId_traitement() {
		return id_traitement;
	}
	/**
	 * @param id_traitement the id_traitement to set
	 */
	public void setId_traitement(String id_traitement) {
		this.id_traitement = id_traitement;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DataInputBean [id_operation=" + id_operation + ", code_operation=" + code_operation
				+ ", code_client_conventionne=" + code_client_conventionne + ", id_systeme_echange="
				+ id_systeme_echange + ", iban_debitor_sr=" + iban_debitor_sr + ", bic_id_debitor_sr="
				+ bic_id_debitor_sr + ", bic_id_creditor_sr=" + bic_id_creditor_sr + ", iban_creditor_sr="
				+ iban_creditor_sr + ", code_famille_operation=" + code_famille_operation + ", type_operation="
				+ type_operation + ", sens_echange=" + sens_echange + ", num_remise=" + num_remise
				+ ", num_remise_tech=" + num_remise_tech + ", date_pec_amont=" + date_pec_amont + ", heure_pec_amont="
				+ heure_pec_amont + ", date_presentation_remise=" + date_presentation_remise
				+ ", heure_presentation_remise=" + heure_presentation_remise + ", rio=" + rio + ", date_echange="
				+ date_echange + ", date_reglement=" + date_reglement + ", date_traitement_aval_recu="
				+ date_traitement_aval_recu + ", etblt_concerne=" + etblt_concerne + ", ind_rejet=" + ind_rejet
				+ ", flag_debrayage_embargo=" + flag_debrayage_embargo + ", xtimts=" + xtimts
				+ ", ref_operation_origine=" + ref_operation_origine + ", date_comptable_evolmpm="
				+ date_comptable_evolmpm + ", pmtid_txid_src=" + pmtid_txid_src + ", mnt_compense_sit="
				+ mnt_compense_sit + ", code_flux_arch=" + code_flux_arch + ", num_partition=" + num_partition
				+ ", orgnltxid_src=" + orgnltxid_src + ", type_enregistrement=" + type_enregistrement
				+ ", orgnlinstrid_src=" + orgnlinstrid_src + ", orgnlendtoendid_src=" + orgnlendtoendid_src
				+ ", delai_reglement=" + delai_reglement + ", iban_do_sr=" + iban_do_sr + ", bic_id_do_sr="
				+ bic_id_do_sr + ", bic_id_beneficiaire_sr=" + bic_id_beneficiaire_sr + ", iban_beneficiaire_sr="
				+ iban_beneficiaire_sr + ", code_pays_do_sr=" + code_pays_do_sr + ", cle_iban_do_sr=" + cle_iban_do_sr
				+ ", code_banque_do_sr=" + code_banque_do_sr + ", code_guichet_do_sr=" + code_guichet_do_sr
				+ ", num_cpte_do_sr=" + num_cpte_do_sr + ", code_pays_beneficiaire_sr=" + code_pays_beneficiaire_sr
				+ ", cle_iban_beneficiaire_sr=" + cle_iban_beneficiaire_sr + ", code_banque_beneficiaire_sr="
				+ code_banque_beneficiaire_sr + ", code_guichet_beneficiaire_sr=" + code_guichet_beneficiaire_sr
				+ ", num_cpte_beneficiaire_sr=" + num_cpte_beneficiaire_sr + ", code_pays_debitor_sr="
				+ code_pays_debitor_sr + ", cle_iban_debitor_sr=" + cle_iban_debitor_sr + ", code_banque_debitor_sr="
				+ code_banque_debitor_sr + ", code_guichet_debitor_sr=" + code_guichet_debitor_sr
				+ ", num_cpte_debitor_sr=" + num_cpte_debitor_sr + ", code_pays_creditor_sr=" + code_pays_creditor_sr
				+ ", cle_iban_creditor_sr=" + cle_iban_creditor_sr + ", code_banque_creditor_sr="
				+ code_banque_creditor_sr + ", code_guichet_creditor_sr=" + code_guichet_creditor_sr
				+ ", num_cpte_creditor_sr=" + num_cpte_creditor_sr + ", date_insert=" + date_insert
				+ ", id_type_operation=" + id_type_operation + ", id_client=" + id_client + ", code_grp_remettant="
				+ code_grp_remettant + ", lib_grp_remettant=" + lib_grp_remettant + ", id_ics=" + id_ics
				+ ", id_compte_do_sr=" + id_compte_do_sr + ", id_client_do_sr=" + id_client_do_sr
				+ ", id_compte_beneficiaire_sr=" + id_compte_beneficiaire_sr + ", id_client_beneficiaire_sr="
				+ id_client_beneficiaire_sr + ", xpartt=" + xpartt + ", id_traitement=" + id_traitement + "]";
	}
	/**
	 * 
	 */
	public DataInputBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the cle_rib_debitor_sr
	 */
	public String getCle_rib_debitor_sr() {
		return cle_rib_debitor_sr;
	}
	/**
	 * @param cle_rib_debitor_sr the cle_rib_debitor_sr to set
	 */
	public void setCle_rib_debitor_sr(String cle_rib_debitor_sr) {
		this.cle_rib_debitor_sr = cle_rib_debitor_sr;
	}
	/**
	 * @return the cle_rib_creditor_sr
	 */
	public String getCle_rib_creditor_sr() {
		return cle_rib_creditor_sr;
	}
	/**
	 * @param cle_rib_creditor_sr the cle_rib_creditor_sr to set
	 */
	public void setCle_rib_creditor_sr(String cle_rib_creditor_sr) {
		this.cle_rib_creditor_sr = cle_rib_creditor_sr;
	}
	/**
	 * @return the cle_rib_beneficiaire_sr
	 */
	public String getCle_rib_beneficiaire_sr() {
		return cle_rib_beneficiaire_sr;
	}
	/**
	 * @param cle_rib_beneficiaire_sr the cle_rib_beneficiaire_sr to set
	 */
	public void setCle_rib_beneficiaire_sr(String cle_rib_beneficiaire_sr) {
		this.cle_rib_beneficiaire_sr = cle_rib_beneficiaire_sr;
	}
	/**
	 * @return the cle_rib_do_sr
	 */
	public String getCle_rib_do_sr() {
		return cle_rib_do_sr;
	}
	/**
	 * @param cle_rib_do_sr the cle_rib_do_sr to set
	 */
	public void setCle_rib_do_sr(String cle_rib_do_sr) {
		this.cle_rib_do_sr = cle_rib_do_sr;
	}
	public java.sql.Date getDate_ope() {
		return date_ope;
	}
	public void setDate_ope(java.sql.Date date_ope) {
		this.date_ope = date_ope;
	}
	
	
	
	

}
