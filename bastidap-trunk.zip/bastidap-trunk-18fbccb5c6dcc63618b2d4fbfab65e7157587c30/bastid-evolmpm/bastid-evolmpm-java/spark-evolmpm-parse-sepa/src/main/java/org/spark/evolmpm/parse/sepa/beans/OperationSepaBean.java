package org.spark.evolmpm.parse.sepa.beans;

import java.io.Serializable;
import java.math.BigDecimal;

public class OperationSepaBean implements Serializable {

	/**
	 * 
	 */
	public OperationSepaBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = -2578518791893472032L;
	
	
	private String bic_id_beneficiaire_sr;
	private String bic_id_creditor_sr;
	private String bic_id_debitor_sr;
	private String bic_id_do_sr;
	private String cle_iban_beneficiaire_sr;
	private String cle_iban_creditor_sr;
	private String cle_iban_debitor_sr;
	private String cle_iban_do_sr;
	private String cle_rib_beneficiaire_sr;
	private String cle_rib_creditor_sr;
	private String cle_rib_debitor_sr;
	private String cle_rib_do_sr;
	private String code_banque_beneficiaire_sr;
	private String code_banque_creditor_sr;
	private String code_banque_debitor_sr;
	private String code_banque_do_sr;
	private String code_client_conventionne;
	private String code_famille_operation;
	private String code_flux_arch;
	private String code_grp_remettant;
	private String code_guichet_beneficiaire_sr;
	private String code_guichet_creditor_sr;
	private String code_guichet_debitor_sr;
	private String code_guichet_do_sr;
	private String code_operation;
	private String code_pays_beneficiaire_sr;
	private String code_pays_creditor_sr;
	private String code_pays_debitor_sr;
	private String code_pays_do_sr;
	private java.sql.Date date_comptable_evolmpm;
	private java.sql.Date date_echange;
	private java.sql.Timestamp date_pec_amont;
	private java.sql.Timestamp date_presentation_remise;
	private java.sql.Date date_reglement;
	private java.sql.Date date_traitement_aval_recu;
	private Integer delai_reglement;
	private String etblt_concerne;
	private String flag_debrayage_embargo;
	private String heure_pec_amont;
	private String heure_presentation_remise;
	private String iban_beneficiaire_sr;
	private String iban_creditor_sr;
	private String iban_debitor_sr;
	private String iban_do_sr;
	private Integer id_client;
	private Integer id_client_beneficiaire_sr;
	private Integer id_client_do_sr;
	private Integer id_compte_beneficiaire_sr;
	private Integer id_compte_do_sr;
	private Integer id_ics;
	private String id_operation;
	private String id_systeme_echange;
	private Integer id_type_operation;
	private String ind_rejet;
	private String lib_grp_remettant;
	//private int longueur_operation;
	private Double mnt_compense_sit;
	private String num_cpte_beneficiaire_sr;
	private String num_cpte_creditor_sr;
	private String num_cpte_debitor_sr;
	private String num_cpte_do_sr;
	private String num_partition;
	private String num_remise;
	private String num_remise_tech;
	private String orgnlendtoendid_src;
	private String orgnlinstrid_src;
	private String orgnltxid_src;
	private String pmtid_txid_src;
	private String ref_operation_origine;
	private String rio;
	private String sens_echange;
	private java.sql.Timestamp xtimts;
	private String type_enregistrement;
	private String type_operation;
	private String bic_id_beneficiaire;
	private String bic_id_creditor;
	private String bic_id_debitor;
	private String bic_id_do;
	private String cdt_id_org_bic_bei;
	private String cdt_id_org_othr_id;
	private String cdt_id_org_othr_issr;
	private String cdt_id_org_othr_sch_cd;
	private String cdt_id_org_othr_sch_prtry;
	private String cdt_id_pr_dpbi_cry;
	private String cdt_id_pr_dpbi_cty;
	private java.sql.Date cdt_id_pr_dpbi_dat;
	private String cdt_id_pr_dpbi_prv;
	private String cdt_id_prv_othr_id;
	private String cdt_id_prv_othr_issr;
	private String cdt_id_prv_othr_sch_cd;
	private String cdt_id_prv_othr_sch_prtr;
	private String cdt_name;
	private String cdt_padr_adrline;
	private String cdt_padr_ctry;
	private String cdtacc_id_iban;
	private String cdtagt_fi_bic;
	private String chrgbr;
	private Double chrginf_amt;
	private String chrginf_amtc;
	private String chrginf_pty_fi_bic;
	private String code_format_pacs;
	private Double compstnamt;
	private String compstnamtc;
	private String csch_idproi;
	private String csch_idproi_cd;
	private String csch_idproi_issr;
	private String csch_idproi_prtry;
	private java.sql.Date date_insert;
	private java.sql.Date date_ope;
	private String dbt_id_org_bic_bei;
	private String dbt_id_org_othr_id;
	private String dbt_id_org_othr_issr;
	private String dbt_id_org_othr_sch_cd;
	private String dbt_id_org_othr_sch_prtry;
	private String dbt_id_pr_dpbi_cr;
	private String dbt_id_pr_dpbi_cty;
	private java.sql.Date dbt_id_pr_dpbi_dat;
	private String dbt_id_pr_dpbi_prv;
	private String dbt_id_prv_othr_id;
	private String dbt_id_prv_othr_issr;
	private String dbt_id_prv_othr_sch_cd;
	private String dbt_id_prv_othr_sch_prtr;
	private String dbt_name;
	private String dbt_padr_adrline;
	private String dbt_padr_ctry;
	private String dbtacc_id_iban;
	private String dbtagt_fi_bic;
	private String iban_beneficiaire;
	private String iban_creditor;
	private String iban_debitor;
	private String iban_do;
	private String insdagt_fi_bic;
	private String insgagt_fi_bic;
	private Double instdamt;
	private String instdamtc;
	private BigDecimal intrbksttlmamt;
	private String intrbksttlmamtc;
	private String m_a_odac_id_iban;
	private String m_a_odac_v9_fi_bic;
	private String m_a_odac_v9_id_othr_id;
	private String m_a_odag_fi_othr_id;
	private String m_a_orgnlmndtid;
	private String m_a_s_id_pro_issr;
	private String m_a_s_id_pro_sch_cd;
	private String m_a_s_id_pro_sch_prtry;
	private String m_a_s_id_proid;
	private String m_a_s_nm;
	private String m_add_inf;
	private String m_amdmntind;
	private java.sql.Date m_dtofsgntr;
	private String m_elctrncsgnt;
	private String m_id;
	private String m_mndtid;
	private String m_orgnl_accnt_iban;
	private String m_orgnl_accnt_o_id;
	private String m_orgnl_agt_fi_bic;
	private String m_orgnl_ctct_dt_emadr;
	private String m_orgnl_ctct_dt_fxnm;
	private String m_orgnl_ctct_dt_mbnm;
	private String m_orgnl_ctct_dt_nm;
	private String m_orgnl_ctct_dt_nmpr;
	private String m_orgnl_ctct_dt_other;
	private String m_orgnl_ctct_dt_phnm;
	private String m_orgnl_pty_ctrr;
	private String m_orgnl_pty_id_oi_bic;
	private String m_orgnl_pty_id_oi_id;
	private String m_orgnl_pty_id_oi_o_issr;
	private String m_orgnl_pty_id_oi_o_sn_cd;
	private String m_orgnl_pty_id_oi_sn_pty;
	private String m_orgnl_pty_id_pr_bi_cry;
	private String m_orgnl_pty_id_pr_bi_cty;
	private String m_orgnl_pty_id_pr_bi_dat;
	private String m_orgnl_pty_id_pr_bi_prv;
	private String m_orgnl_pty_id_pr_o_id;
	private String m_orgnl_pty_id_pr_o_issr;
	private String m_orgnl_pty_id_pr_o_sn_cd;
	private String m_orgnl_pty_id_pr_o_sn_pty;
	private String m_orgnl_pty_name;
	private String m_orgnl_pty_padr_adli1;
	private String m_orgnl_pty_padr_adli2;
	private String m_orgnl_pty_padr_adli3;
	private String m_orgnl_pty_padr_adli4;
	private String m_orgnl_pty_padr_adli5;
	private String m_orgnl_pty_padr_adli6;
	private String m_orgnl_pty_padr_adli7;
	private String m_orgnl_pty_padr_bdnm;
	private String m_orgnl_pty_padr_ctry;
	private String m_orgnl_pty_padr_ctsd;
	private String m_orgnl_pty_padr_dpt;
	private String m_orgnl_pty_padr_pscd;
	private String m_orgnl_pty_padr_sbdpt;
	private String m_orgnl_pty_padr_stnm;
	private String m_orgnl_pty_padr_twnm;
	private String m_orgnl_pty_padr_typ;
	private String m_updid_acct_iban;
	private String m_updid_acct_o_id;
	private String m_updid_agt_fi_bic;
	private String m_updid_ctct_dt_emadr;
	private String m_updid_ctct_dt_fxnm;
	private String m_updid_ctct_dt_mbnm;
	private String m_updid_ctct_dt_nm;
	private String m_updid_ctct_dt_nmpr;
	private String m_updid_ctct_dt_other;
	private String m_updid_ctct_dt_phnm;
	private String m_updid_id_o_id;
	private String m_updid_pty_ctrr;
	private String m_updid_pty_id_bic;
	private String m_updid_pty_id_o_issr;
	private String m_updid_pty_id_o_sd_pty;
	private String m_updid_pty_id_o_sn_cd;
	private String m_updid_pty_id_pr_bi_cry;
	private String m_updid_pty_id_pr_bi_cty;
	private String m_updid_pty_id_pr_bi_dat;
	private String m_updid_pty_id_pr_bi_prv;
	private String m_updid_pty_id_pr_o_id;
	private String m_updid_pty_id_pr_o_issr;
	private String m_updid_pty_id_pr_o_sn_cd;
	private String m_updid_pty_id_pr_o_sn_pty;
	private String m_updid_pty_name;
	private String m_updid_pty_padr_adli1;
	private String m_updid_pty_padr_adli2;
	private String m_updid_pty_padr_adli3;
	private String m_updid_pty_padr_adli4;
	private String m_updid_pty_padr_adli5;
	private String m_updid_pty_padr_adli6;
	private String m_updid_pty_padr_adli7;
	private String m_updid_pty_padr_bdnm;
	private String m_updid_pty_padr_ctr;
	private String m_updid_pty_padr_ctsd;
	private String m_updid_pty_padr_dpt;
	private String m_updid_pty_padr_pscd;
	private String m_updid_pty_padr_sbdpt;
	private String m_updid_pty_padr_stnm;
	private String m_updid_pty_padr_twnm;
	private String m_updid_pty_padr_typ;
	private String motif_rejet_annulation;
	private String num_ics;
	private String orggrpinf_orgnlmsgid;
	private String orggrpinf_orgnlmsgnmid;
	private String orgnlendtoendid;
	private String orgnlinstrid;
	private BigDecimal orgnlintrbksttlmamt;
	private String orgnlintrbksttlmamtc;
	private String orgnltxid;
	private String ot_crlsysref;
	private String ot_endtoendid;
	private String ot_first_agt_fi_bic;
	private String ot_instrid;
	private String ot_txid;
	private String otr_csch_id_prv_othr_id;
	private String otr_csch_id_prv_othr_issr;
	private String otr_csch_id_prv_othr_sch_cd;
	private String otr_csch_id_prv_othr_sch_prtr;
	private java.sql.Date otr_intrbksttlmdt;
	private String otr_reqdcolltndt;
	private String otr_stti_clrs_cd;
	private String otr_stti_clrs_prtry;
	private String otr_stti_sttaid_iban;
	private String otr_stti_sttaid_o_id;
	private String otr_stti_sttaid_o_issr;
	private String otr_stti_sttaid_o_sn_cd;
	private String otr_stti_sttaid_o_sn_prtr;
	private String otr_stti_sttlmmtd;
	private String pmtid_endtoendid;
	private String pmtid_instrid;
	private String pmtid_txid;
	private String pmttpi_ctgypurp;
	private String pmttpi_ctgypurp_pr;
	private String pmttpi_lclins_cd;
	private String pmttpi_seqtp;
	private String pmttpi_svclvl_cd;
	private String pmttpilclins_prtry;
	private String pur_cd;
	//private String ref_operation_origine;
	private java.sql.Date reqdcolltndt;
	private String ri_addtlinf1;
	private String ri_addtlinf2;
	private String ri_rorg_id_org_bic_bei;
	private String ri_rorg_id_org_othr_id;
	private String ri_rorg_id_org_othr_issr;
	private String ri_rorg_id_org_othr_sch_cd;
	private String ri_rorg_id_org_othr_sch_prtr;
	private String ri_rorg_id_prv_dpbi_cry;
	private String ri_rorg_id_prv_dpbi_cty;
	private java.sql.Date ri_rorg_id_prv_dpbi_dat;
	private String ri_rorg_id_prv_dpbi_prv;
	private String ri_rorg_id_prv_othr_id;
	private String ri_rorg_id_prv_othr_issr;
	private String ri_rorg_id_prv_othr_sch_cd;
	private String ri_rorg_id_prv_othr_sch_prtr;
	private String ri_rorg_name;
	private String ri_rorg_padr_adrline;
	private String ri_rorg_padr_ctry;
	private String ri_rsn_cd;
	private String ri_sn_prtry;
	private String rmtinf_strd_type_code;
	private String rmtinf_strd_type_is;
	private String rmtinf_strd_type_ref;
	private String rmtinf_ustrd;
	private String sup_chemin;
	private String txsts;
	private String ucdt_id_org_bic_bei;
	private String ucdt_id_org_othr_id;
	private String ucdt_id_org_othr_issr;
	private String ucdt_id_org_othr_sch_cd;
	private String ucdt_id_org_othr_sch_prtry;
	private String ucdt_id_pr_dpbi_cr;
	private String ucdt_id_pr_dpbi_ct;
	private java.sql.Date ucdt_id_pr_dpbi_da;
	private String ucdt_id_pr_dpbi_prv;
	private String ucdt_id_prv_othr_id;
	private String ucdt_id_prv_othr_issr;
	private String ucdt_id_prv_othr_sch_cd;
	private String ucdt_id_prv_othr_sch_prtr;
	private String ucdt_name;
	private String udbt_id_org_bic_bei;
	private String udbt_id_org_othr_id;
	private String udbt_id_org_othr_sch_cd;
	private String udbt_id_org_othr_sch_issr;
	private String udbt_id_org_othr_sch_prtr;
	private String udbt_id_pr_dpbi_cry;
	private String udbt_id_pr_dpbi_cty;
	private java.sql.Date udbt_id_pr_dpbi_dat;
	private String udbt_id_pr_dpbi_prv;
	private String udbt_id_prv_othr_id;
	private String udbt_id_prv_othr_issr;
	private String udbt_id_prv_othr_sch_cd;
	private String udbt_id_prv_othr_sch_prtr;
	private String udbt_name;
	private String flag_evolmpm_maeva;
	private String id_traitement;
	/**
	 * @return the bic_id_beneficiaire_sr
	 */
	public String getBic_id_beneficiaire_sr() {
		return bic_id_beneficiaire_sr;
	}
	/**
	 * @param bic_id_beneficiaire_sr the bic_id_beneficiaire_sr to set
	 */
	public void setBic_id_beneficiaire_sr(String bic_id_beneficiaire_sr) {
		this.bic_id_beneficiaire_sr = bic_id_beneficiaire_sr;
	}
	/**
	 * @return the bic_id_creditor_sr
	 */
	public String getBic_id_creditor_sr() {
		return bic_id_creditor_sr;
	}
	/**
	 * @param bic_id_creditor_sr the bic_id_creditor_sr to set
	 */
	public void setBic_id_creditor_sr(String bic_id_creditor_sr) {
		this.bic_id_creditor_sr = bic_id_creditor_sr;
	}
	/**
	 * @return the bic_id_debitor_sr
	 */
	public String getBic_id_debitor_sr() {
		return bic_id_debitor_sr;
	}
	/**
	 * @param bic_id_debitor_sr the bic_id_debitor_sr to set
	 */
	public void setBic_id_debitor_sr(String bic_id_debitor_sr) {
		this.bic_id_debitor_sr = bic_id_debitor_sr;
	}
	/**
	 * @return the bic_id_do_sr
	 */
	public String getBic_id_do_sr() {
		return bic_id_do_sr;
	}
	/**
	 * @param bic_id_do_sr the bic_id_do_sr to set
	 */
	public void setBic_id_do_sr(String bic_id_do_sr) {
		this.bic_id_do_sr = bic_id_do_sr;
	}
	/**
	 * @return the cle_iban_beneficiaire_sr
	 */
	public String getCle_iban_beneficiaire_sr() {
		return cle_iban_beneficiaire_sr;
	}
	/**
	 * @param cle_iban_beneficiaire_sr the cle_iban_beneficiaire_sr to set
	 */
	public void setCle_iban_beneficiaire_sr(String cle_iban_beneficiaire_sr) {
		this.cle_iban_beneficiaire_sr = cle_iban_beneficiaire_sr;
	}
	/**
	 * @return the cle_iban_creditor_sr
	 */
	public String getCle_iban_creditor_sr() {
		return cle_iban_creditor_sr;
	}
	/**
	 * @param cle_iban_creditor_sr the cle_iban_creditor_sr to set
	 */
	public void setCle_iban_creditor_sr(String cle_iban_creditor_sr) {
		this.cle_iban_creditor_sr = cle_iban_creditor_sr;
	}
	/**
	 * @return the cle_iban_debitor_sr
	 */
	public String getCle_iban_debitor_sr() {
		return cle_iban_debitor_sr;
	}
	/**
	 * @param cle_iban_debitor_sr the cle_iban_debitor_sr to set
	 */
	public void setCle_iban_debitor_sr(String cle_iban_debitor_sr) {
		this.cle_iban_debitor_sr = cle_iban_debitor_sr;
	}
	/**
	 * @return the cle_iban_do_sr
	 */
	public String getCle_iban_do_sr() {
		return cle_iban_do_sr;
	}
	/**
	 * @param cle_iban_do_sr the cle_iban_do_sr to set
	 */
	public void setCle_iban_do_sr(String cle_iban_do_sr) {
		this.cle_iban_do_sr = cle_iban_do_sr;
	}
	/**
	 * @return the cle_rib_beneficiaire_sr
	
	public String getCle_rib_beneficiaire_sr() {
		return cle_rib_beneficiaire_sr;
	}*/
	/**
	 * @param cle_rib_beneficiaire_sr the cle_rib_beneficiaire_sr to set
	 
	public void setCle_rib_beneficiaire_sr(String cle_rib_beneficiaire_sr) {
		this.cle_rib_beneficiaire_sr = cle_rib_beneficiaire_sr;
	}*/
	/**
	 * @return the cle_rib_creditor_sr
	 
	public String getCle_rib_creditor_sr() {
		return cle_rib_creditor_sr;
	}*/
	/**
	 * @param cle_rib_creditor_sr the cle_rib_creditor_sr to set
	 
	public void setCle_rib_creditor_sr(String cle_rib_creditor_sr) {
		this.cle_rib_creditor_sr = cle_rib_creditor_sr;
	}*/
	/**
	 * @return the cle_rib_debitor_sr
	 
	public String getCle_rib_debitor_sr() {
		return cle_rib_debitor_sr;
	}*/
	/**
	 * @param cle_rib_debitor_sr the cle_rib_debitor_sr to set
	 
	public void setCle_rib_debitor_sr(String cle_rib_debitor_sr) {
		this.cle_rib_debitor_sr = cle_rib_debitor_sr;
	}*/
	/**
	 * @return the cle_rib_do_sr
	 
	public String getCle_rib_do_sr() {
		return cle_rib_do_sr;
	}*/
	/**
	 * @param cle_rib_do_sr the cle_rib_do_sr to set
	 
	public void setCle_rib_do_sr(String cle_rib_do_sr) {
		this.cle_rib_do_sr = cle_rib_do_sr;
	}*/
	/**
	 * @return the code_banque_beneficiaire_sr
	 */
	public String getCode_banque_beneficiaire_sr() {
		return code_banque_beneficiaire_sr;
	}
	/**
	 * @param code_banque_beneficiaire_sr the code_banque_beneficiaire_sr to set
	 */
	public void setCode_banque_beneficiaire_sr(String code_banque_beneficiaire_sr) {
		this.code_banque_beneficiaire_sr = code_banque_beneficiaire_sr;
	}
	/**
	 * @return the code_banque_creditor_sr
	 */
	public String getCode_banque_creditor_sr() {
		return code_banque_creditor_sr;
	}
	/**
	 * @param code_banque_creditor_sr the code_banque_creditor_sr to set
	 */
	public void setCode_banque_creditor_sr(String code_banque_creditor_sr) {
		this.code_banque_creditor_sr = code_banque_creditor_sr;
	}
	/**
	 * @return the code_banque_debitor_sr
	 */
	public String getCode_banque_debitor_sr() {
		return code_banque_debitor_sr;
	}
	/**
	 * @param code_banque_debitor_sr the code_banque_debitor_sr to set
	 */
	public void setCode_banque_debitor_sr(String code_banque_debitor_sr) {
		this.code_banque_debitor_sr = code_banque_debitor_sr;
	}
	/**
	 * @return the code_banque_do_sr
	 */
	public String getCode_banque_do_sr() {
		return code_banque_do_sr;
	}
	/**
	 * @param code_banque_do_sr the code_banque_do_sr to set
	 */
	public void setCode_banque_do_sr(String code_banque_do_sr) {
		this.code_banque_do_sr = code_banque_do_sr;
	}
	/**
	 * @return the code_client_conventionne
	 */
	public String getCode_client_conventionne() {
		return code_client_conventionne;
	}
	/**
	 * @param code_client_conventionne the code_client_conventionne to set
	 */
	public void setCode_client_conventionne(String code_client_conventionne) {
		this.code_client_conventionne = code_client_conventionne;
	}
	/**
	 * @return the code_famille_operation
	 */
	public String getCode_famille_operation() {
		return code_famille_operation;
	}
	/**
	 * @param code_famille_operation the code_famille_operation to set
	 */
	public void setCode_famille_operation(String code_famille_operation) {
		this.code_famille_operation = code_famille_operation;
	}
	/**
	 * @return the code_flux_arch
	 */
	public String getCode_flux_arch() {
		return code_flux_arch;
	}
	/**
	 * @param code_flux_arch the code_flux_arch to set
	 */
	public void setCode_flux_arch(String code_flux_arch) {
		this.code_flux_arch = code_flux_arch;
	}
	/**
	 * @return the code_grp_remettant
	 */
	public String getCode_grp_remettant() {
		return code_grp_remettant;
	}
	/**
	 * @param code_grp_remettant the code_grp_remettant to set
	 */
	public void setCode_grp_remettant(String code_grp_remettant) {
		this.code_grp_remettant = code_grp_remettant;
	}
	/**
	 * @return the code_guichet_beneficiaire_sr
	 */
	public String getCode_guichet_beneficiaire_sr() {
		return code_guichet_beneficiaire_sr;
	}
	/**
	 * @param code_guichet_beneficiaire_sr the code_guichet_beneficiaire_sr to set
	 */
	public void setCode_guichet_beneficiaire_sr(String code_guichet_beneficiaire_sr) {
		this.code_guichet_beneficiaire_sr = code_guichet_beneficiaire_sr;
	}
	/**
	 * @return the code_guichet_creditor_sr
	 */
	public String getCode_guichet_creditor_sr() {
		return code_guichet_creditor_sr;
	}
	/**
	 * @param code_guichet_creditor_sr the code_guichet_creditor_sr to set
	 */
	public void setCode_guichet_creditor_sr(String code_guichet_creditor_sr) {
		this.code_guichet_creditor_sr = code_guichet_creditor_sr;
	}
	/**
	 * @return the code_guichet_debitor_sr
	 */
	public String getCode_guichet_debitor_sr() {
		return code_guichet_debitor_sr;
	}
	/**
	 * @param code_guichet_debitor_sr the code_guichet_debitor_sr to set
	 */
	public void setCode_guichet_debitor_sr(String code_guichet_debitor_sr) {
		this.code_guichet_debitor_sr = code_guichet_debitor_sr;
	}
	/**
	 * @return the code_guichet_do_sr
	 */
	public String getCode_guichet_do_sr() {
		return code_guichet_do_sr;
	}
	/**
	 * @param code_guichet_do_sr the code_guichet_do_sr to set
	 */
	public void setCode_guichet_do_sr(String code_guichet_do_sr) {
		this.code_guichet_do_sr = code_guichet_do_sr;
	}
	/**
	 * @return the code_operation
	 */
	public String getCode_operation() {
		return code_operation;
	}
	/**
	 * @param code_operation the code_operation to set
	 */
	public void setCode_operation(String code_operation) {
		this.code_operation = code_operation;
	}
	/**
	 * @return the code_pays_beneficiaire_sr
	 */
	public String getCode_pays_beneficiaire_sr() {
		return code_pays_beneficiaire_sr;
	}
	/**
	 * @param code_pays_beneficiaire_sr the code_pays_beneficiaire_sr to set
	 */
	public void setCode_pays_beneficiaire_sr(String code_pays_beneficiaire_sr) {
		this.code_pays_beneficiaire_sr = code_pays_beneficiaire_sr;
	}
	/**
	 * @return the code_pays_creditor_sr
	 */
	public String getCode_pays_creditor_sr() {
		return code_pays_creditor_sr;
	}
	/**
	 * @param code_pays_creditor_sr the code_pays_creditor_sr to set
	 */
	public void setCode_pays_creditor_sr(String code_pays_creditor_sr) {
		this.code_pays_creditor_sr = code_pays_creditor_sr;
	}
	/**
	 * @return the code_pays_debitor_sr
	 */
	public String getCode_pays_debitor_sr() {
		return code_pays_debitor_sr;
	}
	/**
	 * @param code_pays_debitor_sr the code_pays_debitor_sr to set
	 */
	public void setCode_pays_debitor_sr(String code_pays_debitor_sr) {
		this.code_pays_debitor_sr = code_pays_debitor_sr;
	}
	/**
	 * @return the code_pays_do_sr
	 */
	public String getCode_pays_do_sr() {
		return code_pays_do_sr;
	}
	/**
	 * @param code_pays_do_sr the code_pays_do_sr to set
	 */
	public void setCode_pays_do_sr(String code_pays_do_sr) {
		this.code_pays_do_sr = code_pays_do_sr;
	}
	/**
	 * @return the date_comptable_evolmpm
	 */
	public java.sql.Date getDate_comptable_evolmpm() {
		return date_comptable_evolmpm;
	}
	/**
	 * @param date_comptable_evolmpm the date_comptable_evolmpm to set
	 */
	public void setDate_comptable_evolmpm(java.sql.Date date_comptable_evolmpm) {
		this.date_comptable_evolmpm = date_comptable_evolmpm;
	}
	/**
	 * @return the date_echange
	 */
	public java.sql.Date getDate_echange() {
		return date_echange;
	}
	/**
	 * @param date_echange the date_echange to set
	 */
	public void setDate_echange(java.sql.Date date_echange) {
		this.date_echange = date_echange;
	}
	/**
	 * @return the date_pec_amont
	 */
	public java.sql.Timestamp getDate_pec_amont() {
		return date_pec_amont;
	}
	/**
	 * @param date_pec_amont the date_pec_amont to set
	 */
	public void setDate_pec_amont(java.sql.Timestamp date_pec_amont) {
		this.date_pec_amont = date_pec_amont;
	}
	/**
	 * @return the date_presentation_remise
	 */
	public java.sql.Timestamp getDate_presentation_remise() {
		return date_presentation_remise;
	}
	/**
	 * @param date_presentation_remise the date_presentation_remise to set
	 */
	public void setDate_presentation_remise(java.sql.Timestamp date_presentation_remise) {
		this.date_presentation_remise = date_presentation_remise;
	}
	/**
	 * @return the date_reglement
	 */
	public java.sql.Date getDate_reglement() {
		return date_reglement;
	}
	/**
	 * @param date_reglement the date_reglement to set
	 */
	public void setDate_reglement(java.sql.Date date_reglement) {
		this.date_reglement = date_reglement;
	}
	/**
	 * @return the date_traitement_aval_recu
	 */
	public java.sql.Date getDate_traitement_aval_recu() {
		return date_traitement_aval_recu;
	}
	/**
	 * @param date_traitement_aval_recu the date_traitement_aval_recu to set
	 */
	public void setDate_traitement_aval_recu(java.sql.Date date_traitement_aval_recu) {
		this.date_traitement_aval_recu = date_traitement_aval_recu;
	}
	/**
	 * @return the delai_reglement
	 */
	public Integer getDelai_reglement() {
		return delai_reglement;
	}
	/**
	 * @param delai_reglement the delai_reglement to set
	 */
	public void setDelai_reglement(Integer delai_reglement) {
		this.delai_reglement = delai_reglement;
	}
	/**
	 * @return the etblt_concerne
	 */
	public String getEtblt_concerne() {
		return etblt_concerne;
	}
	/**
	 * @param etblt_concerne the etblt_concerne to set
	 */
	public void setEtblt_concerne(String etblt_concerne) {
		this.etblt_concerne = etblt_concerne;
	}
	/**
	 * @return the flag_debrayage_embargo
	 */
	public String getFlag_debrayage_embargo() {
		return flag_debrayage_embargo;
	}
	/**
	 * @param flag_debrayage_embargo the flag_debrayage_embargo to set
	 */
	public void setFlag_debrayage_embargo(String flag_debrayage_embargo) {
		this.flag_debrayage_embargo = flag_debrayage_embargo;
	}
	/**
	 * @return the heure_pec_amont
	 */
	public String getHeure_pec_amont() {
		return heure_pec_amont;
	}
	/**
	 * @param heure_pec_amont the heure_pec_amont to set
	 */
	public void setHeure_pec_amont(String heure_pec_amont) {
		this.heure_pec_amont = heure_pec_amont;
	}
	/**
	 * @return the heure_presentation_remise
	 */
	public String getHeure_presentation_remise() {
		return heure_presentation_remise;
	}
	/**
	 * @param heure_presentation_remise the heure_presentation_remise to set
	 */
	public void setHeure_presentation_remise(String heure_presentation_remise) {
		this.heure_presentation_remise = heure_presentation_remise;
	}
	/**
	 * @return the iban_beneficiaire_sr
	 */
	public String getIban_beneficiaire_sr() {
		return iban_beneficiaire_sr;
	}
	/**
	 * @param iban_beneficiaire_sr the iban_beneficiaire_sr to set
	 */
	public void setIban_beneficiaire_sr(String iban_beneficiaire_sr) {
		this.iban_beneficiaire_sr = iban_beneficiaire_sr;
	}
	/**
	 * @return the iban_creditor_sr
	 */
	public String getIban_creditor_sr() {
		return iban_creditor_sr;
	}
	/**
	 * @param iban_creditor_sr the iban_creditor_sr to set
	 */
	public void setIban_creditor_sr(String iban_creditor_sr) {
		this.iban_creditor_sr = iban_creditor_sr;
	}
	/**
	 * @return the iban_debitor_sr
	 */
	public String getIban_debitor_sr() {
		return iban_debitor_sr;
	}
	/**
	 * @param iban_debitor_sr the iban_debitor_sr to set
	 */
	public void setIban_debitor_sr(String iban_debitor_sr) {
		this.iban_debitor_sr = iban_debitor_sr;
	}
	/**
	 * @return the iban_do_sr
	 */
	public String getIban_do_sr() {
		return iban_do_sr;
	}
	/**
	 * @param iban_do_sr the iban_do_sr to set
	 */
	public void setIban_do_sr(String iban_do_sr) {
		this.iban_do_sr = iban_do_sr;
	}
	/**
	 * @return the id_client
	 */
	public Integer getId_client() {
		return id_client;
	}
	/**
	 * @param id_client the id_client to set
	 */
	public void setId_client(Integer id_client) {
		this.id_client = id_client;
	}
	/**
	 * @return the id_client_beneficiaire_sr
	 */
	public Integer getId_client_beneficiaire_sr() {
		return id_client_beneficiaire_sr;
	}
	/**
	 * @param id_client_beneficiaire_sr the id_client_beneficiaire_sr to set
	 */
	public void setId_client_beneficiaire_sr(Integer id_client_beneficiaire_sr) {
		this.id_client_beneficiaire_sr = id_client_beneficiaire_sr;
	}
	/**
	 * @return the id_client_do_sr
	 */
	public Integer getId_client_do_sr() {
		return id_client_do_sr;
	}
	/**
	 * @param id_client_do_sr the id_client_do_sr to set
	 */
	public void setId_client_do_sr(Integer id_client_do_sr) {
		this.id_client_do_sr = id_client_do_sr;
	}
	/**
	 * @return the id_compte_beneficiaire_sr
	 */
	public Integer getId_compte_beneficiaire_sr() {
		return id_compte_beneficiaire_sr;
	}
	/**
	 * @param id_compte_beneficiaire_sr the id_compte_beneficiaire_sr to set
	 */
	public void setId_compte_beneficiaire_sr(Integer id_compte_beneficiaire_sr) {
		this.id_compte_beneficiaire_sr = id_compte_beneficiaire_sr;
	}
	/**
	 * @return the id_compte_do_sr
	 */
	public Integer getId_compte_do_sr() {
		return id_compte_do_sr;
	}
	/**
	 * @param id_compte_do_sr the id_compte_do_sr to set
	 */
	public void setId_compte_do_sr(Integer id_compte_do_sr) {
		this.id_compte_do_sr = id_compte_do_sr;
	}
	/**
	 * @return the id_ics
	 */
	public Integer getId_ics() {
		return id_ics;
	}
	/**
	 * @param id_ics the id_ics to set
	 */
	public void setId_ics(Integer id_ics) {
		this.id_ics = id_ics;
	}
	/**
	 * @return the id_operation
	 */
	public String getId_operation() {
		return id_operation;
	}
	/**
	 * @param id_operation the id_operation to set
	 */
	public void setId_operation(String id_operation) {
		this.id_operation = id_operation;
	}
	/**
	 * @return the id_systeme_echange
	 */
	public String getId_systeme_echange() {
		return id_systeme_echange;
	}
	/**
	 * @param id_systeme_echange the id_systeme_echange to set
	 */
	public void setId_systeme_echange(String id_systeme_echange) {
		this.id_systeme_echange = id_systeme_echange;
	}
	/**
	 * @return the id_type_operation
	 */
	public Integer getId_type_operation() {
		return id_type_operation;
	}
	/**
	 * @param id_type_operation the id_type_operation to set
	 */
	public void setId_type_operation(Integer id_type_operation) {
		this.id_type_operation = id_type_operation;
	}
	/**
	 * @return the ind_rejet
	 */
	public String getInd_rejet() {
		return ind_rejet;
	}
	/**
	 * @param ind_rejet the ind_rejet to set
	 */
	public void setInd_rejet(String ind_rejet) {
		this.ind_rejet = ind_rejet;
	}
	/**
	 * @return the lib_grp_remettant
	 */
	public String getLib_grp_remettant() {
		return lib_grp_remettant;
	}
	/**
	 * @param lib_grp_remettant the lib_grp_remettant to set
	 */
	public void setLib_grp_remettant(String lib_grp_remettant) {
		this.lib_grp_remettant = lib_grp_remettant;
	}
	/**
	 * @return the mnt_compense_sit
	 */
	public Double getMnt_compense_sit() {
		return mnt_compense_sit;
	}
	/**
	 * @param mnt_compense_sit the mnt_compense_sit to set
	 */
	public void setMnt_compense_sit(Double mnt_compense_sit) {
		this.mnt_compense_sit = mnt_compense_sit;
	}
	/**
	 * @return the num_cpte_beneficiaire_sr
	 */
	public String getNum_cpte_beneficiaire_sr() {
		return num_cpte_beneficiaire_sr;
	}
	/**
	 * @param num_cpte_beneficiaire_sr the num_cpte_beneficiaire_sr to set
	 */
	public void setNum_cpte_beneficiaire_sr(String num_cpte_beneficiaire_sr) {
		this.num_cpte_beneficiaire_sr = num_cpte_beneficiaire_sr;
	}
	/**
	 * @return the num_cpte_creditor_sr
	 */
	public String getNum_cpte_creditor_sr() {
		return num_cpte_creditor_sr;
	}
	/**
	 * @param num_cpte_creditor_sr the num_cpte_creditor_sr to set
	 */
	public void setNum_cpte_creditor_sr(String num_cpte_creditor_sr) {
		this.num_cpte_creditor_sr = num_cpte_creditor_sr;
	}
	/**
	 * @return the num_cpte_debitor_sr
	 */
	public String getNum_cpte_debitor_sr() {
		return num_cpte_debitor_sr;
	}
	/**
	 * @param num_cpte_debitor_sr the num_cpte_debitor_sr to set
	 */
	public void setNum_cpte_debitor_sr(String num_cpte_debitor_sr) {
		this.num_cpte_debitor_sr = num_cpte_debitor_sr;
	}
	/**
	 * @return the num_cpte_do_sr
	 */
	public String getNum_cpte_do_sr() {
		return num_cpte_do_sr;
	}
	/**
	 * @param num_cpte_do_sr the num_cpte_do_sr to set
	 */
	public void setNum_cpte_do_sr(String num_cpte_do_sr) {
		this.num_cpte_do_sr = num_cpte_do_sr;
	}
	/**
	 * @return the num_partition
	 */
	public String getNum_partition() {
		return num_partition;
	}
	/**
	 * @param num_partition the num_partition to set
	 */
	public void setNum_partition(String num_partition) {
		this.num_partition = num_partition;
	}
	/**
	 * @return the num_remise
	 */
	public String getNum_remise() {
		return num_remise;
	}
	/**
	 * @param num_remise the num_remise to set
	 */
	public void setNum_remise(String num_remise) {
		this.num_remise = num_remise;
	}
	/**
	 * @return the num_remise_tech
	 */
	public String getNum_remise_tech() {
		return num_remise_tech;
	}
	/**
	 * @param num_remise_tech the num_remise_tech to set
	 */
	public void setNum_remise_tech(String num_remise_tech) {
		this.num_remise_tech = num_remise_tech;
	}
	/**
	 * @return the orgnlendtoendid_src
	 */
	public String getOrgnlendtoendid_src() {
		return orgnlendtoendid_src;
	}
	/**
	 * @param orgnlendtoendid_src the orgnlendtoendid_src to set
	 */
	public void setOrgnlendtoendid_src(String orgnlendtoendid_src) {
		this.orgnlendtoendid_src = orgnlendtoendid_src;
	}
	/**
	 * @return the orgnlinstrid_src
	 */
	public String getOrgnlinstrid_src() {
		return orgnlinstrid_src;
	}
	/**
	 * @param orgnlinstrid_src the orgnlinstrid_src to set
	 */
	public void setOrgnlinstrid_src(String orgnlinstrid_src) {
		this.orgnlinstrid_src = orgnlinstrid_src;
	}
	/**
	 * @return the orgnltxid_src
	 */
	public String getOrgnltxid_src() {
		return orgnltxid_src;
	}
	/**
	 * @param orgnltxid_src the orgnltxid_src to set
	 */
	public void setOrgnltxid_src(String orgnltxid_src) {
		this.orgnltxid_src = orgnltxid_src;
	}
	/**
	 * @return the pmtid_txid_src
	 */
	public String getPmtid_txid_src() {
		return pmtid_txid_src;
	}
	/**
	 * @param pmtid_txid_src the pmtid_txid_src to set
	 */
	public void setPmtid_txid_src(String pmtid_txid_src) {
		this.pmtid_txid_src = pmtid_txid_src;
	}
	/**
	 * @return the ref_operation_origine
	 */
	public String getRef_operation_origine() {
		return ref_operation_origine;
	}
	/**
	 * @param ref_operation_origine the ref_operation_origine to set
	 */
	public void setRef_operation_origine(String ref_operation_origine) {
		this.ref_operation_origine = ref_operation_origine;
	}
	/**
	 * @return the rio
	 */
	public String getRio() {
		return rio;
	}
	/**
	 * @param rio the rio to set
	 */
	public void setRio(String rio) {
		this.rio = rio;
	}
	/**
	 * @return the sens_echange
	 */
	public String getSens_echange() {
		return sens_echange;
	}
	/**
	 * @param sens_echange the sens_echange to set
	 */
	public void setSens_echange(String sens_echange) {
		this.sens_echange = sens_echange;
	}
	/**
	 * @return the xtimts
	 */
	public java.sql.Timestamp getXtimts() {
		return xtimts;
	}
	/**
	 * @param xtimts the xtimts to set
	 */
	public void setXtimts(java.sql.Timestamp xtimts) {
		this.xtimts = xtimts;
	}
	/**
	 * @return the type_enregistrement
	 */
	public String getType_enregistrement() {
		return type_enregistrement;
	}
	/**
	 * @param type_enregistrement the type_enregistrement to set
	 */
	public void setType_enregistrement(String type_enregistrement) {
		this.type_enregistrement = type_enregistrement;
	}
	/**
	 * @return the type_operation
	 */
	public String getType_operation() {
		return type_operation;
	}
	/**
	 * @param type_operation the type_operation to set
	 */
	public void setType_operation(String type_operation) {
		this.type_operation = type_operation;
	}
	/**
	 * @return the bic_id_beneficiaire
	 */
	public String getBic_id_beneficiaire() {
		return bic_id_beneficiaire;
	}
	/**
	 * @param bic_id_beneficiaire the bic_id_beneficiaire to set
	 */
	public void setBic_id_beneficiaire(String bic_id_beneficiaire) {
		this.bic_id_beneficiaire = bic_id_beneficiaire;
	}
	/**
	 * @return the bic_id_creditor
	 */
	public String getBic_id_creditor() {
		return bic_id_creditor;
	}
	/**
	 * @param bic_id_creditor the bic_id_creditor to set
	 */
	public void setBic_id_creditor(String bic_id_creditor) {
		this.bic_id_creditor = bic_id_creditor;
	}
	/**
	 * @return the bic_id_debitor
	 */
	public String getBic_id_debitor() {
		return bic_id_debitor;
	}
	/**
	 * @param bic_id_debitor the bic_id_debitor to set
	 */
	public void setBic_id_debitor(String bic_id_debitor) {
		this.bic_id_debitor = bic_id_debitor;
	}
	/**
	 * @return the bic_id_do
	 */
	public String getBic_id_do() {
		return bic_id_do;
	}
	/**
	 * @param bic_id_do the bic_id_do to set
	 */
	public void setBic_id_do(String bic_id_do) {
		this.bic_id_do = bic_id_do;
	}
	/**
	 * @return the cdt_id_org_bic_bei
	 */
	public String getCdt_id_org_bic_bei() {
		return cdt_id_org_bic_bei;
	}
	/**
	 * @param cdt_id_org_bic_bei the cdt_id_org_bic_bei to set
	 */
	public void setCdt_id_org_bic_bei(String cdt_id_org_bic_bei) {
		this.cdt_id_org_bic_bei = cdt_id_org_bic_bei;
	}
	/**
	 * @return the cdt_id_org_othr_id
	 */
	public String getCdt_id_org_othr_id() {
		return cdt_id_org_othr_id;
	}
	/**
	 * @param cdt_id_org_othr_id the cdt_id_org_othr_id to set
	 */
	public void setCdt_id_org_othr_id(String cdt_id_org_othr_id) {
		this.cdt_id_org_othr_id = cdt_id_org_othr_id;
	}
	/**
	 * @return the cdt_id_org_othr_issr
	 */
	public String getCdt_id_org_othr_issr() {
		return cdt_id_org_othr_issr;
	}
	/**
	 * @param cdt_id_org_othr_issr the cdt_id_org_othr_issr to set
	 */
	public void setCdt_id_org_othr_issr(String cdt_id_org_othr_issr) {
		this.cdt_id_org_othr_issr = cdt_id_org_othr_issr;
	}
	/**
	 * @return the cdt_id_org_othr_sch_cd
	 */
	public String getCdt_id_org_othr_sch_cd() {
		return cdt_id_org_othr_sch_cd;
	}
	/**
	 * @param cdt_id_org_othr_sch_cd the cdt_id_org_othr_sch_cd to set
	 */
	public void setCdt_id_org_othr_sch_cd(String cdt_id_org_othr_sch_cd) {
		this.cdt_id_org_othr_sch_cd = cdt_id_org_othr_sch_cd;
	}
	/**
	 * @return the cdt_id_org_othr_sch_prtry
	 */
	public String getCdt_id_org_othr_sch_prtry() {
		return cdt_id_org_othr_sch_prtry;
	}
	/**
	 * @param cdt_id_org_othr_sch_prtry the cdt_id_org_othr_sch_prtry to set
	 */
	public void setCdt_id_org_othr_sch_prtry(String cdt_id_org_othr_sch_prtry) {
		this.cdt_id_org_othr_sch_prtry = cdt_id_org_othr_sch_prtry;
	}
	/**
	 * @return the cdt_id_pr_dpbi_cry
	 */
	public String getCdt_id_pr_dpbi_cry() {
		return cdt_id_pr_dpbi_cry;
	}
	/**
	 * @param cdt_id_pr_dpbi_cry the cdt_id_pr_dpbi_cry to set
	 */
	public void setCdt_id_pr_dpbi_cry(String cdt_id_pr_dpbi_cry) {
		this.cdt_id_pr_dpbi_cry = cdt_id_pr_dpbi_cry;
	}
	/**
	 * @return the cdt_id_pr_dpbi_cty
	 */
	public String getCdt_id_pr_dpbi_cty() {
		return cdt_id_pr_dpbi_cty;
	}
	/**
	 * @param cdt_id_pr_dpbi_cty the cdt_id_pr_dpbi_cty to set
	 */
	public void setCdt_id_pr_dpbi_cty(String cdt_id_pr_dpbi_cty) {
		this.cdt_id_pr_dpbi_cty = cdt_id_pr_dpbi_cty;
	}
	/**
	 * @return the cdt_id_pr_dpbi_dat
	 */
	public java.sql.Date getCdt_id_pr_dpbi_dat() {
		return cdt_id_pr_dpbi_dat;
	}
	/**
	 * @param cdt_id_pr_dpbi_dat the cdt_id_pr_dpbi_dat to set
	 */
	public void setCdt_id_pr_dpbi_dat(java.sql.Date cdt_id_pr_dpbi_dat) {
		this.cdt_id_pr_dpbi_dat = cdt_id_pr_dpbi_dat;
	}
	/**
	 * @return the cdt_id_pr_dpbi_prv
	 */
	public String getCdt_id_pr_dpbi_prv() {
		return cdt_id_pr_dpbi_prv;
	}
	/**
	 * @param cdt_id_pr_dpbi_prv the cdt_id_pr_dpbi_prv to set
	 */
	public void setCdt_id_pr_dpbi_prv(String cdt_id_pr_dpbi_prv) {
		this.cdt_id_pr_dpbi_prv = cdt_id_pr_dpbi_prv;
	}
	/**
	 * @return the cdt_id_prv_othr_id
	 */
	public String getCdt_id_prv_othr_id() {
		return cdt_id_prv_othr_id;
	}
	/**
	 * @param cdt_id_prv_othr_id the cdt_id_prv_othr_id to set
	 */
	public void setCdt_id_prv_othr_id(String cdt_id_prv_othr_id) {
		this.cdt_id_prv_othr_id = cdt_id_prv_othr_id;
	}
	/**
	 * @return the cdt_id_prv_othr_issr
	 */
	public String getCdt_id_prv_othr_issr() {
		return cdt_id_prv_othr_issr;
	}
	/**
	 * @param cdt_id_prv_othr_issr the cdt_id_prv_othr_issr to set
	 */
	public void setCdt_id_prv_othr_issr(String cdt_id_prv_othr_issr) {
		this.cdt_id_prv_othr_issr = cdt_id_prv_othr_issr;
	}
	/**
	 * @return the cdt_id_prv_othr_sch_cd
	 */
	public String getCdt_id_prv_othr_sch_cd() {
		return cdt_id_prv_othr_sch_cd;
	}
	/**
	 * @param cdt_id_prv_othr_sch_cd the cdt_id_prv_othr_sch_cd to set
	 */
	public void setCdt_id_prv_othr_sch_cd(String cdt_id_prv_othr_sch_cd) {
		this.cdt_id_prv_othr_sch_cd = cdt_id_prv_othr_sch_cd;
	}
	/**
	 * @return the cdt_id_prv_othr_sch_prtr
	 */
	public String getCdt_id_prv_othr_sch_prtr() {
		return cdt_id_prv_othr_sch_prtr;
	}
	/**
	 * @param cdt_id_prv_othr_sch_prtr the cdt_id_prv_othr_sch_prtr to set
	 */
	public void setCdt_id_prv_othr_sch_prtr(String cdt_id_prv_othr_sch_prtr) {
		this.cdt_id_prv_othr_sch_prtr = cdt_id_prv_othr_sch_prtr;
	}
	/**
	 * @return the cdt_name
	 */
	public String getCdt_name() {
		return cdt_name;
	}
	/**
	 * @param cdt_name the cdt_name to set
	 */
	public void setCdt_name(String cdt_name) {
		this.cdt_name = cdt_name;
	}
	/**
	 * @return the cdt_padr_adrline
	 */
	public String getCdt_padr_adrline() {
		return cdt_padr_adrline;
	}
	/**
	 * @param cdt_padr_adrline the cdt_padr_adrline to set
	 */
	public void setCdt_padr_adrline(String cdt_padr_adrline) {
		this.cdt_padr_adrline = cdt_padr_adrline;
	}
	/**
	 * @return the cdt_padr_ctry
	 */
	public String getCdt_padr_ctry() {
		return cdt_padr_ctry;
	}
	/**
	 * @param cdt_padr_ctry the cdt_padr_ctry to set
	 */
	public void setCdt_padr_ctry(String cdt_padr_ctry) {
		this.cdt_padr_ctry = cdt_padr_ctry;
	}
	/**
	 * @return the cdtacc_id_iban
	 */
	public String getCdtacc_id_iban() {
		return cdtacc_id_iban;
	}
	/**
	 * @param cdtacc_id_iban the cdtacc_id_iban to set
	 */
	public void setCdtacc_id_iban(String cdtacc_id_iban) {
		this.cdtacc_id_iban = cdtacc_id_iban;
	}
	/**
	 * @return the cdtagt_fi_bic
	 */
	public String getCdtagt_fi_bic() {
		return cdtagt_fi_bic;
	}
	/**
	 * @param cdtagt_fi_bic the cdtagt_fi_bic to set
	 */
	public void setCdtagt_fi_bic(String cdtagt_fi_bic) {
		this.cdtagt_fi_bic = cdtagt_fi_bic;
	}
	/**
	 * @return the chrgbr
	 */
	public String getChrgbr() {
		return chrgbr;
	}
	/**
	 * @param chrgbr the chrgbr to set
	 */
	public void setChrgbr(String chrgbr) {
		this.chrgbr = chrgbr;
	}
	/**
	 * @return the chrginf_amt
	 */
	public Double getChrginf_amt() {
		return chrginf_amt;
	}
	/**
	 * @param chrginf_amt the chrginf_amt to set
	 */
	public void setChrginf_amt(Double chrginf_amt) {
		this.chrginf_amt = chrginf_amt;
	}
	/**
	 * @return the chrginf_amtc
	 */
	public String getChrginf_amtc() {
		return chrginf_amtc;
	}
	/**
	 * @param chrginf_amtc the chrginf_amtc to set
	 */
	public void setChrginf_amtc(String chrginf_amtc) {
		this.chrginf_amtc = chrginf_amtc;
	}
	/**
	 * @return the chrginf_pty_fi_bic
	 */
	public String getChrginf_pty_fi_bic() {
		return chrginf_pty_fi_bic;
	}
	/**
	 * @param chrginf_pty_fi_bic the chrginf_pty_fi_bic to set
	 */
	public void setChrginf_pty_fi_bic(String chrginf_pty_fi_bic) {
		this.chrginf_pty_fi_bic = chrginf_pty_fi_bic;
	}
	/**
	 * @return the code_format_pacs
	 */
	public String getCode_format_pacs() {
		return code_format_pacs;
	}
	/**
	 * @param code_format_pacs the code_format_pacs to set
	 */
	public void setCode_format_pacs(String code_format_pacs) {
		this.code_format_pacs = code_format_pacs;
	}
	/**
	 * @return the compstnamt
	 */
	public Double getCompstnamt() {
		return compstnamt;
	}
	/**
	 * @param compstnamt the compstnamt to set
	 */
	public void setCompstnamt(Double compstnamt) {
		this.compstnamt = compstnamt;
	}
	/**
	 * @return the compstnamtc
	 */
	public String getCompstnamtc() {
		return compstnamtc;
	}
	/**
	 * @param compstnamtc the compstnamtc to set
	 */
	public void setCompstnamtc(String compstnamtc) {
		this.compstnamtc = compstnamtc;
	}
	/**
	 * @return the csch_idproi
	 */
	public String getCsch_idproi() {
		return csch_idproi;
	}
	/**
	 * @param csch_idproi the csch_idproi to set
	 */
	public void setCsch_idproi(String csch_idproi) {
		this.csch_idproi = csch_idproi;
	}
	/**
	 * @return the csch_idproi_cd
	 */
	public String getCsch_idproi_cd() {
		return csch_idproi_cd;
	}
	/**
	 * @param csch_idproi_cd the csch_idproi_cd to set
	 */
	public void setCsch_idproi_cd(String csch_idproi_cd) {
		this.csch_idproi_cd = csch_idproi_cd;
	}
	/**
	 * @return the csch_idproi_issr
	 */
	public String getCsch_idproi_issr() {
		return csch_idproi_issr;
	}
	/**
	 * @param csch_idproi_issr the csch_idproi_issr to set
	 */
	public void setCsch_idproi_issr(String csch_idproi_issr) {
		this.csch_idproi_issr = csch_idproi_issr;
	}
	/**
	 * @return the csch_idproi_prtry
	 */
	public String getCsch_idproi_prtry() {
		return csch_idproi_prtry;
	}
	/**
	 * @param csch_idproi_prtry the csch_idproi_prtry to set
	 */
	public void setCsch_idproi_prtry(String csch_idproi_prtry) {
		this.csch_idproi_prtry = csch_idproi_prtry;
	}
	/**
	 * @return the date_insert
	 */
	public java.sql.Date getDate_insert() {
		return date_insert;
	}
	/**
	 * @param date_insert the date_insert to set
	 */
	public void setDate_insert(java.sql.Date date_insert) {
		this.date_insert = date_insert;
	}
	/**
	 * @return the dbt_id_org_bic_bei
	 */
	public String getDbt_id_org_bic_bei() {
		return dbt_id_org_bic_bei;
	}
	/**
	 * @param dbt_id_org_bic_bei the dbt_id_org_bic_bei to set
	 */
	public void setDbt_id_org_bic_bei(String dbt_id_org_bic_bei) {
		this.dbt_id_org_bic_bei = dbt_id_org_bic_bei;
	}
	/**
	 * @return the dbt_id_org_othr_id
	 */
	public String getDbt_id_org_othr_id() {
		return dbt_id_org_othr_id;
	}
	/**
	 * @param dbt_id_org_othr_id the dbt_id_org_othr_id to set
	 */
	public void setDbt_id_org_othr_id(String dbt_id_org_othr_id) {
		this.dbt_id_org_othr_id = dbt_id_org_othr_id;
	}
	/**
	 * @return the dbt_id_org_othr_issr
	 */
	public String getDbt_id_org_othr_issr() {
		return dbt_id_org_othr_issr;
	}
	/**
	 * @param dbt_id_org_othr_issr the dbt_id_org_othr_issr to set
	 */
	public void setDbt_id_org_othr_issr(String dbt_id_org_othr_issr) {
		this.dbt_id_org_othr_issr = dbt_id_org_othr_issr;
	}
	/**
	 * @return the dbt_id_org_othr_sch_cd
	 */
	public String getDbt_id_org_othr_sch_cd() {
		return dbt_id_org_othr_sch_cd;
	}
	/**
	 * @param dbt_id_org_othr_sch_cd the dbt_id_org_othr_sch_cd to set
	 */
	public void setDbt_id_org_othr_sch_cd(String dbt_id_org_othr_sch_cd) {
		this.dbt_id_org_othr_sch_cd = dbt_id_org_othr_sch_cd;
	}
	/**
	 * @return the dbt_id_org_othr_sch_prtry
	 */
	public String getDbt_id_org_othr_sch_prtry() {
		return dbt_id_org_othr_sch_prtry;
	}
	/**
	 * @param dbt_id_org_othr_sch_prtry the dbt_id_org_othr_sch_prtry to set
	 */
	public void setDbt_id_org_othr_sch_prtry(String dbt_id_org_othr_sch_prtry) {
		this.dbt_id_org_othr_sch_prtry = dbt_id_org_othr_sch_prtry;
	}
	/**
	 * @return the dbt_id_pr_dpbi_cr
	 */
	public String getDbt_id_pr_dpbi_cr() {
		return dbt_id_pr_dpbi_cr;
	}
	/**
	 * @param dbt_id_pr_dpbi_cr the dbt_id_pr_dpbi_cr to set
	 */
	public void setDbt_id_pr_dpbi_cr(String dbt_id_pr_dpbi_cr) {
		this.dbt_id_pr_dpbi_cr = dbt_id_pr_dpbi_cr;
	}
	/**
	 * @return the dbt_id_pr_dpbi_cty
	 */
	public String getDbt_id_pr_dpbi_cty() {
		return dbt_id_pr_dpbi_cty;
	}
	/**
	 * @param dbt_id_pr_dpbi_cty the dbt_id_pr_dpbi_cty to set
	 */
	public void setDbt_id_pr_dpbi_cty(String dbt_id_pr_dpbi_cty) {
		this.dbt_id_pr_dpbi_cty = dbt_id_pr_dpbi_cty;
	}
	/**
	 * @return the dbt_id_pr_dpbi_dat
	 */
	public java.sql.Date getDbt_id_pr_dpbi_dat() {
		return dbt_id_pr_dpbi_dat;
	}
	/**
	 * @param dbt_id_pr_dpbi_dat the dbt_id_pr_dpbi_dat to set
	 */
	public void setDbt_id_pr_dpbi_dat(java.sql.Date dbt_id_pr_dpbi_dat) {
		this.dbt_id_pr_dpbi_dat = dbt_id_pr_dpbi_dat;
	}
	/**
	 * @return the dbt_id_pr_dpbi_prv
	 */
	public String getDbt_id_pr_dpbi_prv() {
		return dbt_id_pr_dpbi_prv;
	}
	/**
	 * @param dbt_id_pr_dpbi_prv the dbt_id_pr_dpbi_prv to set
	 */
	public void setDbt_id_pr_dpbi_prv(String dbt_id_pr_dpbi_prv) {
		this.dbt_id_pr_dpbi_prv = dbt_id_pr_dpbi_prv;
	}
	/**
	 * @return the dbt_id_prv_othr_id
	 */
	public String getDbt_id_prv_othr_id() {
		return dbt_id_prv_othr_id;
	}
	/**
	 * @param dbt_id_prv_othr_id the dbt_id_prv_othr_id to set
	 */
	public void setDbt_id_prv_othr_id(String dbt_id_prv_othr_id) {
		this.dbt_id_prv_othr_id = dbt_id_prv_othr_id;
	}
	/**
	 * @return the dbt_id_prv_othr_issr
	 */
	public String getDbt_id_prv_othr_issr() {
		return dbt_id_prv_othr_issr;
	}
	/**
	 * @param dbt_id_prv_othr_issr the dbt_id_prv_othr_issr to set
	 */
	public void setDbt_id_prv_othr_issr(String dbt_id_prv_othr_issr) {
		this.dbt_id_prv_othr_issr = dbt_id_prv_othr_issr;
	}
	/**
	 * @return the dbt_id_prv_othr_sch_cd
	 */
	public String getDbt_id_prv_othr_sch_cd() {
		return dbt_id_prv_othr_sch_cd;
	}
	/**
	 * @param dbt_id_prv_othr_sch_cd the dbt_id_prv_othr_sch_cd to set
	 */
	public void setDbt_id_prv_othr_sch_cd(String dbt_id_prv_othr_sch_cd) {
		this.dbt_id_prv_othr_sch_cd = dbt_id_prv_othr_sch_cd;
	}
	/**
	 * @return the dbt_id_prv_othr_sch_prtr
	 */
	public String getDbt_id_prv_othr_sch_prtr() {
		return dbt_id_prv_othr_sch_prtr;
	}
	/**
	 * @param dbt_id_prv_othr_sch_prtr the dbt_id_prv_othr_sch_prtr to set
	 */
	public void setDbt_id_prv_othr_sch_prtr(String dbt_id_prv_othr_sch_prtr) {
		this.dbt_id_prv_othr_sch_prtr = dbt_id_prv_othr_sch_prtr;
	}
	/**
	 * @return the dbt_name
	 */
	public String getDbt_name() {
		return dbt_name;
	}
	/**
	 * @param dbt_name the dbt_name to set
	 */
	public void setDbt_name(String dbt_name) {
		this.dbt_name = dbt_name;
	}
	/**
	 * @return the dbt_padr_adrline
	 */
	public String getDbt_padr_adrline() {
		return dbt_padr_adrline;
	}
	/**
	 * @param dbt_padr_adrline the dbt_padr_adrline to set
	 */
	public void setDbt_padr_adrline(String dbt_padr_adrline) {
		this.dbt_padr_adrline = dbt_padr_adrline;
	}
	/**
	 * @return the dbt_padr_ctry
	 */
	public String getDbt_padr_ctry() {
		return dbt_padr_ctry;
	}
	/**
	 * @param dbt_padr_ctry the dbt_padr_ctry to set
	 */
	public void setDbt_padr_ctry(String dbt_padr_ctry) {
		this.dbt_padr_ctry = dbt_padr_ctry;
	}
	/**
	 * @return the dbtacc_id_iban
	 */
	public String getDbtacc_id_iban() {
		return dbtacc_id_iban;
	}
	/**
	 * @param dbtacc_id_iban the dbtacc_id_iban to set
	 */
	public void setDbtacc_id_iban(String dbtacc_id_iban) {
		this.dbtacc_id_iban = dbtacc_id_iban;
	}
	/**
	 * @return the dbtagt_fi_bic
	 */
	public String getDbtagt_fi_bic() {
		return dbtagt_fi_bic;
	}
	/**
	 * @param dbtagt_fi_bic the dbtagt_fi_bic to set
	 */
	public void setDbtagt_fi_bic(String dbtagt_fi_bic) {
		this.dbtagt_fi_bic = dbtagt_fi_bic;
	}
	/**
	 * @return the iban_beneficiaire
	 */
	public String getIban_beneficiaire() {
		return iban_beneficiaire;
	}
	/**
	 * @param iban_beneficiaire the iban_beneficiaire to set
	 */
	public void setIban_beneficiaire(String iban_beneficiaire) {
		this.iban_beneficiaire = iban_beneficiaire;
	}
	/**
	 * @return the iban_creditor
	 */
	public String getIban_creditor() {
		return iban_creditor;
	}
	/**
	 * @param iban_creditor the iban_creditor to set
	 */
	public void setIban_creditor(String iban_creditor) {
		this.iban_creditor = iban_creditor;
	}
	/**
	 * @return the iban_debtor
	 */
	public String getIban_debitor() {
		return iban_debitor;
	}
	/**
	 * @param iban_debtor the iban_debtor to set
	 */
	public void setIban_debitor(String iban_debitor) {
		this.iban_debitor = iban_debitor;
	}
	/**
	 * @return the iban_do
	 */
	public String getIban_do() {
		return iban_do;
	}
	/**
	 * @param iban_do the iban_do to set
	 */
	public void setIban_do(String iban_do) {
		this.iban_do = iban_do;
	}
	/**
	 * @return the insdagt_fi_bic
	 */
	public String getInsdagt_fi_bic() {
		return insdagt_fi_bic;
	}
	/**
	 * @param insdagt_fi_bic the insdagt_fi_bic to set
	 */
	public void setInsdagt_fi_bic(String insdagt_fi_bic) {
		this.insdagt_fi_bic = insdagt_fi_bic;
	}
	/**
	 * @return the insgagt_fi_bic
	 */
	public String getInsgagt_fi_bic() {
		return insgagt_fi_bic;
	}
	/**
	 * @param insgagt_fi_bic the insgagt_fi_bic to set
	 */
	public void setInsgagt_fi_bic(String insgagt_fi_bic) {
		this.insgagt_fi_bic = insgagt_fi_bic;
	}
	/**
	 * @return the instdamt
	 */
	public Double getInstdamt() {
		return instdamt;
	}
	/**
	 * @param instdamt the instdamt to set
	 */
	public void setInstdamt(Double instdamt) {
		this.instdamt = instdamt;
	}
	/**
	 * @return the instdamtc
	 */
	public String getInstdamtc() {
		return instdamtc;
	}
	/**
	 * @param instdamtc the instdamtc to set
	 */
	public void setInstdamtc(String instdamtc) {
		this.instdamtc = instdamtc;
	}
	/**
	 * @return the intrbksttlmamt
	 */
	public BigDecimal getIntrbksttlmamt() {
		return intrbksttlmamt;
	}
	/**
	 * @param intrbksttlmamt the intrbksttlmamt to set
	 */
	public void setIntrbksttlmamt(BigDecimal intrbksttlmamt) {
		this.intrbksttlmamt = intrbksttlmamt;
	}
	/**
	 * @return the intrbksttlmamtc
	 */
	public String getIntrbksttlmamtc() {
		return intrbksttlmamtc;
	}
	/**
	 * @param intrbksttlmamtc the intrbksttlmamtc to set
	 */
	public void setIntrbksttlmamtc(String intrbksttlmamtc) {
		this.intrbksttlmamtc = intrbksttlmamtc;
	}
	/**
	 * @return the m_a_odac_id_iban
	 */
	public String getM_a_odac_id_iban() {
		return m_a_odac_id_iban;
	}
	/**
	 * @param m_a_odac_id_iban the m_a_odac_id_iban to set
	 */
	public void setM_a_odac_id_iban(String m_a_odac_id_iban) {
		this.m_a_odac_id_iban = m_a_odac_id_iban;
	}
	/**
	 * @return the m_a_odac_v9_fi_bic
	 */
	public String getM_a_odac_v9_fi_bic() {
		return m_a_odac_v9_fi_bic;
	}
	/**
	 * @param m_a_odac_v9_fi_bic the m_a_odac_v9_fi_bic to set
	 */
	public void setM_a_odac_v9_fi_bic(String m_a_odac_v9_fi_bic) {
		this.m_a_odac_v9_fi_bic = m_a_odac_v9_fi_bic;
	}
	/**
	 * @return the m_a_odac_v9_id_othr_id
	 */
	public String getM_a_odac_v9_id_othr_id() {
		return m_a_odac_v9_id_othr_id;
	}
	/**
	 * @param m_a_odac_v9_id_othr_id the m_a_odac_v9_id_othr_id to set
	 */
	public void setM_a_odac_v9_id_othr_id(String m_a_odac_v9_id_othr_id) {
		this.m_a_odac_v9_id_othr_id = m_a_odac_v9_id_othr_id;
	}
	/**
	 * @return the m_a_odag_fi_othr_id
	 */
	public String getM_a_odag_fi_othr_id() {
		return m_a_odag_fi_othr_id;
	}
	/**
	 * @param m_a_odag_fi_othr_id the m_a_odag_fi_othr_id to set
	 */
	public void setM_a_odag_fi_othr_id(String m_a_odag_fi_othr_id) {
		this.m_a_odag_fi_othr_id = m_a_odag_fi_othr_id;
	}
	/**
	 * @return the m_a_orgnlmndtid
	 */
	public String getM_a_orgnlmndtid() {
		return m_a_orgnlmndtid;
	}
	/**
	 * @param m_a_orgnlmndtid the m_a_orgnlmndtid to set
	 */
	public void setM_a_orgnlmndtid(String m_a_orgnlmndtid) {
		this.m_a_orgnlmndtid = m_a_orgnlmndtid;
	}
	/**
	 * @return the m_a_s_id_pro_issr
	 */
	public String getM_a_s_id_pro_issr() {
		return m_a_s_id_pro_issr;
	}
	/**
	 * @param m_a_s_id_pro_issr the m_a_s_id_pro_issr to set
	 */
	public void setM_a_s_id_pro_issr(String m_a_s_id_pro_issr) {
		this.m_a_s_id_pro_issr = m_a_s_id_pro_issr;
	}
	/**
	 * @return the m_a_s_id_pro_sch_cd
	 */
	public String getM_a_s_id_pro_sch_cd() {
		return m_a_s_id_pro_sch_cd;
	}
	/**
	 * @param m_a_s_id_pro_sch_cd the m_a_s_id_pro_sch_cd to set
	 */
	public void setM_a_s_id_pro_sch_cd(String m_a_s_id_pro_sch_cd) {
		this.m_a_s_id_pro_sch_cd = m_a_s_id_pro_sch_cd;
	}
	/**
	 * @return the m_a_s_id_pro_sch_prtry
	 */
	public String getM_a_s_id_pro_sch_prtry() {
		return m_a_s_id_pro_sch_prtry;
	}
	/**
	 * @param m_a_s_id_pro_sch_prtry the m_a_s_id_pro_sch_prtry to set
	 */
	public void setM_a_s_id_pro_sch_prtry(String m_a_s_id_pro_sch_prtry) {
		this.m_a_s_id_pro_sch_prtry = m_a_s_id_pro_sch_prtry;
	}
	/**
	 * @return the m_a_s_id_proid
	 */
	public String getM_a_s_id_proid() {
		return m_a_s_id_proid;
	}
	/**
	 * @param m_a_s_id_proid the m_a_s_id_proid to set
	 */
	public void setM_a_s_id_proid(String m_a_s_id_proid) {
		this.m_a_s_id_proid = m_a_s_id_proid;
	}
	/**
	 * @return the m_a_s_nm
	 */
	public String getM_a_s_nm() {
		return m_a_s_nm;
	}
	/**
	 * @param m_a_s_nm the m_a_s_nm to set
	 */
	public void setM_a_s_nm(String m_a_s_nm) {
		this.m_a_s_nm = m_a_s_nm;
	}
	/**
	 * @return the m_add_inf
	 */
	public String getM_add_inf() {
		return m_add_inf;
	}
	/**
	 * @param m_add_inf the m_add_inf to set
	 */
	public void setM_add_inf(String m_add_inf) {
		this.m_add_inf = m_add_inf;
	}
	/**
	 * @return the m_amdmntind
	 */
	public String getM_amdmntind() {
		return m_amdmntind;
	}
	/**
	 * @param m_amdmntind the m_amdmntind to set
	 */
	public void setM_amdmntind(String m_amdmntind) {
		this.m_amdmntind = m_amdmntind;
	}
	/**
	 * @return the m_dtofsgntr
	 */
	public java.sql.Date getM_dtofsgntr() {
		return m_dtofsgntr;
	}
	/**
	 * @param m_dtofsgntr the m_dtofsgntr to set
	 */
	public void setM_dtofsgntr(java.sql.Date m_dtofsgntr) {
		this.m_dtofsgntr = m_dtofsgntr;
	}
	/**
	 * @return the m_elctrncsgnt
	 */
	public String getM_elctrncsgnt() {
		return m_elctrncsgnt;
	}
	/**
	 * @param m_elctrncsgnt the m_elctrncsgnt to set
	 */
	public void setM_elctrncsgnt(String m_elctrncsgnt) {
		this.m_elctrncsgnt = m_elctrncsgnt;
	}
	/**
	 * @return the m_id
	 */
	public String getM_id() {
		return m_id;
	}
	/**
	 * @param m_id the m_id to set
	 */
	public void setM_id(String m_id) {
		this.m_id = m_id;
	}
	/**
	 * @return the m_mndtid
	 */
	public String getM_mndtid() {
		return m_mndtid;
	}
	/**
	 * @param m_mndtid the m_mndtid to set
	 */
	public void setM_mndtid(String m_mndtid) {
		this.m_mndtid = m_mndtid;
	}
	/**
	 * @return the m_orgnl_accnt_iban
	 */
	public String getM_orgnl_accnt_iban() {
		return m_orgnl_accnt_iban;
	}
	/**
	 * @param m_orgnl_accnt_iban the m_orgnl_accnt_iban to set
	 */
	public void setM_orgnl_accnt_iban(String m_orgnl_accnt_iban) {
		this.m_orgnl_accnt_iban = m_orgnl_accnt_iban;
	}
	/**
	 * @return the m_orgnl_accnt_o_id
	 */
	public String getM_orgnl_accnt_o_id() {
		return m_orgnl_accnt_o_id;
	}
	/**
	 * @param m_orgnl_accnt_o_id the m_orgnl_accnt_o_id to set
	 */
	public void setM_orgnl_accnt_o_id(String m_orgnl_accnt_o_id) {
		this.m_orgnl_accnt_o_id = m_orgnl_accnt_o_id;
	}
	/**
	 * @return the m_orgnl_agt_fi_bic
	 */
	public String getM_orgnl_agt_fi_bic() {
		return m_orgnl_agt_fi_bic;
	}
	/**
	 * @param m_orgnl_agt_fi_bic the m_orgnl_agt_fi_bic to set
	 */
	public void setM_orgnl_agt_fi_bic(String m_orgnl_agt_fi_bic) {
		this.m_orgnl_agt_fi_bic = m_orgnl_agt_fi_bic;
	}
	/**
	 * @return the m_orgnl_ctct_dt_emadr
	 */
	public String getM_orgnl_ctct_dt_emadr() {
		return m_orgnl_ctct_dt_emadr;
	}
	/**
	 * @param m_orgnl_ctct_dt_emadr the m_orgnl_ctct_dt_emadr to set
	 */
	public void setM_orgnl_ctct_dt_emadr(String m_orgnl_ctct_dt_emadr) {
		this.m_orgnl_ctct_dt_emadr = m_orgnl_ctct_dt_emadr;
	}
	/**
	 * @return the m_orgnl_ctct_dt_fxnm
	 */
	public String getM_orgnl_ctct_dt_fxnm() {
		return m_orgnl_ctct_dt_fxnm;
	}
	/**
	 * @param m_orgnl_ctct_dt_fxnm the m_orgnl_ctct_dt_fxnm to set
	 */
	public void setM_orgnl_ctct_dt_fxnm(String m_orgnl_ctct_dt_fxnm) {
		this.m_orgnl_ctct_dt_fxnm = m_orgnl_ctct_dt_fxnm;
	}
	/**
	 * @return the m_orgnl_ctct_dt_mbnm
	 */
	public String getM_orgnl_ctct_dt_mbnm() {
		return m_orgnl_ctct_dt_mbnm;
	}
	/**
	 * @param m_orgnl_ctct_dt_mbnm the m_orgnl_ctct_dt_mbnm to set
	 */
	public void setM_orgnl_ctct_dt_mbnm(String m_orgnl_ctct_dt_mbnm) {
		this.m_orgnl_ctct_dt_mbnm = m_orgnl_ctct_dt_mbnm;
	}
	/**
	 * @return the m_orgnl_ctct_dt_nm
	 */
	public String getM_orgnl_ctct_dt_nm() {
		return m_orgnl_ctct_dt_nm;
	}
	/**
	 * @param m_orgnl_ctct_dt_nm the m_orgnl_ctct_dt_nm to set
	 */
	public void setM_orgnl_ctct_dt_nm(String m_orgnl_ctct_dt_nm) {
		this.m_orgnl_ctct_dt_nm = m_orgnl_ctct_dt_nm;
	}
	/**
	 * @return the m_orgnl_ctct_dt_nmpr
	 */
	public String getM_orgnl_ctct_dt_nmpr() {
		return m_orgnl_ctct_dt_nmpr;
	}
	/**
	 * @param m_orgnl_ctct_dt_nmpr the m_orgnl_ctct_dt_nmpr to set
	 */
	public void setM_orgnl_ctct_dt_nmpr(String m_orgnl_ctct_dt_nmpr) {
		this.m_orgnl_ctct_dt_nmpr = m_orgnl_ctct_dt_nmpr;
	}
	/**
	 * @return the m_orgnl_ctct_dt_other
	 */
	public String getM_orgnl_ctct_dt_other() {
		return m_orgnl_ctct_dt_other;
	}
	/**
	 * @param m_orgnl_ctct_dt_other the m_orgnl_ctct_dt_other to set
	 */
	public void setM_orgnl_ctct_dt_other(String m_orgnl_ctct_dt_other) {
		this.m_orgnl_ctct_dt_other = m_orgnl_ctct_dt_other;
	}
	/**
	 * @return the m_orgnl_ctct_dt_phnm
	 */
	public String getM_orgnl_ctct_dt_phnm() {
		return m_orgnl_ctct_dt_phnm;
	}
	/**
	 * @param m_orgnl_ctct_dt_phnm the m_orgnl_ctct_dt_phnm to set
	 */
	public void setM_orgnl_ctct_dt_phnm(String m_orgnl_ctct_dt_phnm) {
		this.m_orgnl_ctct_dt_phnm = m_orgnl_ctct_dt_phnm;
	}
	/**
	 * @return the m_orgnl_pty_ctrr
	 */
	public String getM_orgnl_pty_ctrr() {
		return m_orgnl_pty_ctrr;
	}
	/**
	 * @param m_orgnl_pty_ctrr the m_orgnl_pty_ctrr to set
	 */
	public void setM_orgnl_pty_ctrr(String m_orgnl_pty_ctrr) {
		this.m_orgnl_pty_ctrr = m_orgnl_pty_ctrr;
	}
	/**
	 * @return the m_orgnl_pty_id_oi_bic
	 */
	public String getM_orgnl_pty_id_oi_bic() {
		return m_orgnl_pty_id_oi_bic;
	}
	/**
	 * @param m_orgnl_pty_id_oi_bic the m_orgnl_pty_id_oi_bic to set
	 */
	public void setM_orgnl_pty_id_oi_bic(String m_orgnl_pty_id_oi_bic) {
		this.m_orgnl_pty_id_oi_bic = m_orgnl_pty_id_oi_bic;
	}
	/**
	 * @return the m_orgnl_pty_id_oi_id
	 */
	public String getM_orgnl_pty_id_oi_id() {
		return m_orgnl_pty_id_oi_id;
	}
	/**
	 * @param m_orgnl_pty_id_oi_id the m_orgnl_pty_id_oi_id to set
	 */
	public void setM_orgnl_pty_id_oi_id(String m_orgnl_pty_id_oi_id) {
		this.m_orgnl_pty_id_oi_id = m_orgnl_pty_id_oi_id;
	}
	/**
	 * @return the m_orgnl_pty_id_oi_o_issr
	 */
	public String getM_orgnl_pty_id_oi_o_issr() {
		return m_orgnl_pty_id_oi_o_issr;
	}
	/**
	 * @param m_orgnl_pty_id_oi_o_issr the m_orgnl_pty_id_oi_o_issr to set
	 */
	public void setM_orgnl_pty_id_oi_o_issr(String m_orgnl_pty_id_oi_o_issr) {
		this.m_orgnl_pty_id_oi_o_issr = m_orgnl_pty_id_oi_o_issr;
	}
	/**
	 * @return the m_orgnl_pty_id_oi_o_sn_cd
	 */
	public String getM_orgnl_pty_id_oi_o_sn_cd() {
		return m_orgnl_pty_id_oi_o_sn_cd;
	}
	/**
	 * @param m_orgnl_pty_id_oi_o_sn_cd the m_orgnl_pty_id_oi_o_sn_cd to set
	 */
	public void setM_orgnl_pty_id_oi_o_sn_cd(String m_orgnl_pty_id_oi_o_sn_cd) {
		this.m_orgnl_pty_id_oi_o_sn_cd = m_orgnl_pty_id_oi_o_sn_cd;
	}
	/**
	 * @return the m_orgnl_pty_id_oi_sn_pty
	 */
	public String getM_orgnl_pty_id_oi_sn_pty() {
		return m_orgnl_pty_id_oi_sn_pty;
	}
	/**
	 * @param m_orgnl_pty_id_oi_sn_pty the m_orgnl_pty_id_oi_sn_pty to set
	 */
	public void setM_orgnl_pty_id_oi_sn_pty(String m_orgnl_pty_id_oi_sn_pty) {
		this.m_orgnl_pty_id_oi_sn_pty = m_orgnl_pty_id_oi_sn_pty;
	}
	/**
	 * @return the m_orgnl_pty_id_pr_bi_cry
	 */
	public String getM_orgnl_pty_id_pr_bi_cry() {
		return m_orgnl_pty_id_pr_bi_cry;
	}
	/**
	 * @param m_orgnl_pty_id_pr_bi_cry the m_orgnl_pty_id_pr_bi_cry to set
	 */
	public void setM_orgnl_pty_id_pr_bi_cry(String m_orgnl_pty_id_pr_bi_cry) {
		this.m_orgnl_pty_id_pr_bi_cry = m_orgnl_pty_id_pr_bi_cry;
	}
	/**
	 * @return the m_orgnl_pty_id_pr_bi_cty
	 */
	public String getM_orgnl_pty_id_pr_bi_cty() {
		return m_orgnl_pty_id_pr_bi_cty;
	}
	/**
	 * @param m_orgnl_pty_id_pr_bi_cty the m_orgnl_pty_id_pr_bi_cty to set
	 */
	public void setM_orgnl_pty_id_pr_bi_cty(String m_orgnl_pty_id_pr_bi_cty) {
		this.m_orgnl_pty_id_pr_bi_cty = m_orgnl_pty_id_pr_bi_cty;
	}
	/**
	 * @return the m_orgnl_pty_id_pr_bi_dat
	 */
	public String getM_orgnl_pty_id_pr_bi_dat() {
		return m_orgnl_pty_id_pr_bi_dat;
	}
	/**
	 * @param m_orgnl_pty_id_pr_bi_dat the m_orgnl_pty_id_pr_bi_dat to set
	 */
	public void setM_orgnl_pty_id_pr_bi_dat(String m_orgnl_pty_id_pr_bi_dat) {
		this.m_orgnl_pty_id_pr_bi_dat = m_orgnl_pty_id_pr_bi_dat;
	}
	/**
	 * @return the m_orgnl_pty_id_pr_bi_prv
	 */
	public String getM_orgnl_pty_id_pr_bi_prv() {
		return m_orgnl_pty_id_pr_bi_prv;
	}
	/**
	 * @param m_orgnl_pty_id_pr_bi_prv the m_orgnl_pty_id_pr_bi_prv to set
	 */
	public void setM_orgnl_pty_id_pr_bi_prv(String m_orgnl_pty_id_pr_bi_prv) {
		this.m_orgnl_pty_id_pr_bi_prv = m_orgnl_pty_id_pr_bi_prv;
	}
	/**
	 * @return the m_orgnl_pty_id_pr_o_id
	 */
	public String getM_orgnl_pty_id_pr_o_id() {
		return m_orgnl_pty_id_pr_o_id;
	}
	/**
	 * @param m_orgnl_pty_id_pr_o_id the m_orgnl_pty_id_pr_o_id to set
	 */
	public void setM_orgnl_pty_id_pr_o_id(String m_orgnl_pty_id_pr_o_id) {
		this.m_orgnl_pty_id_pr_o_id = m_orgnl_pty_id_pr_o_id;
	}
	/**
	 * @return the m_orgnl_pty_id_pr_o_issr
	 */
	public String getM_orgnl_pty_id_pr_o_issr() {
		return m_orgnl_pty_id_pr_o_issr;
	}
	/**
	 * @param m_orgnl_pty_id_pr_o_issr the m_orgnl_pty_id_pr_o_issr to set
	 */
	public void setM_orgnl_pty_id_pr_o_issr(String m_orgnl_pty_id_pr_o_issr) {
		this.m_orgnl_pty_id_pr_o_issr = m_orgnl_pty_id_pr_o_issr;
	}
	/**
	 * @return the m_orgnl_pty_id_pr_o_sn_cd
	 */
	public String getM_orgnl_pty_id_pr_o_sn_cd() {
		return m_orgnl_pty_id_pr_o_sn_cd;
	}
	/**
	 * @param m_orgnl_pty_id_pr_o_sn_cd the m_orgnl_pty_id_pr_o_sn_cd to set
	 */
	public void setM_orgnl_pty_id_pr_o_sn_cd(String m_orgnl_pty_id_pr_o_sn_cd) {
		this.m_orgnl_pty_id_pr_o_sn_cd = m_orgnl_pty_id_pr_o_sn_cd;
	}
	/**
	 * @return the m_orgnl_pty_id_pr_o_sn_pty
	 */
	public String getM_orgnl_pty_id_pr_o_sn_pty() {
		return m_orgnl_pty_id_pr_o_sn_pty;
	}
	/**
	 * @param m_orgnl_pty_id_pr_o_sn_pty the m_orgnl_pty_id_pr_o_sn_pty to set
	 */
	public void setM_orgnl_pty_id_pr_o_sn_pty(String m_orgnl_pty_id_pr_o_sn_pty) {
		this.m_orgnl_pty_id_pr_o_sn_pty = m_orgnl_pty_id_pr_o_sn_pty;
	}
	/**
	 * @return the m_orgnl_pty_name
	 */
	public String getM_orgnl_pty_name() {
		return m_orgnl_pty_name;
	}
	/**
	 * @param m_orgnl_pty_name the m_orgnl_pty_name to set
	 */
	public void setM_orgnl_pty_name(String m_orgnl_pty_name) {
		this.m_orgnl_pty_name = m_orgnl_pty_name;
	}
	/**
	 * @return the m_orgnl_pty_padr_adli1
	 */
	public String getM_orgnl_pty_padr_adli1() {
		return m_orgnl_pty_padr_adli1;
	}
	/**
	 * @param m_orgnl_pty_padr_adli1 the m_orgnl_pty_padr_adli1 to set
	 */
	public void setM_orgnl_pty_padr_adli1(String m_orgnl_pty_padr_adli1) {
		this.m_orgnl_pty_padr_adli1 = m_orgnl_pty_padr_adli1;
	}
	/**
	 * @return the m_orgnl_pty_padr_adli2
	 */
	public String getM_orgnl_pty_padr_adli2() {
		return m_orgnl_pty_padr_adli2;
	}
	/**
	 * @param m_orgnl_pty_padr_adli2 the m_orgnl_pty_padr_adli2 to set
	 */
	public void setM_orgnl_pty_padr_adli2(String m_orgnl_pty_padr_adli2) {
		this.m_orgnl_pty_padr_adli2 = m_orgnl_pty_padr_adli2;
	}
	/**
	 * @return the m_orgnl_pty_padr_adli3
	 */
	public String getM_orgnl_pty_padr_adli3() {
		return m_orgnl_pty_padr_adli3;
	}
	/**
	 * @param m_orgnl_pty_padr_adli3 the m_orgnl_pty_padr_adli3 to set
	 */
	public void setM_orgnl_pty_padr_adli3(String m_orgnl_pty_padr_adli3) {
		this.m_orgnl_pty_padr_adli3 = m_orgnl_pty_padr_adli3;
	}
	/**
	 * @return the m_orgnl_pty_padr_adli4
	 */
	public String getM_orgnl_pty_padr_adli4() {
		return m_orgnl_pty_padr_adli4;
	}
	/**
	 * @param m_orgnl_pty_padr_adli4 the m_orgnl_pty_padr_adli4 to set
	 */
	public void setM_orgnl_pty_padr_adli4(String m_orgnl_pty_padr_adli4) {
		this.m_orgnl_pty_padr_adli4 = m_orgnl_pty_padr_adli4;
	}
	/**
	 * @return the m_orgnl_pty_padr_adli5
	 */
	public String getM_orgnl_pty_padr_adli5() {
		return m_orgnl_pty_padr_adli5;
	}
	/**
	 * @param m_orgnl_pty_padr_adli5 the m_orgnl_pty_padr_adli5 to set
	 */
	public void setM_orgnl_pty_padr_adli5(String m_orgnl_pty_padr_adli5) {
		this.m_orgnl_pty_padr_adli5 = m_orgnl_pty_padr_adli5;
	}
	/**
	 * @return the m_orgnl_pty_padr_adli6
	 */
	public String getM_orgnl_pty_padr_adli6() {
		return m_orgnl_pty_padr_adli6;
	}
	/**
	 * @param m_orgnl_pty_padr_adli6 the m_orgnl_pty_padr_adli6 to set
	 */
	public void setM_orgnl_pty_padr_adli6(String m_orgnl_pty_padr_adli6) {
		this.m_orgnl_pty_padr_adli6 = m_orgnl_pty_padr_adli6;
	}
	/**
	 * @return the m_orgnl_pty_padr_adli7
	 */
	public String getM_orgnl_pty_padr_adli7() {
		return m_orgnl_pty_padr_adli7;
	}
	/**
	 * @param m_orgnl_pty_padr_adli7 the m_orgnl_pty_padr_adli7 to set
	 */
	public void setM_orgnl_pty_padr_adli7(String m_orgnl_pty_padr_adli7) {
		this.m_orgnl_pty_padr_adli7 = m_orgnl_pty_padr_adli7;
	}
	/**
	 * @return the m_orgnl_pty_padr_bdnm
	 */
	public String getM_orgnl_pty_padr_bdnm() {
		return m_orgnl_pty_padr_bdnm;
	}
	/**
	 * @param m_orgnl_pty_padr_bdnm the m_orgnl_pty_padr_bdnm to set
	 */
	public void setM_orgnl_pty_padr_bdnm(String m_orgnl_pty_padr_bdnm) {
		this.m_orgnl_pty_padr_bdnm = m_orgnl_pty_padr_bdnm;
	}
	/**
	 * @return the m_orgnl_pty_padr_ctry
	 */
	public String getM_orgnl_pty_padr_ctry() {
		return m_orgnl_pty_padr_ctry;
	}
	/**
	 * @param m_orgnl_pty_padr_ctry the m_orgnl_pty_padr_ctry to set
	 */
	public void setM_orgnl_pty_padr_ctry(String m_orgnl_pty_padr_ctry) {
		this.m_orgnl_pty_padr_ctry = m_orgnl_pty_padr_ctry;
	}
	/**
	 * @return the m_orgnl_pty_padr_ctsd
	 */
	public String getM_orgnl_pty_padr_ctsd() {
		return m_orgnl_pty_padr_ctsd;
	}
	/**
	 * @param m_orgnl_pty_padr_ctsd the m_orgnl_pty_padr_ctsd to set
	 */
	public void setM_orgnl_pty_padr_ctsd(String m_orgnl_pty_padr_ctsd) {
		this.m_orgnl_pty_padr_ctsd = m_orgnl_pty_padr_ctsd;
	}
	/**
	 * @return the m_orgnl_pty_padr_dpt
	 */
	public String getM_orgnl_pty_padr_dpt() {
		return m_orgnl_pty_padr_dpt;
	}
	/**
	 * @param m_orgnl_pty_padr_dpt the m_orgnl_pty_padr_dpt to set
	 */
	public void setM_orgnl_pty_padr_dpt(String m_orgnl_pty_padr_dpt) {
		this.m_orgnl_pty_padr_dpt = m_orgnl_pty_padr_dpt;
	}
	/**
	 * @return the m_orgnl_pty_padr_pscd
	 */
	public String getM_orgnl_pty_padr_pscd() {
		return m_orgnl_pty_padr_pscd;
	}
	/**
	 * @param m_orgnl_pty_padr_pscd the m_orgnl_pty_padr_pscd to set
	 */
	public void setM_orgnl_pty_padr_pscd(String m_orgnl_pty_padr_pscd) {
		this.m_orgnl_pty_padr_pscd = m_orgnl_pty_padr_pscd;
	}
	/**
	 * @return the m_orgnl_pty_padr_sbdpt
	 */
	public String getM_orgnl_pty_padr_sbdpt() {
		return m_orgnl_pty_padr_sbdpt;
	}
	/**
	 * @param m_orgnl_pty_padr_sbdpt the m_orgnl_pty_padr_sbdpt to set
	 */
	public void setM_orgnl_pty_padr_sbdpt(String m_orgnl_pty_padr_sbdpt) {
		this.m_orgnl_pty_padr_sbdpt = m_orgnl_pty_padr_sbdpt;
	}
	/**
	 * @return the m_orgnl_pty_padr_stnm
	 */
	public String getM_orgnl_pty_padr_stnm() {
		return m_orgnl_pty_padr_stnm;
	}
	/**
	 * @param m_orgnl_pty_padr_stnm the m_orgnl_pty_padr_stnm to set
	 */
	public void setM_orgnl_pty_padr_stnm(String m_orgnl_pty_padr_stnm) {
		this.m_orgnl_pty_padr_stnm = m_orgnl_pty_padr_stnm;
	}
	/**
	 * @return the m_orgnl_pty_padr_twnm
	 */
	public String getM_orgnl_pty_padr_twnm() {
		return m_orgnl_pty_padr_twnm;
	}
	/**
	 * @param m_orgnl_pty_padr_twnm the m_orgnl_pty_padr_twnm to set
	 */
	public void setM_orgnl_pty_padr_twnm(String m_orgnl_pty_padr_twnm) {
		this.m_orgnl_pty_padr_twnm = m_orgnl_pty_padr_twnm;
	}
	/**
	 * @return the m_orgnl_pty_padr_typ
	 */
	public String getM_orgnl_pty_padr_typ() {
		return m_orgnl_pty_padr_typ;
	}
	/**
	 * @param m_orgnl_pty_padr_typ the m_orgnl_pty_padr_typ to set
	 */
	public void setM_orgnl_pty_padr_typ(String m_orgnl_pty_padr_typ) {
		this.m_orgnl_pty_padr_typ = m_orgnl_pty_padr_typ;
	}
	/**
	 * @return the m_updid_acct_iban
	 */
	public String getM_updid_acct_iban() {
		return m_updid_acct_iban;
	}
	/**
	 * @param m_updid_acct_iban the m_updid_acct_iban to set
	 */
	public void setM_updid_acct_iban(String m_updid_acct_iban) {
		this.m_updid_acct_iban = m_updid_acct_iban;
	}
	/**
	 * @return the m_updid_acct_o_id
	 */
	public String getM_updid_acct_o_id() {
		return m_updid_acct_o_id;
	}
	/**
	 * @param m_updid_acct_o_id the m_updid_acct_o_id to set
	 */
	public void setM_updid_acct_o_id(String m_updid_acct_o_id) {
		this.m_updid_acct_o_id = m_updid_acct_o_id;
	}
	/**
	 * @return the m_updid_agt_fi_bic
	 */
	public String getM_updid_agt_fi_bic() {
		return m_updid_agt_fi_bic;
	}
	/**
	 * @param m_updid_agt_fi_bic the m_updid_agt_fi_bic to set
	 */
	public void setM_updid_agt_fi_bic(String m_updid_agt_fi_bic) {
		this.m_updid_agt_fi_bic = m_updid_agt_fi_bic;
	}
	/**
	 * @return the m_updid_ctct_dt_emadr
	 */
	public String getM_updid_ctct_dt_emadr() {
		return m_updid_ctct_dt_emadr;
	}
	/**
	 * @param m_updid_ctct_dt_emadr the m_updid_ctct_dt_emadr to set
	 */
	public void setM_updid_ctct_dt_emadr(String m_updid_ctct_dt_emadr) {
		this.m_updid_ctct_dt_emadr = m_updid_ctct_dt_emadr;
	}
	/**
	 * @return the m_updid_ctct_dt_fxnm
	 */
	public String getM_updid_ctct_dt_fxnm() {
		return m_updid_ctct_dt_fxnm;
	}
	/**
	 * @param m_updid_ctct_dt_fxnm the m_updid_ctct_dt_fxnm to set
	 */
	public void setM_updid_ctct_dt_fxnm(String m_updid_ctct_dt_fxnm) {
		this.m_updid_ctct_dt_fxnm = m_updid_ctct_dt_fxnm;
	}
	/**
	 * @return the m_updid_ctct_dt_mbnm
	 */
	public String getM_updid_ctct_dt_mbnm() {
		return m_updid_ctct_dt_mbnm;
	}
	/**
	 * @param m_updid_ctct_dt_mbnm the m_updid_ctct_dt_mbnm to set
	 */
	public void setM_updid_ctct_dt_mbnm(String m_updid_ctct_dt_mbnm) {
		this.m_updid_ctct_dt_mbnm = m_updid_ctct_dt_mbnm;
	}
	/**
	 * @return the m_updid_ctct_dt_nm
	 */
	public String getM_updid_ctct_dt_nm() {
		return m_updid_ctct_dt_nm;
	}
	/**
	 * @param m_updid_ctct_dt_nm the m_updid_ctct_dt_nm to set
	 */
	public void setM_updid_ctct_dt_nm(String m_updid_ctct_dt_nm) {
		this.m_updid_ctct_dt_nm = m_updid_ctct_dt_nm;
	}
	/**
	 * @return the m_updid_ctct_dt_nmpr
	 */
	public String getM_updid_ctct_dt_nmpr() {
		return m_updid_ctct_dt_nmpr;
	}
	/**
	 * @param m_updid_ctct_dt_nmpr the m_updid_ctct_dt_nmpr to set
	 */
	public void setM_updid_ctct_dt_nmpr(String m_updid_ctct_dt_nmpr) {
		this.m_updid_ctct_dt_nmpr = m_updid_ctct_dt_nmpr;
	}
	/**
	 * @return the m_updid_ctct_dt_other
	 */
	public String getM_updid_ctct_dt_other() {
		return m_updid_ctct_dt_other;
	}
	/**
	 * @param m_updid_ctct_dt_other the m_updid_ctct_dt_other to set
	 */
	public void setM_updid_ctct_dt_other(String m_updid_ctct_dt_other) {
		this.m_updid_ctct_dt_other = m_updid_ctct_dt_other;
	}
	/**
	 * @return the m_updid_ctct_dt_phnm
	 */
	public String getM_updid_ctct_dt_phnm() {
		return m_updid_ctct_dt_phnm;
	}
	/**
	 * @param m_updid_ctct_dt_phnm the m_updid_ctct_dt_phnm to set
	 */
	public void setM_updid_ctct_dt_phnm(String m_updid_ctct_dt_phnm) {
		this.m_updid_ctct_dt_phnm = m_updid_ctct_dt_phnm;
	}
	/**
	 * @return the m_updid_id_o_id
	 */
	public String getM_updid_id_o_id() {
		return m_updid_id_o_id;
	}
	/**
	 * @param m_updid_id_o_id the m_updid_id_o_id to set
	 */
	public void setM_updid_id_o_id(String m_updid_id_o_id) {
		this.m_updid_id_o_id = m_updid_id_o_id;
	}
	/**
	 * @return the m_updid_pty_ctrr
	 */
	public String getM_updid_pty_ctrr() {
		return m_updid_pty_ctrr;
	}
	/**
	 * @param m_updid_pty_ctrr the m_updid_pty_ctrr to set
	 */
	public void setM_updid_pty_ctrr(String m_updid_pty_ctrr) {
		this.m_updid_pty_ctrr = m_updid_pty_ctrr;
	}
	/**
	 * @return the m_updid_pty_id_bic
	 */
	public String getM_updid_pty_id_bic() {
		return m_updid_pty_id_bic;
	}
	/**
	 * @param m_updid_pty_id_bic the m_updid_pty_id_bic to set
	 */
	public void setM_updid_pty_id_bic(String m_updid_pty_id_bic) {
		this.m_updid_pty_id_bic = m_updid_pty_id_bic;
	}
	/**
	 * @return the m_updid_pty_id_o_issr
	 */
	public String getM_updid_pty_id_o_issr() {
		return m_updid_pty_id_o_issr;
	}
	/**
	 * @param m_updid_pty_id_o_issr the m_updid_pty_id_o_issr to set
	 */
	public void setM_updid_pty_id_o_issr(String m_updid_pty_id_o_issr) {
		this.m_updid_pty_id_o_issr = m_updid_pty_id_o_issr;
	}
	/**
	 * @return the m_updid_pty_id_o_sd_pty
	 */
	public String getM_updid_pty_id_o_sd_pty() {
		return m_updid_pty_id_o_sd_pty;
	}
	/**
	 * @param m_updid_pty_id_o_sd_pty the m_updid_pty_id_o_sd_pty to set
	 */
	public void setM_updid_pty_id_o_sd_pty(String m_updid_pty_id_o_sd_pty) {
		this.m_updid_pty_id_o_sd_pty = m_updid_pty_id_o_sd_pty;
	}
	/**
	 * @return the m_updid_pty_id_o_sn_cd
	 */
	public String getM_updid_pty_id_o_sn_cd() {
		return m_updid_pty_id_o_sn_cd;
	}
	/**
	 * @param m_updid_pty_id_o_sn_cd the m_updid_pty_id_o_sn_cd to set
	 */
	public void setM_updid_pty_id_o_sn_cd(String m_updid_pty_id_o_sn_cd) {
		this.m_updid_pty_id_o_sn_cd = m_updid_pty_id_o_sn_cd;
	}
	/**
	 * @return the m_updid_pty_id_pr_bi_cry
	 */
	public String getM_updid_pty_id_pr_bi_cry() {
		return m_updid_pty_id_pr_bi_cry;
	}
	/**
	 * @param m_updid_pty_id_pr_bi_cry the m_updid_pty_id_pr_bi_cry to set
	 */
	public void setM_updid_pty_id_pr_bi_cry(String m_updid_pty_id_pr_bi_cry) {
		this.m_updid_pty_id_pr_bi_cry = m_updid_pty_id_pr_bi_cry;
	}
	/**
	 * @return the m_updid_pty_id_pr_bi_cty
	 */
	public String getM_updid_pty_id_pr_bi_cty() {
		return m_updid_pty_id_pr_bi_cty;
	}
	/**
	 * @param m_updid_pty_id_pr_bi_cty the m_updid_pty_id_pr_bi_cty to set
	 */
	public void setM_updid_pty_id_pr_bi_cty(String m_updid_pty_id_pr_bi_cty) {
		this.m_updid_pty_id_pr_bi_cty = m_updid_pty_id_pr_bi_cty;
	}
	/**
	 * @return the m_updid_pty_id_pr_bi_dat
	 */
	public String getM_updid_pty_id_pr_bi_dat() {
		return m_updid_pty_id_pr_bi_dat;
	}
	/**
	 * @param m_updid_pty_id_pr_bi_dat the m_updid_pty_id_pr_bi_dat to set
	 */
	public void setM_updid_pty_id_pr_bi_dat(String m_updid_pty_id_pr_bi_dat) {
		this.m_updid_pty_id_pr_bi_dat = m_updid_pty_id_pr_bi_dat;
	}
	/**
	 * @return the m_updid_pty_id_pr_bi_prv
	 */
	public String getM_updid_pty_id_pr_bi_prv() {
		return m_updid_pty_id_pr_bi_prv;
	}
	/**
	 * @param m_updid_pty_id_pr_bi_prv the m_updid_pty_id_pr_bi_prv to set
	 */
	public void setM_updid_pty_id_pr_bi_prv(String m_updid_pty_id_pr_bi_prv) {
		this.m_updid_pty_id_pr_bi_prv = m_updid_pty_id_pr_bi_prv;
	}
	/**
	 * @return the m_updid_pty_id_pr_o_id
	 */
	public String getM_updid_pty_id_pr_o_id() {
		return m_updid_pty_id_pr_o_id;
	}
	/**
	 * @param m_updid_pty_id_pr_o_id the m_updid_pty_id_pr_o_id to set
	 */
	public void setM_updid_pty_id_pr_o_id(String m_updid_pty_id_pr_o_id) {
		this.m_updid_pty_id_pr_o_id = m_updid_pty_id_pr_o_id;
	}
	/**
	 * @return the m_updid_pty_id_pr_o_issr
	 */
	public String getM_updid_pty_id_pr_o_issr() {
		return m_updid_pty_id_pr_o_issr;
	}
	/**
	 * @param m_updid_pty_id_pr_o_issr the m_updid_pty_id_pr_o_issr to set
	 */
	public void setM_updid_pty_id_pr_o_issr(String m_updid_pty_id_pr_o_issr) {
		this.m_updid_pty_id_pr_o_issr = m_updid_pty_id_pr_o_issr;
	}
	/**
	 * @return the m_updid_pty_id_pr_o_sn_cd
	 */
	public String getM_updid_pty_id_pr_o_sn_cd() {
		return m_updid_pty_id_pr_o_sn_cd;
	}
	/**
	 * @param m_updid_pty_id_pr_o_sn_cd the m_updid_pty_id_pr_o_sn_cd to set
	 */
	public void setM_updid_pty_id_pr_o_sn_cd(String m_updid_pty_id_pr_o_sn_cd) {
		this.m_updid_pty_id_pr_o_sn_cd = m_updid_pty_id_pr_o_sn_cd;
	}
	/**
	 * @return the m_updid_pty_id_pr_o_sn_pty
	 */
	public String getM_updid_pty_id_pr_o_sn_pty() {
		return m_updid_pty_id_pr_o_sn_pty;
	}
	/**
	 * @param m_updid_pty_id_pr_o_sn_pty the m_updid_pty_id_pr_o_sn_pty to set
	 */
	public void setM_updid_pty_id_pr_o_sn_pty(String m_updid_pty_id_pr_o_sn_pty) {
		this.m_updid_pty_id_pr_o_sn_pty = m_updid_pty_id_pr_o_sn_pty;
	}
	/**
	 * @return the m_updid_pty_name
	 */
	public String getM_updid_pty_name() {
		return m_updid_pty_name;
	}
	/**
	 * @param m_updid_pty_name the m_updid_pty_name to set
	 */
	public void setM_updid_pty_name(String m_updid_pty_name) {
		this.m_updid_pty_name = m_updid_pty_name;
	}
	/**
	 * @return the m_updid_pty_padr_adli1
	 */
	public String getM_updid_pty_padr_adli1() {
		return m_updid_pty_padr_adli1;
	}
	/**
	 * @param m_updid_pty_padr_adli1 the m_updid_pty_padr_adli1 to set
	 */
	public void setM_updid_pty_padr_adli1(String m_updid_pty_padr_adli1) {
		this.m_updid_pty_padr_adli1 = m_updid_pty_padr_adli1;
	}
	/**
	 * @return the m_updid_pty_padr_adli2
	 */
	public String getM_updid_pty_padr_adli2() {
		return m_updid_pty_padr_adli2;
	}
	/**
	 * @param m_updid_pty_padr_adli2 the m_updid_pty_padr_adli2 to set
	 */
	public void setM_updid_pty_padr_adli2(String m_updid_pty_padr_adli2) {
		this.m_updid_pty_padr_adli2 = m_updid_pty_padr_adli2;
	}
	/**
	 * @return the m_updid_pty_padr_adli3
	 */
	public String getM_updid_pty_padr_adli3() {
		return m_updid_pty_padr_adli3;
	}
	/**
	 * @param m_updid_pty_padr_adli3 the m_updid_pty_padr_adli3 to set
	 */
	public void setM_updid_pty_padr_adli3(String m_updid_pty_padr_adli3) {
		this.m_updid_pty_padr_adli3 = m_updid_pty_padr_adli3;
	}
	/**
	 * @return the m_updid_pty_padr_adli4
	 */
	public String getM_updid_pty_padr_adli4() {
		return m_updid_pty_padr_adli4;
	}
	/**
	 * @param m_updid_pty_padr_adli4 the m_updid_pty_padr_adli4 to set
	 */
	public void setM_updid_pty_padr_adli4(String m_updid_pty_padr_adli4) {
		this.m_updid_pty_padr_adli4 = m_updid_pty_padr_adli4;
	}
	/**
	 * @return the m_updid_pty_padr_adli5
	 */
	public String getM_updid_pty_padr_adli5() {
		return m_updid_pty_padr_adli5;
	}
	/**
	 * @param m_updid_pty_padr_adli5 the m_updid_pty_padr_adli5 to set
	 */
	public void setM_updid_pty_padr_adli5(String m_updid_pty_padr_adli5) {
		this.m_updid_pty_padr_adli5 = m_updid_pty_padr_adli5;
	}
	/**
	 * @return the m_updid_pty_padr_adli6
	 */
	public String getM_updid_pty_padr_adli6() {
		return m_updid_pty_padr_adli6;
	}
	/**
	 * @param m_updid_pty_padr_adli6 the m_updid_pty_padr_adli6 to set
	 */
	public void setM_updid_pty_padr_adli6(String m_updid_pty_padr_adli6) {
		this.m_updid_pty_padr_adli6 = m_updid_pty_padr_adli6;
	}
	/**
	 * @return the m_updid_pty_padr_adli7
	 */
	public String getM_updid_pty_padr_adli7() {
		return m_updid_pty_padr_adli7;
	}
	/**
	 * @param m_updid_pty_padr_adli7 the m_updid_pty_padr_adli7 to set
	 */
	public void setM_updid_pty_padr_adli7(String m_updid_pty_padr_adli7) {
		this.m_updid_pty_padr_adli7 = m_updid_pty_padr_adli7;
	}
	/**
	 * @return the m_updid_pty_padr_bdnm
	 */
	public String getM_updid_pty_padr_bdnm() {
		return m_updid_pty_padr_bdnm;
	}
	/**
	 * @param m_updid_pty_padr_bdnm the m_updid_pty_padr_bdnm to set
	 */
	public void setM_updid_pty_padr_bdnm(String m_updid_pty_padr_bdnm) {
		this.m_updid_pty_padr_bdnm = m_updid_pty_padr_bdnm;
	}
	/**
	 * @return the m_updid_pty_padr_ctr
	 */
	public String getM_updid_pty_padr_ctr() {
		return m_updid_pty_padr_ctr;
	}
	/**
	 * @param m_updid_pty_padr_ctr the m_updid_pty_padr_ctr to set
	 */
	public void setM_updid_pty_padr_ctr(String m_updid_pty_padr_ctr) {
		this.m_updid_pty_padr_ctr = m_updid_pty_padr_ctr;
	}
	/**
	 * @return the m_updid_pty_padr_ctsd
	 */
	public String getM_updid_pty_padr_ctsd() {
		return m_updid_pty_padr_ctsd;
	}
	/**
	 * @param m_updid_pty_padr_ctsd the m_updid_pty_padr_ctsd to set
	 */
	public void setM_updid_pty_padr_ctsd(String m_updid_pty_padr_ctsd) {
		this.m_updid_pty_padr_ctsd = m_updid_pty_padr_ctsd;
	}
	/**
	 * @return the m_updid_pty_padr_dpt
	 */
	public String getM_updid_pty_padr_dpt() {
		return m_updid_pty_padr_dpt;
	}
	/**
	 * @param m_updid_pty_padr_dpt the m_updid_pty_padr_dpt to set
	 */
	public void setM_updid_pty_padr_dpt(String m_updid_pty_padr_dpt) {
		this.m_updid_pty_padr_dpt = m_updid_pty_padr_dpt;
	}
	/**
	 * @return the m_updid_pty_padr_pscd
	 */
	public String getM_updid_pty_padr_pscd() {
		return m_updid_pty_padr_pscd;
	}
	/**
	 * @param m_updid_pty_padr_pscd the m_updid_pty_padr_pscd to set
	 */
	public void setM_updid_pty_padr_pscd(String m_updid_pty_padr_pscd) {
		this.m_updid_pty_padr_pscd = m_updid_pty_padr_pscd;
	}
	/**
	 * @return the m_updid_pty_padr_sbdpt
	 */
	public String getM_updid_pty_padr_sbdpt() {
		return m_updid_pty_padr_sbdpt;
	}
	/**
	 * @param m_updid_pty_padr_sbdpt the m_updid_pty_padr_sbdpt to set
	 */
	public void setM_updid_pty_padr_sbdpt(String m_updid_pty_padr_sbdpt) {
		this.m_updid_pty_padr_sbdpt = m_updid_pty_padr_sbdpt;
	}
	/**
	 * @return the m_updid_pty_padr_stnm
	 */
	public String getM_updid_pty_padr_stnm() {
		return m_updid_pty_padr_stnm;
	}
	/**
	 * @param m_updid_pty_padr_stnm the m_updid_pty_padr_stnm to set
	 */
	public void setM_updid_pty_padr_stnm(String m_updid_pty_padr_stnm) {
		this.m_updid_pty_padr_stnm = m_updid_pty_padr_stnm;
	}
	/**
	 * @return the m_updid_pty_padr_twnm
	 */
	public String getM_updid_pty_padr_twnm() {
		return m_updid_pty_padr_twnm;
	}
	/**
	 * @param m_updid_pty_padr_twnm the m_updid_pty_padr_twnm to set
	 */
	public void setM_updid_pty_padr_twnm(String m_updid_pty_padr_twnm) {
		this.m_updid_pty_padr_twnm = m_updid_pty_padr_twnm;
	}
	/**
	 * @return the m_updid_pty_padr_typ
	 */
	public String getM_updid_pty_padr_typ() {
		return m_updid_pty_padr_typ;
	}
	/**
	 * @param m_updid_pty_padr_typ the m_updid_pty_padr_typ to set
	 */
	public void setM_updid_pty_padr_typ(String m_updid_pty_padr_typ) {
		this.m_updid_pty_padr_typ = m_updid_pty_padr_typ;
	}
	/**
	 * @return the motif_rejet_annulation
	 */
	public String getMotif_rejet_annulation() {
		return motif_rejet_annulation;
	}
	/**
	 * @param motif_rejet_annulation the motif_rejet_annulation to set
	 */
	public void setMotif_rejet_annulation(String motif_rejet_annulation) {
		this.motif_rejet_annulation = motif_rejet_annulation;
	}
	/**
	 * @return the num_ics
	 */
	public String getNum_ics() {
		return num_ics;
	}
	/**
	 * @param num_ics the num_ics to set
	 */
	public void setNum_ics(String num_ics) {
		this.num_ics = num_ics;
	}
	/**
	 * @return the orggrpinf_orgnlmsgid
	 */
	public String getOrggrpinf_orgnlmsgid() {
		return orggrpinf_orgnlmsgid;
	}
	/**
	 * @param orggrpinf_orgnlmsgid the orggrpinf_orgnlmsgid to set
	 */
	public void setOrggrpinf_orgnlmsgid(String orggrpinf_orgnlmsgid) {
		this.orggrpinf_orgnlmsgid = orggrpinf_orgnlmsgid;
	}
	/**
	 * @return the orggrpinf_orgnlmsgnmid
	 */
	public String getOrggrpinf_orgnlmsgnmid() {
		return orggrpinf_orgnlmsgnmid;
	}
	/**
	 * @param orggrpinf_orgnlmsgnmid the orggrpinf_orgnlmsgnmid to set
	 */
	public void setOrggrpinf_orgnlmsgnmid(String orggrpinf_orgnlmsgnmid) {
		this.orggrpinf_orgnlmsgnmid = orggrpinf_orgnlmsgnmid;
	}
	/**
	 * @return the orgnlendtoendid
	 */
	public String getOrgnlendtoendid() {
		return orgnlendtoendid;
	}
	/**
	 * @param orgnlendtoendid the orgnlendtoendid to set
	 */
	public void setOrgnlendtoendid(String orgnlendtoendid) {
		this.orgnlendtoendid = orgnlendtoendid;
	}
	/**
	 * @return the orgnlinstrid
	 */
	public String getOrgnlinstrid() {
		return orgnlinstrid;
	}
	/**
	 * @param orgnlinstrid the orgnlinstrid to set
	 */
	public void setOrgnlinstrid(String orgnlinstrid) {
		this.orgnlinstrid = orgnlinstrid;
	}
	/**
	 * @return the orgnlintrbksttlmamt
	 */
	public BigDecimal getOrgnlintrbksttlmamt() {
		return orgnlintrbksttlmamt;
	}
	/**
	 * @param orgnlintrbksttlmamt the orgnlintrbksttlmamt to set
	 */
	public void setOrgnlintrbksttlmamt(BigDecimal orgnlintrbksttlmamt) {
		this.orgnlintrbksttlmamt = orgnlintrbksttlmamt;
	}
	/**
	 * @return the orgnlintrbksttlmamtc
	 */
	public String getOrgnlintrbksttlmamtc() {
		return orgnlintrbksttlmamtc;
	}
	/**
	 * @param orgnlintrbksttlmamtc the orgnlintrbksttlmamtc to set
	 */
	public void setOrgnlintrbksttlmamtc(String orgnlintrbksttlmamtc) {
		this.orgnlintrbksttlmamtc = orgnlintrbksttlmamtc;
	}
	/**
	 * @return the orgnltxid
	 */
	public String getOrgnltxid() {
		return orgnltxid;
	}
	/**
	 * @param orgnltxid the orgnltxid to set
	 */
	public void setOrgnltxid(String orgnltxid) {
		this.orgnltxid = orgnltxid;
	}
	/**
	 * @return the ot_crlsysref
	 */
	public String getOt_crlsysref() {
		return ot_crlsysref;
	}
	/**
	 * @param ot_crlsysref the ot_crlsysref to set
	 */
	public void setOt_crlsysref(String ot_crlsysref) {
		this.ot_crlsysref = ot_crlsysref;
	}
	/**
	 * @return the ot_endtoendid
	 */
	public String getOt_endtoendid() {
		return ot_endtoendid;
	}
	/**
	 * @param ot_endtoendid the ot_endtoendid to set
	 */
	public void setOt_endtoendid(String ot_endtoendid) {
		this.ot_endtoendid = ot_endtoendid;
	}
	/**
	 * @return the ot_first_agt_fi_bic
	 */
	public String getOt_first_agt_fi_bic() {
		return ot_first_agt_fi_bic;
	}
	/**
	 * @param ot_first_agt_fi_bic the ot_first_agt_fi_bic to set
	 */
	public void setOt_first_agt_fi_bic(String ot_first_agt_fi_bic) {
		this.ot_first_agt_fi_bic = ot_first_agt_fi_bic;
	}
	/**
	 * @return the ot_instrid
	 */
	public String getOt_instrid() {
		return ot_instrid;
	}
	/**
	 * @param ot_instrid the ot_instrid to set
	 */
	public void setOt_instrid(String ot_instrid) {
		this.ot_instrid = ot_instrid;
	}
	/**
	 * @return the ot_txid
	 */
	public String getOt_txid() {
		return ot_txid;
	}
	/**
	 * @param ot_txid the ot_txid to set
	 */
	public void setOt_txid(String ot_txid) {
		this.ot_txid = ot_txid;
	}
	/**
	 * @return the otr_csch_id_prv_othr_id
	 */
	public String getOtr_csch_id_prv_othr_id() {
		return otr_csch_id_prv_othr_id;
	}
	/**
	 * @param otr_csch_id_prv_othr_id the otr_csch_id_prv_othr_id to set
	 */
	public void setOtr_csch_id_prv_othr_id(String otr_csch_id_prv_othr_id) {
		this.otr_csch_id_prv_othr_id = otr_csch_id_prv_othr_id;
	}
	/**
	 * @return the otr_csch_id_prv_othr_issr
	 */
	public String getOtr_csch_id_prv_othr_issr() {
		return otr_csch_id_prv_othr_issr;
	}
	/**
	 * @param otr_csch_id_prv_othr_issr the otr_csch_id_prv_othr_issr to set
	 */
	public void setOtr_csch_id_prv_othr_issr(String otr_csch_id_prv_othr_issr) {
		this.otr_csch_id_prv_othr_issr = otr_csch_id_prv_othr_issr;
	}
	/**
	 * @return the otr_csch_id_prv_othr_sch_cd
	 */
	public String getOtr_csch_id_prv_othr_sch_cd() {
		return otr_csch_id_prv_othr_sch_cd;
	}
	/**
	 * @param otr_csch_id_prv_othr_sch_cd the otr_csch_id_prv_othr_sch_cd to set
	 */
	public void setOtr_csch_id_prv_othr_sch_cd(String otr_csch_id_prv_othr_sch_cd) {
		this.otr_csch_id_prv_othr_sch_cd = otr_csch_id_prv_othr_sch_cd;
	}
	/**
	 * @return the otr_csch_id_prv_othr_sch_prtr
	 */
	public String getOtr_csch_id_prv_othr_sch_prtr() {
		return otr_csch_id_prv_othr_sch_prtr;
	}
	/**
	 * @param otr_csch_id_prv_othr_sch_prtr the otr_csch_id_prv_othr_sch_prtr to set
	 */
	public void setOtr_csch_id_prv_othr_sch_prtr(String otr_csch_id_prv_othr_sch_prtr) {
		this.otr_csch_id_prv_othr_sch_prtr = otr_csch_id_prv_othr_sch_prtr;
	}
	/**
	 * @return the otr_intrbksttlmdt
	 */
	public java.sql.Date getOtr_intrbksttlmdt() {
		return otr_intrbksttlmdt;
	}
	/**
	 * @param otr_intrbksttlmdt the otr_intrbksttlmdt to set
	 */
	public void setOtr_intrbksttlmdt(java.sql.Date otr_intrbksttlmdt) {
		this.otr_intrbksttlmdt = otr_intrbksttlmdt;
	}
	/**
	 * @return the otr_reqdcolltndt
	 */
	public String getOtr_reqdcolltndt() {
		return otr_reqdcolltndt;
	}
	/**
	 * @param otr_reqdcolltndt the otr_reqdcolltndt to set
	 */
	public void setOtr_reqdcolltndt(String otr_reqdcolltndt) {
		this.otr_reqdcolltndt = otr_reqdcolltndt;
	}
	/**
	 * @return the otr_stti_clrs_cd
	 */
	public String getOtr_stti_clrs_cd() {
		return otr_stti_clrs_cd;
	}
	/**
	 * @param otr_stti_clrs_cd the otr_stti_clrs_cd to set
	 */
	public void setOtr_stti_clrs_cd(String otr_stti_clrs_cd) {
		this.otr_stti_clrs_cd = otr_stti_clrs_cd;
	}
	/**
	 * @return the otr_stti_clrs_prtry
	 */
	public String getOtr_stti_clrs_prtry() {
		return otr_stti_clrs_prtry;
	}
	/**
	 * @param otr_stti_clrs_prtry the otr_stti_clrs_prtry to set
	 */
	public void setOtr_stti_clrs_prtry(String otr_stti_clrs_prtry) {
		this.otr_stti_clrs_prtry = otr_stti_clrs_prtry;
	}
	/**
	 * @return the otr_stti_sttaid_iban
	 */
	public String getOtr_stti_sttaid_iban() {
		return otr_stti_sttaid_iban;
	}
	/**
	 * @param otr_stti_sttaid_iban the otr_stti_sttaid_iban to set
	 */
	public void setOtr_stti_sttaid_iban(String otr_stti_sttaid_iban) {
		this.otr_stti_sttaid_iban = otr_stti_sttaid_iban;
	}
	/**
	 * @return the otr_stti_sttaid_o_id
	 */
	public String getOtr_stti_sttaid_o_id() {
		return otr_stti_sttaid_o_id;
	}
	/**
	 * @param otr_stti_sttaid_o_id the otr_stti_sttaid_o_id to set
	 */
	public void setOtr_stti_sttaid_o_id(String otr_stti_sttaid_o_id) {
		this.otr_stti_sttaid_o_id = otr_stti_sttaid_o_id;
	}
	/**
	 * @return the otr_stti_sttaid_o_issr
	 */
	public String getOtr_stti_sttaid_o_issr() {
		return otr_stti_sttaid_o_issr;
	}
	/**
	 * @param otr_stti_sttaid_o_issr the otr_stti_sttaid_o_issr to set
	 */
	public void setOtr_stti_sttaid_o_issr(String otr_stti_sttaid_o_issr) {
		this.otr_stti_sttaid_o_issr = otr_stti_sttaid_o_issr;
	}
	/**
	 * @return the otr_stti_sttaid_o_sn_cd
	 */
	public String getOtr_stti_sttaid_o_sn_cd() {
		return otr_stti_sttaid_o_sn_cd;
	}
	/**
	 * @param otr_stti_sttaid_o_sn_cd the otr_stti_sttaid_o_sn_cd to set
	 */
	public void setOtr_stti_sttaid_o_sn_cd(String otr_stti_sttaid_o_sn_cd) {
		this.otr_stti_sttaid_o_sn_cd = otr_stti_sttaid_o_sn_cd;
	}
	/**
	 * @return the otr_stti_sttaid_o_sn_prtr
	 */
	public String getOtr_stti_sttaid_o_sn_prtr() {
		return otr_stti_sttaid_o_sn_prtr;
	}
	/**
	 * @param otr_stti_sttaid_o_sn_prtr the otr_stti_sttaid_o_sn_prtr to set
	 */
	public void setOtr_stti_sttaid_o_sn_prtr(String otr_stti_sttaid_o_sn_prtr) {
		this.otr_stti_sttaid_o_sn_prtr = otr_stti_sttaid_o_sn_prtr;
	}
	/**
	 * @return the otr_stti_sttlmmtd
	 */
	public String getOtr_stti_sttlmmtd() {
		return otr_stti_sttlmmtd;
	}
	/**
	 * @param otr_stti_sttlmmtd the otr_stti_sttlmmtd to set
	 */
	public void setOtr_stti_sttlmmtd(String otr_stti_sttlmmtd) {
		this.otr_stti_sttlmmtd = otr_stti_sttlmmtd;
	}
	/**
	 * @return the pmtid_endtoendid
	 */
	public String getPmtid_endtoendid() {
		return pmtid_endtoendid;
	}
	/**
	 * @param pmtid_endtoendid the pmtid_endtoendid to set
	 */
	public void setPmtid_endtoendid(String pmtid_endtoendid) {
		this.pmtid_endtoendid = pmtid_endtoendid;
	}
	/**
	 * @return the pmtid_instrid
	 */
	public String getPmtid_instrid() {
		return pmtid_instrid;
	}
	/**
	 * @param pmtid_instrid the pmtid_instrid to set
	 */
	public void setPmtid_instrid(String pmtid_instrid) {
		this.pmtid_instrid = pmtid_instrid;
	}
	/**
	 * @return the pmtid_txid
	 */
	public String getPmtid_txid() {
		return pmtid_txid;
	}
	/**
	 * @param pmtid_txid the pmtid_txid to set
	 */
	public void setPmtid_txid(String pmtid_txid) {
		this.pmtid_txid = pmtid_txid;
	}
	/**
	 * @return the pmttpi_ctgypurp
	 */
	public String getPmttpi_ctgypurp() {
		return pmttpi_ctgypurp;
	}
	/**
	 * @param pmttpi_ctgypurp the pmttpi_ctgypurp to set
	 */
	public void setPmttpi_ctgypurp(String pmttpi_ctgypurp) {
		this.pmttpi_ctgypurp = pmttpi_ctgypurp;
	}
	/**
	 * @return the pmttpi_ctgypurp_pr
	 */
	public String getPmttpi_ctgypurp_pr() {
		return pmttpi_ctgypurp_pr;
	}
	/**
	 * @param pmttpi_ctgypurp_pr the pmttpi_ctgypurp_pr to set
	 */
	public void setPmttpi_ctgypurp_pr(String pmttpi_ctgypurp_pr) {
		this.pmttpi_ctgypurp_pr = pmttpi_ctgypurp_pr;
	}
	/**
	 * @return the pmttpi_lclins_cd
	 */
	public String getPmttpi_lclins_cd() {
		return pmttpi_lclins_cd;
	}
	/**
	 * @param pmttpi_lclins_cd the pmttpi_lclins_cd to set
	 */
	public void setPmttpi_lclins_cd(String pmttpi_lclins_cd) {
		this.pmttpi_lclins_cd = pmttpi_lclins_cd;
	}
	/**
	 * @return the pmttpi_seqtp
	 */
	public String getPmttpi_seqtp() {
		return pmttpi_seqtp;
	}
	/**
	 * @param pmttpi_seqtp the pmttpi_seqtp to set
	 */
	public void setPmttpi_seqtp(String pmttpi_seqtp) {
		this.pmttpi_seqtp = pmttpi_seqtp;
	}
	/**
	 * @return the pmttpi_svclvl_cd
	 */
	public String getPmttpi_svclvl_cd() {
		return pmttpi_svclvl_cd;
	}
	/**
	 * @param pmttpi_svclvl_cd the pmttpi_svclvl_cd to set
	 */
	public void setPmttpi_svclvl_cd(String pmttpi_svclvl_cd) {
		this.pmttpi_svclvl_cd = pmttpi_svclvl_cd;
	}
	/**
	 * @return the pmttpilclins_prtry
	 */
	public String getPmttpilclins_prtry() {
		return pmttpilclins_prtry;
	}
	/**
	 * @param pmttpilclins_prtry the pmttpilclins_prtry to set
	 */
	public void setPmttpilclins_prtry(String pmttpilclins_prtry) {
		this.pmttpilclins_prtry = pmttpilclins_prtry;
	}
	/**
	 * @return the pur_cd
	 */
	public String getPur_cd() {
		return pur_cd;
	}
	/**
	 * @param pur_cd the pur_cd to set
	 */
	public void setPur_cd(String pur_cd) {
		this.pur_cd = pur_cd;
	}
	/**
	 * @return the reqdcolltndt
	 */
	public java.sql.Date getReqdcolltndt() {
		return reqdcolltndt;
	}
	/**
	 * @param reqdcolltndt the reqdcolltndt to set
	 */
	public void setReqdcolltndt(java.sql.Date reqdcolltndt) {
		this.reqdcolltndt = reqdcolltndt;
	}
	/**
	 * @return the ri_addtlinf1
	 */
	public String getRi_addtlinf1() {
		return ri_addtlinf1;
	}
	/**
	 * @param ri_addtlinf1 the ri_addtlinf1 to set
	 */
	public void setRi_addtlinf1(String ri_addtlinf1) {
		this.ri_addtlinf1 = ri_addtlinf1;
	}
	/**
	 * @return the ri_addtlinf2
	 */
	public String getRi_addtlinf2() {
		return ri_addtlinf2;
	}
	/**
	 * @param ri_addtlinf2 the ri_addtlinf2 to set
	 */
	public void setRi_addtlinf2(String ri_addtlinf2) {
		this.ri_addtlinf2 = ri_addtlinf2;
	}
	/**
	 * @return the ri_rorg_id_org_bic_bei
	 */
	public String getRi_rorg_id_org_bic_bei() {
		return ri_rorg_id_org_bic_bei;
	}
	/**
	 * @param ri_rorg_id_org_bic_bei the ri_rorg_id_org_bic_bei to set
	 */
	public void setRi_rorg_id_org_bic_bei(String ri_rorg_id_org_bic_bei) {
		this.ri_rorg_id_org_bic_bei = ri_rorg_id_org_bic_bei;
	}
	/**
	 * @return the ri_rorg_id_org_othr_id
	 */
	public String getRi_rorg_id_org_othr_id() {
		return ri_rorg_id_org_othr_id;
	}
	/**
	 * @param ri_rorg_id_org_othr_id the ri_rorg_id_org_othr_id to set
	 */
	public void setRi_rorg_id_org_othr_id(String ri_rorg_id_org_othr_id) {
		this.ri_rorg_id_org_othr_id = ri_rorg_id_org_othr_id;
	}
	/**
	 * @return the ri_rorg_id_org_othr_issr
	 */
	public String getRi_rorg_id_org_othr_issr() {
		return ri_rorg_id_org_othr_issr;
	}
	/**
	 * @param ri_rorg_id_org_othr_issr the ri_rorg_id_org_othr_issr to set
	 */
	public void setRi_rorg_id_org_othr_issr(String ri_rorg_id_org_othr_issr) {
		this.ri_rorg_id_org_othr_issr = ri_rorg_id_org_othr_issr;
	}
	/**
	 * @return the ri_rorg_id_org_othr_sch_cd
	 */
	public String getRi_rorg_id_org_othr_sch_cd() {
		return ri_rorg_id_org_othr_sch_cd;
	}
	/**
	 * @param ri_rorg_id_org_othr_sch_cd the ri_rorg_id_org_othr_sch_cd to set
	 */
	public void setRi_rorg_id_org_othr_sch_cd(String ri_rorg_id_org_othr_sch_cd) {
		this.ri_rorg_id_org_othr_sch_cd = ri_rorg_id_org_othr_sch_cd;
	}
	/**
	 * @return the ri_rorg_id_org_othr_sch_prtr
	 */
	public String getRi_rorg_id_org_othr_sch_prtr() {
		return ri_rorg_id_org_othr_sch_prtr;
	}
	/**
	 * @param ri_rorg_id_org_othr_sch_prtr the ri_rorg_id_org_othr_sch_prtr to set
	 */
	public void setRi_rorg_id_org_othr_sch_prtr(String ri_rorg_id_org_othr_sch_prtr) {
		this.ri_rorg_id_org_othr_sch_prtr = ri_rorg_id_org_othr_sch_prtr;
	}
	/**
	 * @return the ri_rorg_id_prv_dpbi_cry
	 */
	public String getRi_rorg_id_prv_dpbi_cry() {
		return ri_rorg_id_prv_dpbi_cry;
	}
	/**
	 * @param ri_rorg_id_prv_dpbi_cry the ri_rorg_id_prv_dpbi_cry to set
	 */
	public void setRi_rorg_id_prv_dpbi_cry(String ri_rorg_id_prv_dpbi_cry) {
		this.ri_rorg_id_prv_dpbi_cry = ri_rorg_id_prv_dpbi_cry;
	}
	/**
	 * @return the ri_rorg_id_prv_dpbi_cty
	 */
	public String getRi_rorg_id_prv_dpbi_cty() {
		return ri_rorg_id_prv_dpbi_cty;
	}
	/**
	 * @param ri_rorg_id_prv_dpbi_cty the ri_rorg_id_prv_dpbi_cty to set
	 */
	public void setRi_rorg_id_prv_dpbi_cty(String ri_rorg_id_prv_dpbi_cty) {
		this.ri_rorg_id_prv_dpbi_cty = ri_rorg_id_prv_dpbi_cty;
	}
	/**
	 * @return the ri_rorg_id_prv_dpbi_dat
	 */
	public java.sql.Date getRi_rorg_id_prv_dpbi_dat() {
		return ri_rorg_id_prv_dpbi_dat;
	}
	/**
	 * @param ri_rorg_id_prv_dpbi_dat the ri_rorg_id_prv_dpbi_dat to set
	 */
	public void setRi_rorg_id_prv_dpbi_dat(java.sql.Date ri_rorg_id_prv_dpbi_dat) {
		this.ri_rorg_id_prv_dpbi_dat = ri_rorg_id_prv_dpbi_dat;
	}
	/**
	 * @return the ri_rorg_id_prv_dpbi_prv
	 */
	public String getRi_rorg_id_prv_dpbi_prv() {
		return ri_rorg_id_prv_dpbi_prv;
	}
	/**
	 * @param ri_rorg_id_prv_dpbi_prv the ri_rorg_id_prv_dpbi_prv to set
	 */
	public void setRi_rorg_id_prv_dpbi_prv(String ri_rorg_id_prv_dpbi_prv) {
		this.ri_rorg_id_prv_dpbi_prv = ri_rorg_id_prv_dpbi_prv;
	}
	/**
	 * @return the ri_rorg_id_prv_othr_id
	 */
	public String getRi_rorg_id_prv_othr_id() {
		return ri_rorg_id_prv_othr_id;
	}
	/**
	 * @param ri_rorg_id_prv_othr_id the ri_rorg_id_prv_othr_id to set
	 */
	public void setRi_rorg_id_prv_othr_id(String ri_rorg_id_prv_othr_id) {
		this.ri_rorg_id_prv_othr_id = ri_rorg_id_prv_othr_id;
	}
	/**
	 * @return the ri_rorg_id_prv_othr_issr
	 */
	public String getRi_rorg_id_prv_othr_issr() {
		return ri_rorg_id_prv_othr_issr;
	}
	/**
	 * @param ri_rorg_id_prv_othr_issr the ri_rorg_id_prv_othr_issr to set
	 */
	public void setRi_rorg_id_prv_othr_issr(String ri_rorg_id_prv_othr_issr) {
		this.ri_rorg_id_prv_othr_issr = ri_rorg_id_prv_othr_issr;
	}
	/**
	 * @return the ri_rorg_id_prv_othr_sch_cd
	 */
	public String getRi_rorg_id_prv_othr_sch_cd() {
		return ri_rorg_id_prv_othr_sch_cd;
	}
	/**
	 * @param ri_rorg_id_prv_othr_sch_cd the ri_rorg_id_prv_othr_sch_cd to set
	 */
	public void setRi_rorg_id_prv_othr_sch_cd(String ri_rorg_id_prv_othr_sch_cd) {
		this.ri_rorg_id_prv_othr_sch_cd = ri_rorg_id_prv_othr_sch_cd;
	}
	/**
	 * @return the ri_rorg_id_prv_othr_sch_prtr
	 */
	public String getRi_rorg_id_prv_othr_sch_prtr() {
		return ri_rorg_id_prv_othr_sch_prtr;
	}
	/**
	 * @param ri_rorg_id_prv_othr_sch_prtr the ri_rorg_id_prv_othr_sch_prtr to set
	 */
	public void setRi_rorg_id_prv_othr_sch_prtr(String ri_rorg_id_prv_othr_sch_prtr) {
		this.ri_rorg_id_prv_othr_sch_prtr = ri_rorg_id_prv_othr_sch_prtr;
	}
	/**
	 * @return the ri_rorg_name
	 */
	public String getRi_rorg_name() {
		return ri_rorg_name;
	}
	/**
	 * @param ri_rorg_name the ri_rorg_name to set
	 */
	public void setRi_rorg_name(String ri_rorg_name) {
		this.ri_rorg_name = ri_rorg_name;
	}
	/**
	 * @return the ri_rorg_padr_adrline
	 */
	public String getRi_rorg_padr_adrline() {
		return ri_rorg_padr_adrline;
	}
	/**
	 * @param ri_rorg_padr_adrline the ri_rorg_padr_adrline to set
	 */
	public void setRi_rorg_padr_adrline(String ri_rorg_padr_adrline) {
		this.ri_rorg_padr_adrline = ri_rorg_padr_adrline;
	}
	/**
	 * @return the ri_rorg_padr_ctry
	 */
	public String getRi_rorg_padr_ctry() {
		return ri_rorg_padr_ctry;
	}
	/**
	 * @param ri_rorg_padr_ctry the ri_rorg_padr_ctry to set
	 */
	public void setRi_rorg_padr_ctry(String ri_rorg_padr_ctry) {
		this.ri_rorg_padr_ctry = ri_rorg_padr_ctry;
	}
	/**
	 * @return the ri_rsn_cd
	 */
	public String getRi_rsn_cd() {
		return ri_rsn_cd;
	}
	/**
	 * @param ri_rsn_cd the ri_rsn_cd to set
	 */
	public void setRi_rsn_cd(String ri_rsn_cd) {
		this.ri_rsn_cd = ri_rsn_cd;
	}
	/**
	 * @return the ri_sn_prtry
	 */
	public String getRi_sn_prtry() {
		return ri_sn_prtry;
	}
	/**
	 * @param ri_sn_prtry the ri_sn_prtry to set
	 */
	public void setRi_sn_prtry(String ri_sn_prtry) {
		this.ri_sn_prtry = ri_sn_prtry;
	}
	/**
	 * @return the rmtinf_strd_type_code
	 */
	public String getRmtinf_strd_type_code() {
		return rmtinf_strd_type_code;
	}
	/**
	 * @param rmtinf_strd_type_code the rmtinf_strd_type_code to set
	 */
	public void setRmtinf_strd_type_code(String rmtinf_strd_type_code) {
		this.rmtinf_strd_type_code = rmtinf_strd_type_code;
	}
	/**
	 * @return the rmtinf_strd_type_is
	 */
	public String getRmtinf_strd_type_is() {
		return rmtinf_strd_type_is;
	}
	/**
	 * @param rmtinf_strd_type_is the rmtinf_strd_type_is to set
	 */
	public void setRmtinf_strd_type_is(String rmtinf_strd_type_is) {
		this.rmtinf_strd_type_is = rmtinf_strd_type_is;
	}
	/**
	 * @return the rmtinf_strd_type_ref
	 */
	public String getRmtinf_strd_type_ref() {
		return rmtinf_strd_type_ref;
	}
	/**
	 * @param rmtinf_strd_type_ref the rmtinf_strd_type_ref to set
	 */
	public void setRmtinf_strd_type_ref(String rmtinf_strd_type_ref) {
		this.rmtinf_strd_type_ref = rmtinf_strd_type_ref;
	}
	/**
	 * @return the rmtinf_ustrd
	 */
	public String getRmtinf_ustrd() {
		return rmtinf_ustrd;
	}
	/**
	 * @param rmtinf_ustrd the rmtinf_ustrd to set
	 */
	public void setRmtinf_ustrd(String rmtinf_ustrd) {
		this.rmtinf_ustrd = rmtinf_ustrd;
	}
	/**
	 * @return the sup_chemin
	 */
	public String getSup_chemin() {
		return sup_chemin;
	}
	/**
	 * @param sup_chemin the sup_chemin to set
	 */
	public void setSup_chemin(String sup_chemin) {
		this.sup_chemin = sup_chemin;
	}
	/**
	 * @return the txsts
	 */
	public String getTxsts() {
		return txsts;
	}
	/**
	 * @param txsts the txsts to set
	 */
	public void setTxsts(String txsts) {
		this.txsts = txsts;
	}
	/**
	 * @return the ucdt_id_org_bic_bei
	 */
	public String getUcdt_id_org_bic_bei() {
		return ucdt_id_org_bic_bei;
	}
	/**
	 * @param ucdt_id_org_bic_bei the ucdt_id_org_bic_bei to set
	 */
	public void setUcdt_id_org_bic_bei(String ucdt_id_org_bic_bei) {
		this.ucdt_id_org_bic_bei = ucdt_id_org_bic_bei;
	}
	/**
	 * @return the ucdt_id_org_othr_id
	 */
	public String getUcdt_id_org_othr_id() {
		return ucdt_id_org_othr_id;
	}
	/**
	 * @param ucdt_id_org_othr_id the ucdt_id_org_othr_id to set
	 */
	public void setUcdt_id_org_othr_id(String ucdt_id_org_othr_id) {
		this.ucdt_id_org_othr_id = ucdt_id_org_othr_id;
	}
	/**
	 * @return the ucdt_id_org_othr_issr
	 */
	public String getUcdt_id_org_othr_issr() {
		return ucdt_id_org_othr_issr;
	}
	/**
	 * @param ucdt_id_org_othr_issr the ucdt_id_org_othr_issr to set
	 */
	public void setUcdt_id_org_othr_issr(String ucdt_id_org_othr_issr) {
		this.ucdt_id_org_othr_issr = ucdt_id_org_othr_issr;
	}
	/**
	 * @return the ucdt_id_org_othr_sch_cd
	 */
	public String getUcdt_id_org_othr_sch_cd() {
		return ucdt_id_org_othr_sch_cd;
	}
	/**
	 * @param ucdt_id_org_othr_sch_cd the ucdt_id_org_othr_sch_cd to set
	 */
	public void setUcdt_id_org_othr_sch_cd(String ucdt_id_org_othr_sch_cd) {
		this.ucdt_id_org_othr_sch_cd = ucdt_id_org_othr_sch_cd;
	}
	/**
	 * @return the ucdt_id_org_othr_sch_prtry
	 */
	public String getUcdt_id_org_othr_sch_prtry() {
		return ucdt_id_org_othr_sch_prtry;
	}
	/**
	 * @param ucdt_id_org_othr_sch_prtry the ucdt_id_org_othr_sch_prtry to set
	 */
	public void setUcdt_id_org_othr_sch_prtry(String ucdt_id_org_othr_sch_prtry) {
		this.ucdt_id_org_othr_sch_prtry = ucdt_id_org_othr_sch_prtry;
	}
	/**
	 * @return the ucdt_id_pr_dpbi_cr
	 */
	public String getUcdt_id_pr_dpbi_cr() {
		return ucdt_id_pr_dpbi_cr;
	}
	/**
	 * @param ucdt_id_pr_dpbi_cr the ucdt_id_pr_dpbi_cr to set
	 */
	public void setUcdt_id_pr_dpbi_cr(String ucdt_id_pr_dpbi_cr) {
		this.ucdt_id_pr_dpbi_cr = ucdt_id_pr_dpbi_cr;
	}
	/**
	 * @return the ucdt_id_pr_dpbi_ct
	 */
	public String getUcdt_id_pr_dpbi_ct() {
		return ucdt_id_pr_dpbi_ct;
	}
	/**
	 * @param ucdt_id_pr_dpbi_ct the ucdt_id_pr_dpbi_ct to set
	 */
	public void setUcdt_id_pr_dpbi_ct(String ucdt_id_pr_dpbi_ct) {
		this.ucdt_id_pr_dpbi_ct = ucdt_id_pr_dpbi_ct;
	}
	/**
	 * @return the ucdt_id_pr_dpbi_da
	 */
	public java.sql.Date getUcdt_id_pr_dpbi_da() {
		return ucdt_id_pr_dpbi_da;
	}
	/**
	 * @param ucdt_id_pr_dpbi_da the ucdt_id_pr_dpbi_da to set
	 */
	public void setUcdt_id_pr_dpbi_da(java.sql.Date ucdt_id_pr_dpbi_da) {
		this.ucdt_id_pr_dpbi_da = ucdt_id_pr_dpbi_da;
	}
	/**
	 * @return the ucdt_id_pr_dpbi_prv
	 */
	public String getUcdt_id_pr_dpbi_prv() {
		return ucdt_id_pr_dpbi_prv;
	}
	/**
	 * @param ucdt_id_pr_dpbi_prv the ucdt_id_pr_dpbi_prv to set
	 */
	public void setUcdt_id_pr_dpbi_prv(String ucdt_id_pr_dpbi_prv) {
		this.ucdt_id_pr_dpbi_prv = ucdt_id_pr_dpbi_prv;
	}
	/**
	 * @return the ucdt_id_prv_othr_id
	 */
	public String getUcdt_id_prv_othr_id() {
		return ucdt_id_prv_othr_id;
	}
	/**
	 * @param ucdt_id_prv_othr_id the ucdt_id_prv_othr_id to set
	 */
	public void setUcdt_id_prv_othr_id(String ucdt_id_prv_othr_id) {
		this.ucdt_id_prv_othr_id = ucdt_id_prv_othr_id;
	}
	/**
	 * @return the ucdt_id_prv_othr_issr
	 */
	public String getUcdt_id_prv_othr_issr() {
		return ucdt_id_prv_othr_issr;
	}
	/**
	 * @param ucdt_id_prv_othr_issr the ucdt_id_prv_othr_issr to set
	 */
	public void setUcdt_id_prv_othr_issr(String ucdt_id_prv_othr_issr) {
		this.ucdt_id_prv_othr_issr = ucdt_id_prv_othr_issr;
	}
	/**
	 * @return the ucdt_id_prv_othr_sch_cd
	 */
	public String getUcdt_id_prv_othr_sch_cd() {
		return ucdt_id_prv_othr_sch_cd;
	}
	/**
	 * @param ucdt_id_prv_othr_sch_cd the ucdt_id_prv_othr_sch_cd to set
	 */
	public void setUcdt_id_prv_othr_sch_cd(String ucdt_id_prv_othr_sch_cd) {
		this.ucdt_id_prv_othr_sch_cd = ucdt_id_prv_othr_sch_cd;
	}
	/**
	 * @return the ucdt_id_prv_othr_sch_prtr
	 */
	public String getUcdt_id_prv_othr_sch_prtr() {
		return ucdt_id_prv_othr_sch_prtr;
	}
	/**
	 * @param ucdt_id_prv_othr_sch_prtr the ucdt_id_prv_othr_sch_prtr to set
	 */
	public void setUcdt_id_prv_othr_sch_prtr(String ucdt_id_prv_othr_sch_prtr) {
		this.ucdt_id_prv_othr_sch_prtr = ucdt_id_prv_othr_sch_prtr;
	}
	/**
	 * @return the ucdt_name
	 */
	public String getUcdt_name() {
		return ucdt_name;
	}
	/**
	 * @param ucdt_name the ucdt_name to set
	 */
	public void setUcdt_name(String ucdt_name) {
		this.ucdt_name = ucdt_name;
	}
	/**
	 * @return the udbt_id_org_bic_bei
	 */
	public String getUdbt_id_org_bic_bei() {
		return udbt_id_org_bic_bei;
	}
	/**
	 * @param udbt_id_org_bic_bei the udbt_id_org_bic_bei to set
	 */
	public void setUdbt_id_org_bic_bei(String udbt_id_org_bic_bei) {
		this.udbt_id_org_bic_bei = udbt_id_org_bic_bei;
	}
	/**
	 * @return the udbt_id_org_othr_id
	 */
	public String getUdbt_id_org_othr_id() {
		return udbt_id_org_othr_id;
	}
	/**
	 * @param udbt_id_org_othr_id the udbt_id_org_othr_id to set
	 */
	public void setUdbt_id_org_othr_id(String udbt_id_org_othr_id) {
		this.udbt_id_org_othr_id = udbt_id_org_othr_id;
	}
	/**
	 * @return the udbt_id_org_othr_sch_cd
	 */
	public String getUdbt_id_org_othr_sch_cd() {
		return udbt_id_org_othr_sch_cd;
	}

	/**
	 * @param udbt_id_org_othr_sch_cd the udbt_id_org_othr_sch_cd to set
	 */
	public void setUdbt_id_org_othr_sch_cd(String udbt_id_org_othr_sch_cd) {
		this.udbt_id_org_othr_sch_cd = udbt_id_org_othr_sch_cd;
	}
	/**
	 * @return the udbt_id_org_othr_sch_issr
	 */
	public String getUdbt_id_org_othr_sch_issr() {
		return udbt_id_org_othr_sch_issr;
	}
	/**
	 * @param udbt_id_org_othr_sch_issr the udbt_id_org_othr_sch_issr to set
	 */
	public void setUdbt_id_org_othr_sch_issr(String udbt_id_org_othr_sch_issr) {
		this.udbt_id_org_othr_sch_issr = udbt_id_org_othr_sch_issr;
	}
	/**
	 * @return the udbt_id_org_othr_sch_prtr
	 */
	public String getUdbt_id_org_othr_sch_prtr() {
		return udbt_id_org_othr_sch_prtr;
	}
	/**
	 * @param udbt_id_org_othr_sch_prtr the udbt_id_org_othr_sch_prtr to set
	 */
	public void setUdbt_id_org_othr_sch_prtr(String udbt_id_org_othr_sch_prtr) {
		this.udbt_id_org_othr_sch_prtr = udbt_id_org_othr_sch_prtr;
	}
	/**
	 * @return the udbt_id_pr_dpbi_cry
	 */
	public String getUdbt_id_pr_dpbi_cry() {
		return udbt_id_pr_dpbi_cry;
	}
	/**
	 * @param udbt_id_pr_dpbi_cry the udbt_id_pr_dpbi_cry to set
	 */
	public void setUdbt_id_pr_dpbi_cry(String udbt_id_pr_dpbi_cry) {
		this.udbt_id_pr_dpbi_cry = udbt_id_pr_dpbi_cry;
	}
	/**
	 * @return the udbt_id_pr_dpbi_cty
	 */
	public String getUdbt_id_pr_dpbi_cty() {
		return udbt_id_pr_dpbi_cty;
	}
	/**
	 * @param udbt_id_pr_dpbi_cty the udbt_id_pr_dpbi_cty to set
	 */
	public void setUdbt_id_pr_dpbi_cty(String udbt_id_pr_dpbi_cty) {
		this.udbt_id_pr_dpbi_cty = udbt_id_pr_dpbi_cty;
	}
	/**
	 * @return the udbt_id_pr_dpbi_dat
	 */
	public java.sql.Date getUdbt_id_pr_dpbi_dat() {
		return udbt_id_pr_dpbi_dat;
	}
	/**
	 * @param udbt_id_pr_dpbi_dat the udbt_id_pr_dpbi_dat to set
	 */
	public void setUdbt_id_pr_dpbi_dat(java.sql.Date udbt_id_pr_dpbi_dat) {
		this.udbt_id_pr_dpbi_dat = udbt_id_pr_dpbi_dat;
	}
	/**
	 * @return the udbt_id_pr_dpbi_prv
	 */
	public String getUdbt_id_pr_dpbi_prv() {
		return udbt_id_pr_dpbi_prv;
	}
	/**
	 * @param udbt_id_pr_dpbi_prv the udbt_id_pr_dpbi_prv to set
	 */
	public void setUdbt_id_pr_dpbi_prv(String udbt_id_pr_dpbi_prv) {
		this.udbt_id_pr_dpbi_prv = udbt_id_pr_dpbi_prv;
	}
	/**
	 * @return the udbt_id_prv_othr_id
	 */
	public String getUdbt_id_prv_othr_id() {
		return udbt_id_prv_othr_id;
	}
	/**
	 * @param udbt_id_prv_othr_id the udbt_id_prv_othr_id to set
	 */
	public void setUdbt_id_prv_othr_id(String udbt_id_prv_othr_id) {
		this.udbt_id_prv_othr_id = udbt_id_prv_othr_id;
	}
	/**
	 * @return the udbt_id_prv_othr_issr
	 */
	public String getUdbt_id_prv_othr_issr() {
		return udbt_id_prv_othr_issr;
	}
	/**
	 * @param udbt_id_prv_othr_issr the udbt_id_prv_othr_issr to set
	 */
	public void setUdbt_id_prv_othr_issr(String udbt_id_prv_othr_issr) {
		this.udbt_id_prv_othr_issr = udbt_id_prv_othr_issr;
	}
	/**
	 * @return the udbt_id_prv_othr_sch_cd
	 */
	public String getUdbt_id_prv_othr_sch_cd() {
		return udbt_id_prv_othr_sch_cd;
	}
	/**
	 * @param udbt_id_prv_othr_sch_cd the udbt_id_prv_othr_sch_cd to set
	 */
	public void setUdbt_id_prv_othr_sch_cd(String udbt_id_prv_othr_sch_cd) {
		this.udbt_id_prv_othr_sch_cd = udbt_id_prv_othr_sch_cd;
	}
	/**
	 * @return the udbt_id_prv_othr_sch_prtr
	 */
	public String getUdbt_id_prv_othr_sch_prtr() {
		return udbt_id_prv_othr_sch_prtr;
	}
	/**
	 * @param udbt_id_prv_othr_sch_prtr the udbt_id_prv_othr_sch_prtr to set
	 */
	public void setUdbt_id_prv_othr_sch_prtr(String udbt_id_prv_othr_sch_prtr) {
		this.udbt_id_prv_othr_sch_prtr = udbt_id_prv_othr_sch_prtr;
	}
	/**
	 * @return the udbt_name
	 */
	public String getUdbt_name() {
		return udbt_name;
	}
	/**
	 * @param udbt_name the udbt_name to set
	 */
	public void setUdbt_name(String udbt_name) {
		this.udbt_name = udbt_name;
	}
	
	/**
	 * @param udbt_name the udbt_name to set
	 */
	public void setFlag_evolmpm_maeva(String flag_evolmpm_maeva) {
		this.flag_evolmpm_maeva = flag_evolmpm_maeva;
	}
	
	/**
	 * @return the id_traitement
	 */
	public String getId_traitement() {
		return id_traitement;
	}
	/**
	 * @param id_traitement the id_traitement to set
	 */
	public void setId_traitement(String id_traitement) {
		this.id_traitement = id_traitement;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OperationSepaBean [bic_id_beneficiaire_sr=" + bic_id_beneficiaire_sr + ", bic_id_creditor_sr="
				+ bic_id_creditor_sr + ", bic_id_debitor_sr=" + bic_id_debitor_sr + ", bic_id_do_sr=" + bic_id_do_sr
				+ ", cle_iban_beneficiaire_sr=" + cle_iban_beneficiaire_sr + ", cle_iban_creditor_sr="
				+ cle_iban_creditor_sr + ", cle_iban_debitor_sr=" + cle_iban_debitor_sr + ", cle_iban_do_sr="
				+ cle_iban_do_sr + ", code_banque_beneficiaire_sr=" + code_banque_beneficiaire_sr
				+ ", code_banque_creditor_sr=" + code_banque_creditor_sr + ", code_banque_debitor_sr="
				+ code_banque_debitor_sr + ", code_banque_do_sr=" + code_banque_do_sr + ", code_client_conventionne="
				+ code_client_conventionne + ", code_famille_operation=" + code_famille_operation + ", code_flux_arch="
				+ code_flux_arch + ", code_grp_remettant=" + code_grp_remettant + ", code_guichet_beneficiaire_sr="
				+ code_guichet_beneficiaire_sr + ", code_guichet_creditor_sr=" + code_guichet_creditor_sr
				+ ", code_guichet_debitor_sr=" + code_guichet_debitor_sr + ", code_guichet_do_sr=" + code_guichet_do_sr
				+ ", code_operation=" + code_operation + ", code_pays_beneficiaire_sr=" + code_pays_beneficiaire_sr
				+ ", code_pays_creditor_sr=" + code_pays_creditor_sr + ", code_pays_debitor_sr=" + code_pays_debitor_sr
				+ ", code_pays_do_sr=" + code_pays_do_sr + ", date_comptable_evolmpm=" + date_comptable_evolmpm
				+ ", date_echange=" + date_echange + ", date_pec_amont=" + date_pec_amont
				+ ", date_presentation_remise=" + date_presentation_remise + ", date_reglement=" + date_reglement
				+ ", date_traitement_aval_recu=" + date_traitement_aval_recu + ", delai_reglement=" + delai_reglement
				+ ", etblt_concerne=" + etblt_concerne + ", flag_debrayage_embargo=" + flag_debrayage_embargo
				+ ", heure_pec_amont=" + heure_pec_amont + ", heure_presentation_remise=" + heure_presentation_remise
				+ ", iban_beneficiaire_sr=" + iban_beneficiaire_sr + ", iban_creditor_sr=" + iban_creditor_sr
				+ ", iban_debitor_sr=" + iban_debitor_sr + ", iban_do_sr=" + iban_do_sr + ", id_client=" + id_client
				+ ", id_client_beneficiaire_sr=" + id_client_beneficiaire_sr + ", id_client_do_sr=" + id_client_do_sr
				+ ", id_compte_beneficiaire_sr=" + id_compte_beneficiaire_sr + ", id_compte_do_sr=" + id_compte_do_sr
				+ ", id_ics=" + id_ics + ", id_operation=" + id_operation + ", id_systeme_echange=" + id_systeme_echange
				+ ", id_type_operation=" + id_type_operation + ", ind_rejet=" + ind_rejet + ", lib_grp_remettant="
				+ lib_grp_remettant + ", mnt_compense_sit=" + mnt_compense_sit + ", num_cpte_beneficiaire_sr="
				+ num_cpte_beneficiaire_sr + ", num_cpte_creditor_sr=" + num_cpte_creditor_sr + ", num_cpte_debitor_sr="
				+ num_cpte_debitor_sr + ", num_cpte_do_sr=" + num_cpte_do_sr + ", num_partition=" + num_partition
				+ ", num_remise=" + num_remise + ", num_remise_tech=" + num_remise_tech + ", orgnlendtoendid_src="
				+ orgnlendtoendid_src + ", orgnlinstrid_src=" + orgnlinstrid_src + ", orgnltxid_src=" + orgnltxid_src
				+ ", pmtid_txid_src=" + pmtid_txid_src + ", ref_operation_origine=" + ref_operation_origine + ", rio="
				+ rio + ", sens_echange=" + sens_echange + ", xtimts=" + xtimts + ", type_enregistrement="
				+ type_enregistrement + ", type_operation=" + type_operation + ", bic_id_beneficiaire="
				+ bic_id_beneficiaire + ", bic_id_creditor=" + bic_id_creditor + ", bic_id_debitor=" + bic_id_debitor
				+ ", bic_id_do=" + bic_id_do + ", cdt_id_org_bic_bei=" + cdt_id_org_bic_bei + ", cdt_id_org_othr_id="
				+ cdt_id_org_othr_id + ", cdt_id_org_othr_issr=" + cdt_id_org_othr_issr + ", cdt_id_org_othr_sch_cd="
				+ cdt_id_org_othr_sch_cd + ", cdt_id_org_othr_sch_prtry=" + cdt_id_org_othr_sch_prtry
				+ ", cdt_id_pr_dpbi_cry=" + cdt_id_pr_dpbi_cry + ", cdt_id_pr_dpbi_cty=" + cdt_id_pr_dpbi_cty
				+ ", cdt_id_pr_dpbi_dat=" + cdt_id_pr_dpbi_dat + ", cdt_id_pr_dpbi_prv=" + cdt_id_pr_dpbi_prv
				+ ", cdt_id_prv_othr_id=" + cdt_id_prv_othr_id + ", cdt_id_prv_othr_issr=" + cdt_id_prv_othr_issr
				+ ", cdt_id_prv_othr_sch_cd=" + cdt_id_prv_othr_sch_cd + ", cdt_id_prv_othr_sch_prtr="
				+ cdt_id_prv_othr_sch_prtr + ", cdt_name=" + cdt_name + ", cdt_padr_adrline=" + cdt_padr_adrline
				+ ", cdt_padr_ctry=" + cdt_padr_ctry + ", cdtacc_id_iban=" + cdtacc_id_iban + ", cdtagt_fi_bic="
				+ cdtagt_fi_bic + ", chrgbr=" + chrgbr + ", chrginf_amt=" + chrginf_amt + ", chrginf_amtc="
				+ chrginf_amtc + ", chrginf_pty_fi_bic=" + chrginf_pty_fi_bic + ", code_format_pacs=" + code_format_pacs
				+ ", compstnamt=" + compstnamt + ", compstnamtc=" + compstnamtc + ", csch_idproi=" + csch_idproi
				+ ", csch_idproi_cd=" + csch_idproi_cd + ", csch_idproi_issr=" + csch_idproi_issr
				+ ", csch_idproi_prtry=" + csch_idproi_prtry + ", date_insert=" + date_insert + ", dbt_id_org_bic_bei="
				+ dbt_id_org_bic_bei + ", dbt_id_org_othr_id=" + dbt_id_org_othr_id + ", dbt_id_org_othr_issr="
				+ dbt_id_org_othr_issr + ", dbt_id_org_othr_sch_cd=" + dbt_id_org_othr_sch_cd
				+ ", dbt_id_org_othr_sch_prtry=" + dbt_id_org_othr_sch_prtry + ", dbt_id_pr_dpbi_cr="
				+ dbt_id_pr_dpbi_cr + ", dbt_id_pr_dpbi_cty=" + dbt_id_pr_dpbi_cty + ", dbt_id_pr_dpbi_dat="
				+ dbt_id_pr_dpbi_dat + ", dbt_id_pr_dpbi_prv=" + dbt_id_pr_dpbi_prv + ", dbt_id_prv_othr_id="
				+ dbt_id_prv_othr_id + ", dbt_id_prv_othr_issr=" + dbt_id_prv_othr_issr + ", dbt_id_prv_othr_sch_cd="
				+ dbt_id_prv_othr_sch_cd + ", dbt_id_prv_othr_sch_prtr=" + dbt_id_prv_othr_sch_prtr + ", dbt_name="
				+ dbt_name + ", dbt_padr_adrline=" + dbt_padr_adrline + ", dbt_padr_ctry=" + dbt_padr_ctry
				+ ", dbtacc_id_iban=" + dbtacc_id_iban + ", dbtagt_fi_bic=" + dbtagt_fi_bic + ", iban_beneficiaire="
				+ iban_beneficiaire + ", iban_creditor=" + iban_creditor + ", iban_debitor=" + iban_debitor
				+ ", iban_do=" + iban_do + ", insdagt_fi_bic=" + insdagt_fi_bic + ", insgagt_fi_bic=" + insgagt_fi_bic
				+ ", instdamt=" + instdamt + ", instdamtc=" + instdamtc + ", intrbksttlmamt=" + intrbksttlmamt
				+ ", intrbksttlmamtc=" + intrbksttlmamtc + ", m_a_odac_id_iban=" + m_a_odac_id_iban
				+ ", m_a_odac_v9_fi_bic=" + m_a_odac_v9_fi_bic + ", m_a_odac_v9_id_othr_id=" + m_a_odac_v9_id_othr_id
				+ ", m_a_odag_fi_othr_id=" + m_a_odag_fi_othr_id + ", m_a_orgnlmndtid=" + m_a_orgnlmndtid
				+ ", m_a_s_id_pro_issr=" + m_a_s_id_pro_issr + ", m_a_s_id_pro_sch_cd=" + m_a_s_id_pro_sch_cd
				+ ", m_a_s_id_pro_sch_prtry=" + m_a_s_id_pro_sch_prtry + ", m_a_s_id_proid=" + m_a_s_id_proid
				+ ", m_a_s_nm=" + m_a_s_nm + ", m_add_inf=" + m_add_inf + ", m_amdmntind=" + m_amdmntind
				+ ", m_dtofsgntr=" + m_dtofsgntr + ", m_elctrncsgnt=" + m_elctrncsgnt + ", m_id=" + m_id + ", m_mndtid="
				+ m_mndtid + ", m_orgnl_accnt_iban=" + m_orgnl_accnt_iban + ", m_orgnl_accnt_o_id=" + m_orgnl_accnt_o_id
				+ ", m_orgnl_agt_fi_bic=" + m_orgnl_agt_fi_bic + ", m_orgnl_ctct_dt_emadr=" + m_orgnl_ctct_dt_emadr
				+ ", m_orgnl_ctct_dt_fxnm=" + m_orgnl_ctct_dt_fxnm + ", m_orgnl_ctct_dt_mbnm=" + m_orgnl_ctct_dt_mbnm
				+ ", m_orgnl_ctct_dt_nm=" + m_orgnl_ctct_dt_nm + ", m_orgnl_ctct_dt_nmpr=" + m_orgnl_ctct_dt_nmpr
				+ ", m_orgnl_ctct_dt_other=" + m_orgnl_ctct_dt_other + ", m_orgnl_ctct_dt_phnm=" + m_orgnl_ctct_dt_phnm
				+ ", m_orgnl_pty_ctrr=" + m_orgnl_pty_ctrr + ", m_orgnl_pty_id_oi_bic=" + m_orgnl_pty_id_oi_bic
				+ ", m_orgnl_pty_id_oi_id=" + m_orgnl_pty_id_oi_id + ", m_orgnl_pty_id_oi_o_issr="
				+ m_orgnl_pty_id_oi_o_issr + ", m_orgnl_pty_id_oi_o_sn_cd=" + m_orgnl_pty_id_oi_o_sn_cd
				+ ", m_orgnl_pty_id_oi_sn_pty=" + m_orgnl_pty_id_oi_sn_pty + ", m_orgnl_pty_id_pr_bi_cry="
				+ m_orgnl_pty_id_pr_bi_cry + ", m_orgnl_pty_id_pr_bi_cty=" + m_orgnl_pty_id_pr_bi_cty
				+ ", m_orgnl_pty_id_pr_bi_dat=" + m_orgnl_pty_id_pr_bi_dat + ", m_orgnl_pty_id_pr_bi_prv="
				+ m_orgnl_pty_id_pr_bi_prv + ", m_orgnl_pty_id_pr_o_id=" + m_orgnl_pty_id_pr_o_id
				+ ", m_orgnl_pty_id_pr_o_issr=" + m_orgnl_pty_id_pr_o_issr + ", m_orgnl_pty_id_pr_o_sn_cd="
				+ m_orgnl_pty_id_pr_o_sn_cd + ", m_orgnl_pty_id_pr_o_sn_pty=" + m_orgnl_pty_id_pr_o_sn_pty
				+ ", m_orgnl_pty_name=" + m_orgnl_pty_name + ", m_orgnl_pty_padr_adli1=" + m_orgnl_pty_padr_adli1
				+ ", m_orgnl_pty_padr_adli2=" + m_orgnl_pty_padr_adli2 + ", m_orgnl_pty_padr_adli3="
				+ m_orgnl_pty_padr_adli3 + ", m_orgnl_pty_padr_adli4=" + m_orgnl_pty_padr_adli4
				+ ", m_orgnl_pty_padr_adli5=" + m_orgnl_pty_padr_adli5 + ", m_orgnl_pty_padr_adli6="
				+ m_orgnl_pty_padr_adli6 + ", m_orgnl_pty_padr_adli7=" + m_orgnl_pty_padr_adli7
				+ ", m_orgnl_pty_padr_bdnm=" + m_orgnl_pty_padr_bdnm + ", m_orgnl_pty_padr_ctry="
				+ m_orgnl_pty_padr_ctry + ", m_orgnl_pty_padr_ctsd=" + m_orgnl_pty_padr_ctsd + ", m_orgnl_pty_padr_dpt="
				+ m_orgnl_pty_padr_dpt + ", m_orgnl_pty_padr_pscd=" + m_orgnl_pty_padr_pscd
				+ ", m_orgnl_pty_padr_sbdpt=" + m_orgnl_pty_padr_sbdpt + ", m_orgnl_pty_padr_stnm="
				+ m_orgnl_pty_padr_stnm + ", m_orgnl_pty_padr_twnm=" + m_orgnl_pty_padr_twnm + ", m_orgnl_pty_padr_typ="
				+ m_orgnl_pty_padr_typ + ", m_updid_acct_iban=" + m_updid_acct_iban + ", m_updid_acct_o_id="
				+ m_updid_acct_o_id + ", m_updid_agt_fi_bic=" + m_updid_agt_fi_bic + ", m_updid_ctct_dt_emadr="
				+ m_updid_ctct_dt_emadr + ", m_updid_ctct_dt_fxnm=" + m_updid_ctct_dt_fxnm + ", m_updid_ctct_dt_mbnm="
				+ m_updid_ctct_dt_mbnm + ", m_updid_ctct_dt_nm=" + m_updid_ctct_dt_nm + ", m_updid_ctct_dt_nmpr="
				+ m_updid_ctct_dt_nmpr + ", m_updid_ctct_dt_other=" + m_updid_ctct_dt_other + ", m_updid_ctct_dt_phnm="
				+ m_updid_ctct_dt_phnm + ", m_updid_id_o_id=" + m_updid_id_o_id + ", m_updid_pty_ctrr="
				+ m_updid_pty_ctrr + ", m_updid_pty_id_bic=" + m_updid_pty_id_bic + ", m_updid_pty_id_o_issr="
				+ m_updid_pty_id_o_issr + ", m_updid_pty_id_o_sd_pty=" + m_updid_pty_id_o_sd_pty
				+ ", m_updid_pty_id_o_sn_cd=" + m_updid_pty_id_o_sn_cd + ", m_updid_pty_id_pr_bi_cry="
				+ m_updid_pty_id_pr_bi_cry + ", m_updid_pty_id_pr_bi_cty=" + m_updid_pty_id_pr_bi_cty
				+ ", m_updid_pty_id_pr_bi_dat=" + m_updid_pty_id_pr_bi_dat + ", m_updid_pty_id_pr_bi_prv="
				+ m_updid_pty_id_pr_bi_prv + ", m_updid_pty_id_pr_o_id=" + m_updid_pty_id_pr_o_id
				+ ", m_updid_pty_id_pr_o_issr=" + m_updid_pty_id_pr_o_issr + ", m_updid_pty_id_pr_o_sn_cd="
				+ m_updid_pty_id_pr_o_sn_cd + ", m_updid_pty_id_pr_o_sn_pty=" + m_updid_pty_id_pr_o_sn_pty
				+ ", m_updid_pty_name=" + m_updid_pty_name + ", m_updid_pty_padr_adli1=" + m_updid_pty_padr_adli1
				+ ", m_updid_pty_padr_adli2=" + m_updid_pty_padr_adli2 + ", m_updid_pty_padr_adli3="
				+ m_updid_pty_padr_adli3 + ", m_updid_pty_padr_adli4=" + m_updid_pty_padr_adli4
				+ ", m_updid_pty_padr_adli5=" + m_updid_pty_padr_adli5 + ", m_updid_pty_padr_adli6="
				+ m_updid_pty_padr_adli6 + ", m_updid_pty_padr_adli7=" + m_updid_pty_padr_adli7
				+ ", m_updid_pty_padr_bdnm=" + m_updid_pty_padr_bdnm + ", m_updid_pty_padr_ctr=" + m_updid_pty_padr_ctr
				+ ", m_updid_pty_padr_ctsd=" + m_updid_pty_padr_ctsd + ", m_updid_pty_padr_dpt=" + m_updid_pty_padr_dpt
				+ ", m_updid_pty_padr_pscd=" + m_updid_pty_padr_pscd + ", m_updid_pty_padr_sbdpt="
				+ m_updid_pty_padr_sbdpt + ", m_updid_pty_padr_stnm=" + m_updid_pty_padr_stnm
				+ ", m_updid_pty_padr_twnm=" + m_updid_pty_padr_twnm + ", m_updid_pty_padr_typ=" + m_updid_pty_padr_typ
				+ ", motif_rejet_annulation=" + motif_rejet_annulation + ", num_ics=" + num_ics
				+ ", orggrpinf_orgnlmsgid=" + orggrpinf_orgnlmsgid + ", orggrpinf_orgnlmsgnmid="
				+ orggrpinf_orgnlmsgnmid + ", orgnlendtoendid=" + orgnlendtoendid + ", orgnlinstrid=" + orgnlinstrid
				+ ", orgnlintrbksttlmamt=" + orgnlintrbksttlmamt + ", orgnlintrbksttlmamtc=" + orgnlintrbksttlmamtc
				+ ", orgnltxid=" + orgnltxid + ", ot_crlsysref=" + ot_crlsysref + ", ot_endtoendid=" + ot_endtoendid
				+ ", ot_first_agt_fi_bic=" + ot_first_agt_fi_bic + ", ot_instrid=" + ot_instrid + ", ot_txid=" + ot_txid
				+ ", otr_csch_id_prv_othr_id=" + otr_csch_id_prv_othr_id + ", otr_csch_id_prv_othr_issr="
				+ otr_csch_id_prv_othr_issr + ", otr_csch_id_prv_othr_sch_cd=" + otr_csch_id_prv_othr_sch_cd
				+ ", otr_csch_id_prv_othr_sch_prtr=" + otr_csch_id_prv_othr_sch_prtr + ", otr_intrbksttlmdt="
				+ otr_intrbksttlmdt + ", otr_reqdcolltndt=" + otr_reqdcolltndt + ", otr_stti_clrs_cd="
				+ otr_stti_clrs_cd + ", otr_stti_clrs_prtry=" + otr_stti_clrs_prtry + ", otr_stti_sttaid_iban="
				+ otr_stti_sttaid_iban + ", otr_stti_sttaid_o_id=" + otr_stti_sttaid_o_id + ", otr_stti_sttaid_o_issr="
				+ otr_stti_sttaid_o_issr + ", otr_stti_sttaid_o_sn_cd=" + otr_stti_sttaid_o_sn_cd
				+ ", otr_stti_sttaid_o_sn_prtr=" + otr_stti_sttaid_o_sn_prtr + ", otr_stti_sttlmmtd="
				+ otr_stti_sttlmmtd + ", pmtid_endtoendid=" + pmtid_endtoendid + ", pmtid_instrid=" + pmtid_instrid
				+ ", pmtid_txid=" + pmtid_txid + ", pmttpi_ctgypurp=" + pmttpi_ctgypurp + ", pmttpi_ctgypurp_pr="
				+ pmttpi_ctgypurp_pr + ", pmttpi_lclins_cd=" + pmttpi_lclins_cd + ", pmttpi_seqtp=" + pmttpi_seqtp
				+ ", pmttpi_svclvl_cd=" + pmttpi_svclvl_cd + ", pmttpilclins_prtry=" + pmttpilclins_prtry + ", pur_cd="
				+ pur_cd + ", reqdcolltndt=" + reqdcolltndt + ", ri_addtlinf1=" + ri_addtlinf1 + ", ri_addtlinf2="
				+ ri_addtlinf2 + ", ri_rorg_id_org_bic_bei=" + ri_rorg_id_org_bic_bei + ", ri_rorg_id_org_othr_id="
				+ ri_rorg_id_org_othr_id + ", ri_rorg_id_org_othr_issr=" + ri_rorg_id_org_othr_issr
				+ ", ri_rorg_id_org_othr_sch_cd=" + ri_rorg_id_org_othr_sch_cd + ", ri_rorg_id_org_othr_sch_prtr="
				+ ri_rorg_id_org_othr_sch_prtr + ", ri_rorg_id_prv_dpbi_cry=" + ri_rorg_id_prv_dpbi_cry
				+ ", ri_rorg_id_prv_dpbi_cty=" + ri_rorg_id_prv_dpbi_cty + ", ri_rorg_id_prv_dpbi_dat="
				+ ri_rorg_id_prv_dpbi_dat + ", ri_rorg_id_prv_dpbi_prv=" + ri_rorg_id_prv_dpbi_prv
				+ ", ri_rorg_id_prv_othr_id=" + ri_rorg_id_prv_othr_id + ", ri_rorg_id_prv_othr_issr="
				+ ri_rorg_id_prv_othr_issr + ", ri_rorg_id_prv_othr_sch_cd=" + ri_rorg_id_prv_othr_sch_cd
				+ ", ri_rorg_id_prv_othr_sch_prtr=" + ri_rorg_id_prv_othr_sch_prtr + ", ri_rorg_name=" + ri_rorg_name
				+ ", ri_rorg_padr_adrline=" + ri_rorg_padr_adrline + ", ri_rorg_padr_ctry=" + ri_rorg_padr_ctry
				+ ", ri_rsn_cd=" + ri_rsn_cd + ", ri_sn_prtry=" + ri_sn_prtry + ", rmtinf_strd_type_code="
				+ rmtinf_strd_type_code + ", rmtinf_strd_type_is=" + rmtinf_strd_type_is + ", rmtinf_strd_type_ref="
				+ rmtinf_strd_type_ref + ", rmtinf_ustrd=" + rmtinf_ustrd + ", sup_chemin=" + sup_chemin + ", txsts="
				+ txsts + ", ucdt_id_org_bic_bei=" + ucdt_id_org_bic_bei + ", ucdt_id_org_othr_id="
				+ ucdt_id_org_othr_id + ", ucdt_id_org_othr_issr=" + ucdt_id_org_othr_issr
				+ ", ucdt_id_org_othr_sch_cd=" + ucdt_id_org_othr_sch_cd + ", ucdt_id_org_othr_sch_prtry="
				+ ucdt_id_org_othr_sch_prtry + ", ucdt_id_pr_dpbi_cr=" + ucdt_id_pr_dpbi_cr + ", ucdt_id_pr_dpbi_ct="
				+ ucdt_id_pr_dpbi_ct + ", ucdt_id_pr_dpbi_da=" + ucdt_id_pr_dpbi_da + ", ucdt_id_pr_dpbi_prv="
				+ ucdt_id_pr_dpbi_prv + ", ucdt_id_prv_othr_id=" + ucdt_id_prv_othr_id + ", ucdt_id_prv_othr_issr="
				+ ucdt_id_prv_othr_issr + ", ucdt_id_prv_othr_sch_cd=" + ucdt_id_prv_othr_sch_cd
				+ ", ucdt_id_prv_othr_sch_prtr=" + ucdt_id_prv_othr_sch_prtr + ", ucdt_name=" + ucdt_name
				+ ", udbt_id_org_bic_bei=" + udbt_id_org_bic_bei + ", udbt_id_org_othr_id=" + udbt_id_org_othr_id
				+ ", udbt_id_org_othr_sch_cd=" + udbt_id_org_othr_sch_cd + ", udbt_id_org_othr_sch_issr="
				+ udbt_id_org_othr_sch_issr + ", udbt_id_org_othr_sch_prtr=" + udbt_id_org_othr_sch_prtr
				+ ", udbt_id_pr_dpbi_cry=" + udbt_id_pr_dpbi_cry + ", udbt_id_pr_dpbi_cty=" + udbt_id_pr_dpbi_cty
				+ ", udbt_id_pr_dpbi_dat=" + udbt_id_pr_dpbi_dat + ", udbt_id_pr_dpbi_prv=" + udbt_id_pr_dpbi_prv
				+ ", udbt_id_prv_othr_id=" + udbt_id_prv_othr_id + "+ , udbt_id_prv_othr_issr=" + udbt_id_prv_othr_issr
				+ ",fFlag_evolmpm_maeva=" + flag_evolmpm_maeva 
				+ ", udbt_id_prv_othr_sch_cd=" + udbt_id_prv_othr_sch_cd + ", udbt_id_prv_othr_sch_prtr="
				+ udbt_id_prv_othr_sch_prtr + ", udbt_name=" + udbt_name + ", id_traitement=" + id_traitement + "]";
	}
	
	/**
	 * @return the cle_rib_beneficiaire_sr
	 */
	public String getCle_rib_beneficiaire_sr() {
		return cle_rib_beneficiaire_sr;
	}
	/**
	 * @param cle_rib_beneficiaire_sr the cle_rib_beneficiaire_sr to set
	 */
	public void setCle_rib_beneficiaire_sr(String cle_rib_beneficiaire_sr) {
		this.cle_rib_beneficiaire_sr = cle_rib_beneficiaire_sr;
	}
	/**
	 * @return the cle_rib_creditor_sr
	 */
	public String getCle_rib_creditor_sr() {
		return cle_rib_creditor_sr;
	}
	/**
	 * @param cle_rib_creditor_sr the cle_rib_creditor_sr to set
	 */
	public void setCle_rib_creditor_sr(String cle_rib_creditor_sr) {
		this.cle_rib_creditor_sr = cle_rib_creditor_sr;
	}
	/**
	 * @return the cle_rib_debitor_sr
	 */
	public String getCle_rib_debitor_sr() {
		return cle_rib_debitor_sr;
	}
	/**
	 * @param cle_rib_debitor_sr the cle_rib_debitor_sr to set
	 */
	public void setCle_rib_debitor_sr(String cle_rib_debitor_sr) {
		this.cle_rib_debitor_sr = cle_rib_debitor_sr;
	}
	/**
	 * @return the cle_rib_do_sr
	 */
	public String getCle_rib_do_sr() {
		return cle_rib_do_sr;
	}
	/**
	 * @param cle_rib_do_sr the cle_rib_do_sr to set
	 */
	public void setCle_rib_do_sr(String cle_rib_do_sr) {
		this.cle_rib_do_sr = cle_rib_do_sr;
	}
	/**
	 * @return the flag_evolpm_maeva
	 */
	public String getFlag_evolmpm_maeva() {
		return flag_evolmpm_maeva;
	}
	public java.sql.Date getDate_ope() {
		return date_ope;
	}
	public void setDate_ope(java.sql.Date date_ope) {
		this.date_ope = date_ope;
	}

	
	
	
	
}
