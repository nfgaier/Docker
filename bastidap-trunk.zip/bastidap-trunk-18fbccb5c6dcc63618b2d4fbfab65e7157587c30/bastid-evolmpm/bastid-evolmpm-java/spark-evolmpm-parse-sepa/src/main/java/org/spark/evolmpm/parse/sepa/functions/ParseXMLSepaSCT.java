package org.spark.evolmpm.parse.sepa.functions;
import java.io.InputStream;


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;


import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class ParseXMLSepaSCT {

	public ParseXMLSepaSCT() {
		// TODO Auto-generated constructor stub

	}

	//	public static void main(String[] args) throws Exception {
	//		/** 
	//		 * Initialisation du parser
	//		 * */
	//		final ParseXMLUtil parser = new ParseXMLUtil();
	//
	//		
	//		/** 
	//		 * Récupération du fichier de test
	//		 * */
	//		final InputStream input = parser.getInputFile();
	//		
	//		/** 
	//		 * Initialisation des objets pour XPath
	//		 * */
	//		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
	//		DocumentBuilder builder = builderFactory.newDocumentBuilder();
	//		Document xml = builder.parse(input);
	//		Element root = xml.getDocumentElement();
	//		XPathFactory xpf = XPathFactory.newInstance();
	//		XPath path = xpf.newXPath();
	//		
	//		
	//		/** Appels au parsing */
	//		System.out.println("Tag InstrId value : "+parser.getTagINTRBKSTTLMAMTC(path, root));
	//		
	//	}
	//	
	//	
	//
	//	
	//	
	//
	//
	//
	//	
	//
	//	// TODO : A supprimer
	//		/** Méthode utilitaire pour tests */
	//		private InputStream getInputFile() {
	//			return getClass().getClassLoader().getResourceAsStream("example.xml");
	//		}
	//
	//	
	//	







	public String getTagCODE_FORMAT_PACS(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Fille";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagPMTID_TXID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/PmtId/TxId";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTagPMTID_INSTRID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/PmtId/InstrId";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagPMTID_ENDTOENDID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/PmtId/EndToEndId";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}





	public String getTagPMTTPI_SVCLVL_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/PmtTpInf/SvcLvl/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}








	public String getTagPMTTPI_LCLINS_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/PmtTpInf/LclInstrm/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}




	public String getTagPMTTPILCLINS_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/PmtTpInf/LclInstrm/Prtry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}



	public String getTagPMTTPI_CTGYPURP(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/PmtTpInf/CtgyPurp";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}






	public String getTagINTRBKSTTLMAMT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/IntrBkSttlmAmt";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagINTRBKSTTLMAMTC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/IntrBkSttlmAmt/@Ccy";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}




	public String getTagCHRGBR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/ChrgBr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagUCDT_NAME(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtCdtr/Nm";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagUCDT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtCdtr/Id/OrgId/BICOrBEI";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagUCDT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtCdtr/Id/OrgId/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}



	public String getTagUCDT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtCdtr/Id/OrgId/Othr/SchmeNm/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagUCDT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtCdtr/Id/OrgId/Othr/SchmeNm/Prtry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}



	public String getTagUCDT_ID_ORG_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtCdtr/Id/OrgId/Othr/Issr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}




	public String getTagUCDT_ID_PR_DPBI_DA(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}







	public String getTagUCDT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}



	public String getTagUCDT_ID_PR_DPBI_CT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTagUCDT_ID_PR_DPBI_CR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagUCDT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtCdtr/Id/PrvtId/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}



	public String getTagUCDT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtCdtr/Id/PrvtId/Othr/SchmeNm/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}



	public String getTagUCDT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtCdtr/Id/PrvtId/Othr/SchmeNm/Prtry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}



	public String getTagUCDT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtCdtr/Id/PrvtId/Othr/Issr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}




	public String getTagDBT_NAME(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Dbtr/Nm";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}



	public String getTagDBT_PADR_ADRLINE(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Dbtr/PstlAdr/AdrLine";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}



	public String getTagDBT_PADR_CTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Dbtr/PstlAdr/Ctry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagDBT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Dbtr/Id/OrgId/BICOrBEI";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagDBT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Dbtr/Id/OrgId/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}



	public String getTagDBT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Dbtr/Id/OrgId/Othr/SchmeNm/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTagDBT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Dbtr/Id/OrgId/Othr/SchmeNm/Prtry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}




	public String getTagDBT_ID_ORG_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Dbtr/Id/OrgId/Othr/Issr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}




	public String getTagDBT_ID_PR_DPBI_DAT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Dbtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}





	public String getTagDBT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Dbtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagDBT_ID_PR_DPBI_CTY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Dbtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagDBT_ID_PR_DPBI_CR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Dbtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagDBT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Dbtr/Id/PrvtId/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}




	public String getTagDBT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Dbtr/Id/PrvtId/Othr/SchmeNm/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagDBT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Dbtr/Id/PrvtId/Othr/SchmeNm/Prtry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagDBT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Dbtr/Id/PrvtId/Othr/Issr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTagDBTACC_ID_IBAN(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/DbtrAcct/Id/IBAN";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagDBTAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/DbtrAgt/FinInstnId/BIC";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTagCDTACC_ID_IBAN(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/CdtrAcct/Id/IBAN";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagCDTAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/CdtrAgt/FinInstnId/BIC";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}



	public String getTagCDT_NAME(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Cdtr/Nm";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}



	public String getTagCDT_PADR_ADRLINE(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Cdtr/PstlAdr/AdrLine";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagCDT_PADR_CTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Cdtr/PstlAdr/Ctry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagCDT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Cdtr/Id/OrgId/BICOrBEI";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagCDT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Cdtr/Id/OrgId/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagCDT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Cdtr/Id/OrgId/Othr/SchmeNm/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagCDT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Cdtr/Id/OrgId/Othr/SchmeNm/Prtry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}



	public String getTagCDT_ID_ORG_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Cdtr/Id/OrgId/Othr/Issr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagCDT_ID_PR_DPBI_DAT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Cdtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagCDT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Cdtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagCDT_ID_PR_DPBI_CTY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Cdtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagCDT_ID_PR_DPBI_CRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Cdtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagCDT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Cdtr/Id/PrvtId/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}



	public String getTagCDT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Cdtr/Id/PrvtId/Othr/SchmeNm/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTagCDT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Cdtr/Id/PrvtId/Othr/SchmeNm/Prtry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagCDT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Cdtr/Id/PrvtId/Othr/Issr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTagUDBT_NAME(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtDbtr/Nm";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagUDBT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtDbtr/Id/OrgId/BICOrBEI";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagUDBT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtDbtr/Id/OrgId/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagUDBT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtDbtr/Id/OrgId/Othr/SchmeNm/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagUDBT_ID_ORG_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtDbtr/Id/OrgId/Othr/SchmeNm/Prtry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagUDBT_ID_ORG_OTHR_SCH_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtDbtr/Id/OrgId/Othr/Issr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagUDBT_ID_PR_DPBI_DAT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTagUDBT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagUDBT_ID_PR_DPBI_CTY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagUDBT_ID_PR_DPBI_CRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagUDBT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtDbtr/Id/PrvtId/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagUDBT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtDbtr/Id/PrvtId/Othr/SchmeNm/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagUDBT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtDbtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagUDBT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/UltmtDbtr/Id/PrvtId/Othr/Issr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagINSGAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/InstgAgt/FinInstnId/BIC";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagINSDAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/InstdAgt/FinInstnId/BIC";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagRMTINF_USTRD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/RmtInf/Ustrd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagRMTINF_STRD_TYPE_CODE(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/RmtInf/Strd/CdtrRefInf/Tp/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTagRMTINF_STRD_TYPE_REF(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/RmtInf/Strd/CdtrRefInf/Ref";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTagPUR_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/Purp/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagBIC_ID_Debitor(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/DbtrAgt/FinInstnId/BIC";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTagBIC_ID_Creditor(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/CdtrAgt/FinInstnId/BIC";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}



	public String getTagIBAN_DEBTOR (XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/DbtrAcct/Id/IBAN";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagIBAN_CREDITOR (XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/CdtrAcct/Id/IBAN";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagBIC_ID_DO(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/DbtrAgt/FinInstnId/BIC";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagIBAN_DO  (XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/DbtrAcct/Id/IBAN";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	public String getTagBIC_ID_BENEFICIAIRE(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/CdtrAgt/FinInstnId/BIC";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTagIBAN_BENEFICIAIRE(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/CdtTrfTxInf/CdtrAcct/Id/IBAN";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}


	/**
	 * function parse code 326
	 */
	public String getTag_326MOTIF_REJET_ANNULATION(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/CxlRsnInf/Rsn/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326PMTTPI_SVCLVL_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/PmtTpInf/SvcLvl/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326PMTTPI_LCLINS_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/PmtTpInf/LclInstrm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326PMTTPILCLINS_PRTRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/PmtTpInf/LclInstrm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTag_326PMTTPI_CTGYPURP(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/PmtTpInf/CtgyPurp/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UCDT_NAME(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Nm"   ;                     
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UCDT_ID_ORG_BIC_BEI(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UCDT_ID_ORG_OTHR_ID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UCDT_ID_ORG_OTHR_SCH_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UCDT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UCDT_ID_ORG_OTHR_ISSR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UCDT_ID_PR_DPBI_DA(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UCDT_ID_PR_DPBI_PRV(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UCDT_ID_PR_DPBI_CT(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";                
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UCDT_ID_PR_DPBI_CR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";                  
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UCDT_ID_PRV_OTHR_ID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/Id"; 
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UCDT_ID_PRV_OTHR_SCH_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UCDT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/SchmeNm/Prtry";   
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UCDT_ID_PRV_OTHR_ISSR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326DBT_NAME(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326DBT_PADR_ADRLINE(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/PstlAdr/AdrLine";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326DBT_PADR_CTRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/PstlAdr/Ctry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326DBT_ID_ORG_BIC_BEI(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326DBT_ID_ORG_OTHR_ID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326DBT_ID_ORG_OTHR_SCH_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/OrgId/Othr/SchmeNm/Cd";  
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326DBT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326DBT_ID_ORG_OTHR_ISSR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/OrgId/Othr/Issr";  
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326DBT_ID_PR_DPBI_DAT(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326DBT_ID_PR_DPBI_PRV(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326DBT_ID_PR_DPBI_CTY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326DBT_ID_PR_DPBI_CR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326DBT_ID_PRV_OTHR_ID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326DBT_ID_PRV_OTHR_SCH_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326DBT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326DBT_ID_PRV_OTHR_ISSR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/Issr";      
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326DBTACC_ID_IBAN(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/DbtrAcct/Id/IBAN"; 
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326DBTAGT_FI_BIC(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/DbtrAgt/FinInstnId/BIC";     
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326CDTACC_ID_IBAN(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/CdtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326CDTAGT_FI_BIC(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/CdtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326CDT_NAME(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Nm";       
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326CDT_PADR_ADRLINE(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/PstlAdr/AdrLine";   
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326CDT_PADR_CTRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/PstlAdr/Ctry";  
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326CDT_ID_ORG_BIC_BEI(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/ld/OrgId/BICOrBEI";    
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326CDT_ID_ORG_OTHR_ID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/ld/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326CDT_ID_ORG_OTHR_SCH_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/ld/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326CDT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/ld/OrgId/Othr/SchmeNm/Prtry"; 
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326CDT_ID_ORG_OTHR_ISSR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/ld/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326CDT_ID_PR_DPBI_DAT(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/ld/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326CDT_ID_PR_DPBI_PRV(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/ld/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326CDT_ID_PR_DPBI_CTY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/ld/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326CDT_ID_PR_DPBI_CRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/ld/PrvtId/DtAndPlcOfBirth/CtryOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326CDT_ID_PRV_OTHR_ID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/ld/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326CDT_ID_PRV_OTHR_SCH_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/ld/PrvtId/Othr/SchmeNm/Cd"; 
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326CDT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/ld/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326CDT_ID_PRV_OTHR_ISSR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/ld/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UDBT_NAME(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UDBT_ID_ORG_BIC_BEI(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UDBT_ID_ORG_OTHR_ID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UDBT_ID_ORG_OTHR_SCH_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UDBT_ID_ORG_OTHR_SCH_PRTR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UDBT_ID_ORG_OTHR_SCH_ISSR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UDBT_ID_PR_DPBI_DAT(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UDBT_ID_PR_DPBI_PRV(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UDBT_ID_PR_DPBI_CTY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UDBT_ID_PR_DPBI_CRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UDBT_ID_PRV_OTHR_ID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UDBT_ID_PRV_OTHR_SCH_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UDBT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326UDBT_ID_PRV_OTHR_ISSR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTag_326RMTINF_USTRD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/RmtInf/Ustrd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326RMTINF_STRD_TYPE_CODE(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/RmtInf/Strd/CdtrRefInf/Tp/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326RMTINF_STRD_TYPE_REF(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/RmtInf/Strd/CdtrRefInf/Ref";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTag_326ORGNLTXID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326ORGGRPINF_ORGNLMSGID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlGrpInf/OrgnlMsgId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326ORGGRPINF_ORGNLMSGNMID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlGrpInf/OrgnlMsgNmId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326ORGNLINSTRID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlGrpInf/OrgnlInstrId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326ORGNLENDTOENDID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlGrpInf/OrgnlEndToEndId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTag_326ORGNLINTRBKSTTLMAMT(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlGrpInf/OrgnlIntrBkSttlmAmt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}


	public String getTag_326ORGNLINTRBKSTTLMAMTC(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlGrpInf/@OrgnlIntrBkSttlmAmt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326OTR_INTRBKSTTLMDT(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlIntrBkSttlmDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTag_326RI_RORG_NAME(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/CxlRsnInf/Orgtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTag_326RI_RORG_ID_ORG_BIC_BEI(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/CxlRsnInf/Orgtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTag_326RI_RSN_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/CxlRsnInf/Rsn/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326RI_SN_PRTRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/CxlRsnInf/Rsn/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTag_326OTR_REQDCOLLTNDT(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/ReqdExctnDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326OTR_CSCH_ID_PRV_OTHR_ID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/CdtrSchmeId/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326OTR_CSCH_ID_PRV_OTHR_SCH_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/CdtrSchmeId/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326OTR_CSCH_ID_PRV_OTHR_ISSR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/CdtrSchmeId/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326OTR_CSCH_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/CdtrSchmeId/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326OTR_STTI_STTLMMTD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/SttlmInf/SttlmMtd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326OTR_STTI_STTAID_IBAN(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/SttlmInf/SttlmAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326OTR_STTI_STTAID_O_ID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326OTR_STTI_STTAID_O_SN_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326OTR_STTI_STTAID_O_SN_PRTR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326OTR_STTI_STTAID_O_ISSR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326OTR_STTI_CLRS_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/SttlmInf/ClrSys/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326OTR_STTI_CLRS_PRTRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/SttlmInf/ClrSys/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326BIC_ID_Debitor(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/DbtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326BIC_ID_Creditor(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/CdtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTag_326IBAN_DEBTOR (XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/DbtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326IBAN_CREDITOR (XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/CdtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326BIC_ID_DO(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/DbtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326IBAN_DO  (XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/DbtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326BIC_ID_BENEFICIAIRE(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/CdtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_326IBAN_BENEFICIAIRE(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/TxInf/OrgnlTxRef/CdtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * function parse code 329
	 */

	public String getTag_329MOTIF_REJET_ANNULATION(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/CxlStsRsnInf/Rsn/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTag_329PMTTPI_SVCLVL_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/PmtTpInf/SvcLvl/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329PMTTPI_LCLINS_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/PmtTpInf/LclInstrm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329PMTTPILCLINS_PRTRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/PmtTpInf/LclInstrm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTag_329PMTTPI_CTGYPURP(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/PmtTpInf/CtgyPurp/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}


	public String getTag_329UCDT_NAME(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UCDT_ID_ORG_BIC_BEI(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UCDT_ID_ORG_OTHR_ID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/OrgId/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UCDT_ID_ORG_OTHR_SCH_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/OrgId/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UCDT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/OrgId/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UCDT_ID_ORG_OTHR_ISSR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/OrgId/SchmeNm/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UCDT_ID_PR_DPBI_DA(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UCDT_ID_PR_DPBI_PRV(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UCDT_ID_PR_DPBI_CT(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UCDT_ID_PR_DPBI_CR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UCDT_ID_PRV_OTHR_ID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UCDT_ID_PRV_OTHR_SCH_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/SchmeNm/Cd"; 
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UCDT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UCDT_ID_PRV_OTHR_ISSR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329DBT_NAME(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Dbtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329DBT_PADR_ADRLINE(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/AdrLine";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329DBT_PADR_CTRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/Ctry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329DBT_ID_ORG_BIC_BEI(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Dbtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329DBT_ID_ORG_OTHR_ID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Dbtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329DBT_ID_ORG_OTHR_SCH_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Dbtr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329DBT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Dbtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329DBT_ID_ORG_OTHR_ISSR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Dbtr/Id/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329DBT_ID_PR_DPBI_DAT(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt"; 
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329DBT_ID_PR_DPBI_PRV(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329DBT_ID_PR_DPBI_CTY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329DBT_ID_PR_DPBI_CR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329DBT_ID_PRV_OTHR_ID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329DBT_ID_PRV_OTHR_SCH_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329DBT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329DBT_ID_PRV_OTHR_ISSR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329DBTACC_ID_IBAN(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/DbtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329DBTAGT_FI_BIC(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/DbtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329CDTACC_ID_IBAN(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/CdtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329CDTAGT_FI_BIC(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/CdtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329CDT_NAME(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Cdtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329CDT_PADR_ADRLINE(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Cdtr/PstlAdr/AdrLine"; 
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329CDT_PADR_CTRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Cdtr/PstlAdr/Ctry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329CDT_ID_ORG_BIC_BEI(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Cdtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329CDT_ID_ORG_OTHR_ID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Cdtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329CDT_ID_ORG_OTHR_SCH_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Cdtr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329CDT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Cdtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329CDT_ID_ORG_OTHR_ISSR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Cdtr/Id/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329CDT_ID_PR_DPBI_DAT(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Cdtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt"; 
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329CDT_ID_PR_DPBI_PRV(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Cdtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329CDT_ID_PR_DPBI_CTY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Cdtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329CDT_ID_PR_DPBI_CRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Cdtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth"; 
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329CDT_ID_PRV_OTHR_ID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Cdtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329CDT_ID_PRV_OTHR_SCH_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Cdtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329CDT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Cdtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329CDT_ID_PRV_OTHR_ISSR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/Cdtr/Id/PrvtId/Othr/Issr"; 
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UDBT_NAME(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UDBT_ID_ORG_BIC_BEI(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UDBT_ID_ORG_OTHR_ID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UDBT_ID_ORG_OTHR_SCH_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UDBT_ID_ORG_OTHR_SCH_PRTR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UDBT_ID_ORG_OTHR_SCH_ISSR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UDBT_ID_PR_DPBI_DAT(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UDBT_ID_PR_DPBI_PRV(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UDBT_ID_PR_DPBI_CTY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UDBT_ID_PR_DPBI_CRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth"; 
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UDBT_ID_PRV_OTHR_ID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UDBT_ID_PRV_OTHR_SCH_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UDBT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329UDBT_ID_PRV_OTHR_ISSR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTag_329RMTINF_USTRD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/RmtInf/Ustrd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329RMTINF_STRD_TYPE_CODE(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/RmtInf/Strd/CdtrRefInf/Tp/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329RMTINF_STRD_TYPE_REF(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/RmtInf/Strd/CdtrRefInf/Ref"; 
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}


	public String getTag_329ORGNLTXID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329ORGGRPINF_ORGNLMSGID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlGrpInf/OrgnlMsgId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329ORGGRPINF_ORGNLMSGNMID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlMsgNmId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329ORGNLINSTRID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlInstrId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329ORGNLENDTOENDID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlEndToEndId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329TXSTS(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/TxCxlSts";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329ORGNLINTRBKSTTLMAMT(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/IntrBkSttlmAmt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329ORGNLINTRBKSTTLMAMTC(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/@IntrBkSttlmAmt"; 
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329OTR_INTRBKSTTLMDT(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/IntrBkSttlmDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTag_329RI_RORG_NAME(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/CxlStsRsnInf/Orgtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTag_329RI_RORG_ID_ORG_BIC_BEI(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTag_329RI_RSN_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/CxlStsRsnInf/Rsn/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329RI_SN_PRTRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/CxlStsRsnInf/Rsn/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329RI_ADDTLINF1(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/CxlStsRsnInf/AddtlInf";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329RI_ADDTLINF2(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/CxlStsRsnInf/AddtlInf";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTag_329OTR_STTI_STTLMMTD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/SttlmInf/SttlmMtd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329OTR_STTI_STTAID_IBAN(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/SttlmInf/SttlmAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329OTR_STTI_STTAID_O_ID(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329OTR_STTI_STTAID_O_SN_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329OTR_STTI_STTAID_O_SN_PRTR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329OTR_STTI_STTAID_O_ISSR(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329OTR_STTI_CLRS_CD(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/SttlmInf/ClrSys/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	public String getTag_329OTR_STTI_CLRS_PRTRY(XPath path, Element root)throws XPathExpressionException   {  
		String expr = "/XPARTT/CxlDtls/TxInfAndSts/OrgnlTxRef/SttlmInf/ClrSys/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * function parse code 330
	 */


	public String getTag_330MOTIF_REJET_ANNULATION(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/RvslRsnInf/Rsn/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}

	public String getTag_330PMTTPI_SVCLVL_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/PmtTpInf/SvcLvl/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330PMTTPI_LCLINS_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/PmtTpInf/LclInstrm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330PMTTPILCLINS_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/PmtTpInf/LclInstrm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330PMTTPI_SEQTP(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/PmtTpInf/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330PMTTPI_CTGYPURP(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/PmtTpInf/CtgyPurp/Cd";	
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330INTRBKSTTLMAMT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/RvsdIntrBkSttlmAmt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330INTRBKSTTLMAMTC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/@RvsdIntrBkSttlmAmt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CHRGBR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/ChrgBr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CHRGINF_AMT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/ChrgsInf/Amt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CHRGINF_AMTC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/ChrgsInf/@Amt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CHRGINF_PTY_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/ChrgsInf/Pty/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}

	public String getTag_330M_MNDTID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/MndtRltdInf/MndtId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330M_DTOFSGNTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/MndtRltdInf/DtOfSgntr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330M_AMDMNTIND(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/MndtRltdInf/AmdmntInd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330M_A_ORGNLMNDTID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/MndtRltdInf/AmdmntInfDtls/OrgnlMndtId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330M_A_S_NM(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/MndtRltdInf/AmdmntInfDtls/OrgnlCdtrSchmeId/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330M_A_S_ID_PROID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/MndtRltdInf/AmdmntInfDtls/OrgnlCdtrSchmeId/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330M_A_S_ID_PRO_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/MndtRltdInf/AmdmntInfDtls/OrgnlCdtrSchmeId/Id/PrvtId/Othr/SchmeNm/Cd;";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330M_A_S_ID_PRO_SCH_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/MndtRltdInf/AmdmntInfDtls/OrgnlCdtrSchmeId/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330M_A_S_ID_PRO_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/MndtRltdInf/AmdmntInfDtls/OrgnlCdtrSchmeId/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330M_A_ODAC_ID_IBAN(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/MndtRltdInf/AmdmntInfDtls/OrgnlDbtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330M_A_ODAG_FI_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/MndtRltdInf/AmdmntInfDtls/OrgnlDbtrAgt/FinInstnId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330M_ELCTRNCSGNT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/MndtRltdInf/ElctrncSgntr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}

	public String getTag_330UCDT_NAME(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UCDT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UCDT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UCDT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UCDT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UCDT_ID_ORG_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UCDT_ID_PR_DPBI_DA(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UCDT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UCDT_ID_PR_DPBI_CT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UCDT_ID_PR_DPBI_CR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UCDT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UCDT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UCDT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UCDT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330DBT_NAME(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330DBT_PADR_ADRLINE(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/PstlAdr/AdrLine";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330DBT_PADR_CTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/PstlAdr/Ctry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330DBT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330DBT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330DBT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330DBT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330DBT_ID_ORG_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330DBT_ID_PR_DPBI_DAT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330DBT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330DBT_ID_PR_DPBI_CTY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330DBT_ID_PR_DPBI_CR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330DBT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330DBT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330DBT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330DBT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330DBTACC_ID_IBAN(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/DbtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330DBTAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/DbtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CDTACC_ID_IBAN(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/CdtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CDTAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/CdtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CDT_NAME(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CDT_PADR_ADRLINE(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/PstlAdr/AdrLine";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CDT_PADR_CTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/PstlAdr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CDT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CDT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CDT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CDT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CDT_ID_ORG_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CDT_ID_PR_DPBI_DAT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CDT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CDT_ID_PR_DPBI_CTY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CDT_ID_PR_DPBI_CRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CDT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CDT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CDT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330CDT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UDBT_NAME(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UDBT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UDBT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UDBT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UDBT_ID_ORG_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UDBT_ID_ORG_OTHR_SCH_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UDBT_ID_PR_DPBI_DAT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UDBT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UDBT_ID_PR_DPBI_CTY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UDBT_ID_PR_DPBI_CRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UDBT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UDBT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UDBT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330UDBT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330INSGAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/InstgAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330INSDAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/InstdAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330RMTINF_USTRD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/RmtInf/Ustrd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330RMTINF_STRD_TYPE_CODE(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/RmtInf/Strd/CdtrRefInf/Tp/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330RMTINF_STRD_TYPE_REF(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/RmtInf/Strd/CdtrRefInf/Ref";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}

	public String getTag_330ORGNLTXID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}

	public String getTag_330ORGNLINSTRID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlInstrId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330ORGNLENDTOENDID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlEndToEndId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330ORGNLINTRBKSTTLMAMT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlIntrBkSttlmAmt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330ORGNLINTRBKSTTLMAMTC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/@OrgnlIntrBkSttlmAmt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}
	public String getTag_330OTR_INTRBKSTTLMDT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInf/OrgnlTxRef/IntrBkSttlmDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
	}

	/**
	 * function parse code 720 //730
	 */
	public String getTag_720MOTIF_REJET_ANNULATION(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/RtrRsnInf/Rsn/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720PMTTPI_SVCLVL_CD(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/PmtTpInf/SvcLvl/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720PMTTPI_LCLINS_CD(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/PmtTpInf/LclInstrm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720PMTTPILCLINS_PRTRY(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/PmtTpInf/LclInstrm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720PMTTPI_CTGYPURP(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/PmtTpInf/CtgyPurp/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720INTRBKSTTLMAMT(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/RtrdIntrBkSttlmAmt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}
	public String getTag_720INTRBKSTTLMAMTC(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/@RtrdIntrBkSttlmAmt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CHRGBR(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/ChrgBr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CHRGINF_AMT(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/ChrgsInf/Amt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}
	public String getTag_720CHRGINF_AMTC(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/ChrgsInf/@Amt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CHRGINF_PTY_FI_BIC(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/ChrgsInf/Pty/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UCDT_NAME(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UCDT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UCDT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UCDT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UCDT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UCDT_ID_ORG_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UCDT_ID_PR_DPBI_DA(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UCDT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UCDT_ID_PR_DPBI_CT(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UCDT_ID_PR_DPBI_CR(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UCDT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UCDT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UCDT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UCDT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720DBT_NAME(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720DBT_PADR_ADRLINE(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/PstlAdr/AdrLine";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720DBT_PADR_CTRY(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/PstlAdr/Ctry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720DBT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720DBT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720DBT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720DBT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720DBT_ID_ORG_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720DBT_ID_PR_DPBI_DAT(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720DBT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720DBT_ID_PR_DPBI_CTY(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720DBT_ID_PR_DPBI_CR(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720DBT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720DBT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720DBT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720DBT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720DBTACC_ID_IBAN(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/DbtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720DBTAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/DbtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CDTACC_ID_IBAN(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/CdtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CDTAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/CdtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CDT_NAME(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CDT_PADR_ADRLINE(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/PstlAdr/AdrLine";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CDT_PADR_CTRY(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/PstlAdr/Ctry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CDT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CDT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CDT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CDT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CDT_ID_ORG_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}
	public String getTag_720CDT_ID_PR_DPBI_DAT(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CDT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CDT_ID_PR_DPBI_CTY(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CDT_ID_PR_DPBI_CRY(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CDT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CDT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CDT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720CDT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/Cdtr/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UDBT_NAME(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UDBT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UDBT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UDBT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UDBT_ID_ORG_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UDBT_ID_ORG_OTHR_SCH_ISSR(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UDBT_ID_PR_DPBI_DAT(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UDBT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UDBT_ID_PR_DPBI_CTY(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UDBT_ID_PR_DPBI_CRY(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UDBT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UDBT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UDBT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720UDBT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720INSGAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/InstgAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720INSDAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/InstdAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720RMTINF_USTRD(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/RmtInf/Ustrd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720RMTINF_STRD_TYPE_CODE(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/RmtInf/Strd/CdtrRefInf/Tp/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720RMTINF_STRD_TYPE_REF(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/RmtInf/Strd/CdtrRefInf/Ref";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720ORGNLTXID(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720ORGGRPINF_ORGNLMSGID(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlGrpInf/OrgnlMsgId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720ORGGRPINF_ORGNLMSGNMID(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlGrpInf/OrgnlMsgNmId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720ORGNLINSTRID(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlInstrId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720ORGNLENDTOENDID(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlEndToEndId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720ORGNLINTRBKSTTLMAMT(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlIntrBkSttlmAmt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}
	public String getTag_720ORGNLINTRBKSTTLMAMTC(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/@OrgnlIntrBkSttlmAmt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}
	public String getTag_720OTR_INTRBKSTTLMDT(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/IntrBkSttlmDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720INSTDAMT(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/RtrdInstdAmt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}
	public String getTag_720INSTDAMTC(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/@RtrdInstdAmt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}
	public String getTag_720RI_RORG_NAME(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/RtrRsnInf/Orgtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720RI_RORG_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/RtrRsnInf/Orgtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720RI_RSN_CD(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/RtrRsnInf/Rsn/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720RI_ADDTLINF1(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/RtrRsnInf/AddtlInf";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720OTR_STTI_STTLMMTD(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/SttlmInf/SttlmMtd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720OTR_STTI_STTAID_IBAN(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/SttlmInf/SttlmAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720OTR_STTI_STTAID_O_ID(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720OTR_STTI_STTAID_O_SN_CD(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720OTR_STTI_STTAID_O_SN_PRTR(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720OTR_STTI_STTAID_O_ISSR(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720OTR_STTI_CLRS_CD(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/SttlmInf/ClrSys/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720OTR_STTI_CLRS_PRTRY(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/SttlmInf/ClrSys/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720BIC_ID_Debitor(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/DbtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720BIC_ID_Creditor(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/CdtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720IBAN_DEBTOR(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/DbtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720IBAN_CREDITOR(XPath path, Element root) throws XPathExpressionException { 
		String expr ="/XPARTT/TxInf/OrgnlTxRef/CdtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}
	public String getTag_720BIC_ID_DO(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/CdtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720IBAN_DO(XPath path, Element root) throws XPathExpressionException {  
		String expr ="/XPARTT/TxInf/OrgnlTxRef/CdtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720BIC_ID_BENEFICIAIRE(XPath path, Element root) throws XPathExpressionException {
		String expr ="/XPARTT/TxInf/OrgnlTxRef/DbtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	public String getTag_720IBAN_BENEFICIAIRE(XPath path, Element root) throws XPathExpressionException { 
		String expr = "/XPARTT/TxInf/OrgnlTxRef/DbtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);

	}

	/**
	 * function parse code 920
	 */
	
	public String getTag_920MOTIF_REJET_ANNULATION(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/StsRsnInf/Rsn/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920PMTTPI_SVCLVL_CD(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/PmtTpInf/SvcLvl/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920PMTTPI_LCLINS_CD(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/PmtTpInf/LclInstrm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920PMTTPILCLINS_PRTRY(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/PmtTpInf/LclInstrm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920PMTTPI_CTGYPURP(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/PmtTpInf/LclInstrm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UCDT_NAME(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UCDT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UCDT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UCDT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UCDT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UCDT_ID_ORG_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UCDT_ID_PR_DPBI_DA(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UCDT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UCDT_ID_PR_DPBI_CT(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UCDT_ID_PR_DPBI_CR(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UCDT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UCDT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UCDT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UCDT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920DBT_NAME(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920DBT_PADR_ADRLINE(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/AdrLine";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920DBT_PADR_CTRY(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/Ctry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920DBT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920DBT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920DBT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920DBT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920DBT_ID_ORG_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/Id/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920DBT_ID_PR_DPBI_DAT(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920DBT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920DBT_ID_PR_DPBI_CTY(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920DBT_ID_PR_DPBI_CR(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBir";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920DBT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920DBT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920DBT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920DBT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920DBTACC_ID_IBAN(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/DbtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920DBTAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/DbtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920CDTAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/CdtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920CDT_NAME(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Cdtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920CDT_PADR_ADRLINE(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Cdtr/PstlAdr/AdrLine";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920CDT_PADR_CTRY(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Cdtr/PstlAdr/Ctry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920CDT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Cdtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920CDT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Cdtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920CDT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Cdtr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920CDT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Cdtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920CDT_ID_ORG_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Cdtr/Id/OrgId/Othr/SchmeNm/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920CDT_ID_PR_DPBI_DAT(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Cdtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920CDT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Cdtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920CDT_ID_PR_DPBI_CTY(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Cdtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920CDT_ID_PR_DPBI_CRY(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Cdtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920CDT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Cdtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920CDT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Cdtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920CDT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Cdtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UDBT_NAME(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UDBT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UDBT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UDBT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UDBT_ID_ORG_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UDBT_ID_ORG_OTHR_SCH_ISSR(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UDBT_ID_PR_DPBI_DAT(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UDBT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UDBT_ID_PR_DPBI_CTY(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UDBT_ID_PR_DPBI_CRY(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UDBT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UDBT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UDBT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920UDBT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920INSGAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/InstgAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920INSDAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/InstdAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920RMTINF_USTRD(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/InstdAgt/RmtInf/Ustrd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920RMTINF_STRD_TYPE_CODE(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/InstdAgt/RmtInf/Strd/CdtrRefInf/Tp/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920RMTINF_STRD_TYPE_REF(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/InstdAgt/RmtInf/Strd/CdtrRefInf/Ref";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920ORGNLTXID(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920ORGNLINSTRID(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlInstrId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920ORGNLENDTOENDID(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlEndToEndId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920TXSTS(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/TxSts";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920ORGNLINTRBKSTTLMAMT(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/IntrBkSttlmAmt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920OTR_INTRBKSTTLMDT(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/IntrBkSttlmDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920RI_RORG_NAME(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/StsRsnInf/Orgtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920RI_RORG_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/StsRsnInf/Orgtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920RI_RSN_CD(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/StsRsnInf/Rsn/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920RI_SN_PRTRY(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/StsRsnInf/Rsn/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920OTR_STTI_STTLMMTD(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/SttlmInf";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920OTR_STTI_STTAID_IBAN(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/SttlmInf/SttlmAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920OTR_STTI_STTAID_O_ID(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920OTR_STTI_STTAID_O_SN_CD(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920OTR_STTI_STTAID_O_SN_PRTR(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920OTR_STTI_STTAID_O_ISSR(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920OTR_STTI_CLRS_CD(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/SttlmInf/ClrSys/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }
		public String getTag_920OTR_STTI_CLRS_PRTRY(XPath path, Element root) throws XPathExpressionException {
		 String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/SttlmInf/ClrSys/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING); 
		 }


}

