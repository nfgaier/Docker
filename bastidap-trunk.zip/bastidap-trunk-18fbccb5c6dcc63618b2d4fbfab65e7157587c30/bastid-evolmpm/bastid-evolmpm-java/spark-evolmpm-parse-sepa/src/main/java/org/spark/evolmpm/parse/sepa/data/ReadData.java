package org.spark.evolmpm.parse.sepa.data;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.spark.evolmpm.parse.sepa.LoadOperationsSepaMain;
import org.spark.evolmpm.parse.sepa.constant.ParseSepaConstant;

import fr.bdf.bastid.util.bean.LineAcqFile;



public class ReadData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2993247359692712395L;
	
	private SparkSession sqlContext;
    //private String tsStart;
   // private String tsEnd;
    private String idAcq;
    private List<LineAcqFile> listIdAcq;
    private String lastPartition;
    
    /**
     * @param sqlContext
     * @param idAcqStart
     */
    public ReadData(SparkSession sqlContext, List<LineAcqFile> listIdAcq) {
        super();
        this.sqlContext = sqlContext;
       // this.tsStart = tsStart;
       // this.tsEnd = tsEnd;
        //this.idAcq = idAcq;
        this.listIdAcq = listIdAcq;
       
        
    }
    
    /**
     * Reads th70 table data, creates an unique id for each transaction, prepares the date_pec_amont column
     * @return Dataset<Row>
     */
    public String getLastPartition() {
    	return lastPartition = sqlContext.sql("select max(id_traitement)"
    			                              + " from " + ParseSepaConstant.HIVE_RAW_LAYER+"."+ParseSepaConstant.REF_OPE_TABLE ).
    			                              as(Encoders.STRING()).collectAsList().get(0);

    	 
    }
    
    public Dataset<Row> getSepaData(String lastPartition) {

    	this.lastPartition = lastPartition;
    	
    	String test_requ = "select concat(row_number() over (order by t3.date_insert),'" + listIdAcq.get(0).getIdAcq() + "')  as id_operation, "
                + "t3.rfopi,"
                + "t3.tyopec,"
                + "t3.seopec,"
                + "t3.ddops2,"
                + "t3.mtopa2,"
                + "t3.coops,"
                + "t3.cofamo,"
                + "t3.nuprm,"
                + "t3.coclc,"
                + "t3.idees4,"
                + "t3.idiba1,"
                + "t3.iddss2,"
                + "t3.idiba2,"
                + "t3.e8rme,"
                + "t3.ddpre,"
                + "t3.hepre,"
                + "t3.nurms1,"
                + "t3.ddpre1,"
                + "t3.hepre1,"
                + "t3.e8trav,"
                + "t3.idefe,"
                + "t3.xtimts,"
                + "t3.cocll,"
                + "t3.rfopsc,"
                + "t3.codoar,"
                + "t3.inopr,"
                + "t3.nopart,"
                + "t3.xpart1,"
                + "t3.xpartt,"
                + "t3.rfopso,"
                + "t3.rfeeso,"
                + "t3.idopso,"
                + "t3.dtjco,"
                + "t3.debemb,"
                + "t3.date_insert as date_insert, "
                + " 'TM' as type_enregistrement,"
                + "t3.id_type_ope "
                + " from ("+ "select t1.*, t2.id_type_ope"
                           + " from " + ParseSepaConstant.HIVE_RAW_LAYER+"."+ParseSepaConstant.TH70_TABLE + " t1"
                           + " left join " + ParseSepaConstant.HIVE_RAW_LAYER+"."+ParseSepaConstant.REF_OPE_TABLE + " t2"
                           + " on t1.coops=t2.code_ope where t2.sscode_ope='0000' and to_date(t1.ddops2) between t2.date_deb_val and t2.date_fin_val"
                           + " and t2.id_traitement='"+ lastPartition+ "') t3"                                                                  
                + this.getWhereClause(listIdAcq)
                + "   and t3.tyopec = 'S' "; 
    	 System.out.println("INFO:" + LoadOperationsSepaMain.getTime() + " test " + test_requ);
    	
	 	 
    	return sqlContext.sql("select concat(row_number() over (order by t3.date_insert),'" + listIdAcq.get(0).getIdAcq() + "')  as id_operation, "
               + "t3.rfopi,"
                + "t3.tyopec,"
                + "t3.seopec,"
                + "t3.ddops2,"
                + "t3.mtopa2,"
                + "t3.coops,"
                + "t3.cofamo,"
                + "t3.nuprm,"
                + "t3.coclc,"
                + "t3.idees4,"
                + "t3.idiba1,"
                + "t3.iddss2,"
                + "t3.idiba2,"
                + "t3.e8rme,"
                + "t3.ddpre,"
                + "t3.hepre,"
                + "t3.nurms1,"
                + "t3.ddpre1,"
                + "t3.hepre1,"
                + "t3.e8trav,"
                + "t3.idefe,"
                + "t3.xtimts,"
                + "t3.cocll,"
                + "t3.rfopsc,"
                + "t3.codoar,"
                + "t3.inopr,"
                + "t3.nopart,"
                + "t3.xpart1,"
                + "t3.xpartt,"
                + "t3.rfopso,"
                + "t3.rfeeso,"
                + "t3.idopso,"
                + "t3.dtjco,"
                + "t3.debemb,"
                + "t3.date_insert as date_insert, "
                + "t3.date_ope as date_ope,"
                + " 'TM' as type_enregistrement,"
                + "t3.id_type_ope "
                + " from ("+ "select t1.*, t2.id_type_ope"
                           + " from " + ParseSepaConstant.HIVE_RAW_LAYER+"."+ParseSepaConstant.TH70_TABLE + " t1"
                           + " left join " + ParseSepaConstant.HIVE_RAW_LAYER+"."+ParseSepaConstant.REF_OPE_TABLE + " t2"
                           + " on t1.coops=t2.code_ope where t2.sscode_ope='0000' and to_date(t1.ddops2) between t2.date_deb_val and t2.date_fin_val"
                           + " and t2.id_traitement='"+ lastPartition+ "') t3"                                                                  
                + this.getWhereClause(listIdAcq)
                + "   and t3.tyopec = 'S' ");	
    }
    /**
	 * Method that constructs the where part of the request.
	 * 
	 * @param listIdAcq
	 *            the list of id_acquisition / date_ope
	 * @return the where part of the request
	 */
	private String getWhereClause(List<LineAcqFile> listIdAcq) {
		StringBuilder sb = new StringBuilder(" WHERE (");
		for (LineAcqFile line : listIdAcq) {
//			sb.append(" (t3.dtjco = '").append(line.getJourFonc())
			sb.append(" (t3.date_ope = '").append(line.getJourFonc())
					.append("' AND t3.id_traitement = '").append(line.getIdAcq())
					.append("') OR");
		}

		System.out.println("INFO:" + "[" + new SimpleDateFormat("HH:mm:ss" ).format(new Date()) + "] - " 
				+ "getWhereClause : " + sb.substring(0, sb.length() - 3));

		return sb.substring(0, sb.length() - 3)+")";
	}   
}
