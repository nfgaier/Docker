package org.spark.evolmpm.parse.sepa.constant;

import java.io.Serializable;

public class ParseSepaConstant implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1802917498562728796L;
		
		//hive databases
	    public static final String HIVE_LAN_LAYER = "evolmpm_landing_layer";
	    public static final String HIVE_RAW_LAYER = "evolmpm_raw_layer";	    
	    public static final String HIVE_WRK_LAYER = "evolmpm_work_layer";
	    
	    // evolmpm data tables
	    public static final String TH70_TABLE = "th70";
	    public static final String TH7A_TABLE = "th7a";
	    
	    // referentiels $ target table
	    public static final String REF_OPE_TABLE = "ref_type_operation";
	    public static final String REF_CLI = "ref_client";
	    public static final String REF_CMP = "ref_compte";
	    public static final String TARGET_SEPA_TABLE = "operations_sepa";
	    
	    // HDFS path
	    public static final String SEPA_HDFS_PATH_ROOT = "/data/source/";
	    public static final String SEPA_HDFS_PATH_TABLE = "/work_layer/operations_sepa";
	  

}


