package org.spark.evolmpm.parse.sepa.functions;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;

import org.w3c.dom.Element;

public class ParseXMLSepaSDD {

	/**
	 * Constructeur vide
	 */
	public ParseXMLSepaSDD() {

	}


	public String getTagNUM_ICS(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DrctDbtTx/CdtrSchmeID/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagPMTID_TXID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/PmtId/TxId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagPMTID_INSTRID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/PmtId/InstrId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagPMTID_ENDTOENDID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/PmtId/EndToEndId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagPMTTPI_SVCLVL_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/PmtTpInf/SvcLvl/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagPMTTPI_LCLINS_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/PmtTpInf/LclInstrm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagPMTTPILCLINS_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/PmtTpInf/LclInstrm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagPMTTPI_SEQTP(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/PmtTpInf/SeqTp";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagPMTTPI_CTGYPURP(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/PmtTpInf/CtgyPurp/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagINTRBKSTTLMAMT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/IntrBkSttlmAmt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagINTRBKSTTLMAMTC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/IntrBkSttlmAmt/@Ccy";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}
	
	public String getTagCHRGBR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/ChrgBr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagREQDCOLLTNDT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/ReqdColltnDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagM_MNDTID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DrctDbtTx/MndtRltdInf/MndtId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagM_DTOFSGNTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DrctDbtTx/MndtRltdInf/DtOfSgntr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagM_AMDMNTIND(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DrctDbtTx/MndtRltdInf/AmdmntInd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagM_A_ORGNLMNDTID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DrctDbtTx/MndtRltdInf/AmdmntInfDtls/OrgnlMndtId";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagM_A_S_NM(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DrctDbtTx/MndtRltdInf/AmdmntInfDtls/OrgnlCdtrSchmeId/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagM_A_S_ID_PROID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DrctDbtTx/MndtRltdInf/AmdmntInfDtls/OrgnlCdtrSchmeId/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagM_A_S_ID_PRO_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DrctDbtTx/MndtRltdInf/AmdmntInfDtls/OrgnlCdtrSchmeId/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagM_A_S_ID_PRO_SCH_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DrctDbtTx/MndtRltdInf/AmdmntInfDtls/OrgnlCdtrSchmeId/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagM_A_S_ID_PRO_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DrctDbtTx/MndtRltdInf/AmdmntInfDtls/OrgnlCdtrSchmeId/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagM_A_ODAC_ID_IBAN(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DrctDbtTx/MndtRltdInf/AmdmntInfDtls/OrgnlDbtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagM_A_ODAG_FI_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DrctDbtTx/MndtRltdInf/AmdmntInfDtls/OrgnlDbtrAgt/FinInstnId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagM_ELCTRNCSGNT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DrctDbtTx/MndtRltdInf/ElctrncSgntr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagCSCH_IDPROI(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DrctDbtTx/CdtrSchmeId/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagCSCH_IDPROI_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DrctDbtTx/CdtrSchmeId/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagCSCH_IDPROI_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DrctDbtTx/CdtrSchmeId/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagCSCH_IDPROI_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DrctDbtTx/CdtrSchmeId/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUCDT_NAME(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtCdtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUCDT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtCdtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUCDT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtCdtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUCDT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtCdtr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUCDT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtCdtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUCDT_ID_ORG_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtCdtr/Id/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUCDT_ID_PR_DPBI_DA(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUCDT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUCDT_ID_PR_DPBI_CT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUCDT_ID_PR_DPBI_CR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUCDT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtCdtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUCDT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtCdtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUCDT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtCdtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUCDT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtCdtr/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagDBT_NAME(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Dbtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagDBT_PADR_ADRLINE(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Dbtr/PstlAdr/AdrLine";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagDBT_PADR_CTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Dbtr/PstlAdr/Ctry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagDBT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Dbtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagDBT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Dbtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagDBT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Dbtr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagDBT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Dbtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagDBT_ID_ORG_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Dbtr/Id/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagDBT_ID_PR_DPBI_DAT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Dbtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagDBT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Dbtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagDBT_ID_PR_DPBI_CTY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Dbtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagDBT_ID_PR_DPBI_CR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Dbtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagDBT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Dbtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagDBT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Dbtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagDBT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Dbtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagDBT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Dbtr/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagDBTACC_ID_IBAN(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DbtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagDBTAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DbtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagCDTACC_ID_IBAN(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT//DrctDbtTxInf/CdtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagCDTAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/CdtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagCDT_NAME(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Cdtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagCDT_PADR_ADRLINE(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Cdtr/PstlAdr/AdrLine";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagCDT_PADR_CTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Cdtr/PstlAdr/Ctry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUDBT_NAME(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtDbtr/Nm";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUDBT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtDbtr/Id/OrgId/BICOrBEI";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUDBT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtDbtr/Id/OrgId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUDBT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtDbtr/Id/OrgId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUDBT_ID_ORG_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtDbtr/Id/OrgId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUDBT_ID_ORG_OTHR_SCH_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtDbtr/Id/OrgId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUDBT_ID_PR_DPBI_DAT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUDBT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUDBT_ID_PR_DPBI_CTY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUDBT_ID_PR_DPBI_CRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUDBT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtDbtr/Id/PrvtId/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUDBT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtDbtr/Id/PrvtId/Othr/SchmeNm/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUDBT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtDbtr/Id/PrvtId/Othr/SchmeNm/Prtry";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagUDBT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/UltmtDbtr/Id/PrvtId/Othr/Issr";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagINSGAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/InstgAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagINSDAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/InstdAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagRMTINF_USTRD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/RmtInf/Ustrd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagRMTINF_STRD_TYPE_CODE(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/RmtInf/Strd/CdtrRefInf/Tp/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagRMTINF_STRD_TYPE_REF(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/RmtInf/Strd/CdtrRefInf/Ref";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagPUR_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/Purp/Cd";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagBIC_ID_Debitor(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/CdtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagBIC_ID_Creditor(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DbtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagIBAN_DEBTOR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DbtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagIBAN_CREDITOR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/PmtInf/CdtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagM_A_ODAC_V9_ID_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/MndtRltdInf/AmdmntInfDtls/OrgnlDbtrAcct/Othr/Id";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagM_A_ODAC_V9_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/MndtRltdInf/AmdmntInfDtls/OrgnlDbtrAgt/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagBIC_ID_DO(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/CdtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagIBAN_DO(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/PmtInf/CdtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagBIC_ID_BENEFICIAIRE(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DbtrAgt/FinInstnId/BIC";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	public String getTagIBAN_BENEFICIAIRE(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/DrctDbtTxInf/DbtrAcct/Id/IBAN";
		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

}
