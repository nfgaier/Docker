package org.spark.evolmpm.parse.sepa.functions;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;

import org.w3c.dom.Element;

public class ParseXMLSepaSDD681 {

	/**
	 * Constructeur vide.
	 */
	public ParseXMLSepaSDD681() {

	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagNUM_ICS(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/CdtrSchmeId/Id/PrvtId/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagMOTIF_REJET_ANNULATION(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/StsRsnInf/Rsn/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagPMTID_TXID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/StsId";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagPMTTPI_SVCLVL_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/PmtTpInf/SvcLvl/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagPMTTPI_LCLINS_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/PmtTpInf/LclInstrm/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagPMTTPILCLINS_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/PmtTpInf/LclInstrm/Prtry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagPMTTPI_SEQTP(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/PmtTpInf/SeqTp";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagPMTTPI_CTGYPURP(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/PmtTpInf/CtgyPurp/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagCHRGINF_AMT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/StsRsnInf/ChrgsInf/Amt";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagCHRGINF_AMTC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/StsRsnInf/ChrgsInf/Amt/@Ccy";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagCHRGINF_PTY_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/StsRsnInf/ChrgsInf/Pty";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagM_MNDTID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/MndtRltdInf/MndtId";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagM_DTOFSGNTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/MndtRltdInf/DtOfSgntr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagM_AMDMNTIND(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/MndtRltdInf/AmdmntInd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagM_A_ORGNLMNDTID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/MndtRltdInf/AmdmntInfDtls/OrgnlMndtId";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagM_A_S_NM(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/MndtRltdInf/AmdmntInfDtls/OrgnlCdtrSchmeId/Nm";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagM_A_S_ID_PROID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/MndtRltdInf/AmdmntInfDtls/OrgnlCdtrSchmeId/Id/PrvtId/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagM_A_S_ID_PRO_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/MndtRltdInf/AmdmntInfDtls/OrgnlCdtrSchmeId/Id/PrvtId/Othr/SchmeNm/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagM_A_S_ID_PRO_SCH_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/MndtRltdInf/AmdmntInfDtls/OrgnlCdtrSchmeId/Id/PrvtId/Othr/Id/SchmeNm/Prtry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagM_A_S_ID_PRO_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/MndtRltdInf/AmdmntInfDtls/OrgnlCdtrSchmeId/Id/PrvtId/Othr/Issr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagM_A_ODAC_ID_IBAN(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/MndtRltdInf/AmdmntInfDtls/OrgnlDbtrAcct/Id/IBAN";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagM_A_ODAG_FI_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/MndtRltdInf/AmdmntInfDtls/OrgnlDbtrAgt/FinInstnId/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagM_ELCTRNCSGNT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/MndtRltdInf/ElctrncSgntr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUCDT_NAME(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Nm";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUCDT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/OrgId/BICOrBEI";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUCDT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUCDT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/SchmeNm/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUCDT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/SchmeNm/Prtry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUCDT_ID_ORG_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/OrgId/Othr/Issr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUCDT_ID_PR_DPBI_DA(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUCDT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUCDT_ID_PR_DPBI_CT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUCDT_ID_PR_DPBI_CR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUCDT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUCDT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/SchmeNm/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUCDT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/SchmeNm/Prtry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUCDT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtCdtr/Id/PrvtId/Othr/Issr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagDBT_NAME(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/Nm";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagDBT_PADR_ADRLINE(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/AdrLine";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagDBT_PADR_CTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/PstlAdr/Ctry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagDBT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/Id/OrgId/BICOrBEI";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagDBT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/Id/OrgId/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagDBT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/Id/OrgId/Othr/SchmeNm/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagDBT_ID_ORG_OTHR_SCH_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/Id/OrgId/Othr/SchmeNm/Prtry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagDBT_ID_ORG_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/Id/OrgId/Othr/Issr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagDBT_ID_PR_DPBI_DAT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagDBT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagDBT_ID_PR_DPBI_CTY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagDBT_ID_PR_DPBI_CR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagDBT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagDBT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/SchmeNm/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagDBT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/SchmeNm/Issr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagDBT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Dbtr/Id/PrvtId/Othr/Issr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagDBTACC_ID_IBAN(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/DbtrAcct/Id/IBAN";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagDBTAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/DbtrAgt/FinInstnId/BIC";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagCDTACC_ID_IBAN(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/CdtrAcct/Id/IBAN";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagCDTAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/CdtrAgt/FinInstnId/BIC";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagCDT_NAME(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Cdtr/Nm";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagCDT_PADR_ADRLINE(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Cdtr/PstlAdr/AdrLine";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagCDT_PADR_CTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/Cdtr/PstlAdr/Ctry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUDBT_NAME(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Nm";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUDBT_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/OrgId/BICOrBEI";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUDBT_ID_ORG_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUDBT_ID_ORG_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/SchmeNm/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUDBT_ID_ORG_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/SchmeNm/Prtry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUDBT_ID_ORG_OTHR_SCH_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/OrgId/Othr/Issr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUDBT_ID_PR_DPBI_DAT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/BirthDt";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUDBT_ID_PR_DPBI_PRV(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/PrvcOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUDBT_ID_PR_DPBI_CTY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/CityOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUDBT_ID_PR_DPBI_CRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/DtAndPlcOfBirth/CtryOfBirth";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUDBT_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUDBT_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/SchmeNm/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUDBT_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/SchmeNm/Prtry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagUDBT_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/UltmtDbtr/Id/PrvtId/Othr/Issr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagINSGAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/InstgAgt/FinInstnId/BIC";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagINSDAGT_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/InstdAgt/FinInstnId/BIC";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagRMTINF_USTRD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/RmtInf/Ustrd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagRMTINF_STRD_TYPE_CODE(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/RmtInf/Strd/CdtrRefInf/Tp/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagRMTINF_STRD_TYPE_REF(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/RmtInf/Strd/CdtrRefInf/Ref";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagORGNLTXID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxId";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagORGNLINSTRID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlInstrId";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagORGNLENDTOENDID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlEndToEndId";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagTXSTS(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/TxSts";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagORGNLINTRBKSTTLMAMT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/IntrBkSttlmAmt";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagORGNLINTRBKSTTLMAMTC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/IntrBkSttlmAmt/@Ccy";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagOTR_INTRBKSTTLMDT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/IntrBkSttlmDt";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagRI_RORG_NAME(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/StsRsnInf/Orgtr/Nm";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagRI_RORG_ID_ORG_BIC_BEI(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/StsRsnInf/Orgtr/Id/OrgId/BICOrBEI";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagRI_RSN_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/StsRsnInf/Rsn/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagRI_SN_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/StsRsnInf/Rsn/Prtry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagOTR_REQDCOLLTNDT(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/ReqdColltnDt";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagOTR_CSCH_ID_PRV_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/CdtrSchmeId/Id/PrvtId/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagOTR_CSCH_ID_PRV_OTHR_SCH_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/CdtrSchmeId/Id/PrvtId/Othr/SchmeNm/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagOTR_CSCH_ID_PRV_OTHR_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/CdtrSchmeId/Id/PrvtId/Othr/Issr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagOTR_CSCH_ID_PRV_OTHR_SCH_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/CdtrSchmeId/Id/PrvtId/Othr/SchmeNm/Prtry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagOTR_STTI_STTLMMTD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/SttlmInf/SttlmMtd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagOTR_STTI_STTAID_IBAN(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/SttlmInf/SttlmAcct/Id/IBAN";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagOTR_STTI_STTAID_O_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagOTR_STTI_STTAID_O_SN_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/SchmeNm/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagOTR_STTI_STTAID_O_SN_PRTR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/SchmeNm/Prtry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagOTR_STTI_STTAID_O_ISSR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/SttlmInf/SttlmAcct/Id/Othr/Issr";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagOTR_STTI_CLRS_CD(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/SttlmInf/ClrSys/Cd";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagOTR_STTI_CLRS_PRTRY(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/SttlmInf/ClrSys/Prtry";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagBIC_ID_Debitor(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/DbtrAgt/FinInstnId/BIC";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagBIC_ID_Creditor(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/CdtrAgt/FinInstnId/BIC";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagREF_OPERATION_ORIGINE(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxId";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagIBAN_DEBTOR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/DbtrAcct/Id/IBAN";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagIBAN_CREDITOR(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/CdtrAcct/Id/IBAN";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagM_A_ODAC_V9_ID_OTHR_ID(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/MndtRltdInf/AmdmntInfDtls/OrgnlDbtrAcct/Othr/Id";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagM_A_ODAC_V9_FI_BIC(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/MndtRltdInf/AmdmntInfDtls/OrgnlDbtrAgt/FinInstnId/BIC";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagBIC_ID_DO(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/DbtrAgt/FinInstnId/BIC";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagIBAN_DO(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/DbtrAcct/Id/IBAN";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagBIC_ID_BENEFICIAIRE(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/CdtrAgt/FinInstnId/BIC";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

	/**
	 * @param path
	 * @param root
	 * @return
	 * @throws XPathExpressionException
	 */
	public String getTagIBAN_BENEFICIAIRE(XPath path, Element root) throws XPathExpressionException {
		String expr = "/XPARTT/TxInfAndSts/OrgnlTxRef/CdtrAcct/Id/IBAN";

		return (String) path.evaluate(expr, root, XPathConstants.STRING);
	}

}
