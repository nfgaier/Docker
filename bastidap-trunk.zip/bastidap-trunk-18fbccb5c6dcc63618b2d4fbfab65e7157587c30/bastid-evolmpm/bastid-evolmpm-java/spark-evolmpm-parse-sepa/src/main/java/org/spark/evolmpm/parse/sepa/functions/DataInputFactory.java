package org.spark.evolmpm.parse.sepa.functions;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Row;
import org.spark.evolmpm.parse.sepa.beans.DataInputBean;
import org.spark.evolmpm.parse.sepa.utils.UtilFunctions;



public class DataInputFactory extends AbstractFactory implements Function<Row, DataInputBean>, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3358106157918729871L;
	
	
	@Override
	public DataInputBean call(Row v1) throws Exception {
		// TODO Auto-generated method stub
		

		DataInputBean inputBean = new DataInputBean();
        
//		inputBean.setId_operation(SomeFunctions.getString(v1.getAs("id_operation")));
//		inputBean.setCode_operation(SomeFunctions.getString(v1.getAs("code_operation")));
//		inputBean.setCode_client_conventionne(SomeFunctions.getString(v1.getAs("code_client_conventionne")));
//		inputBean.setId_systeme_echange(SomeFunctions.getString(v1.getAs("id_systeme_echange")));
//		inputBean.setIban_debitor_sr(SomeFunctions.getString(v1.getAs("iban_debitor_sr")));
//		inputBean.setBic_id_debitor_sr(SomeFunctions.getString(v1.getAs("bic_id_debitor_sr")));
//		inputBean.setBic_id_creditor_sr(SomeFunctions.getString(v1.getAs("bic_id_creditor_sr")));
//		inputBean.setIban_creditor_sr(SomeFunctions.getString(v1.getAs("iban_creditor_sr")));
//		inputBean.setCode_famille_operation(SomeFunctions.getString(v1.getAs("code_famille_operation")));
//		inputBean.setType_operation(SomeFunctions.getString(v1.getAs("type_operation")));
//		inputBean.setSens_echange(SomeFunctions.getString(v1.getAs("sens_echange")));
//		inputBean.setNum_remise(SomeFunctions.getString(v1.getAs("num_remise")));
//		inputBean.setNum_remise_tech(SomeFunctions.getString(v1.getAs("num_remise_tech")));
//		inputBean.setDate_pec_amont(SomeFunctions.getDateTimestamp(v1.getAs("date_pec_amont")));
//		inputBean.setHeure_pec_amont(SomeFunctions.getString(v1.getAs("heure_pec_amont")));
//		inputBean.setDate_presentation_remise(SomeFunctions.getDateTimestamp(v1.getAs("date_presentation_remise")));
//		inputBean.setHeure_presentation_remise(SomeFunctions.getString(v1.getAs("heure_presentation_remise")));
//		inputBean.setRio(SomeFunctions.getString(v1.getAs("rio")));
//		inputBean.setDate_echange(SomeFunctions.getDateSql(v1.getAs("date_echange")));
//		inputBean.setDate_reglement(SomeFunctions.getDateSql(v1.getAs("date_reglement")));
//		inputBean.setDate_traitement_aval_recu(SomeFunctions.getDateSql(v1.getAs("date_traitement_aval_recu")));
//		inputBean.setEtblt_concerne(SomeFunctions.getString(v1.getAs("etblt_concerne")));
//		inputBean.setInd_rejet(SomeFunctions.getString(v1.getAs("ind_rejet")));
//		inputBean.setFlag_debrayage_embargo(SomeFunctions.getString(v1.getAs("flag_debrayage_embargo")));
//		inputBean.setXtimts(SomeFunctions.getDateTimestamp(v1.getAs("xtimts")));
//		inputBean.setRef_operation_origine(SomeFunctions.getString(v1.getAs("ref_operation_origine")));
//		inputBean.setDate_comptable_evolmpm(SomeFunctions.getDateSql(v1.getAs("date_comptable_evolmpm")));
//		inputBean.setPmtid_txid_src(SomeFunctions.getString(v1.getAs("pmtid_txid_src")));
//		inputBean.setMnt_compense_sit(v1.getAs("mnt_compense_sit"));
//		inputBean.setCode_flux_arch(SomeFunctions.getString(v1.getAs("code_flux_arch")));
//		inputBean.setNum_partition(SomeFunctions.getString(v1.getAs("num_partition")));
//		inputBean.setOrgnltxid_src(SomeFunctions.getString(v1.getAs("orgnltxid_src")));
//		inputBean.setType_enregistrement(SomeFunctions.getString(v1.getAs("type_enregistrement")));
//		inputBean.setOrgnlinstrid_src(SomeFunctions.getString(v1.getAs("orgnlinstrid_src")));
//		inputBean.setOrgnlendtoendid_src(SomeFunctions.getString(v1.getAs("orgnlendtoendid_src")));
//		//inputBean.setDelai_reglement(1);
//		inputBean.setDelai_reglement(SomeFunctions.getInteger(v1.getAs("delai_reglement")));
//		inputBean.setIban_do_sr(SomeFunctions.getString(v1.getAs("iban_do_sr")));
//		inputBean.setBic_id_do_sr(SomeFunctions.getString(v1.getAs("bic_id_do_sr")));
//		inputBean.setBic_id_beneficiaire_sr(SomeFunctions.getString(v1.getAs("bic_id_beneficiaire_sr")));
//		inputBean.setIban_beneficiaire_sr(SomeFunctions.getString(v1.getAs("iban_beneficiaire_sr")));
//		inputBean.setCode_pays_do_sr(SomeFunctions.getString(v1.getAs("code_pays_do_sr")));
//		inputBean.setCle_iban_do_sr(SomeFunctions.getString(v1.getAs("cle_iban_do_sr")));
//		inputBean.setCode_banque_do_sr(SomeFunctions.getString(v1.getAs("code_banque_do_sr")));
//		inputBean.setCode_guichet_do_sr(SomeFunctions.getString(v1.getAs("code_guichet_do_sr")));
//		inputBean.setNum_cpte_do_sr(SomeFunctions.getString(v1.getAs("num_cpte_do_sr")));
//		inputBean.setCle_rib_do_sr(SomeFunctions.getString(v1.getAs("cle_rib_do_sr")));
//		inputBean.setCode_pays_beneficiaire_sr(SomeFunctions.getString(v1.getAs("code_pays_beneficiaire_sr")));
//		inputBean.setCle_iban_beneficiaire_sr(SomeFunctions.getString(v1.getAs("cle_iban_beneficiaire_sr")));
//		inputBean.setCode_banque_beneficiaire_sr(SomeFunctions.getString(v1.getAs("code_banque_beneficiaire_sr")));
//		inputBean.setCode_guichet_beneficiaire_sr(SomeFunctions.getString(v1.getAs("code_guichet_beneficiaire_sr")));
//		inputBean.setNum_cpte_beneficiaire_sr(SomeFunctions.getString(v1.getAs("num_cpte_beneficiaire_sr")));
//		inputBean.setCle_rib_beneficiaire_sr(SomeFunctions.getString(v1.getAs("cle_rib_beneficiaire_sr")));
//		inputBean.setCode_pays_debitor_sr(SomeFunctions.getString(v1.getAs("code_pays_debitor_sr")));
//		inputBean.setCle_iban_debitor_sr(SomeFunctions.getString(v1.getAs("cle_iban_debitor_sr")));
//		inputBean.setCode_banque_debitor_sr(SomeFunctions.getString(v1.getAs("code_banque_debitor_sr")));
//		inputBean.setCode_guichet_debitor_sr(SomeFunctions.getString(v1.getAs("code_guichet_debitor_sr")));
//		inputBean.setNum_cpte_debitor_sr(SomeFunctions.getString(v1.getAs("num_cpte_debitor_sr")));
//		inputBean.setCle_rib_debitor_sr(SomeFunctions.getString(v1.getAs("cle_rib_debitor_sr")));
//		inputBean.setCode_pays_creditor_sr(SomeFunctions.getString(v1.getAs("code_pays_creditor_sr")));
//		inputBean.setCle_iban_creditor_sr(SomeFunctions.getString(v1.getAs("cle_iban_creditor_sr")));
//		inputBean.setCode_banque_creditor_sr(SomeFunctions.getString(v1.getAs("code_banque_creditor_sr")));
//		inputBean.setCode_guichet_creditor_sr(SomeFunctions.getString(v1.getAs("code_guichet_creditor_sr")));
//		inputBean.setNum_cpte_creditor_sr(SomeFunctions.getString(v1.getAs("num_cpte_creditor_sr")));
//		inputBean.setCle_rib_creditor_sr(SomeFunctions.getString(v1.getAs("cle_rib_creditor_sr")));
//		inputBean.setDate_insert(SomeFunctions.getDateSql(v1.getAs("date_insert")));
//		inputBean.setId_type_operation(SomeFunctions.getInteger(v1.getAs("id_type_operation")));
//		inputBean.setId_client(SomeFunctions.getInteger(v1.getAs("id_client")));
//		inputBean.setCode_grp_remettant(SomeFunctions.getString(v1.getAs("code_grp_remettant")));
//		inputBean.setLib_grp_remettant(SomeFunctions.getString(v1.getAs("lib_grp_remettant")));
//		inputBean.setId_ics(SomeFunctions.getInteger(v1.getAs("id_ics")));
//		inputBean.setId_compte_do_sr(SomeFunctions.getInteger(v1.getAs("id_compte_do_sr")));
//		inputBean.setId_client_do_sr(SomeFunctions.getInteger(v1.getAs("id_client_do_sr")));
//		inputBean.setId_compte_beneficiaire_sr(SomeFunctions.getInteger(v1.getAs("id_compte_beneficiaire_sr")));
//		inputBean.setId_client_beneficiaire_sr(SomeFunctions.getInteger(v1.getAs("id_client_beneficiaire_sr")));
//		inputBean.setId_traitement(SomeFunctions.getString(v1.getAs("id_traitement")));
		
		
		
		inputBean.setId_operation(getString(v1.getAs("id_operation")));
		inputBean.setCode_operation(getString(v1.getAs("code_operation")));
		inputBean.setCode_client_conventionne(getString(v1.getAs("code_client_conventionne")));
		inputBean.setId_systeme_echange(getString(v1.getAs("id_systeme_echange")));
		inputBean.setIban_debitor_sr(getString(v1.getAs("iban_debitor_sr")));
		inputBean.setBic_id_debitor_sr(getString(v1.getAs("bic_id_debitor_sr")));
		inputBean.setBic_id_creditor_sr(getString(v1.getAs("bic_id_creditor_sr")));
		inputBean.setIban_creditor_sr(getString(v1.getAs("iban_creditor_sr")));
		inputBean.setCode_famille_operation(getString(v1.getAs("code_famille_operation")));
		inputBean.setType_operation(getString(v1.getAs("type_operation")));
		inputBean.setSens_echange(getString(v1.getAs("sens_echange")));
		inputBean.setNum_remise(getString(v1.getAs("num_remise")));
		inputBean.setNum_remise_tech(getString(v1.getAs("num_remise_tech")));
		inputBean.setDate_pec_amont(getDateTimestamp(v1.getAs("date_pec_amont")));
		inputBean.setHeure_pec_amont(getString(v1.getAs("heure_pec_amont")));
		inputBean.setDate_presentation_remise(getDateTimestamp(v1.getAs("date_presentation_remise")));
		inputBean.setHeure_presentation_remise(getString(v1.getAs("heure_presentation_remise")));
		inputBean.setRio(getString(v1.getAs("rio")));
		inputBean.setDate_echange(getDateSql(v1.getAs("date_echange")));
		inputBean.setDate_reglement(getDateSql(v1.getAs("date_reglement")));
		inputBean.setDate_traitement_aval_recu(getDateSql(v1.getAs("date_traitement_aval_recu")));
		inputBean.setEtblt_concerne(getString(v1.getAs("etblt_concerne")));
		inputBean.setInd_rejet(getString(v1.getAs("ind_rejet")));
		inputBean.setFlag_debrayage_embargo(getString(v1.getAs("flag_debrayage_embargo")));
		inputBean.setXtimts(getDateTimestamp(v1.getAs("xtimts")));
		inputBean.setRef_operation_origine(getString(v1.getAs("ref_operation_origine")));
		inputBean.setDate_comptable_evolmpm(getDateSql(v1.getAs("date_comptable_evolmpm")));
		inputBean.setPmtid_txid_src(getString(v1.getAs("pmtid_txid_src")));
		inputBean.setMnt_compense_sit(v1.getAs("mnt_compense_sit"));
		inputBean.setCode_flux_arch(getString(v1.getAs("code_flux_arch")));
		inputBean.setNum_partition(getString(v1.getAs("num_partition")));
		inputBean.setOrgnltxid_src(getString(v1.getAs("orgnltxid_src")));
		inputBean.setType_enregistrement(getString(v1.getAs("type_enregistrement")));
		inputBean.setOrgnlinstrid_src(getString(v1.getAs("orgnlinstrid_src")));
		inputBean.setOrgnlendtoendid_src(getString(v1.getAs("orgnlendtoendid_src")));
		//inputBean.setDelai_reglement(1);
		inputBean.setDelai_reglement(getInteger(v1.getAs("delai_reglement")));
		inputBean.setIban_do_sr(getString(v1.getAs("iban_do_sr")));
		inputBean.setBic_id_do_sr(getString(v1.getAs("bic_id_do_sr")));
		inputBean.setBic_id_beneficiaire_sr(getString(v1.getAs("bic_id_beneficiaire_sr")));
		inputBean.setIban_beneficiaire_sr(getString(v1.getAs("iban_beneficiaire_sr")));
		inputBean.setCode_pays_do_sr(getString(v1.getAs("code_pays_do_sr")));
		inputBean.setCle_iban_do_sr(getString(v1.getAs("cle_iban_do_sr")));
		inputBean.setCode_banque_do_sr(getString(v1.getAs("code_banque_do_sr")));
		inputBean.setCode_guichet_do_sr(getString(v1.getAs("code_guichet_do_sr")));
		inputBean.setNum_cpte_do_sr(getString(v1.getAs("num_cpte_do_sr")));
		inputBean.setCle_rib_do_sr(getString(v1.getAs("cle_rib_do_sr")));
		inputBean.setCode_pays_beneficiaire_sr(getString(v1.getAs("code_pays_beneficiaire_sr")));
		inputBean.setCle_iban_beneficiaire_sr(getString(v1.getAs("cle_iban_beneficiaire_sr")));
		inputBean.setCode_banque_beneficiaire_sr(getString(v1.getAs("code_banque_beneficiaire_sr")));
		inputBean.setCode_guichet_beneficiaire_sr(getString(v1.getAs("code_guichet_beneficiaire_sr")));
		inputBean.setNum_cpte_beneficiaire_sr(getString(v1.getAs("num_cpte_beneficiaire_sr")));
		inputBean.setCle_rib_beneficiaire_sr(getString(v1.getAs("cle_rib_beneficiaire_sr")));
		inputBean.setCode_pays_debitor_sr(getString(v1.getAs("code_pays_debitor_sr")));
		inputBean.setCle_iban_debitor_sr(getString(v1.getAs("cle_iban_debitor_sr")));
		inputBean.setCode_banque_debitor_sr(getString(v1.getAs("code_banque_debitor_sr")));
		inputBean.setCode_guichet_debitor_sr(getString(v1.getAs("code_guichet_debitor_sr")));
		inputBean.setNum_cpte_debitor_sr(getString(v1.getAs("num_cpte_debitor_sr")));
		inputBean.setCle_rib_debitor_sr(getString(v1.getAs("cle_rib_debitor_sr")));
		inputBean.setCode_pays_creditor_sr(getString(v1.getAs("code_pays_creditor_sr")));
		inputBean.setCle_iban_creditor_sr(getString(v1.getAs("cle_iban_creditor_sr")));
		inputBean.setCode_banque_creditor_sr(getString(v1.getAs("code_banque_creditor_sr")));
		inputBean.setCode_guichet_creditor_sr(getString(v1.getAs("code_guichet_creditor_sr")));
		inputBean.setNum_cpte_creditor_sr(getString(v1.getAs("num_cpte_creditor_sr")));
		inputBean.setCle_rib_creditor_sr(getString(v1.getAs("cle_rib_creditor_sr")));
		inputBean.setDate_insert(getDateSql(v1.getAs("date_insert")));
		inputBean.setDate_ope(getDateSql(v1.getAs("date_ope")));
		inputBean.setId_type_operation(getInteger(v1.getAs("id_type_operation")));
		inputBean.setId_client(getInteger(v1.getAs("id_client")));
		inputBean.setCode_grp_remettant(getString(v1.getAs("code_grp_remettant")));
		inputBean.setLib_grp_remettant(getString(v1.getAs("lib_grp_remettant")));
		inputBean.setId_ics(getInteger(v1.getAs("id_ics")));
		inputBean.setId_compte_do_sr(getInteger(v1.getAs("id_compte_do_sr")));
		inputBean.setId_client_do_sr(getInteger(v1.getAs("id_client_do_sr")));
		inputBean.setId_compte_beneficiaire_sr(getInteger(v1.getAs("id_compte_beneficiaire_sr")));
		inputBean.setId_client_beneficiaire_sr(getInteger(v1.getAs("id_client_beneficiaire_sr")));
		inputBean.setXpartt(getString(v1.getAs("xpartt")));
		inputBean.setId_traitement(getString(v1.getAs("id_traitement")));
		
		return inputBean;
		
	}

}
