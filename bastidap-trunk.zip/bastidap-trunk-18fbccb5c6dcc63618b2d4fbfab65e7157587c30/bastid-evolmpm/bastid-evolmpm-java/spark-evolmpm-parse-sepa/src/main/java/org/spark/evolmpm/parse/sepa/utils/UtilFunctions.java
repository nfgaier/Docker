package org.spark.evolmpm.parse.sepa.utils;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
//import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.SparkSession;

import org.spark.evolmpm.parse.sepa.beans.OperationSepaBean;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;


public class UtilFunctions {	
//
//	/**
//	 * DateDiff -- compute the difference between two dates.
//	 */
//	public static int DateDiff (Date dt1, Date dt2) {		
//	    
//	    // Get msec from each, ansd subtract.
//		if (dt2 != null && dt1 != null && dt2.after(dt1)) {
//		       return toIntExact(dt2.getTime() - dt1.getTime());
//		} else if (dt2 != null && dt1 != null && dt2.equals(dt1)) {
//			   return (Integer) null;
//		}
//		return (Integer) null; 
//		
//	}
//		
	/* add 5 days
	private void add5Day(OperationSepaBean operationSepa, Date datePre) {
		java.sql.Date maDate = null;
		if(datePre != null) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(datePre);
			cal.set(Calendar.DATE, 5);
			maDate = new java.sql.Date(cal.getTime().getTime());
		}
		return maDate;
	}  */
	
	
	public static boolean useList(List<String> arr, String targetValue){
		return Arrays.asList(arr).contains(targetValue);
	}
	
	public static String getString(Object obj) {
		if (obj == null) {
			return null;
		}
			return obj.toString();
		}
	
	
	/**public static Integer getInteger(String myIntegerToString) {
		if (StringUtils.isNotEmpty(myIntegerToString) && StringUtils.isNumeric(myIntegerToString)){
			return new Integer(myIntegerToString);
		} 
		return null;		  
	}*/
	public static Integer getInteger(Object obj) {
		if(obj == null) {
			return null;
		}
		return new Integer(obj.toString());
		
	}
	
	/** conversion d'un object en Double
	 * @param obj
	 * @return double
	 */
	public static Double getDouble(Object obj) {
	
		if (StringUtils.isNotBlank(obj.toString())) {
			return Double.parseDouble(obj.toString());
		} else {
			return null;
			
		}
	}
	
	/**
	 * Concatenation de la date de presentation
	 * @param datePresentation
	 * @param heurePresentation
	 * @return java.sql.Timestamp au format yyyy-MM-dd hh:mm:ss
	 * @throws ParseException
	 */
	public static java.sql.Timestamp concatDateHeure(java.sql.Date datePresentation, String heurePresentation )
			throws ParseException {
		if(datePresentation != null) {
			final String hour = StringUtils.substring(heurePresentation, 0,2);
			final String minute = StringUtils.substring(heurePresentation, 2,4);
			final String second = StringUtils.substring(heurePresentation, 4,6);
			
			final SimpleDateFormat formatter = new SimpleDateFormat("YYYY-MM-DD");				
			
			final StringBuilder dateBuilder = new StringBuilder();
			dateBuilder.append(formatter.format(new Date(datePresentation.getTime())))
			.append(" ").append(hour)
			.append(":").append(minute)
			.append(":").append(second);
			
			return getDateTime(dateBuilder.toString());
					
		}
		return null;
		
	}

	/**
	 * @param obj
	 * @return java.sql.Timestamp
	 * @throws ParseException
	 */
	public static java.sql.Timestamp getDateTime(Object obj) throws ParseException {
		if (obj != null) {
		    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		    Date parsedTimeStamp = (Date) dateFormat.parse(obj.toString());
		    return new Timestamp(parsedTimeStamp.getTime());    
	    }
		return null; 
	}
	
	public static java.sql.Date getDateSql(Object obj) {
		if (obj == null) {
			return null;
		} else if (StringUtils.isBlank(obj.toString())) {
			return null;
		} else {
			try {
				java.sql.Date dateSql = null;
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				format.setLenient(Boolean.FALSE);
				final java.util.Date dateUtil = format.parse(obj.toString());
				if (dateUtil != null) {
					dateSql = new java.sql.Date(dateUtil.getTime());
				}
				return dateSql;
			} catch (ParseException e) {
				e.printStackTrace();
				return null;
			}
		}
	}
	
	/**
	public static Dataset<org.apache.spark.sql.Row> createOperationSepaDF(SparkSession session, JavaRDD<OperationSepaBean> rdd) {
		return session.createDataFrame(rdd, OperationSepaBean.class);	
		
	}*/
	
	public static Dataset<Row> createOperationSepaDF(SparkSession session, JavaRDD<OperationSepaBean> rdd) {
		
		//session.sparkContext().broadcast(session,OperationSepaBean.class);	
		//if (!rdd.isEmpty()) {
			return session.createDataFrame(rdd.rdd(), OperationSepaBean.class);
    }
	
}



