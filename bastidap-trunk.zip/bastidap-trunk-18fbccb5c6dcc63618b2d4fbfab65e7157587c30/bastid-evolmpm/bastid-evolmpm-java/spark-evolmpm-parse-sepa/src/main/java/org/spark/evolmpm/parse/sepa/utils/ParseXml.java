package org.spark.evolmpm.parse.sepa.utils;


import javax.xml.parsers.*;
import org.xml.sax.InputSource;
import org.w3c.dom.*;
import java.io.*;


public class ParseXml {

	  public static String ParseXparttColumn(String champ, String TargetNode) {
	     String input = champ;	
	     
        if (input != null) {
        	
            try {
		        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		        DocumentBuilder db = dbf.newDocumentBuilder();
		        InputSource is = new InputSource();
		        is.setCharacterStream(new StringReader(input));
	
		        Document doc = db.parse(is);
		        NodeList nodes = doc.getElementsByTagName("CdtTrfTxInf");
	
		        // iterate the TargetNode
		        for (int i = 0; i < nodes.getLength(); i++) {
		           Element element = (Element) nodes.item(i);
	
		           NodeList name = element.getElementsByTagName(TargetNode);
		           Element line = (Element) name.item(0);
		           //System.out.println(TargetNode + ": " + getCharacterDataFromElement(line));
		           return getCharacterDataFromElement(line) ;
	
		        }
		    }
		    catch (Exception e) {
		        e.printStackTrace();
		    }
			return null;

	  }
		return null;        
	      
	    
}

	  public static String getCharacterDataFromElement(Element e) {
	    Node child = e.getFirstChild();
	    if (child instanceof CharacterData) {
	       CharacterData cd = (CharacterData) child;
	       return cd.getData();
	    }
	    return "?";
	  }
	
	
}




	
	
	
	
	
		