package org.spark.evolmpm.parse.sepa.functions;

import java.io.InputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;


import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.function.Function;
import org.spark.evolmpm.parse.sepa.beans.DataInputBean;
import org.spark.evolmpm.parse.sepa.beans.OperationSepaBean;
import org.spark.evolmpm.parse.sepa.utils.UtilFunctions;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * @author I2108GB
 *
 */
public class OperationSepaFactory extends AbstractFactory implements Function<DataInputBean, OperationSepaBean> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 928493719556715812L;

	public OperationSepaBean call(DataInputBean v1) throws Exception {
		// TODO Auto-generated method stub

		// Destination record
		OperationSepaBean operationSepa = new OperationSepaBean();

		if (v1 == null) {
			return operationSepa;
		}
		

		// others fields => bastid-347	
		operationSepa.setId_operation(v1.getId_operation());
		operationSepa.setCode_operation(v1.getCode_operation());
		operationSepa.setCode_client_conventionne(v1.getCode_client_conventionne());
		operationSepa.setId_systeme_echange(v1.getId_systeme_echange());
		operationSepa.setIban_debitor_sr(v1.getIban_debitor_sr());
		operationSepa.setBic_id_debitor_sr(v1.getBic_id_debitor_sr());
		operationSepa.setBic_id_creditor_sr(v1.getBic_id_creditor_sr());
		operationSepa.setIban_creditor_sr(v1.getIban_creditor_sr());
		operationSepa.setCode_famille_operation(v1.getCode_famille_operation());
		operationSepa.setType_operation(v1.getType_operation());
		operationSepa.setSens_echange(v1.getSens_echange());
		operationSepa.setNum_remise(v1.getNum_remise());
		operationSepa.setNum_remise_tech(v1.getNum_remise_tech());
		operationSepa.setDate_pec_amont(v1.getDate_pec_amont());
		operationSepa.setHeure_pec_amont(v1.getHeure_pec_amont());
		operationSepa.setDate_presentation_remise(v1.getDate_presentation_remise());
		operationSepa.setHeure_presentation_remise(v1.getHeure_presentation_remise());
		operationSepa.setRio(v1.getRio());
		operationSepa.setDate_echange(v1.getDate_echange());
		operationSepa.setDate_reglement(v1.getDate_reglement());
		operationSepa.setDate_traitement_aval_recu(v1.getDate_traitement_aval_recu());
		operationSepa.setEtblt_concerne(v1.getEtblt_concerne());
		operationSepa.setInd_rejet(v1.getInd_rejet());
		operationSepa.setFlag_debrayage_embargo(v1.getFlag_debrayage_embargo());
		operationSepa.setXtimts(v1.getXtimts());
		operationSepa.setRef_operation_origine(v1.getRef_operation_origine());
		operationSepa.setDate_comptable_evolmpm(v1.getDate_comptable_evolmpm());
		operationSepa.setPmtid_txid_src(v1.getPmtid_txid_src());
		operationSepa.setMnt_compense_sit(getDouble(v1.getMnt_compense_sit()));
		operationSepa.setCode_flux_arch(v1.getCode_flux_arch());
		operationSepa.setNum_partition(v1.getNum_partition());
		operationSepa.setOrgnltxid_src(v1.getOrgnltxid_src());
		operationSepa.setType_enregistrement(v1.getType_enregistrement());
		operationSepa.setOrgnlinstrid_src(v1.getOrgnlinstrid_src());
		operationSepa.setOrgnlendtoendid_src(v1.getOrgnlendtoendid_src());
		operationSepa.setDelai_reglement(UtilFunctions.getInteger(v1.getDelai_reglement()));
		operationSepa.setIban_do_sr(v1.getIban_do_sr());
		operationSepa.setBic_id_do_sr(v1.getBic_id_do_sr());
		operationSepa.setBic_id_beneficiaire_sr(v1.getBic_id_beneficiaire_sr());
		operationSepa.setIban_beneficiaire_sr(v1.getIban_beneficiaire_sr());
		operationSepa.setCode_pays_do_sr(v1.getCode_pays_do_sr());
		operationSepa.setCle_iban_do_sr(v1.getCle_iban_do_sr());
		operationSepa.setCode_banque_do_sr(v1.getCode_banque_do_sr());
		operationSepa.setCode_guichet_do_sr(v1.getCode_guichet_do_sr());
		operationSepa.setNum_cpte_do_sr(v1.getNum_cpte_do_sr());
		operationSepa.setCle_rib_do_sr(v1.getCle_rib_do_sr());
		operationSepa.setCode_pays_beneficiaire_sr(v1.getCode_pays_beneficiaire_sr());
		operationSepa.setCle_iban_beneficiaire_sr(v1.getCle_iban_beneficiaire_sr());
		operationSepa.setCode_banque_beneficiaire_sr(v1.getCode_banque_beneficiaire_sr());
		operationSepa.setCode_guichet_beneficiaire_sr(v1.getCode_guichet_beneficiaire_sr());
		operationSepa.setNum_cpte_beneficiaire_sr(v1.getNum_cpte_beneficiaire_sr());
		operationSepa.setCle_rib_beneficiaire_sr(v1.getCle_rib_beneficiaire_sr());
		operationSepa.setCode_pays_debitor_sr(v1.getCode_pays_debitor_sr());
		operationSepa.setCle_iban_debitor_sr(v1.getCle_iban_debitor_sr());
		operationSepa.setCode_banque_debitor_sr(v1.getCode_banque_debitor_sr());
		operationSepa.setCode_guichet_debitor_sr(v1.getCode_guichet_debitor_sr());
		operationSepa.setNum_cpte_debitor_sr(v1.getNum_cpte_debitor_sr());
		operationSepa.setCle_rib_debitor_sr(v1.getCle_rib_debitor_sr());
		operationSepa.setCode_pays_creditor_sr(v1.getCode_pays_creditor_sr());
		operationSepa.setCle_iban_creditor_sr(v1.getCle_iban_creditor_sr());
		operationSepa.setCode_banque_creditor_sr(v1.getCode_banque_creditor_sr());
		operationSepa.setCode_guichet_creditor_sr(v1.getCode_guichet_creditor_sr());
		operationSepa.setNum_cpte_creditor_sr(v1.getNum_cpte_creditor_sr());
		operationSepa.setCle_rib_creditor_sr(v1.getCle_rib_creditor_sr());
		operationSepa.setDate_insert(v1.getDate_insert());
		operationSepa.setDate_ope(getDateSql(v1.getDate_ope()));
		operationSepa.setId_type_operation(v1.getId_type_operation());
		operationSepa.setId_client(v1.getId_client());
		operationSepa.setCode_grp_remettant(v1.getCode_grp_remettant());
		operationSepa.setLib_grp_remettant(v1.getLib_grp_remettant());
		operationSepa.setId_ics(v1.getId_ics());
		operationSepa.setId_compte_do_sr(v1.getId_compte_do_sr());
		operationSepa.setId_client_do_sr(v1.getId_client_do_sr());
		operationSepa.setId_compte_beneficiaire_sr(v1.getId_compte_beneficiaire_sr());
		operationSepa.setId_client_beneficiaire_sr(v1.getId_client_beneficiaire_sr());
		operationSepa.setId_traitement(v1.getId_traitement());		
		
		try {
		/** parsing xpartt */
		if (StringUtils.isNotBlank(v1.getXpartt())) {

			DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = builderFactory.newDocumentBuilder();

            InputStream input = IOUtils.toInputStream(v1.getXpartt());
            Document xml = builder.parse(input);

			Element root = xml.getDocumentElement();
			XPathFactory xpf = XPathFactory.newInstance();
			XPath path = xpf.newXPath();
			
	        // final ParseXMLSepaSCT parserxml = new ParseXMLSepaSCT();

			
			// if coops in (320) => bastid-348
			if (v1.getCode_operation().equals("320")) {
				parseCode320(operationSepa, root, path);
			}
			// if coops in (326) => bastid-454
			else if (v1.getCode_operation().equals("326")) {
				parseCode326(operationSepa, root, path);
			}
			// if coops in (329) => bastid-454
			else if (v1.getCode_operation().equals("329")) {
				parseCode329(operationSepa, root, path);
			}
			// if coops in (330) => bastid-454
			else if (v1.getCode_operation().equals("330")) {
				parseCode330(operationSepa, root, path);
			}
			// if coops in (720) or 730 => bastid-454
			else if ((v1.getCode_operation().equals("720") || v1.getCode_operation().equals("730"))) {
				parseCode720Or730(operationSepa, root, path);
			} else if (v1.getCode_operation().equals("920")) {
				parseCode920(operationSepa, root, path);	
			}
			// if coops in (340,380) => bastid-350
			else if ((v1.getCode_operation().equals("340") || v1.getCode_operation().equals("380"))) {				
				parseCode340Or380(operationSepa, root, path);	
			}
			// if coops in (381) => bastid-352
			else if (v1.getCode_operation().equals("381")) {
					parseCode381(operationSepa, root, path);	
			} else if (v1.getCode_operation().equals("386")) {
			  	parseCode386(operationSepa, root, path);
		    } else if (v1.getCode_operation().equals("615")) {
            	parseCode615(operationSepa, root, path);
            } else if (v1.getCode_operation().equals("680")) {
            	parseCode680(operationSepa, root, path);
            } else if (v1.getCode_operation().equals("780")) {
            	parseCode780(operationSepa, root, path);
            } else if (v1.getCode_operation().equals("980")) {
            	parseCode980(operationSepa, root, path);	
            } 		
			// BASTID-455
			else if (v1.getCode_operation().equals("387")) {
				parseCode387(operationSepa, root, path);
			} else if (v1.getCode_operation().equals("616")) {
				parseCode616(operationSepa, root, path);
			} else if (v1.getCode_operation().equals("681")) {
				parseCode681(operationSepa, root, path);
			} else if (v1.getCode_operation().equals("781")) {
				parseCode781(operationSepa, root, path);
			} else if (v1.getCode_operation().equals("981")) {
				parseCode981(operationSepa, root, path);
			}
				
			
			
			
		}
		/** colonnes (cle_rib_do_sr - cle_rib_beneficiaire_sr - cle_rib_debitor_sr - cle_rib_creditor_sr)
		
		if(StringUtils.isNotBlank(operationSepa.getIban_do()) && 
				"FR".equals(operationSepa.getCode_pays_do_sr()) &&
				operationSepa.getIban_do().length() > 1) {			
			operationSepa.setCle_rib_do_sr(StringUtils.substring(operationSepa.getIban_do(), operationSepa.getIban_do().length() - 1));
			
		}
		*/
		
		
		return operationSepa;
		}
		catch (Exception e) {
			
			System.out.println("ici catch parse "+ e);
			return operationSepa;
		}
	}
	
	
	private void parseCode320(OperationSepaBean operationSepa, Element root, XPath path) throws XPathExpressionException {
		
		final ParseXMLSepaSCT parserxml = new ParseXMLSepaSCT();
		
		//java.util.Date UCDT_ID_PR_DPBI_DA = new SimpleDateFormat("dd/MM/yyyy").parse(parserxml.getTagUCDT_ID_PR_DPBI_DA(path, root));
		//java.util.Date DBT_ID_PR_DPBI_DAT = new SimpleDateFormat("dd/MM/yyyy").parse(parserxml.getTagDBT_ID_PR_DPBI_DAT(path, root));
		//java.util.Date CDT_ID_PR_DPBI_DAT = new SimpleDateFormat("dd/MM/yyyy").parse(parserxml.getTagCDT_ID_PR_DPBI_DAT(path, root));
		//java.util.Date UDBT_ID_PR_DPBI_DAT = new SimpleDateFormat("dd/MM/yyyy").parse(parserxml.getTagUDBT_ID_PR_DPBI_DAT(path, root));
		
		operationSepa.setPmtid_txid(parserxml.getTagPMTID_TXID(path, root));
		operationSepa.setPmtid_instrid(parserxml.getTagPMTID_INSTRID(path, root));
		operationSepa.setPmtid_endtoendid(parserxml.getTagPMTID_ENDTOENDID(path, root));
		operationSepa.setPmttpi_svclvl_cd(parserxml.getTagPMTTPI_SVCLVL_CD(path, root));
		operationSepa.setPmttpi_lclins_cd(parserxml.getTagPMTTPI_LCLINS_CD(path, root));
		operationSepa.setPmttpilclins_prtry(parserxml.getTagPMTTPILCLINS_PRTRY(path, root));
		operationSepa.setPmttpi_ctgypurp(parserxml.getTagPMTTPI_CTGYPURP(path, root));
		operationSepa.setIntrbksttlmamt(getBigDecimalSct(parserxml.getTagINTRBKSTTLMAMT(path, root),2));
		operationSepa.setIntrbksttlmamtc(parserxml.getTagINTRBKSTTLMAMTC(path, root));
		operationSepa.setChrgbr(parserxml.getTagCHRGBR(path, root));
		operationSepa.setUcdt_name(parserxml.getTagUCDT_NAME(path, root));
		operationSepa.setUcdt_id_org_bic_bei(parserxml.getTagUCDT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setUcdt_id_org_othr_id(parserxml.getTagUCDT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setUcdt_id_org_othr_sch_cd(parserxml.getTagUCDT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setUcdt_id_org_othr_sch_prtry(parserxml.getTagUCDT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setUcdt_id_org_othr_issr(parserxml.getTagUCDT_ID_ORG_OTHR_ISSR(path, root));

		//operationSepa.setUcdt_id_pr_dpbi_da(new java.sql.Date(UCDT_ID_PR_DPBI_DA.getTime()));
		operationSepa.setUcdt_id_pr_dpbi_da(getDateSql(parserxml.getTagUCDT_ID_PR_DPBI_DA(path, root)));

		operationSepa.setUcdt_id_pr_dpbi_prv(parserxml.getTagUCDT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setUcdt_id_pr_dpbi_ct(parserxml.getTagUCDT_ID_PR_DPBI_CT(path, root));
		operationSepa.setUcdt_id_pr_dpbi_cr(parserxml.getTagUCDT_ID_PR_DPBI_CR(path, root));
		operationSepa.setUcdt_id_prv_othr_id(parserxml.getTagUCDT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setUcdt_id_prv_othr_sch_cd(parserxml.getTagUCDT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setUcdt_id_prv_othr_sch_prtr(parserxml.getTagUCDT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setUcdt_id_prv_othr_issr(parserxml.getTagUCDT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setDbt_name(parserxml.getTagDBT_NAME(path, root));
		operationSepa.setDbt_padr_adrline(parserxml.getTagDBT_PADR_ADRLINE(path, root));
		operationSepa.setDbt_padr_ctry(parserxml.getTagDBT_PADR_CTRY(path, root));
		operationSepa.setDbt_id_org_bic_bei(parserxml.getTagDBT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setDbt_id_org_othr_id(parserxml.getTagDBT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setDbt_id_org_othr_sch_cd(parserxml.getTagDBT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setDbt_id_org_othr_sch_prtry(parserxml.getTagDBT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setDbt_id_org_othr_issr(parserxml.getTagDBT_ID_ORG_OTHR_ISSR(path, root));

		//operationSepa.setDbt_id_pr_dpbi_dat(new java.sql.Date(DBT_ID_PR_DPBI_DAT.getTime()));
		operationSepa.setDbt_id_pr_dpbi_dat(getDateSql(parserxml.getTagDBT_ID_PR_DPBI_DAT(path, root)));

		operationSepa.setDbt_id_pr_dpbi_prv(parserxml.getTagDBT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setDbt_id_pr_dpbi_cty(parserxml.getTagDBT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setDbt_id_pr_dpbi_cr(parserxml.getTagDBT_ID_PR_DPBI_CR(path, root));
		operationSepa.setDbt_id_prv_othr_id(parserxml.getTagDBT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setDbt_id_prv_othr_sch_cd(parserxml.getTagDBT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setDbt_id_prv_othr_sch_prtr(parserxml.getTagDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setDbt_id_prv_othr_issr(parserxml.getTagDBT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setDbtacc_id_iban(parserxml.getTagDBTACC_ID_IBAN(path, root));
		operationSepa.setDbtagt_fi_bic(parserxml.getTagDBTAGT_FI_BIC(path, root));
		operationSepa.setCdtacc_id_iban(parserxml.getTagCDTACC_ID_IBAN(path, root));
		operationSepa.setCdtagt_fi_bic(parserxml.getTagCDTAGT_FI_BIC(path, root));
		operationSepa.setCdt_name(parserxml.getTagCDT_NAME(path, root));
		operationSepa.setCdt_padr_adrline(parserxml.getTagCDT_PADR_ADRLINE(path, root));
		operationSepa.setCdt_padr_ctry(parserxml.getTagCDT_PADR_CTRY(path, root));
		operationSepa.setCdt_id_org_bic_bei(parserxml.getTagCDT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setCdt_id_org_othr_id(parserxml.getTagCDT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setCdt_id_org_othr_sch_cd(parserxml.getTagCDT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setCdt_id_org_othr_sch_prtry(parserxml.getTagCDT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setCdt_id_org_othr_issr(parserxml.getTagCDT_ID_ORG_OTHR_ISSR(path, root));

		//operationSepa.setCdt_id_pr_dpbi_dat(new java.sql.Date(CDT_ID_PR_DPBI_DAT.getTime()));
		operationSepa.setCdt_id_pr_dpbi_dat(getDateSql(parserxml.getTagCDT_ID_PR_DPBI_DAT(path, root)));
		
		operationSepa.setCdt_id_pr_dpbi_prv(parserxml.getTagCDT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setCdt_id_pr_dpbi_cty(parserxml.getTagCDT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setCdt_id_pr_dpbi_cry(parserxml.getTagCDT_ID_PR_DPBI_CRY(path, root));
		operationSepa.setCdt_id_prv_othr_id(parserxml.getTagCDT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setCdt_id_prv_othr_sch_cd(parserxml.getTagCDT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setCdt_id_prv_othr_sch_prtr(parserxml.getTagCDT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setCdt_id_prv_othr_issr(parserxml.getTagCDT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setUdbt_name(parserxml.getTagUDBT_NAME(path, root));
		operationSepa.setUdbt_id_org_bic_bei(parserxml.getTagUDBT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setUdbt_id_org_othr_id(parserxml.getTagUDBT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setUdbt_id_org_othr_sch_cd(parserxml.getTagUDBT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setUdbt_id_org_othr_sch_prtr(parserxml.getTagUDBT_ID_ORG_OTHR_SCH_PRTR(path, root));
		operationSepa.setUdbt_id_org_othr_sch_issr(parserxml.getTagUDBT_ID_ORG_OTHR_SCH_ISSR(path, root));

		//operationSepa.setUdbt_id_pr_dpbi_dat(new java.sql.Date(UDBT_ID_PR_DPBI_DAT.getTime()));
		operationSepa.setCdt_id_pr_dpbi_dat(getDateSql(parserxml.getTagUDBT_ID_PR_DPBI_DAT(path, root)));
		
		operationSepa.setUdbt_id_pr_dpbi_prv(parserxml.getTagUDBT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setUdbt_id_pr_dpbi_cty(parserxml.getTagUDBT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setUdbt_id_pr_dpbi_cry(parserxml.getTagUDBT_ID_PR_DPBI_CRY(path, root));
		operationSepa.setUdbt_id_prv_othr_id(parserxml.getTagUDBT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setUdbt_id_prv_othr_sch_cd(parserxml.getTagUDBT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setUdbt_id_prv_othr_sch_prtr(parserxml.getTagUDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setUdbt_id_prv_othr_issr(parserxml.getTagUDBT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setInsgagt_fi_bic(parserxml.getTagINSGAGT_FI_BIC(path, root));
		operationSepa.setInsdagt_fi_bic(parserxml.getTagINSDAGT_FI_BIC(path, root));
		operationSepa.setRmtinf_ustrd(parserxml.getTagRMTINF_USTRD(path, root));
		operationSepa.setRmtinf_strd_type_code(parserxml.getTagRMTINF_STRD_TYPE_CODE(path, root));
		operationSepa.setRmtinf_strd_type_ref(parserxml.getTagRMTINF_STRD_TYPE_REF(path, root));
		operationSepa.setPur_cd(parserxml.getTagPUR_CD(path, root));
		operationSepa.setBic_id_debitor(parserxml.getTagBIC_ID_Debitor(path, root));
		operationSepa.setBic_id_creditor(parserxml.getTagBIC_ID_Creditor(path, root));
		operationSepa.setIban_debitor(parserxml.getTagIBAN_DEBTOR(path, root));
		operationSepa.setIban_creditor(parserxml.getTagIBAN_CREDITOR(path, root));
		operationSepa.setBic_id_do(parserxml.getTagBIC_ID_DO(path, root));
		operationSepa.setIban_do(parserxml.getTagIBAN_DO(path, root));
		operationSepa.setBic_id_beneficiaire(parserxml.getTagBIC_ID_BENEFICIAIRE(path, root));
		operationSepa.setIban_beneficiaire(parserxml.getTagIBAN_BENEFICIAIRE(path, root));
		operationSepa.setFlag_evolmpm_maeva("EVOLMPM");
		
	}


	private void parseCode326(OperationSepaBean operationSepa, Element root, XPath path) throws XPathExpressionException {
		
		final ParseXMLSepaSCT parserxml = new ParseXMLSepaSCT();

		operationSepa.setMotif_rejet_annulation(parserxml.getTag_326MOTIF_REJET_ANNULATION(path, root));
		operationSepa.setPmttpi_svclvl_cd(parserxml.getTag_326PMTTPI_SVCLVL_CD(path, root));
		operationSepa.setPmttpi_lclins_cd(parserxml.getTag_326PMTTPI_LCLINS_CD(path, root));
		operationSepa.setPmttpilclins_prtry(parserxml.getTag_326PMTTPILCLINS_PRTRY(path, root));
		operationSepa.setPmttpi_ctgypurp(parserxml.getTag_326PMTTPI_CTGYPURP(path, root));
		operationSepa.setUcdt_name(parserxml.getTag_326UCDT_NAME(path, root));
		operationSepa.setUcdt_id_org_bic_bei(parserxml.getTag_326UCDT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setUcdt_id_org_othr_id(parserxml.getTag_326UCDT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setUcdt_id_org_othr_sch_cd(parserxml.getTag_326UCDT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setUcdt_id_org_othr_sch_prtry(parserxml.getTag_326UCDT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setUcdt_id_org_othr_issr(parserxml.getTag_326UCDT_ID_ORG_OTHR_ISSR(path, root));
		operationSepa.setUcdt_id_pr_dpbi_da(getDateSql(parserxml.getTag_326UCDT_ID_PR_DPBI_DA(path, root)));
		operationSepa.setUcdt_id_pr_dpbi_prv(parserxml.getTag_326UCDT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setUcdt_id_pr_dpbi_ct(parserxml.getTag_326UCDT_ID_PR_DPBI_CT(path, root));
		operationSepa.setUcdt_id_pr_dpbi_cr(parserxml.getTag_326UCDT_ID_PR_DPBI_CR(path, root));
		operationSepa.setUcdt_id_prv_othr_id(parserxml.getTag_326UCDT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setUcdt_id_prv_othr_sch_cd(parserxml.getTag_326UCDT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setUcdt_id_prv_othr_sch_prtr(parserxml.getTag_326UCDT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setUcdt_id_prv_othr_issr(parserxml.getTag_326UCDT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setDbt_name(parserxml.getTag_326DBT_NAME(path, root));
		operationSepa.setDbt_padr_adrline(parserxml.getTag_326DBT_PADR_ADRLINE(path, root));
		operationSepa.setDbt_padr_ctry(parserxml.getTag_326DBT_PADR_CTRY(path, root));
		operationSepa.setDbt_id_org_bic_bei(parserxml.getTag_326DBT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setDbt_id_org_othr_id(parserxml.getTag_326DBT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setDbt_id_org_othr_sch_cd(parserxml.getTag_326DBT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setDbt_id_org_othr_sch_prtry(parserxml.getTag_326DBT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setDbt_id_org_othr_issr(parserxml.getTag_326DBT_ID_ORG_OTHR_ISSR(path, root));
		operationSepa.setDbt_id_pr_dpbi_dat(getDateSql(parserxml.getTag_326DBT_ID_PR_DPBI_DAT(path, root)));
		operationSepa.setDbt_id_pr_dpbi_prv(parserxml.getTag_326DBT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setDbt_id_pr_dpbi_cty(parserxml.getTag_326DBT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setDbt_id_pr_dpbi_cr(parserxml.getTag_326DBT_ID_PR_DPBI_CR(path, root));
		operationSepa.setDbt_id_prv_othr_id(parserxml.getTag_326DBT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setDbt_id_prv_othr_sch_cd(parserxml.getTag_326DBT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setDbt_id_prv_othr_sch_prtr(parserxml.getTag_326DBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setDbt_id_prv_othr_issr(parserxml.getTag_326DBT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setDbtacc_id_iban(parserxml.getTag_326DBTACC_ID_IBAN(path, root));
		operationSepa.setDbtagt_fi_bic(parserxml.getTag_326DBTAGT_FI_BIC(path, root));
		operationSepa.setCdtacc_id_iban(parserxml.getTag_326CDTACC_ID_IBAN(path, root));
		operationSepa.setCdtagt_fi_bic(parserxml.getTag_326CDTAGT_FI_BIC(path, root));
		operationSepa.setCdt_name(parserxml.getTag_326CDT_NAME(path, root));
		operationSepa.setCdt_padr_adrline(parserxml.getTag_326CDT_PADR_ADRLINE(path, root));
		operationSepa.setCdt_padr_ctry(parserxml.getTag_326CDT_PADR_CTRY(path, root));
		operationSepa.setCdt_id_org_bic_bei(parserxml.getTag_326CDT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setCdt_id_org_othr_id(parserxml.getTag_326CDT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setCdt_id_org_othr_sch_cd(parserxml.getTag_326CDT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setCdt_id_org_othr_sch_prtry(parserxml.getTag_326CDT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setCdt_id_org_othr_issr(parserxml.getTag_326CDT_ID_ORG_OTHR_ISSR(path, root));
		operationSepa.setCdt_id_pr_dpbi_dat(getDateSql(parserxml.getTag_326CDT_ID_PR_DPBI_DAT(path, root)));
		operationSepa.setCdt_id_pr_dpbi_prv(parserxml.getTag_326CDT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setCdt_id_pr_dpbi_cty(parserxml.getTag_326CDT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setCdt_id_pr_dpbi_cry(parserxml.getTag_326CDT_ID_PR_DPBI_CRY(path, root));
		operationSepa.setCdt_id_prv_othr_id(parserxml.getTag_326CDT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setCdt_id_prv_othr_sch_cd(parserxml.getTag_326CDT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setCdt_id_prv_othr_sch_prtr(parserxml.getTag_326CDT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setCdt_id_prv_othr_issr(parserxml.getTag_326CDT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setUdbt_name(parserxml.getTag_326UDBT_NAME(path, root));
		operationSepa.setUdbt_id_org_bic_bei(parserxml.getTag_326UDBT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setUdbt_id_org_othr_id(parserxml.getTag_326UDBT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setUdbt_id_org_othr_sch_cd(parserxml.getTag_326UDBT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setUdbt_id_org_othr_sch_prtr(parserxml.getTag_326UDBT_ID_ORG_OTHR_SCH_PRTR(path, root));
		operationSepa.setUdbt_id_org_othr_sch_issr(parserxml.getTag_326UDBT_ID_ORG_OTHR_SCH_ISSR(path, root));
		operationSepa.setUdbt_id_pr_dpbi_dat(getDateSql(parserxml.getTag_326UDBT_ID_PR_DPBI_DAT(path, root)));
		operationSepa.setUdbt_id_pr_dpbi_prv(parserxml.getTag_326UDBT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setUdbt_id_pr_dpbi_cty(parserxml.getTag_326UDBT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setUdbt_id_pr_dpbi_cry(parserxml.getTag_326UDBT_ID_PR_DPBI_CRY(path, root));
		operationSepa.setUdbt_id_prv_othr_id(parserxml.getTag_326UDBT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setUdbt_id_prv_othr_sch_cd(parserxml.getTag_326UDBT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setUdbt_id_prv_othr_sch_prtr(parserxml.getTag_326UDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setUdbt_id_prv_othr_issr(parserxml.getTag_326UDBT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setRmtinf_ustrd(parserxml.getTag_326RMTINF_USTRD(path, root));
		operationSepa.setRmtinf_strd_type_code(parserxml.getTag_326RMTINF_STRD_TYPE_CODE(path, root));
		operationSepa.setRmtinf_strd_type_ref(parserxml.getTag_326RMTINF_STRD_TYPE_REF(path, root));
		operationSepa.setOrgnltxid(parserxml.getTag_326ORGNLTXID(path, root));
		operationSepa.setOrggrpinf_orgnlmsgid(parserxml.getTag_326ORGGRPINF_ORGNLMSGID(path, root));
		operationSepa.setOrggrpinf_orgnlmsgnmid(parserxml.getTag_326ORGGRPINF_ORGNLMSGNMID(path, root));
		operationSepa.setOrgnlinstrid(parserxml.getTag_326ORGNLINSTRID(path, root));
		operationSepa.setOrgnlendtoendid(parserxml.getTag_326ORGNLENDTOENDID(path, root));
		operationSepa.setOrgnlintrbksttlmamt(getBigDecimal(getDouble(parserxml.getTag_326ORGNLINTRBKSTTLMAMT(path, root)), 2));
		operationSepa.setOrgnlintrbksttlmamtc(parserxml.getTag_326ORGNLINTRBKSTTLMAMTC(path, root));
		operationSepa.setOtr_intrbksttlmdt(getDateSql(parserxml.getTag_326OTR_INTRBKSTTLMDT(path, root)));
		operationSepa.setRi_rorg_name(parserxml.getTag_326RI_RORG_NAME(path, root));
		operationSepa.setRi_rorg_id_org_bic_bei(parserxml.getTag_326RI_RORG_ID_ORG_BIC_BEI(path, root));
		operationSepa.setRi_rsn_cd(parserxml.getTag_326RI_RSN_CD(path, root));
		operationSepa.setRi_sn_prtry(parserxml.getTag_326RI_SN_PRTRY(path, root));
		operationSepa.setOtr_reqdcolltndt(parserxml.getTag_326OTR_REQDCOLLTNDT(path, root));
		operationSepa.setOtr_csch_id_prv_othr_id(parserxml.getTag_326OTR_CSCH_ID_PRV_OTHR_ID(path, root));
		operationSepa.setOtr_csch_id_prv_othr_sch_cd(parserxml.getTag_326OTR_CSCH_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setOtr_csch_id_prv_othr_issr(parserxml.getTag_326OTR_CSCH_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setOtr_csch_id_prv_othr_sch_prtr(parserxml.getTag_326OTR_CSCH_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setOtr_stti_sttlmmtd(parserxml.getTag_326OTR_STTI_STTLMMTD(path, root));
		operationSepa.setOtr_stti_sttaid_iban(parserxml.getTag_326OTR_STTI_STTAID_IBAN(path, root));
		operationSepa.setOtr_stti_sttaid_o_id(parserxml.getTag_326OTR_STTI_STTAID_O_ID(path, root));
		operationSepa.setOtr_stti_sttaid_o_sn_cd(parserxml.getTag_326OTR_STTI_STTAID_O_SN_CD(path, root));
		operationSepa.setOtr_stti_sttaid_o_sn_prtr(parserxml.getTag_326OTR_STTI_STTAID_O_SN_PRTR(path, root));
		operationSepa.setOtr_stti_sttaid_o_issr(parserxml.getTag_326OTR_STTI_STTAID_O_ISSR(path, root));
		operationSepa.setOtr_stti_clrs_cd(parserxml.getTag_326OTR_STTI_CLRS_CD(path, root));
		operationSepa.setOtr_stti_clrs_prtry(parserxml.getTag_326OTR_STTI_CLRS_PRTRY(path, root));
		operationSepa.setBic_id_debitor(parserxml.getTag_326BIC_ID_Debitor(path, root));
		operationSepa.setBic_id_creditor(parserxml.getTag_326BIC_ID_Creditor(path, root));
		operationSepa.setIban_debitor(parserxml.getTag_326IBAN_DEBTOR(path, root));
		operationSepa.setIban_creditor (parserxml.getTag_326IBAN_CREDITOR(path, root));
		operationSepa.setBic_id_do(parserxml.getTag_326BIC_ID_DO(path, root));
		operationSepa.setIban_do  (parserxml.getTag_326IBAN_DO(path, root));
		operationSepa.setBic_id_beneficiaire(parserxml.getTag_326BIC_ID_BENEFICIAIRE(path, root));
		operationSepa.setIban_beneficiaire(parserxml.getTag_326IBAN_BENEFICIAIRE(path, root));
		operationSepa.setFlag_evolmpm_maeva("EVOLMPM");
		
		
	}


	private void parseCode329(OperationSepaBean operationSepa, Element root, XPath path) throws XPathExpressionException {
		
		final ParseXMLSepaSCT parserxml = new ParseXMLSepaSCT();

		operationSepa.setMotif_rejet_annulation(parserxml.getTag_329MOTIF_REJET_ANNULATION(path, root));
		operationSepa.setPmttpi_svclvl_cd(parserxml.getTag_329PMTTPI_SVCLVL_CD(path, root));
		operationSepa.setPmttpi_lclins_cd(parserxml.getTag_329PMTTPI_LCLINS_CD(path, root));
		operationSepa.setPmttpilclins_prtry(parserxml.getTag_329PMTTPILCLINS_PRTRY(path, root));
		operationSepa.setPmttpi_ctgypurp(parserxml.getTag_329PMTTPI_CTGYPURP(path, root));
		operationSepa.setUcdt_name(parserxml.getTag_329UCDT_NAME(path, root));
		operationSepa.setUcdt_id_org_bic_bei(parserxml.getTag_329UCDT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setUcdt_id_org_othr_id(parserxml.getTag_329UCDT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setUcdt_id_org_othr_sch_cd(parserxml.getTag_329UCDT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setUcdt_id_org_othr_sch_prtry(parserxml.getTag_329UCDT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setUcdt_id_org_othr_issr(parserxml.getTag_329UCDT_ID_ORG_OTHR_ISSR(path, root));
		operationSepa.setUcdt_id_pr_dpbi_da(getDateSql(parserxml.getTag_329UCDT_ID_PR_DPBI_DA(path, root)));
		operationSepa.setUcdt_id_pr_dpbi_prv(parserxml.getTag_329UCDT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setUcdt_id_pr_dpbi_ct(parserxml.getTag_329UCDT_ID_PR_DPBI_CT(path, root));
		operationSepa.setUcdt_id_pr_dpbi_cr(parserxml.getTag_329UCDT_ID_PR_DPBI_CR(path, root));
		operationSepa.setUcdt_id_prv_othr_id(parserxml.getTag_329UCDT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setUcdt_id_prv_othr_sch_cd(parserxml.getTag_329UCDT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setUcdt_id_prv_othr_sch_prtr(parserxml.getTag_329UCDT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setUcdt_id_prv_othr_issr(parserxml.getTag_329UCDT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setDbt_name(parserxml.getTag_329DBT_NAME(path, root));
		operationSepa.setDbt_padr_adrline(parserxml.getTag_329DBT_PADR_ADRLINE(path, root));
		operationSepa.setDbt_padr_ctry(parserxml.getTag_329DBT_PADR_CTRY(path, root));
		operationSepa.setDbt_id_org_bic_bei(parserxml.getTag_329DBT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setDbt_id_org_othr_id(parserxml.getTag_329DBT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setDbt_id_org_othr_sch_cd(parserxml.getTag_329DBT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setDbt_id_org_othr_sch_prtry(parserxml.getTag_329DBT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setDbt_id_org_othr_issr(parserxml.getTag_329DBT_ID_ORG_OTHR_ISSR(path, root));
		operationSepa.setDbt_id_pr_dpbi_dat(getDateSql(parserxml.getTag_329DBT_ID_PR_DPBI_DAT(path, root)));
		operationSepa.setDbt_id_pr_dpbi_prv(parserxml.getTag_329DBT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setDbt_id_pr_dpbi_cty(parserxml.getTag_329DBT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setDbt_id_pr_dpbi_cr(parserxml.getTag_329DBT_ID_PR_DPBI_CR(path, root));
		operationSepa.setDbt_id_prv_othr_id(parserxml.getTag_329DBT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setDbt_id_prv_othr_sch_cd(parserxml.getTag_329DBT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setDbt_id_prv_othr_sch_prtr(parserxml.getTag_329DBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setDbt_id_prv_othr_issr(parserxml.getTag_329DBT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setDbtacc_id_iban(parserxml.getTag_329DBTACC_ID_IBAN(path, root));
		operationSepa.setDbtagt_fi_bic(parserxml.getTag_329DBTAGT_FI_BIC(path, root));
		operationSepa.setCdtacc_id_iban(parserxml.getTag_329CDTACC_ID_IBAN(path, root));
		operationSepa.setCdtagt_fi_bic(parserxml.getTag_329CDTAGT_FI_BIC(path, root));
		operationSepa.setCdt_name(parserxml.getTag_329CDT_NAME(path, root));
		operationSepa.setCdt_padr_adrline(parserxml.getTag_329CDT_PADR_ADRLINE(path, root));
		operationSepa.setCdt_padr_ctry(parserxml.getTag_329CDT_PADR_CTRY(path, root));
		operationSepa.setCdt_id_org_bic_bei(parserxml.getTag_329CDT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setCdt_id_org_othr_id(parserxml.getTag_329CDT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setCdt_id_org_othr_sch_cd(parserxml.getTag_329CDT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setCdt_id_org_othr_sch_prtry(parserxml.getTag_329CDT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setCdt_id_org_othr_issr(parserxml.getTag_329CDT_ID_ORG_OTHR_ISSR(path, root));
		operationSepa.setCdt_id_pr_dpbi_dat(getDateSql(parserxml.getTag_329CDT_ID_PR_DPBI_DAT(path, root)));
		operationSepa.setCdt_id_pr_dpbi_prv(parserxml.getTag_329CDT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setCdt_id_pr_dpbi_cty(parserxml.getTag_329CDT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setCdt_id_pr_dpbi_cry(parserxml.getTag_329CDT_ID_PR_DPBI_CRY(path, root));
		operationSepa.setCdt_id_prv_othr_id(parserxml.getTag_329CDT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setCdt_id_prv_othr_sch_cd(parserxml.getTag_329CDT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setCdt_id_prv_othr_sch_prtr(parserxml.getTag_329CDT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setCdt_id_prv_othr_issr(parserxml.getTag_329CDT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setUdbt_name(parserxml.getTag_329UDBT_NAME(path, root));
		operationSepa.setUdbt_id_org_bic_bei(parserxml.getTag_329UDBT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setUdbt_id_org_othr_id(parserxml.getTag_329UDBT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setUdbt_id_org_othr_sch_cd(parserxml.getTag_329UDBT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setUdbt_id_org_othr_sch_prtr(parserxml.getTag_329UDBT_ID_ORG_OTHR_SCH_PRTR(path, root));
		operationSepa.setUdbt_id_org_othr_sch_issr(parserxml.getTag_329UDBT_ID_ORG_OTHR_SCH_ISSR(path, root));
		operationSepa.setUdbt_id_pr_dpbi_dat(getDateSql(parserxml.getTag_329UDBT_ID_PR_DPBI_DAT(path, root)));
		operationSepa.setUdbt_id_pr_dpbi_prv(parserxml.getTag_329UDBT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setUdbt_id_pr_dpbi_cty(parserxml.getTag_329UDBT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setUdbt_id_pr_dpbi_cry(parserxml.getTag_329UDBT_ID_PR_DPBI_CRY(path, root));
		operationSepa.setUdbt_id_prv_othr_id(parserxml.getTag_329UDBT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setUdbt_id_prv_othr_sch_cd(parserxml.getTag_329UDBT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setUdbt_id_prv_othr_sch_prtr(parserxml.getTag_329UDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setUdbt_id_prv_othr_issr(parserxml.getTag_329UDBT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setRmtinf_ustrd(parserxml.getTag_329RMTINF_USTRD(path, root));
		operationSepa.setRmtinf_strd_type_code(parserxml.getTag_329RMTINF_STRD_TYPE_CODE(path, root));
		operationSepa.setRmtinf_strd_type_ref(parserxml.getTag_329RMTINF_STRD_TYPE_REF(path, root));
		operationSepa.setOrgnltxid(parserxml.getTag_329ORGNLTXID(path, root));
		operationSepa.setOrggrpinf_orgnlmsgid(parserxml.getTag_329ORGGRPINF_ORGNLMSGID(path, root));
		operationSepa.setOrggrpinf_orgnlmsgnmid(parserxml.getTag_329ORGGRPINF_ORGNLMSGNMID(path, root));
		operationSepa.setOrgnlinstrid(parserxml.getTag_329ORGNLINSTRID(path, root));
		operationSepa.setOrgnlendtoendid(parserxml.getTag_329ORGNLENDTOENDID(path, root));
		operationSepa.setTxsts(parserxml.getTag_329TXSTS(path, root));
		operationSepa.setOrgnlintrbksttlmamt(getBigDecimal(getDouble(parserxml.getTag_329ORGNLINTRBKSTTLMAMT(path, root)),2));
		operationSepa.setOrgnlintrbksttlmamtc(parserxml.getTag_329ORGNLINTRBKSTTLMAMTC(path, root));
		operationSepa.setOtr_intrbksttlmdt(getDateSql(parserxml.getTag_329OTR_INTRBKSTTLMDT(path, root)));
		operationSepa.setRi_rorg_name(parserxml.getTag_329RI_RORG_NAME(path, root));
		operationSepa.setRi_rorg_id_org_bic_bei(parserxml.getTag_329RI_RORG_ID_ORG_BIC_BEI(path, root));
		operationSepa.setRi_rsn_cd(parserxml.getTag_329RI_RSN_CD(path, root));
		operationSepa.setRi_sn_prtry(parserxml.getTag_329RI_SN_PRTRY(path, root));
		operationSepa.setRi_addtlinf1(parserxml.getTag_329RI_ADDTLINF1(path, root));
		operationSepa.setRi_addtlinf2(parserxml.getTag_329RI_ADDTLINF2(path, root));
		operationSepa.setOtr_stti_sttlmmtd(parserxml.getTag_329OTR_STTI_STTLMMTD(path, root));
		operationSepa.setOtr_stti_sttaid_iban(parserxml.getTag_329OTR_STTI_STTAID_IBAN(path, root));
		operationSepa.setOtr_stti_sttaid_o_id(parserxml.getTag_329OTR_STTI_STTAID_O_ID(path, root));
		operationSepa.setOtr_stti_sttaid_o_sn_cd(parserxml.getTag_329OTR_STTI_STTAID_O_SN_CD(path, root));
		operationSepa.setOtr_stti_sttaid_o_sn_prtr(parserxml.getTag_329OTR_STTI_STTAID_O_SN_PRTR(path, root));
		operationSepa.setOtr_stti_sttaid_o_issr(parserxml.getTag_329OTR_STTI_STTAID_O_ISSR(path, root));
		operationSepa.setOtr_stti_clrs_cd(parserxml.getTag_329OTR_STTI_CLRS_CD(path, root));
		operationSepa.setOtr_stti_clrs_prtry(parserxml.getTag_329OTR_STTI_CLRS_PRTRY(path, root));	
		operationSepa.setFlag_evolmpm_maeva("EVOLMPM");
		
	}


	private void parseCode330(OperationSepaBean operationSepa, Element root, XPath path) throws XPathExpressionException {
		
		final ParseXMLSepaSCT parserxml = new ParseXMLSepaSCT();
		
		operationSepa.setMotif_rejet_annulation(parserxml.getTag_330MOTIF_REJET_ANNULATION(path, root));
		operationSepa.setPmttpi_svclvl_cd(parserxml.getTag_330PMTTPI_SVCLVL_CD(path, root));
		operationSepa.setPmttpi_lclins_cd(parserxml.getTag_330PMTTPI_LCLINS_CD(path, root));
		operationSepa.setPmttpilclins_prtry(parserxml.getTag_330PMTTPILCLINS_PRTRY(path, root));
		operationSepa.setPmttpi_seqtp(parserxml.getTag_330PMTTPI_SEQTP(path, root));
		operationSepa.setPmttpi_ctgypurp(parserxml.getTag_330PMTTPI_CTGYPURP(path, root));

		operationSepa.setIntrbksttlmamt(getBigDecimal(getDouble(parserxml.getTag_330INTRBKSTTLMAMT(path, root)),2));
		operationSepa.setIntrbksttlmamtc(parserxml.getTag_330INTRBKSTTLMAMTC(path, root));
		operationSepa.setChrgbr(parserxml.getTag_330CHRGBR(path, root));
		operationSepa.setChrginf_amt(getDouble(parserxml.getTag_330CHRGINF_AMT(path, root)));
		operationSepa.setChrginf_amtc(parserxml.getTag_330CHRGINF_AMTC(path, root));
		operationSepa.setChrginf_pty_fi_bic(parserxml.getTag_330CHRGINF_PTY_FI_BIC(path, root));
		operationSepa.setM_mndtid(parserxml.getTag_330M_MNDTID(path, root));
		operationSepa.setM_dtofsgntr(getDateSql(parserxml.getTag_330M_DTOFSGNTR(path, root)));
		operationSepa.setM_amdmntind(parserxml.getTag_330M_AMDMNTIND(path, root));
		operationSepa.setM_a_orgnlmndtid(parserxml.getTag_330M_A_ORGNLMNDTID(path, root));
		operationSepa.setM_a_s_nm(parserxml.getTag_330M_A_S_NM(path, root));
		operationSepa.setM_a_s_id_proid(parserxml.getTag_330M_A_S_ID_PROID(path, root));
		operationSepa.setM_a_s_id_pro_sch_cd(parserxml.getTag_330M_A_S_ID_PRO_SCH_CD(path, root));
		operationSepa.setM_a_s_id_pro_sch_prtry(parserxml.getTag_330M_A_S_ID_PRO_SCH_PRTRY(path, root));
		operationSepa.setM_a_s_id_pro_issr(parserxml.getTag_330M_A_S_ID_PRO_ISSR(path, root));
		operationSepa.setM_a_odac_id_iban(parserxml.getTag_330M_A_ODAC_ID_IBAN(path, root));
		operationSepa.setM_a_odag_fi_othr_id(parserxml.getTag_330M_A_ODAG_FI_OTHR_ID(path, root));
		operationSepa.setM_elctrncsgnt(parserxml.getTag_330M_ELCTRNCSGNT(path, root));
		operationSepa.setUcdt_name(parserxml.getTag_330UCDT_NAME(path, root));
		operationSepa.setUcdt_id_org_bic_bei(parserxml.getTag_330UCDT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setUcdt_id_org_othr_id(parserxml.getTag_330UCDT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setUcdt_id_org_othr_sch_cd(parserxml.getTag_330UCDT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setUcdt_id_org_othr_sch_prtry(parserxml.getTag_330UCDT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setUcdt_id_org_othr_issr(parserxml.getTag_330UCDT_ID_ORG_OTHR_ISSR(path, root));
		operationSepa.setUcdt_id_pr_dpbi_da(getDateSql(parserxml.getTag_330UCDT_ID_PR_DPBI_DA(path, root)));
		operationSepa.setUcdt_id_pr_dpbi_prv(parserxml.getTag_330UCDT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setUcdt_id_pr_dpbi_ct(parserxml.getTag_330UCDT_ID_PR_DPBI_CT(path, root));
		operationSepa.setUcdt_id_pr_dpbi_cr(parserxml.getTag_330UCDT_ID_PR_DPBI_CR(path, root));
		operationSepa.setUcdt_id_prv_othr_id(parserxml.getTag_330UCDT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setUcdt_id_prv_othr_sch_cd(parserxml.getTag_330UCDT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setUcdt_id_prv_othr_sch_prtr(parserxml.getTag_330UCDT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setUcdt_id_prv_othr_issr(parserxml.getTag_330UCDT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setDbt_name(parserxml.getTag_330DBT_NAME(path, root));
		operationSepa.setDbt_padr_adrline(parserxml.getTag_330DBT_PADR_ADRLINE(path, root));
		operationSepa.setDbt_padr_ctry(parserxml.getTag_330DBT_PADR_CTRY(path, root));
		operationSepa.setDbt_id_org_bic_bei(parserxml.getTag_330DBT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setDbt_id_org_othr_id(parserxml.getTag_330DBT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setDbt_id_org_othr_sch_cd(parserxml.getTag_330DBT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setDbt_id_org_othr_sch_prtry(parserxml.getTag_330DBT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setDbt_id_org_othr_issr(parserxml.getTag_330DBT_ID_ORG_OTHR_ISSR(path, root));
		operationSepa.setDbt_id_pr_dpbi_dat(getDateSql(parserxml.getTag_330DBT_ID_PR_DPBI_DAT(path, root)));
		operationSepa.setDbt_id_pr_dpbi_prv(parserxml.getTag_330DBT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setDbt_id_pr_dpbi_cty(parserxml.getTag_330DBT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setDbt_id_pr_dpbi_cr(parserxml.getTag_330DBT_ID_PR_DPBI_CR(path, root));
		operationSepa.setDbt_id_prv_othr_id(parserxml.getTag_330DBT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setDbt_id_prv_othr_sch_cd(parserxml.getTag_330DBT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setDbt_id_prv_othr_sch_prtr(parserxml.getTag_330DBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setDbt_id_prv_othr_issr(parserxml.getTag_330DBT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setDbtacc_id_iban(parserxml.getTag_330DBTACC_ID_IBAN(path, root));
		operationSepa.setDbtagt_fi_bic(parserxml.getTag_330DBTAGT_FI_BIC(path, root));
		operationSepa.setCdtacc_id_iban(parserxml.getTag_330CDTACC_ID_IBAN(path, root));
		operationSepa.setCdtagt_fi_bic(parserxml.getTag_330CDTAGT_FI_BIC(path, root));
		operationSepa.setCdt_name(parserxml.getTag_330CDT_NAME(path, root));
		operationSepa.setCdt_padr_adrline(parserxml.getTag_330CDT_PADR_ADRLINE(path, root));
		operationSepa.setCdt_padr_ctry(parserxml.getTag_330CDT_PADR_CTRY(path, root));
		operationSepa.setCdt_id_org_bic_bei(parserxml.getTag_330CDT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setCdt_id_org_othr_id(parserxml.getTag_330CDT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setCdt_id_org_othr_sch_cd(parserxml.getTag_330CDT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setCdt_id_org_othr_sch_prtry(parserxml.getTag_330CDT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setCdt_id_org_othr_issr(parserxml.getTag_330CDT_ID_ORG_OTHR_ISSR(path, root));
		operationSepa.setCdt_id_pr_dpbi_dat(getDateSql(parserxml.getTag_330CDT_ID_PR_DPBI_DAT(path, root)));
		operationSepa.setCdt_id_pr_dpbi_prv(parserxml.getTag_330CDT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setCdt_id_pr_dpbi_cty(parserxml.getTag_330CDT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setCdt_id_pr_dpbi_cry(parserxml.getTag_330CDT_ID_PR_DPBI_CRY(path, root));
		operationSepa.setCdt_id_prv_othr_id(parserxml.getTag_330CDT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setCdt_id_prv_othr_sch_cd(parserxml.getTag_330CDT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setCdt_id_prv_othr_sch_prtr(parserxml.getTag_330CDT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setCdt_id_prv_othr_issr(parserxml.getTag_330CDT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setUdbt_name(parserxml.getTag_330UDBT_NAME(path, root));
		operationSepa.setUdbt_id_org_bic_bei(parserxml.getTag_330UDBT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setUdbt_id_org_othr_id(parserxml.getTag_330UDBT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setUdbt_id_org_othr_sch_cd(parserxml.getTag_330UDBT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setUdbt_id_org_othr_sch_prtr(parserxml.getTag_330UDBT_ID_ORG_OTHR_SCH_PRTR(path, root));
		operationSepa.setUdbt_id_org_othr_sch_issr(parserxml.getTag_330UDBT_ID_ORG_OTHR_SCH_ISSR(path, root));
		operationSepa.setUdbt_id_pr_dpbi_dat(getDateSql(parserxml.getTag_330UDBT_ID_PR_DPBI_DAT(path, root)));
		operationSepa.setUdbt_id_pr_dpbi_prv(parserxml.getTag_330UDBT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setUdbt_id_pr_dpbi_cty(parserxml.getTag_330UDBT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setUdbt_id_pr_dpbi_cry(parserxml.getTag_330UDBT_ID_PR_DPBI_CRY(path, root));
		operationSepa.setUdbt_id_prv_othr_id(parserxml.getTag_330UDBT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setUdbt_id_prv_othr_sch_cd(parserxml.getTag_330UDBT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setUdbt_id_prv_othr_sch_prtr(parserxml.getTag_330UDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setUdbt_id_prv_othr_issr(parserxml.getTag_330UDBT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setInsgagt_fi_bic(parserxml.getTag_330INSGAGT_FI_BIC(path, root));
		operationSepa.setInsdagt_fi_bic(parserxml.getTag_330INSDAGT_FI_BIC(path, root));
		operationSepa.setRmtinf_ustrd(parserxml.getTag_330RMTINF_USTRD(path, root));
		operationSepa.setRmtinf_strd_type_code(parserxml.getTag_330RMTINF_STRD_TYPE_CODE(path, root));
		operationSepa.setRmtinf_strd_type_ref(parserxml.getTag_330RMTINF_STRD_TYPE_REF(path, root));
		operationSepa.setOrgnltxid(parserxml.getTag_330ORGNLTXID(path, root));
		operationSepa.setOrgnlinstrid(parserxml.getTag_330ORGNLINSTRID(path, root));
		operationSepa.setOrgnlendtoendid(parserxml.getTag_330ORGNLENDTOENDID(path, root));
		operationSepa.setOrgnlintrbksttlmamt(getBigDecimal(getDouble(parserxml.getTag_330ORGNLINTRBKSTTLMAMT(path, root)),2));
		operationSepa.setOrgnlintrbksttlmamtc(parserxml.getTag_330ORGNLINTRBKSTTLMAMTC(path, root));
		operationSepa.setOtr_intrbksttlmdt(getDateSql(parserxml.getTag_330OTR_INTRBKSTTLMDT(path, root)));
		operationSepa.setFlag_evolmpm_maeva("EVOLMPM");
		
	}


	private void parseCode720Or730(OperationSepaBean operationSepa, Element root, XPath path) throws XPathExpressionException {
		
		final ParseXMLSepaSCT parserxml = new ParseXMLSepaSCT();
		
		operationSepa.setMotif_rejet_annulation(parserxml.getTag_720MOTIF_REJET_ANNULATION(path, root));
		operationSepa.setPmttpi_svclvl_cd(parserxml.getTag_720PMTTPI_SVCLVL_CD(path, root));
		operationSepa.setPmttpi_lclins_cd(parserxml.getTag_720PMTTPI_LCLINS_CD(path, root));
		operationSepa.setPmttpilclins_prtry(parserxml.getTag_720PMTTPILCLINS_PRTRY(path, root));
		operationSepa.setPmttpi_ctgypurp(parserxml.getTag_720PMTTPI_CTGYPURP(path, root));
		operationSepa.setIntrbksttlmamt(getBigDecimal(getDouble(parserxml.getTag_720INTRBKSTTLMAMT(path, root)),2));
		operationSepa.setIntrbksttlmamtc(parserxml.getTag_720INTRBKSTTLMAMTC(path, root));
		operationSepa.setChrgbr(parserxml.getTag_720CHRGBR(path, root));
		operationSepa.setChrginf_amt(getDouble(parserxml.getTag_720CHRGINF_AMT(path, root)));
		operationSepa.setChrginf_amtc(parserxml.getTag_720CHRGINF_AMTC(path, root));
		operationSepa.setChrginf_pty_fi_bic(parserxml.getTag_720CHRGINF_PTY_FI_BIC(path, root));
		operationSepa.setUcdt_name(parserxml.getTag_720UCDT_NAME(path, root));
		operationSepa.setUcdt_id_org_bic_bei(parserxml.getTag_720UCDT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setUcdt_id_org_othr_id(parserxml.getTag_720UCDT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setUcdt_id_org_othr_sch_cd(parserxml.getTag_720UCDT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setUcdt_id_org_othr_sch_prtry(parserxml.getTag_720UCDT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setUcdt_id_org_othr_issr(parserxml.getTag_720UCDT_ID_ORG_OTHR_ISSR(path, root));
		operationSepa.setUcdt_id_pr_dpbi_da(getDateSql(parserxml.getTag_720UCDT_ID_PR_DPBI_DA(path, root)));
		operationSepa.setUcdt_id_pr_dpbi_prv(parserxml.getTag_720UCDT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setUcdt_id_pr_dpbi_ct(parserxml.getTag_720UCDT_ID_PR_DPBI_CT(path, root));
		operationSepa.setUcdt_id_pr_dpbi_cr(parserxml.getTag_720UCDT_ID_PR_DPBI_CR(path, root));
		operationSepa.setUcdt_id_prv_othr_id(parserxml.getTag_720UCDT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setUcdt_id_prv_othr_sch_cd(parserxml.getTag_720UCDT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setUcdt_id_prv_othr_sch_prtr(parserxml.getTag_720UCDT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setUcdt_id_prv_othr_issr(parserxml.getTag_720UCDT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setDbt_name(parserxml.getTag_720DBT_NAME(path, root));
		operationSepa.setDbt_padr_adrline(parserxml.getTag_720DBT_PADR_ADRLINE(path, root));
		operationSepa.setDbt_padr_ctry(parserxml.getTag_720DBT_PADR_CTRY(path, root));
		operationSepa.setDbt_id_org_bic_bei(parserxml.getTag_720DBT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setDbt_id_org_othr_id(parserxml.getTag_720DBT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setDbt_id_org_othr_sch_cd(parserxml.getTag_720DBT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setDbt_id_org_othr_sch_prtry(parserxml.getTag_720DBT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setDbt_id_org_othr_issr(parserxml.getTag_720DBT_ID_ORG_OTHR_ISSR(path, root));
		operationSepa.setDbt_id_pr_dpbi_dat(getDateSql(parserxml.getTag_720DBT_ID_PR_DPBI_DAT(path, root)));
		operationSepa.setDbt_id_pr_dpbi_prv(parserxml.getTag_720DBT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setDbt_id_pr_dpbi_cty(parserxml.getTag_720DBT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setDbt_id_pr_dpbi_cr(parserxml.getTag_720DBT_ID_PR_DPBI_CR(path, root));
		operationSepa.setDbt_id_prv_othr_id(parserxml.getTag_720DBT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setDbt_id_prv_othr_sch_cd(parserxml.getTag_720DBT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setDbt_id_prv_othr_sch_prtr(parserxml.getTag_720DBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setDbt_id_prv_othr_issr(parserxml.getTag_720DBT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setDbtacc_id_iban(parserxml.getTag_720DBTACC_ID_IBAN(path, root));
		operationSepa.setDbtagt_fi_bic(parserxml.getTag_720DBTAGT_FI_BIC(path, root));
		operationSepa.setCdtacc_id_iban(parserxml.getTag_720CDTACC_ID_IBAN(path, root));
		operationSepa.setCdtagt_fi_bic(parserxml.getTag_720CDTAGT_FI_BIC(path, root));
		operationSepa.setCdt_name(parserxml.getTag_720CDT_NAME(path, root));
		operationSepa.setCdt_padr_adrline(parserxml.getTag_720CDT_PADR_ADRLINE(path, root));
		operationSepa.setCdt_padr_ctry(parserxml.getTag_720CDT_PADR_CTRY(path, root));
		operationSepa.setCdt_id_org_bic_bei(parserxml.getTag_720CDT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setCdt_id_org_othr_id(parserxml.getTag_720CDT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setCdt_id_org_othr_sch_cd(parserxml.getTag_720CDT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setCdt_id_org_othr_sch_prtry(parserxml.getTag_720CDT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setCdt_id_org_othr_issr(parserxml.getTag_720CDT_ID_ORG_OTHR_ISSR(path, root));
		operationSepa.setCdt_id_pr_dpbi_dat(getDateSql(parserxml.getTag_720CDT_ID_PR_DPBI_DAT(path, root)));
		operationSepa.setCdt_id_pr_dpbi_prv(parserxml.getTag_720CDT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setCdt_id_pr_dpbi_cty(parserxml.getTag_720CDT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setCdt_id_pr_dpbi_cry(parserxml.getTag_720CDT_ID_PR_DPBI_CRY(path, root));
		operationSepa.setCdt_id_prv_othr_id(parserxml.getTag_720CDT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setCdt_id_prv_othr_sch_cd(parserxml.getTag_720CDT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setCdt_id_prv_othr_sch_prtr(parserxml.getTag_720CDT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setCdt_id_prv_othr_issr(parserxml.getTag_720CDT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setUdbt_name(parserxml.getTag_720UDBT_NAME(path, root));
		operationSepa.setUdbt_id_org_bic_bei(parserxml.getTag_720UDBT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setUdbt_id_org_othr_id(parserxml.getTag_720UDBT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setUdbt_id_org_othr_sch_cd(parserxml.getTag_720UDBT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setUdbt_id_org_othr_sch_prtr(parserxml.getTag_720UDBT_ID_ORG_OTHR_SCH_PRTR(path, root));
		operationSepa.setUdbt_id_org_othr_sch_issr(parserxml.getTag_720UDBT_ID_ORG_OTHR_SCH_ISSR(path, root));
		operationSepa.setUdbt_id_pr_dpbi_dat(getDateSql(parserxml.getTag_720UDBT_ID_PR_DPBI_DAT(path, root)));
		operationSepa.setUdbt_id_pr_dpbi_prv(parserxml.getTag_720UDBT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setUdbt_id_pr_dpbi_cty(parserxml.getTag_720UDBT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setUdbt_id_pr_dpbi_cry(parserxml.getTag_720UDBT_ID_PR_DPBI_CRY(path, root));
		operationSepa.setUdbt_id_prv_othr_id(parserxml.getTag_720UDBT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setUdbt_id_prv_othr_sch_cd(parserxml.getTag_720UDBT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setUdbt_id_prv_othr_sch_prtr(parserxml.getTag_720UDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setUdbt_id_prv_othr_issr(parserxml.getTag_720UDBT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setInsgagt_fi_bic(parserxml.getTag_720INSGAGT_FI_BIC(path, root));
		operationSepa.setInsdagt_fi_bic(parserxml.getTag_720INSDAGT_FI_BIC(path, root));
		operationSepa.setRmtinf_ustrd(parserxml.getTag_720RMTINF_USTRD(path, root));
		operationSepa.setRmtinf_strd_type_code(parserxml.getTag_720RMTINF_STRD_TYPE_CODE(path, root));
		operationSepa.setRmtinf_strd_type_ref(parserxml.getTag_720RMTINF_STRD_TYPE_REF(path, root));
		operationSepa.setOrgnltxid(parserxml.getTag_720ORGNLTXID(path, root));
		operationSepa.setOrggrpinf_orgnlmsgid(parserxml.getTag_720ORGGRPINF_ORGNLMSGID(path, root));
		operationSepa.setOrggrpinf_orgnlmsgnmid(parserxml.getTag_720ORGGRPINF_ORGNLMSGNMID(path, root));
		operationSepa.setOrgnlinstrid(parserxml.getTag_720ORGNLINSTRID(path, root));
		operationSepa.setOrgnlendtoendid(parserxml.getTag_720ORGNLENDTOENDID(path, root));
		operationSepa.setOrgnlintrbksttlmamt(getBigDecimal(getDouble(parserxml.getTag_720ORGNLINTRBKSTTLMAMT(path, root)),2));
		operationSepa.setOrgnlintrbksttlmamtc(parserxml.getTag_720ORGNLINTRBKSTTLMAMTC(path, root));
		operationSepa.setOtr_intrbksttlmdt(getDateSql(parserxml.getTag_720OTR_INTRBKSTTLMDT(path, root)));
		operationSepa.setInstdamt(getDouble(parserxml.getTag_720INSTDAMT(path, root)));
		operationSepa.setInstdamtc(parserxml.getTag_720INSTDAMTC(path, root));
		operationSepa.setRi_rorg_name(parserxml.getTag_720RI_RORG_NAME(path, root));
		operationSepa.setRi_rorg_id_org_bic_bei(parserxml.getTag_720RI_RORG_ID_ORG_BIC_BEI(path, root));
		operationSepa.setRi_rsn_cd(parserxml.getTag_720RI_RSN_CD(path, root));
		operationSepa.setRi_addtlinf1(parserxml.getTag_720RI_ADDTLINF1(path, root));
		operationSepa.setOtr_stti_sttlmmtd(parserxml.getTag_720OTR_STTI_STTLMMTD(path, root));
		operationSepa.setOtr_stti_sttaid_iban(parserxml.getTag_720OTR_STTI_STTAID_IBAN(path, root));
		operationSepa.setOtr_stti_sttaid_o_id(parserxml.getTag_720OTR_STTI_STTAID_O_ID(path, root));
		operationSepa.setOtr_stti_sttaid_o_sn_cd(parserxml.getTag_720OTR_STTI_STTAID_O_SN_CD(path, root));
		operationSepa.setOtr_stti_sttaid_o_sn_prtr(parserxml.getTag_720OTR_STTI_STTAID_O_SN_PRTR(path, root));
		operationSepa.setOtr_stti_sttaid_o_issr(parserxml.getTag_720OTR_STTI_STTAID_O_ISSR(path, root));
		operationSepa.setOtr_stti_clrs_cd(parserxml.getTag_720OTR_STTI_CLRS_CD(path, root));
		operationSepa.setOtr_stti_clrs_prtry(parserxml.getTag_720OTR_STTI_CLRS_PRTRY(path, root));
		operationSepa.setBic_id_debitor(parserxml.getTag_720BIC_ID_Debitor(path, root));
		operationSepa.setBic_id_creditor(parserxml.getTag_720BIC_ID_Creditor(path, root));
		operationSepa.setIban_debitor(parserxml.getTag_720IBAN_DEBTOR(path, root));
		operationSepa.setIban_creditor (parserxml.getTag_720IBAN_CREDITOR(path, root));
		operationSepa.setBic_id_do(parserxml.getTag_720BIC_ID_DO(path, root));
		operationSepa.setIban_do  (parserxml.getTag_720IBAN_DO(path, root));
		operationSepa.setBic_id_beneficiaire(parserxml.getTag_720BIC_ID_BENEFICIAIRE(path, root));
		operationSepa.setIban_beneficiaire(parserxml.getTag_720IBAN_BENEFICIAIRE(path, root));	
		operationSepa.setFlag_evolmpm_maeva("EVOLMPM");
		
	}


	private void parseCode920(OperationSepaBean operationSepa, Element root, XPath path) throws XPathExpressionException {
		
        final ParseXMLSepaSCT parserxml = new ParseXMLSepaSCT();

		operationSepa.setMotif_rejet_annulation(parserxml.getTag_920MOTIF_REJET_ANNULATION(path, root));
		operationSepa.setPmttpi_svclvl_cd(parserxml.getTag_920PMTTPI_SVCLVL_CD(path, root));
		operationSepa.setPmttpi_lclins_cd(parserxml.getTag_920PMTTPI_LCLINS_CD(path, root));
		operationSepa.setPmttpilclins_prtry(parserxml.getTag_920PMTTPILCLINS_PRTRY(path, root));
		operationSepa.setPmttpi_ctgypurp(parserxml.getTag_920PMTTPI_CTGYPURP(path, root));
		operationSepa.setUcdt_name(parserxml.getTag_920UCDT_NAME(path, root));
		operationSepa.setUcdt_id_org_bic_bei(parserxml.getTag_920UCDT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setUcdt_id_org_othr_id(parserxml.getTag_920UCDT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setUcdt_id_org_othr_sch_cd(parserxml.getTag_920UCDT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setUcdt_id_org_othr_sch_prtry(parserxml.getTag_920UCDT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setUcdt_id_org_othr_issr(parserxml.getTag_920UCDT_ID_ORG_OTHR_ISSR(path, root));
		operationSepa.setUcdt_id_pr_dpbi_da(getDateSql(parserxml.getTag_920UCDT_ID_PR_DPBI_DA(path, root)));
		operationSepa.setUcdt_id_pr_dpbi_prv(parserxml.getTag_920UCDT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setUcdt_id_pr_dpbi_ct(parserxml.getTag_920UCDT_ID_PR_DPBI_CT(path, root));
		operationSepa.setUcdt_id_pr_dpbi_cr(parserxml.getTag_920UCDT_ID_PR_DPBI_CR(path, root));
		operationSepa.setUcdt_id_prv_othr_id(parserxml.getTag_920UCDT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setUcdt_id_prv_othr_sch_cd(parserxml.getTag_920UCDT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setUcdt_id_prv_othr_sch_prtr(parserxml.getTag_920UCDT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setUcdt_id_prv_othr_issr(parserxml.getTag_920UCDT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setDbt_name(parserxml.getTag_920DBT_NAME(path, root));
		operationSepa.setDbt_padr_adrline(parserxml.getTag_920DBT_PADR_ADRLINE(path, root));
		operationSepa.setDbt_padr_ctry(parserxml.getTag_920DBT_PADR_CTRY(path, root));
		operationSepa.setDbt_id_org_bic_bei(parserxml.getTag_920DBT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setDbt_id_org_othr_id(parserxml.getTag_920DBT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setDbt_id_org_othr_sch_cd(parserxml.getTag_920DBT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setDbt_id_org_othr_sch_prtry(parserxml.getTag_920DBT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setDbt_id_org_othr_issr(parserxml.getTag_920DBT_ID_ORG_OTHR_ISSR(path, root));
		operationSepa.setDbt_id_pr_dpbi_dat(getDateSql(parserxml.getTag_920DBT_ID_PR_DPBI_DAT(path, root)));
		operationSepa.setDbt_id_pr_dpbi_prv(parserxml.getTag_920DBT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setDbt_id_pr_dpbi_cty(parserxml.getTag_920DBT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setDbt_id_pr_dpbi_cr(parserxml.getTag_920DBT_ID_PR_DPBI_CR(path, root));
		operationSepa.setDbt_id_prv_othr_id(parserxml.getTag_920DBT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setDbt_id_prv_othr_sch_cd(parserxml.getTag_920DBT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setDbt_id_prv_othr_sch_prtr(parserxml.getTag_920DBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setDbt_id_prv_othr_issr(parserxml.getTag_920DBT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setDbtacc_id_iban(parserxml.getTag_920DBTACC_ID_IBAN(path, root));
		operationSepa.setDbtagt_fi_bic(parserxml.getTag_920DBTAGT_FI_BIC(path, root));
		operationSepa.setCdtagt_fi_bic(parserxml.getTag_920CDTAGT_FI_BIC(path, root));
		operationSepa.setCdt_name(parserxml.getTag_920CDT_NAME(path, root));
		operationSepa.setCdt_padr_adrline(parserxml.getTag_920CDT_PADR_ADRLINE(path, root));
		operationSepa.setCdt_padr_ctry(parserxml.getTag_920CDT_PADR_CTRY(path, root));
		operationSepa.setCdt_id_org_bic_bei(parserxml.getTag_920CDT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setCdt_id_org_othr_id(parserxml.getTag_920CDT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setCdt_id_org_othr_sch_cd(parserxml.getTag_920CDT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setCdt_id_org_othr_sch_prtry(parserxml.getTag_920CDT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setCdt_id_org_othr_issr(parserxml.getTag_920CDT_ID_ORG_OTHR_ISSR(path, root));
		operationSepa.setCdt_id_pr_dpbi_dat(getDateSql(parserxml.getTag_920CDT_ID_PR_DPBI_DAT(path, root)));
		operationSepa.setCdt_id_pr_dpbi_prv(parserxml.getTag_920CDT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setCdt_id_pr_dpbi_cty(parserxml.getTag_920CDT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setCdt_id_pr_dpbi_cry(parserxml.getTag_920CDT_ID_PR_DPBI_CRY(path, root));
		operationSepa.setCdt_id_prv_othr_id(parserxml.getTag_920CDT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setCdt_id_prv_othr_sch_cd(parserxml.getTag_920CDT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setCdt_id_prv_othr_sch_prtr(parserxml.getTag_920CDT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setUdbt_name(parserxml.getTag_920UDBT_NAME(path, root));
		operationSepa.setUdbt_id_org_bic_bei(parserxml.getTag_920UDBT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setUdbt_id_org_othr_id(parserxml.getTag_920UDBT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setUdbt_id_org_othr_sch_cd(parserxml.getTag_920UDBT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setUdbt_id_org_othr_sch_prtr(parserxml.getTag_920UDBT_ID_ORG_OTHR_SCH_PRTR(path, root));
		operationSepa.setUdbt_id_org_othr_sch_issr(parserxml.getTag_920UDBT_ID_ORG_OTHR_SCH_ISSR(path, root));
		operationSepa.setUdbt_id_pr_dpbi_dat(getDateSql(parserxml.getTag_920UDBT_ID_PR_DPBI_DAT(path, root)));
		operationSepa.setUdbt_id_pr_dpbi_prv(parserxml.getTag_920UDBT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setUdbt_id_pr_dpbi_cty(parserxml.getTag_920UDBT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setUdbt_id_pr_dpbi_cry(parserxml.getTag_920UDBT_ID_PR_DPBI_CRY(path, root));
		operationSepa.setUdbt_id_prv_othr_id(parserxml.getTag_920UDBT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setUdbt_id_prv_othr_sch_cd(parserxml.getTag_920UDBT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setUdbt_id_prv_othr_sch_prtr(parserxml.getTag_920UDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setUdbt_id_prv_othr_issr(parserxml.getTag_920UDBT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setInsgagt_fi_bic(parserxml.getTag_920INSGAGT_FI_BIC(path, root));
		operationSepa.setInsdagt_fi_bic(parserxml.getTag_920INSDAGT_FI_BIC(path, root));
		operationSepa.setRmtinf_ustrd(parserxml.getTag_920RMTINF_USTRD(path, root));
		operationSepa.setRmtinf_strd_type_code(parserxml.getTag_920RMTINF_STRD_TYPE_CODE(path, root));
		operationSepa.setRmtinf_strd_type_ref(parserxml.getTag_920RMTINF_STRD_TYPE_REF(path, root));
		operationSepa.setOrgnltxid(parserxml.getTag_920ORGNLTXID(path, root));
		operationSepa.setOrgnlinstrid(parserxml.getTag_920ORGNLINSTRID(path, root));
		operationSepa.setOrgnlendtoendid(parserxml.getTag_920ORGNLENDTOENDID(path, root));
		operationSepa.setTxsts(parserxml.getTag_920TXSTS(path, root));
		operationSepa.setOrgnlintrbksttlmamt(getBigDecimal(getDouble(parserxml.getTag_920ORGNLINTRBKSTTLMAMT(path, root)),2));
		operationSepa.setOtr_intrbksttlmdt(getDateSql(parserxml.getTag_920OTR_INTRBKSTTLMDT(path, root)));
		operationSepa.setRi_rorg_name(parserxml.getTag_920RI_RORG_NAME(path, root));
		operationSepa.setRi_rorg_id_org_bic_bei(parserxml.getTag_920RI_RORG_ID_ORG_BIC_BEI(path, root));
		operationSepa.setRi_rsn_cd(parserxml.getTag_920RI_RSN_CD(path, root));
		operationSepa.setRi_sn_prtry(parserxml.getTag_920RI_SN_PRTRY(path, root));
		operationSepa.setOtr_stti_sttlmmtd(parserxml.getTag_920OTR_STTI_STTLMMTD(path, root));
		operationSepa.setOtr_stti_sttaid_iban(parserxml.getTag_920OTR_STTI_STTAID_IBAN(path, root));
		operationSepa.setOtr_stti_sttaid_o_id(parserxml.getTag_920OTR_STTI_STTAID_O_ID(path, root));
		operationSepa.setOtr_stti_sttaid_o_sn_cd(parserxml.getTag_920OTR_STTI_STTAID_O_SN_CD(path, root));
		operationSepa.setOtr_stti_sttaid_o_sn_prtr(parserxml.getTag_920OTR_STTI_STTAID_O_SN_PRTR(path, root));
		operationSepa.setOtr_stti_sttaid_o_issr(parserxml.getTag_920OTR_STTI_STTAID_O_ISSR(path, root));
		operationSepa.setOtr_stti_clrs_cd(parserxml.getTag_920OTR_STTI_CLRS_CD(path, root));
		operationSepa.setOtr_stti_clrs_prtry(parserxml.getTag_920OTR_STTI_CLRS_PRTRY(path, root));
		operationSepa.setFlag_evolmpm_maeva("EVOLMPM");
		
		
	}


	private void parseCode340Or380(OperationSepaBean operationSepa, Element root, XPath path) throws XPathExpressionException {
		final ParseXMLSepaSDD parser = new ParseXMLSepaSDD();
		
		//operationSepa.setCode_format_pacs(parser.getTagCODE_FORMAT_PACS(path, root));
		operationSepa.setPmtid_txid(parser.getTagPMTID_TXID(path, root));
		operationSepa.setPmtid_instrid(parser.getTagPMTID_INSTRID(path, root));
		operationSepa.setPmtid_endtoendid(parser.getTagPMTID_ENDTOENDID(path, root));
		operationSepa.setPmttpi_svclvl_cd(parser.getTagPMTTPI_SVCLVL_CD(path, root));
		operationSepa.setPmttpi_lclins_cd(parser.getTagPMTTPI_LCLINS_CD(path, root));
		operationSepa.setPmttpilclins_prtry(parser.getTagPMTTPILCLINS_PRTRY(path, root));
		operationSepa.setPmttpi_seqtp(parser.getTagPMTTPI_SEQTP(path, root));
		operationSepa.setPmttpi_ctgypurp(parser.getTagPMTTPI_CTGYPURP(path, root));
		operationSepa.setIntrbksttlmamt(getBigDecimal(getDouble(parser.getTagINTRBKSTTLMAMT(path, root)),2));
		operationSepa.setIntrbksttlmamtc(parser.getTagINTRBKSTTLMAMTC(path, root));
		operationSepa.setChrgbr(parser.getTagCHRGBR(path, root));
		operationSepa.setReqdcolltndt(UtilFunctions.getDateSql(parser.getTagREQDCOLLTNDT(path, root)));
		operationSepa.setM_mndtid(parser.getTagM_MNDTID(path, root));
		operationSepa.setM_dtofsgntr(UtilFunctions.getDateSql(parser.getTagM_DTOFSGNTR(path, root)));
		operationSepa.setM_amdmntind(parser.getTagM_AMDMNTIND(path, root));
		operationSepa.setM_a_orgnlmndtid(parser.getTagM_A_ORGNLMNDTID(path, root));
		operationSepa.setM_a_s_nm(parser.getTagM_A_S_NM(path, root));
		operationSepa.setM_a_s_id_proid(parser.getTagM_A_S_ID_PROID(path, root));
		operationSepa.setM_a_s_id_pro_sch_cd(parser.getTagM_A_S_ID_PRO_SCH_CD(path, root));
		operationSepa.setM_a_s_id_pro_sch_prtry(parser.getTagM_A_S_ID_PRO_SCH_PRTRY(path, root));
		operationSepa.setM_a_s_id_pro_issr(parser.getTagM_A_S_ID_PRO_ISSR(path, root));
		operationSepa.setM_a_odac_id_iban(parser.getTagM_A_ODAC_ID_IBAN(path, root));
		operationSepa.setM_a_odag_fi_othr_id(parser.getTagM_A_ODAG_FI_OTHR_ID(path, root));
		operationSepa.setM_elctrncsgnt(parser.getTagM_ELCTRNCSGNT(path, root));
		operationSepa.setM_a_odac_v9_id_othr_id(parser.getTagM_A_ODAC_V9_ID_OTHR_ID(path, root));
		operationSepa.setM_a_odac_v9_fi_bic(parser.getTagM_A_ODAC_V9_FI_BIC(path, root));
		operationSepa.setNum_ics(parser.getTagNUM_ICS(path, root));
		operationSepa.setCsch_idproi(parser.getTagCSCH_IDPROI(path, root));
		operationSepa.setCsch_idproi_cd(parser.getTagCSCH_IDPROI_CD(path, root));
		operationSepa.setCsch_idproi_prtry(parser.getTagCSCH_IDPROI_PRTRY(path, root));
		operationSepa.setCsch_idproi_issr(parser.getTagCSCH_IDPROI_ISSR(path, root));
		operationSepa.setUcdt_name(parser.getTagUCDT_NAME(path, root));
		operationSepa.setUcdt_id_org_bic_bei(parser.getTagUCDT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setUcdt_id_org_othr_id(parser.getTagUCDT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setUcdt_id_org_othr_sch_cd(parser.getTagUCDT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setUcdt_id_org_othr_sch_prtry(parser.getTagUCDT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setUcdt_id_org_othr_issr(parser.getTagUCDT_ID_ORG_OTHR_ISSR(path, root));
		operationSepa.setUcdt_id_pr_dpbi_da(UtilFunctions.getDateSql(parser.getTagUCDT_ID_PR_DPBI_DA(path, root)));
		operationSepa.setUcdt_id_pr_dpbi_prv(parser.getTagUCDT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setUcdt_id_pr_dpbi_ct(parser.getTagUCDT_ID_PR_DPBI_CT(path, root));
		operationSepa.setUcdt_id_pr_dpbi_cr(parser.getTagUCDT_ID_PR_DPBI_CR(path, root));
		operationSepa.setUcdt_id_prv_othr_id(parser.getTagUCDT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setUcdt_id_prv_othr_sch_cd(parser.getTagUCDT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setUcdt_id_prv_othr_sch_prtr(parser.getTagUCDT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setUcdt_id_prv_othr_issr(parser.getTagUCDT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setDbt_name(parser.getTagDBT_NAME(path, root));
		operationSepa.setDbt_padr_adrline(parser.getTagDBT_PADR_ADRLINE(path, root));
		operationSepa.setDbt_padr_ctry(parser.getTagDBT_PADR_CTRY(path, root));
		operationSepa.setDbt_id_org_bic_bei(parser.getTagDBT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setDbt_id_org_othr_id(parser.getTagDBT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setDbt_id_org_othr_sch_cd(parser.getTagDBT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setDbt_id_org_othr_sch_prtry(parser.getTagDBT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		operationSepa.setDbt_id_org_othr_issr(parser.getTagDBT_ID_ORG_OTHR_ISSR(path, root));
		operationSepa.setDbt_id_pr_dpbi_dat(UtilFunctions.getDateSql(parser.getTagDBT_ID_PR_DPBI_DAT(path, root)));
		operationSepa.setDbt_id_pr_dpbi_prv(parser.getTagDBT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setDbt_id_pr_dpbi_cty(parser.getTagDBT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setDbt_id_pr_dpbi_cr(parser.getTagDBT_ID_PR_DPBI_CR(path, root));
		operationSepa.setDbt_id_prv_othr_id(parser.getTagDBT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setDbt_id_prv_othr_sch_cd(parser.getTagDBT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setDbt_id_prv_othr_sch_prtr(parser.getTagDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setDbt_id_prv_othr_issr(parser.getTagDBT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setDbtacc_id_iban(parser.getTagDBTACC_ID_IBAN(path, root));
		operationSepa.setDbtagt_fi_bic(parser.getTagDBTAGT_FI_BIC(path, root));
		operationSepa.setCdtacc_id_iban(parser.getTagCDTACC_ID_IBAN(path, root));
		operationSepa.setCdtagt_fi_bic(parser.getTagCDTAGT_FI_BIC(path, root));
		operationSepa.setCdt_name(parser.getTagCDT_NAME(path, root));
		operationSepa.setCdt_padr_adrline(parser.getTagCDT_PADR_ADRLINE(path, root));
		operationSepa.setCdt_padr_ctry(parser.getTagCDT_PADR_CTRY(path, root));
		operationSepa.setUdbt_name(parser.getTagUDBT_NAME(path, root));
		operationSepa.setUdbt_id_org_bic_bei(parser.getTagUDBT_ID_ORG_BIC_BEI(path, root));
		operationSepa.setUdbt_id_org_othr_id(parser.getTagUDBT_ID_ORG_OTHR_ID(path, root));
		operationSepa.setUdbt_id_org_othr_sch_cd(parser.getTagUDBT_ID_ORG_OTHR_SCH_CD(path, root));
		operationSepa.setUdbt_id_org_othr_sch_prtr(parser.getTagUDBT_ID_ORG_OTHR_SCH_PRTR(path, root));
		operationSepa.setUdbt_id_org_othr_sch_issr(parser.getTagUDBT_ID_ORG_OTHR_SCH_ISSR(path, root));
		operationSepa.setUdbt_id_pr_dpbi_dat(UtilFunctions.getDateSql(parser.getTagUDBT_ID_PR_DPBI_DAT(path, root)));
		operationSepa.setUdbt_id_pr_dpbi_prv(parser.getTagUDBT_ID_PR_DPBI_PRV(path, root));
		operationSepa.setUdbt_id_pr_dpbi_cty(parser.getTagUDBT_ID_PR_DPBI_CTY(path, root));
		operationSepa.setUdbt_id_pr_dpbi_cry(parser.getTagUDBT_ID_PR_DPBI_CRY(path, root));
		operationSepa.setUdbt_id_prv_othr_id(parser.getTagUDBT_ID_PRV_OTHR_ID(path, root));
		operationSepa.setUdbt_id_prv_othr_sch_cd(parser.getTagUDBT_ID_PRV_OTHR_SCH_CD(path, root));
		operationSepa.setUdbt_id_prv_othr_sch_prtr(parser.getTagUDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		operationSepa.setUdbt_id_prv_othr_issr(parser.getTagUDBT_ID_PRV_OTHR_ISSR(path, root));
		operationSepa.setInsgagt_fi_bic(parser.getTagINSGAGT_FI_BIC(path, root));
		operationSepa.setInsdagt_fi_bic(parser.getTagINSDAGT_FI_BIC(path, root));
		operationSepa.setRmtinf_ustrd(parser.getTagRMTINF_USTRD(path, root));
		operationSepa.setRmtinf_strd_type_code(parser.getTagRMTINF_STRD_TYPE_CODE(path, root));
		operationSepa.setRmtinf_strd_type_ref(parser.getTagRMTINF_STRD_TYPE_REF(path, root));
		operationSepa.setPur_cd(parser.getTagPUR_CD(path, root));
		operationSepa.setBic_id_debitor(parser.getTagBIC_ID_Debitor(path, root));
		operationSepa.setBic_id_creditor(parser.getTagBIC_ID_Creditor(path, root));
		operationSepa.setIban_debitor (parser.getTagIBAN_DEBTOR (path, root));
		operationSepa.setIban_creditor (parser.getTagIBAN_CREDITOR (path, root));
		operationSepa.setBic_id_do(parser.getTagBIC_ID_DO(path, root));
		operationSepa.setIban_do  (parser.getTagIBAN_DO  (path, root));
		operationSepa.setBic_id_beneficiaire(parser.getTagBIC_ID_BENEFICIAIRE(path, root));
		operationSepa.setIban_beneficiaire(parser.getTagIBAN_BENEFICIAIRE(path, root));	
		operationSepa.setFlag_evolmpm_maeva("EVOLMPM");
		
	}


	private void parseCode386(OperationSepaBean operationSepa, Element root, XPath path) throws XPathExpressionException {
		final ParseXMLSepaSDD386 parser = new ParseXMLSepaSDD386();
		
		operationSepa.setNum_ics(parser.getTagNUM_ICS(path,root));
		operationSepa.setPmttpi_svclvl_cd(parser.getTagPMTTPI_SVCLVL_CD(path,root));
		operationSepa.setPmttpi_lclins_cd(parser.getTagPMTTPI_LCLINS_CD(path,root));
		operationSepa.setPmttpilclins_prtry(parser.getTagPMTTPILCLINS_PRTRY(path,root));
		operationSepa.setPmttpi_seqtp(parser.getTagPMTTPI_SEQTP(path,root));
		operationSepa.setPmttpi_ctgypurp(parser.getTagPMTTPI_CTGYPURP(path,root));
		operationSepa.setPmttpi_ctgypurp_pr(parser.getTagPMTTPI_CTGYPURP_PR(path,root));
		operationSepa.setM_mndtid(parser.getTagM_MNDTID(path,root));
		operationSepa.setM_dtofsgntr(UtilFunctions.getDateSql(parser.getTagM_DTOFSGNTR(path,root)));
		operationSepa.setM_amdmntind(parser.getTagM_AMDMNTIND(path,root));
		operationSepa.setM_a_orgnlmndtid(parser.getTagM_A_ORGNLMNDTID(path,root));
		operationSepa.setM_a_s_nm(parser.getTagM_A_S_NM(path,root));
		operationSepa.setM_a_s_id_proid(parser.getTagM_A_S_ID_PROID(path,root));
		operationSepa.setM_a_s_id_pro_sch_cd(parser.getTagM_A_S_ID_PRO_SCH_CD(path,root));
		operationSepa.setM_a_s_id_pro_sch_prtry(parser.getTagM_A_S_ID_PRO_SCH_PRTRY(path,root));
		operationSepa.setM_a_s_id_pro_issr(parser.getTagM_A_S_ID_PRO_ISSR(path,root));
		operationSepa.setM_a_odac_id_iban(parser.getTagM_A_ODAC_ID_IBAN(path,root));
		operationSepa.setM_a_odag_fi_othr_id(parser.getTagM_A_ODAG_FI_OTHR_ID(path,root));
		operationSepa.setM_elctrncsgnt(parser.getTagM_ELCTRNCSGNT(path,root));
		operationSepa.setUcdt_name(parser.getTagUCDT_NAME(path,root));
		operationSepa.setUcdt_id_org_bic_bei(parser.getTagUCDT_ID_ORG_BIC_BEI(path,root));
		operationSepa.setUcdt_id_org_othr_id(parser.getTagUCDT_ID_ORG_OTHR_ID(path,root));
		operationSepa.setUcdt_id_org_othr_sch_cd(parser.getTagUCDT_ID_ORG_OTHR_SCH_CD(path,root));
		operationSepa.setUcdt_id_org_othr_sch_prtry(parser.getTagUCDT_ID_ORG_OTHR_SCH_PRTRY(path,root));
		operationSepa.setUcdt_id_org_othr_issr(parser.getTagUCDT_ID_ORG_OTHR_ISSR(path,root));
		operationSepa.setUcdt_id_pr_dpbi_da(UtilFunctions.getDateSql(parser.getTagUCDT_ID_PR_DPBI_DA(path,root)));
		operationSepa.setUcdt_id_pr_dpbi_prv(parser.getTagUCDT_ID_PR_DPBI_PRV(path,root));
		operationSepa.setUcdt_id_pr_dpbi_ct(parser.getTagUCDT_ID_PR_DPBI_CT(path,root));
		operationSepa.setUcdt_id_pr_dpbi_cr(parser.getTagUCDT_ID_PR_DPBI_CR(path,root));
		operationSepa.setUcdt_id_prv_othr_id(parser.getTagUCDT_ID_PRV_OTHR_ID(path,root));
		operationSepa.setUcdt_id_prv_othr_sch_cd(parser.getTagUCDT_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setUcdt_id_prv_othr_sch_prtr(parser.getTagUCDT_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setUcdt_id_prv_othr_issr(parser.getTagUCDT_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setDbt_name(parser.getTagDBT_NAME(path,root));
		operationSepa.setDbt_padr_adrline(parser.getTagDBT_PADR_ADRLINE(path,root));
		operationSepa.setDbt_padr_ctry(parser.getTagDBT_PADR_CTRY(path,root));
		operationSepa.setDbt_id_org_bic_bei(parser.getTagDBT_ID_ORG_BIC_BEI(path,root));
		operationSepa.setDbt_id_org_othr_id(parser.getTagDBT_ID_ORG_OTHR_ID(path,root));
		operationSepa.setDbt_id_org_othr_sch_cd(parser.getTagDBT_ID_ORG_OTHR_SCH_CD(path,root));
		operationSepa.setDbt_id_org_othr_sch_prtry(parser.getTagDBT_ID_ORG_OTHR_SCH_PRTRY(path,root));
		operationSepa.setDbt_id_org_othr_issr(parser.getTagDBT_ID_ORG_OTHR_ISSR(path,root));
		operationSepa.setDbt_id_pr_dpbi_dat(UtilFunctions.getDateSql(parser.getTagDBT_ID_PR_DPBI_DAT(path,root)));
		operationSepa.setDbt_id_pr_dpbi_prv(parser.getTagDBT_ID_PR_DPBI_PRV(path,root));
		operationSepa.setDbt_id_pr_dpbi_cty(parser.getTagDBT_ID_PR_DPBI_CTY(path,root));
		operationSepa.setDbt_id_pr_dpbi_cr(parser.getTagDBT_ID_PR_DPBI_CR(path,root));
		operationSepa.setDbt_id_prv_othr_id(parser.getTagDBT_ID_PRV_OTHR_ID(path,root));
		operationSepa.setDbt_id_prv_othr_sch_cd(parser.getTagDBT_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setDbt_id_prv_othr_sch_prtr(parser.getTagDBT_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setDbt_id_prv_othr_issr(parser.getTagDBT_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setDbtacc_id_iban(parser.getTagDBTACC_ID_IBAN(path,root));
		operationSepa.setDbtagt_fi_bic(parser.getTagDBTAGT_FI_BIC(path,root));
		operationSepa.setCdtacc_id_iban(parser.getTagCDTACC_ID_IBAN(path,root));
		operationSepa.setCdtagt_fi_bic(parser.getTagCDTAGT_FI_BIC(path,root));
		operationSepa.setCdt_name(parser.getTagCDT_NAME(path,root));
		operationSepa.setCdt_padr_adrline(parser.getTagCDT_PADR_ADRLINE(path,root));
		operationSepa.setCdt_padr_ctry(parser.getTagCDT_PADR_CTRY(path,root));
		operationSepa.setCdt_id_org_bic_bei(parser.getTagCDT_ID_ORG_BIC_BEI(path,root));
		operationSepa.setCdt_id_org_othr_id(parser.getTagCDT_ID_ORG_OTHR_ID(path,root));
		operationSepa.setCdt_id_org_othr_sch_cd(parser.getTagCDT_ID_ORG_OTHR_SCH_CD(path,root));
		operationSepa.setCdt_id_org_othr_sch_prtry(parser.getTagCDT_ID_ORG_OTHR_SCH_PRTRY(path,root));
		operationSepa.setCdt_id_org_othr_issr(parser.getTagCDT_ID_ORG_OTHR_ISSR(path,root));
		operationSepa.setCdt_id_pr_dpbi_dat(UtilFunctions.getDateSql(parser.getTagCDT_ID_PR_DPBI_DAT(path,root)));
		operationSepa.setCdt_id_pr_dpbi_prv(parser.getTagCDT_ID_PR_DPBI_PRV(path,root));
		operationSepa.setCdt_id_pr_dpbi_cty(parser.getTagCDT_ID_PR_DPBI_CTY(path,root));
		operationSepa.setCdt_id_pr_dpbi_cry(parser.getTagCDT_ID_PR_DPBI_CRY(path,root));
		operationSepa.setCdt_id_prv_othr_id(parser.getTagCDT_ID_PRV_OTHR_ID(path,root));
		operationSepa.setCdt_id_prv_othr_sch_cd(parser.getTagCDT_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setCdt_id_prv_othr_sch_prtr(parser.getTagCDT_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setCdt_id_prv_othr_issr(parser.getTagCDT_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setUdbt_name(parser.getTagUDBT_NAME(path,root));
		operationSepa.setUdbt_id_org_bic_bei(parser.getTagUDBT_ID_ORG_BIC_BEI(path,root));
		operationSepa.setUdbt_id_org_othr_id(parser.getTagUDBT_ID_ORG_OTHR_ID(path,root));
		operationSepa.setUdbt_id_org_othr_sch_cd(parser.getTagUDBT_ID_ORG_OTHR_SCH_CD(path,root));
		operationSepa.setUdbt_id_org_othr_sch_prtr(parser.getTagUDBT_ID_ORG_OTHR_SCH_PRTR(path,root));
		operationSepa.setUdbt_id_org_othr_sch_issr(parser.getTagUDBT_ID_ORG_OTHR_SCH_ISSR(path,root));
		operationSepa.setUdbt_id_pr_dpbi_dat(UtilFunctions.getDateSql(parser.getTagUDBT_ID_PR_DPBI_DAT(path,root)));
		operationSepa.setUdbt_id_pr_dpbi_prv(parser.getTagUDBT_ID_PR_DPBI_PRV(path,root));
		operationSepa.setUdbt_id_pr_dpbi_cty(parser.getTagUDBT_ID_PR_DPBI_CTY(path,root));
		operationSepa.setUdbt_id_pr_dpbi_cry(parser.getTagUDBT_ID_PR_DPBI_CRY(path,root));
		operationSepa.setUdbt_id_prv_othr_id(parser.getTagUDBT_ID_PRV_OTHR_ID(path,root));
		operationSepa.setUdbt_id_prv_othr_sch_cd(parser.getTagUDBT_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setUdbt_id_prv_othr_sch_prtr(parser.getTagUDBT_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setUdbt_id_prv_othr_issr(parser.getTagUDBT_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setRmtinf_ustrd(parser.getTagRMTINF_USTRD(path,root));
		operationSepa.setRmtinf_strd_type_code(parser.getTagRMTINF_STRD_TYPE_CODE(path,root));
		operationSepa.setRmtinf_strd_type_ref(parser.getTagRMTINF_STRD_TYPE_REF(path,root));
		operationSepa.setRmtinf_strd_type_is(parser.getTagRMTINF_STRD_TYPE_IS(path,root));
		operationSepa.setOrgnltxid(parser.getTagORGNLTXID(path,root));
		operationSepa.setOrggrpinf_orgnlmsgid(parser.getTagORGGRPINF_ORGNLMSGID(path,root));
		operationSepa.setOrggrpinf_orgnlmsgnmid(parser.getTagORGGRPINF_ORGNLMSGNMID(path,root));
		operationSepa.setOrgnlinstrid(parser.getTagORGNLINSTRID(path,root));
		operationSepa.setOrgnlendtoendid(parser.getTagORGNLENDTOENDID(path,root));
		operationSepa.setOrgnlintrbksttlmamt(getBigDecimal(parser.getTagORGNLINTRBKSTTLMAMT(path,root),2));
		operationSepa.setOrgnlintrbksttlmamtc(parser.getTagORGNLINTRBKSTTLMAMTC(path,root));
		operationSepa.setOtr_intrbksttlmdt(UtilFunctions.getDateSql(parser.getTagOTR_INTRBKSTTLMDT(path,root)));
		operationSepa.setRi_rorg_name(parser.getTagRI_RORG_NAME(path,root));
		operationSepa.setRi_rorg_id_org_bic_bei(parser.getTagRI_RORG_ID_ORG_BIC_BEI(path,root));
		operationSepa.setRi_rsn_cd(parser.getTagRI_RSN_CD(path,root));
		operationSepa.setRi_sn_prtry(parser.getTagRI_SN_PRTRY(path,root));
		operationSepa.setOtr_reqdcolltndt(parser.getTagOTR_REQDCOLLTNDT(path,root));
		operationSepa.setOtr_csch_id_prv_othr_id(parser.getTagOTR_CSCH_ID_PRV_OTHR_ID(path,root));
		operationSepa.setOtr_csch_id_prv_othr_sch_cd(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setOtr_csch_id_prv_othr_issr(parser.getTagOTR_CSCH_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setOtr_csch_id_prv_othr_sch_prtr(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setOtr_stti_sttlmmtd(parser.getTagOTR_STTI_STTLMMTD(path,root));
		operationSepa.setOtr_stti_sttaid_iban(parser.getTagOTR_STTI_STTAID_IBAN(path,root));
		operationSepa.setOtr_stti_sttaid_o_id(parser.getTagOTR_STTI_STTAID_O_ID(path,root));
		operationSepa.setOtr_stti_sttaid_o_sn_cd(parser.getTagOTR_STTI_STTAID_O_SN_CD(path,root));
		operationSepa.setOtr_stti_sttaid_o_sn_prtr(parser.getTagOTR_STTI_STTAID_O_SN_PRTR(path,root));
		operationSepa.setOtr_stti_sttaid_o_issr(parser.getTagOTR_STTI_STTAID_O_ISSR(path,root));
		operationSepa.setOtr_stti_clrs_cd(parser.getTagOTR_STTI_CLRS_CD(path,root));
		operationSepa.setOtr_stti_clrs_prtry(parser.getTagOTR_STTI_CLRS_PRTRY(path,root));
		operationSepa.setBic_id_debitor(parser.getTagBIC_ID_Debitor(path,root));
		operationSepa.setBic_id_creditor(parser.getTagBIC_ID_Creditor(path,root));
		operationSepa.setRef_operation_origine (parser.getTagREF_OPERATION_ORIGINE (path,root));
		operationSepa.setIban_debitor (parser.getTagIBAN_DEBITOR (path,root));
		operationSepa.setIban_creditor (parser.getTagIBAN_CREDITOR (path,root));
		operationSepa.setM_a_odac_v9_id_othr_id(parser.getTagM_A_ODAC_V9_ID_OTHR_ID(path,root));
		operationSepa.setM_a_odac_v9_fi_bic(parser.getTagM_A_ODAC_V9_FI_BIC(path,root));
		operationSepa.setBic_id_do(parser.getTagBIC_ID_DO(path,root));
		operationSepa.setIban_do  (parser.getTagIBAN_DO  (path,root));
		operationSepa.setBic_id_beneficiaire(parser.getTagBIC_ID_BENEFICIAIRE(path,root));
		operationSepa.setIban_beneficiaire(parser.getTagIBAN_BENEFICIAIRE(path,root));
		operationSepa.setFlag_evolmpm_maeva("EVOLMPM");
	
		
	}


	private void parseCode615(OperationSepaBean operationSepa, Element root, XPath path) throws XPathExpressionException {
		final ParseXMLSepaSDD615 parser = new ParseXMLSepaSDD615();
		
		operationSepa.setNum_ics(parser.getTagNUM_ICS(path,root));
		operationSepa.setMotif_rejet_annulation(parser.getTagMOTIF_REJET_ANNULATION(path,root));
		operationSepa.setPmtid_txid(parser.getTagPMTID_TXID(path,root));
		operationSepa.setPmttpi_svclvl_cd(parser.getTagPMTTPI_SVCLVL_CD(path,root));
		operationSepa.setPmttpi_lclins_cd(parser.getTagPMTTPI_LCLINS_CD(path,root));
		operationSepa.setPmttpilclins_prtry(parser.getTagPMTTPILCLINS_PRTRY(path,root));
		operationSepa.setPmttpi_seqtp(parser.getTagPMTTPI_SEQTP(path,root));
		operationSepa.setPmttpi_ctgypurp(parser.getTagPMTTPI_CTGYPURP(path,root));
		operationSepa.setIntrbksttlmamt(getBigDecimal(parser.getTagINTRBKSTTLMAMT(path,root),2));
		operationSepa.setIntrbksttlmamtc(parser.getTagINTRBKSTTLMAMTC(path,root));
		operationSepa.setChrgbr(parser.getTagCHRGBR(path,root));
		operationSepa.setChrginf_amt(getDouble(parser.getTagCHRGINF_AMT(path,root)));
		operationSepa.setChrginf_amtc(parser.getTagCHRGINF_AMTC(path,root));
		operationSepa.setChrginf_pty_fi_bic(parser.getTagCHRGINF_PTY_FI_BIC(path,root));
		operationSepa.setM_mndtid(parser.getTagM_MNDTID(path,root));
		operationSepa.setM_dtofsgntr(UtilFunctions.getDateSql(parser.getTagM_DTOFSGNTR(path,root)));
		operationSepa.setM_amdmntind(parser.getTagM_AMDMNTIND(path,root));
		operationSepa.setM_a_orgnlmndtid(parser.getTagM_A_ORGNLMNDTID(path,root));
		operationSepa.setM_a_s_nm(parser.getTagM_A_S_NM(path,root));
		operationSepa.setM_a_s_id_proid(parser.getTagM_A_S_ID_PROID(path,root));
		operationSepa.setM_a_s_id_pro_sch_cd(parser.getTagM_A_S_ID_PRO_SCH_CD(path,root));
		operationSepa.setM_a_s_id_pro_sch_prtry(parser.getTagM_A_S_ID_PRO_SCH_PRTRY(path,root));
		operationSepa.setM_a_s_id_pro_issr(parser.getTagM_A_S_ID_PRO_ISSR(path,root));
		operationSepa.setM_a_odac_id_iban(parser.getTagM_A_ODAC_ID_IBAN(path,root));
		operationSepa.setM_a_odag_fi_othr_id(parser.getTagM_A_ODAG_FI_OTHR_ID(path,root));
		operationSepa.setM_elctrncsgnt(parser.getTagM_ELCTRNCSGNT(path,root));
		operationSepa.setUcdt_name(parser.getTagUCDT_NAME(path,root));
		operationSepa.setUcdt_id_org_bic_bei(parser.getTagUCDT_ID_ORG_BIC_BEI(path,root));
		operationSepa.setUcdt_id_org_othr_id(parser.getTagUCDT_ID_ORG_OTHR_ID(path,root));
		operationSepa.setUcdt_id_org_othr_sch_cd(parser.getTagUCDT_ID_ORG_OTHR_SCH_CD(path,root));
		operationSepa.setUcdt_id_org_othr_sch_prtry(parser.getTagUCDT_ID_ORG_OTHR_SCH_PRTRY(path,root));
		operationSepa.setUcdt_id_org_othr_issr(parser.getTagUCDT_ID_ORG_OTHR_ISSR(path,root));
		operationSepa.setUcdt_id_pr_dpbi_da(UtilFunctions.getDateSql(parser.getTagUCDT_ID_PR_DPBI_DA(path,root)));
		operationSepa.setUcdt_id_pr_dpbi_prv(parser.getTagUCDT_ID_PR_DPBI_PRV(path,root));
		operationSepa.setUcdt_id_pr_dpbi_ct(parser.getTagUCDT_ID_PR_DPBI_CT(path,root));
		operationSepa.setUcdt_id_pr_dpbi_cr(parser.getTagUCDT_ID_PR_DPBI_CR(path,root));
		operationSepa.setUcdt_id_prv_othr_id(parser.getTagUCDT_ID_PRV_OTHR_ID(path,root));
		operationSepa.setUcdt_id_prv_othr_sch_cd(parser.getTagUCDT_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setUcdt_id_prv_othr_sch_prtr(parser.getTagUCDT_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setUcdt_id_prv_othr_issr(parser.getTagUCDT_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setDbt_name(parser.getTagDBT_NAME(path,root));
		operationSepa.setDbt_padr_adrline(parser.getTagDBT_PADR_ADRLINE(path,root));
		operationSepa.setDbt_padr_ctry(parser.getTagDBT_PADR_CTRY(path,root));
		operationSepa.setDbt_id_org_bic_bei(parser.getTagDBT_ID_ORG_BIC_BEI(path,root));
		operationSepa.setDbt_id_org_othr_id(parser.getTagDBT_ID_ORG_OTHR_ID(path,root));
		operationSepa.setDbt_id_org_othr_sch_cd(parser.getTagDBT_ID_ORG_OTHR_SCH_CD(path,root));
		operationSepa.setDbt_id_org_othr_sch_prtry(parser.getTagDBT_ID_ORG_OTHR_SCH_PRTRY(path,root));
		operationSepa.setDbt_id_org_othr_issr(parser.getTagDBT_ID_ORG_OTHR_ISSR(path,root));
		operationSepa.setDbt_id_pr_dpbi_dat(UtilFunctions.getDateSql(parser.getTagDBT_ID_PR_DPBI_DAT(path,root)));
		operationSepa.setDbt_id_pr_dpbi_prv(parser.getTagDBT_ID_PR_DPBI_PRV(path,root));
		operationSepa.setDbt_id_pr_dpbi_cty(parser.getTagDBT_ID_PR_DPBI_CTY(path,root));
		operationSepa.setDbt_id_pr_dpbi_cr(parser.getTagDBT_ID_PR_DPBI_CR(path,root));
		operationSepa.setDbt_id_prv_othr_id(parser.getTagDBT_ID_PRV_OTHR_ID(path,root));
		operationSepa.setDbt_id_prv_othr_sch_cd(parser.getTagDBT_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setDbt_id_prv_othr_sch_prtr(parser.getTagDBT_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setDbt_id_prv_othr_issr(parser.getTagDBT_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setDbtacc_id_iban(parser.getTagDBTACC_ID_IBAN(path,root));
		operationSepa.setDbtagt_fi_bic(parser.getTagDBTAGT_FI_BIC(path,root));
		operationSepa.setCdtacc_id_iban(parser.getTagCDTACC_ID_IBAN(path,root));
		operationSepa.setCdtagt_fi_bic(parser.getTagCDTAGT_FI_BIC(path,root));
		operationSepa.setCdt_name(parser.getTagCDT_NAME(path,root));
		operationSepa.setCdt_padr_adrline(parser.getTagCDT_PADR_ADRLINE(path,root));
		operationSepa.setCdt_padr_ctry(parser.getTagCDT_PADR_CTRY(path,root));
		operationSepa.setUdbt_name(parser.getTagUDBT_NAME(path,root));
		operationSepa.setUdbt_id_org_bic_bei(parser.getTagUDBT_ID_ORG_BIC_BEI(path,root));
		operationSepa.setUdbt_id_org_othr_id(parser.getTagUDBT_ID_ORG_OTHR_ID(path,root));
		operationSepa.setUdbt_id_org_othr_sch_cd(parser.getTagUDBT_ID_ORG_OTHR_SCH_CD(path,root));
		operationSepa.setUdbt_id_org_othr_sch_prtr(parser.getTagUDBT_ID_ORG_OTHR_SCH_PRTR(path,root));
		operationSepa.setUdbt_id_org_othr_sch_issr(parser.getTagUDBT_ID_ORG_OTHR_SCH_ISSR(path,root));
		operationSepa.setUdbt_id_pr_dpbi_dat(UtilFunctions.getDateSql(parser.getTagUDBT_ID_PR_DPBI_DAT(path,root)));
		operationSepa.setUdbt_id_pr_dpbi_prv(parser.getTagUDBT_ID_PR_DPBI_PRV(path,root));
		operationSepa.setUdbt_id_pr_dpbi_cty(parser.getTagUDBT_ID_PR_DPBI_CTY(path,root));
		operationSepa.setUdbt_id_pr_dpbi_cry(parser.getTagUDBT_ID_PR_DPBI_CRY(path,root));
		operationSepa.setUdbt_id_prv_othr_id(parser.getTagUDBT_ID_PRV_OTHR_ID(path,root));
		operationSepa.setUdbt_id_prv_othr_sch_cd(parser.getTagUDBT_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setUdbt_id_prv_othr_sch_prtr(parser.getTagUDBT_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setUdbt_id_prv_othr_issr(parser.getTagUDBT_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setInsgagt_fi_bic(parser.getTagINSGAGT_FI_BIC(path,root));
		operationSepa.setInsdagt_fi_bic(parser.getTagINSDAGT_FI_BIC(path,root));
		operationSepa.setRmtinf_ustrd(parser.getTagRMTINF_USTRD(path,root));
		operationSepa.setRmtinf_strd_type_code(parser.getTagRMTINF_STRD_TYPE_CODE(path,root));
		operationSepa.setRmtinf_strd_type_ref(parser.getTagRMTINF_STRD_TYPE_REF(path,root));
		operationSepa.setOrgnltxid(parser.getTagORGNLTXID(path,root));
		operationSepa.setOrgnlinstrid(parser.getTagORGNLINSTRID(path,root));
		operationSepa.setOrgnlendtoendid(parser.getTagORGNLENDTOENDID(path,root));
		operationSepa.setOrgnlintrbksttlmamt(getBigDecimal(parser.getTagORGNLINTRBKSTTLMAMT(path,root),2));				
		operationSepa.setIntrbksttlmamtc(parser.getTagINTRBKSTTLMAMTC(path,root));	
		operationSepa.setOrgnlintrbksttlmamtc(parser.getTagORGNLINTRBKSTTLMAMTC(path,root));
		operationSepa.setOtr_intrbksttlmdt(UtilFunctions.getDateSql(parser.getTagOTR_INTRBKSTTLMDT(path,root)));
		operationSepa.setInstdamt(getDouble(parser.getTagINSTDAMT(path,root)));
		operationSepa.setInstdamtc(parser.getTagINSTDAMTC(path,root));
		operationSepa.setRi_rorg_name(parser.getTagRI_RORG_NAME(path,root));
		operationSepa.setRi_rorg_padr_adrline(parser.getTagRI_RORG_PADR_ADRLINE(path,root));
		operationSepa.setRi_rorg_padr_ctry(parser.getTagRI_RORG_PADR_CTRY(path,root));
		operationSepa.setRi_rorg_id_org_bic_bei(parser.getTagRI_RORG_ID_ORG_BIC_BEI(path,root));
		operationSepa.setRi_rorg_id_org_othr_id(parser.getTagRI_RORG_ID_ORG_OTHR_ID(path,root));
		operationSepa.setRi_rorg_id_org_othr_sch_cd(parser.getTagRI_RORG_ID_ORG_OTHR_SCH_CD(path,root));
		operationSepa.setRi_rorg_id_org_othr_sch_prtr(parser.getTagRI_RORG_ID_ORG_OTHR_SCH_PRTR(path,root));
		operationSepa.setRi_rorg_id_org_othr_issr(parser.getTagRI_RORG_ID_ORG_OTHR_ISSR(path,root));
		operationSepa.setRi_rorg_id_prv_dpbi_dat(UtilFunctions.getDateSql(parser.getTagRI_RORG_ID_PRV_DPBI_DAT(path,root)));
		operationSepa.setRi_rorg_id_prv_dpbi_prv(parser.getTagRI_RORG_ID_PRV_DPBI_PRV(path,root));
		operationSepa.setRi_rorg_id_prv_dpbi_cty(parser.getTagRI_RORG_ID_PRV_DPBI_CTY(path,root));
		operationSepa.setRi_rorg_id_prv_dpbi_cry(parser.getTagRI_RORG_ID_PRV_DPBI_CRY(path,root));
		operationSepa.setRi_rorg_id_prv_othr_id(parser.getTagRI_RORG_ID_PRV_OTHR_ID(path,root));
		operationSepa.setRi_rorg_id_prv_othr_sch_cd(parser.getTagRI_RORG_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setRi_rorg_id_prv_othr_sch_prtr(parser.getTagRI_RORG_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setRi_rorg_id_prv_othr_issr(parser.getTagRI_RORG_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setRi_rsn_cd(parser.getTagRI_RSN_CD(path,root));
		operationSepa.setOtr_reqdcolltndt(parser.getTagOTR_REQDCOLLTNDT(path,root));
		operationSepa.setOtr_csch_id_prv_othr_id(parser.getTagOTR_CSCH_ID_PRV_OTHR_ID(path,root));
		operationSepa.setOtr_csch_id_prv_othr_sch_cd(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setOtr_csch_id_prv_othr_issr(parser.getTagOTR_CSCH_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setOtr_csch_id_prv_othr_sch_prtr(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setOtr_stti_sttlmmtd(parser.getTagOTR_STTI_STTLMMTD(path,root));
		operationSepa.setOtr_stti_sttaid_iban(parser.getTagOTR_STTI_STTAID_IBAN(path,root));
		operationSepa.setOtr_stti_sttaid_o_id(parser.getTagOTR_STTI_STTAID_O_ID(path,root));
		operationSepa.setOtr_stti_sttaid_o_sn_cd(parser.getTagOTR_STTI_STTAID_O_SN_CD(path,root));
		operationSepa.setOtr_stti_sttaid_o_sn_prtr(parser.getTagOTR_STTI_STTAID_O_SN_PRTR(path,root));
		operationSepa.setOtr_stti_sttaid_o_issr(parser.getTagOTR_STTI_STTAID_O_ISSR(path,root));
		operationSepa.setOtr_stti_clrs_cd(parser.getTagOTR_STTI_CLRS_CD(path,root));
		operationSepa.setOtr_stti_clrs_prtry(parser.getTagOTR_STTI_CLRS_PRTRY(path,root));
		operationSepa.setBic_id_debitor(parser.getTagBIC_ID_Debitor(path,root));
		operationSepa.setBic_id_creditor(parser.getTagBIC_ID_Creditor(path,root));
		operationSepa.setRef_operation_origine (parser.getTagREF_OPERATION_ORIGINE (path,root));
		operationSepa.setIban_debitor (parser.getTagIBAN_DEBITOR (path,root));
		operationSepa.setIban_creditor (parser.getTagIBAN_CREDITOR (path,root));
		operationSepa.setM_a_odac_v9_id_othr_id(parser.getTagM_A_ODAC_V9_ID_OTHR_ID(path,root));
		operationSepa.setM_a_odac_v9_fi_bic(parser.getTagM_A_ODAC_V9_FI_BIC(path,root));
		operationSepa.setBic_id_do(parser.getTagBIC_ID_DO(path,root));
		operationSepa.setIban_do  (parser.getTagIBAN_DO  (path,root));
		operationSepa.setBic_id_beneficiaire(parser.getTagBIC_ID_BENEFICIAIRE(path,root));
		operationSepa.setIban_beneficiaire(parser.getTagIBAN_BENEFICIAIRE(path,root));
		operationSepa.setFlag_evolmpm_maeva("EVOLMPM");
		
		
	}


	private void parseCode680(OperationSepaBean operationSepa, Element root, XPath path) throws XPathExpressionException {
		final ParseXMLSepaSDD680 parser = new ParseXMLSepaSDD680();
		
		operationSepa.setNum_ics(parser.getTagNUM_ICS(path,root));
		operationSepa.setMotif_rejet_annulation(parser.getTagMOTIF_REJET_ANNULATION(path,root));
		operationSepa.setPmtid_txid(parser.getTagPMTID_TXID(path,root));
		operationSepa.setPmttpi_svclvl_cd(parser.getTagPMTTPI_SVCLVL_CD(path,root));
		operationSepa.setPmttpi_lclins_cd(parser.getTagPMTTPI_LCLINS_CD(path,root));
		operationSepa.setPmttpilclins_prtry(parser.getTagPMTTPILCLINS_PRTRY(path,root));
		operationSepa.setPmttpi_seqtp(parser.getTagPMTTPI_SEQTP(path,root));
		operationSepa.setPmttpi_ctgypurp(parser.getTagPMTTPI_CTGYPURP(path,root));
		operationSepa.setChrginf_amt(getDouble(parser.getTagCHRGINF_AMT(path,root)));
		operationSepa.setChrginf_amtc(parser.getTagCHRGINF_AMTC(path,root));
		operationSepa.setChrginf_pty_fi_bic(parser.getTagCHRGINF_PTY_FI_BIC(path,root));
		operationSepa.setM_mndtid(parser.getTagM_MNDTID(path,root));
		operationSepa.setM_dtofsgntr(UtilFunctions.getDateSql(parser.getTagM_DTOFSGNTR(path,root)));
		operationSepa.setM_amdmntind(parser.getTagM_AMDMNTIND(path,root));
		operationSepa.setM_a_orgnlmndtid(parser.getTagM_A_ORGNLMNDTID(path,root));
		operationSepa.setM_a_s_nm(parser.getTagM_A_S_NM(path,root));
		operationSepa.setM_a_s_id_proid(parser.getTagM_A_S_ID_PROID(path,root));
		operationSepa.setM_a_s_id_pro_sch_cd(parser.getTagM_A_S_ID_PRO_SCH_CD(path,root));
		operationSepa.setM_a_s_id_pro_sch_prtry(parser.getTagM_A_S_ID_PRO_SCH_PRTRY(path,root));
		operationSepa.setM_a_s_id_pro_issr(parser.getTagM_A_S_ID_PRO_ISSR(path,root));
		operationSepa.setM_a_odac_id_iban(parser.getTagM_A_ODAC_ID_IBAN(path,root));
		operationSepa.setM_a_odag_fi_othr_id(parser.getTagM_A_ODAG_FI_OTHR_ID(path,root));
		operationSepa.setM_elctrncsgnt(parser.getTagM_ELCTRNCSGNT(path,root));
		operationSepa.setUcdt_name(parser.getTagUCDT_NAME(path,root));
		operationSepa.setUcdt_id_org_bic_bei(parser.getTagUCDT_ID_ORG_BIC_BEI(path,root));
		operationSepa.setUcdt_id_org_othr_id(parser.getTagUCDT_ID_ORG_OTHR_ID(path,root));
		operationSepa.setUcdt_id_org_othr_sch_cd(parser.getTagUCDT_ID_ORG_OTHR_SCH_CD(path,root));
		operationSepa.setUcdt_id_org_othr_sch_prtry(parser.getTagUCDT_ID_ORG_OTHR_SCH_PRTRY(path,root));
		operationSepa.setUcdt_id_org_othr_issr(parser.getTagUCDT_ID_ORG_OTHR_ISSR(path,root));
		operationSepa.setUcdt_id_pr_dpbi_da(UtilFunctions.getDateSql(parser.getTagUCDT_ID_PR_DPBI_DA(path,root)));
		operationSepa.setUcdt_id_pr_dpbi_prv(parser.getTagUCDT_ID_PR_DPBI_PRV(path,root));
		operationSepa.setUcdt_id_pr_dpbi_ct(parser.getTagUCDT_ID_PR_DPBI_CT(path,root));
		operationSepa.setUcdt_id_pr_dpbi_cr(parser.getTagUCDT_ID_PR_DPBI_CR(path,root));
		operationSepa.setUcdt_id_prv_othr_id(parser.getTagUCDT_ID_PRV_OTHR_ID(path,root));
		operationSepa.setUcdt_id_prv_othr_sch_cd(parser.getTagUCDT_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setUcdt_id_prv_othr_sch_prtr(parser.getTagUCDT_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setUcdt_id_prv_othr_issr(parser.getTagUCDT_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setDbt_name(parser.getTagDBT_NAME(path,root));
		operationSepa.setDbt_padr_adrline(parser.getTagDBT_PADR_ADRLINE(path,root));
		operationSepa.setDbt_padr_ctry(parser.getTagDBT_PADR_CTRY(path,root));
		operationSepa.setDbt_id_org_bic_bei(parser.getTagDBT_ID_ORG_BIC_BEI(path,root));
		operationSepa.setDbt_id_org_othr_id(parser.getTagDBT_ID_ORG_OTHR_ID(path,root));
		operationSepa.setDbt_id_org_othr_sch_cd(parser.getTagDBT_ID_ORG_OTHR_SCH_CD(path,root));
		operationSepa.setDbt_id_org_othr_sch_prtry(parser.getTagDBT_ID_ORG_OTHR_SCH_PRTRY(path,root));
		operationSepa.setDbt_id_org_othr_issr(parser.getTagDBT_ID_ORG_OTHR_ISSR(path,root));
		operationSepa.setDbt_id_pr_dpbi_dat(UtilFunctions.getDateSql(parser.getTagDBT_ID_PR_DPBI_DAT(path,root)));
		operationSepa.setDbt_id_pr_dpbi_prv(parser.getTagDBT_ID_PR_DPBI_PRV(path,root));
		operationSepa.setDbt_id_pr_dpbi_cty(parser.getTagDBT_ID_PR_DPBI_CTY(path,root));
		operationSepa.setDbt_id_pr_dpbi_cr(parser.getTagDBT_ID_PR_DPBI_CR(path,root));
		operationSepa.setDbt_id_prv_othr_id(parser.getTagDBT_ID_PRV_OTHR_ID(path,root));
		operationSepa.setDbt_id_prv_othr_sch_cd(parser.getTagDBT_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setDbt_id_prv_othr_sch_prtr(parser.getTagDBT_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setDbt_id_prv_othr_issr(parser.getTagDBT_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setDbtacc_id_iban(parser.getTagDBTACC_ID_IBAN(path,root));
		operationSepa.setDbtagt_fi_bic(parser.getTagDBTAGT_FI_BIC(path,root));
		operationSepa.setCdtacc_id_iban(parser.getTagCDTACC_ID_IBAN(path,root));
		operationSepa.setCdtagt_fi_bic(parser.getTagCDTAGT_FI_BIC(path,root));
		operationSepa.setCdt_name(parser.getTagCDT_NAME(path,root));
		operationSepa.setCdt_padr_adrline(parser.getTagCDT_PADR_ADRLINE(path,root));
		operationSepa.setCdt_padr_ctry(parser.getTagCDT_PADR_CTRY(path,root));
		operationSepa.setUdbt_name(parser.getTagUDBT_NAME(path,root));
		operationSepa.setUdbt_id_org_bic_bei(parser.getTagUDBT_ID_ORG_BIC_BEI(path,root));
		operationSepa.setUdbt_id_org_othr_id(parser.getTagUDBT_ID_ORG_OTHR_ID(path,root));
		operationSepa.setUdbt_id_org_othr_sch_cd(parser.getTagUDBT_ID_ORG_OTHR_SCH_CD(path,root));
		operationSepa.setUdbt_id_org_othr_sch_prtr(parser.getTagUDBT_ID_ORG_OTHR_SCH_PRTR(path,root));
		operationSepa.setUdbt_id_org_othr_sch_issr(parser.getTagUDBT_ID_ORG_OTHR_SCH_ISSR(path,root));
		operationSepa.setUdbt_id_pr_dpbi_dat(UtilFunctions.getDateSql(parser.getTagUDBT_ID_PR_DPBI_DAT(path,root)));
		operationSepa.setUdbt_id_pr_dpbi_prv(parser.getTagUDBT_ID_PR_DPBI_PRV(path,root));
		operationSepa.setUdbt_id_pr_dpbi_cty(parser.getTagUDBT_ID_PR_DPBI_CTY(path,root));
		operationSepa.setUdbt_id_pr_dpbi_cry(parser.getTagUDBT_ID_PR_DPBI_CRY(path,root));
		operationSepa.setUdbt_id_prv_othr_id(parser.getTagUDBT_ID_PRV_OTHR_ID(path,root));
		operationSepa.setUdbt_id_prv_othr_sch_cd(parser.getTagUDBT_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setUdbt_id_prv_othr_sch_prtr(parser.getTagUDBT_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setUdbt_id_prv_othr_issr(parser.getTagUDBT_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setInsgagt_fi_bic(parser.getTagINSGAGT_FI_BIC(path,root));
		operationSepa.setInsdagt_fi_bic(parser.getTagINSDAGT_FI_BIC(path,root));
		operationSepa.setRmtinf_ustrd(parser.getTagRMTINF_USTRD(path,root));
		operationSepa.setRmtinf_strd_type_code(parser.getTagRMTINF_STRD_TYPE_CODE(path,root));
		operationSepa.setRmtinf_strd_type_ref(parser.getTagRMTINF_STRD_TYPE_REF(path,root));
		operationSepa.setOrgnltxid(parser.getTagORGNLTXID(path,root));
		operationSepa.setOrgnlinstrid(parser.getTagORGNLINSTRID(path,root));
		operationSepa.setOrgnlendtoendid(parser.getTagORGNLENDTOENDID(path,root));
		operationSepa.setTxsts(parser.getTagTXSTS(path,root));
		operationSepa.setOrgnlintrbksttlmamt(getBigDecimal(parser.getTagORGNLINTRBKSTTLMAMT(path,root),2));
		operationSepa.setOrgnlintrbksttlmamtc(parser.getTagORGNLINTRBKSTTLMAMTC(path,root));				
		operationSepa.setOtr_intrbksttlmdt(UtilFunctions.getDateSql(parser.getTagOTR_INTRBKSTTLMDT(path,root)));
		operationSepa.setRi_rorg_name(parser.getTagRI_RORG_NAME(path,root));
		operationSepa.setRi_rorg_id_org_bic_bei(parser.getTagRI_RORG_ID_ORG_BIC_BEI(path,root));
		operationSepa.setRi_rsn_cd(parser.getTagRI_RSN_CD(path,root));
		operationSepa.setRi_sn_prtry(parser.getTagRI_SN_PRTRY(path,root));
		operationSepa.setOtr_reqdcolltndt(parser.getTagOTR_REQDCOLLTNDT(path,root));
		operationSepa.setOtr_csch_id_prv_othr_id(parser.getTagOTR_CSCH_ID_PRV_OTHR_ID(path,root));
		operationSepa.setOtr_csch_id_prv_othr_sch_cd(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setOtr_csch_id_prv_othr_issr(parser.getTagOTR_CSCH_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setOtr_csch_id_prv_othr_sch_prtr(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setOtr_stti_sttlmmtd(parser.getTagOTR_STTI_STTLMMTD(path,root));
		operationSepa.setOtr_stti_sttaid_iban(parser.getTagOTR_STTI_STTAID_IBAN(path,root));
		operationSepa.setOtr_stti_sttaid_o_id(parser.getTagOTR_STTI_STTAID_O_ID(path,root));
		operationSepa.setOtr_stti_sttaid_o_sn_cd(parser.getTagOTR_STTI_STTAID_O_SN_CD(path,root));
		operationSepa.setOtr_stti_sttaid_o_sn_prtr(parser.getTagOTR_STTI_STTAID_O_SN_PRTR(path,root));
		operationSepa.setOtr_stti_sttaid_o_issr(parser.getTagOTR_STTI_STTAID_O_ISSR(path,root));
		operationSepa.setOtr_stti_clrs_cd(parser.getTagOTR_STTI_CLRS_CD(path,root));
		operationSepa.setOtr_stti_clrs_prtry(parser.getTagOTR_STTI_CLRS_PRTRY(path,root));
		operationSepa.setBic_id_debitor(parser.getTagBIC_ID_Debitor(path,root));
		operationSepa.setBic_id_creditor(parser.getTagBIC_ID_Creditor(path,root));
		operationSepa.setRef_operation_origine (parser.getTagREF_OPERATION_ORIGINE (path,root));
		operationSepa.setIban_debitor (parser.getTagIBAN_DEBITOR (path,root));
		operationSepa.setIban_creditor (parser.getTagIBAN_CREDITOR (path,root));
		operationSepa.setM_a_odac_v9_id_othr_id(parser.getTagM_A_ODAC_V9_ID_OTHR_ID(path,root));
		operationSepa.setM_a_odac_v9_fi_bic(parser.getTagM_A_ODAC_V9_FI_BIC(path,root));
		operationSepa.setBic_id_do(parser.getTagBIC_ID_DO(path,root));
		operationSepa.setIban_do  (parser.getTagIBAN_DO  (path,root));
		operationSepa.setBic_id_beneficiaire(parser.getTagBIC_ID_BENEFICIAIRE(path,root));
		operationSepa.setIban_beneficiaire(parser.getTagIBAN_BENEFICIAIRE(path,root));
		operationSepa.setFlag_evolmpm_maeva("EVOLMPM");
		
	}


	private void parseCode780(OperationSepaBean operationSepa, Element root, XPath path) throws XPathExpressionException {
		final ParseXMLSepaSDD780 parser = new ParseXMLSepaSDD780();
		
		operationSepa.setNum_ics(parser.getTagNUM_ICS(path,root));
		operationSepa.setMotif_rejet_annulation(parser.getTagMOTIF_REJET_ANNULATION(path,root));
		operationSepa.setPmttpi_svclvl_cd(parser.getTagPMTTPI_SVCLVL_CD(path,root));
		operationSepa.setPmttpi_lclins_cd(parser.getTagPMTTPI_LCLINS_CD(path,root));
		operationSepa.setPmttpilclins_prtry(parser.getTagPMTTPILCLINS_PRTRY(path,root));
		operationSepa.setPmttpi_seqtp(parser.getTagPMTTPI_SEQTP(path,root));
		operationSepa.setPmttpi_ctgypurp(parser.getTagPMTTPI_CTGYPURP(path,root));
		operationSepa.setIntrbksttlmamt(getBigDecimal(parser.getTagINTRBKSTTLMAMT(path,root),2));
		operationSepa.setIntrbksttlmamtc(parser.getTagINTRBKSTTLMAMTC(path,root));
		operationSepa.setChrgbr(parser.getTagCHRGBR(path,root));
		operationSepa.setChrginf_amt(getDouble(parser.getTagCHRGINF_AMT(path,root)));
		operationSepa.setChrginf_amtc(parser.getTagCHRGINF_AMTC(path,root));
		operationSepa.setChrginf_pty_fi_bic(parser.getTagCHRGINF_PTY_FI_BIC(path,root));
		operationSepa.setM_mndtid(parser.getTagM_MNDTID(path,root));
		operationSepa.setM_dtofsgntr(UtilFunctions.getDateSql(parser.getTagM_DTOFSGNTR(path,root)));
		operationSepa.setM_amdmntind(parser.getTagM_AMDMNTIND(path,root));
		operationSepa.setM_a_orgnlmndtid(parser.getTagM_A_ORGNLMNDTID(path,root));
		operationSepa.setM_a_s_nm(parser.getTagM_A_S_NM(path,root));
		operationSepa.setM_a_s_id_proid(parser.getTagM_A_S_ID_PROID(path,root));
		operationSepa.setM_a_s_id_pro_sch_cd(parser.getTagM_A_S_ID_PRO_SCH_CD(path,root));
		operationSepa.setM_a_s_id_pro_sch_prtry(parser.getTagM_A_S_ID_PRO_SCH_PRTRY(path,root));
		operationSepa.setM_a_s_id_pro_issr(parser.getTagM_A_S_ID_PRO_ISSR(path,root));
		operationSepa.setM_a_odac_id_iban(parser.getTagM_A_ODAC_ID_IBAN(path,root));
		operationSepa.setM_a_odag_fi_othr_id(parser.getTagM_A_ODAG_FI_OTHR_ID(path,root));
		operationSepa.setM_elctrncsgnt(parser.getTagM_ELCTRNCSGNT(path,root));
		operationSepa.setUcdt_name(parser.getTagUCDT_NAME(path,root));
		operationSepa.setUcdt_id_org_bic_bei(parser.getTagUCDT_ID_ORG_BIC_BEI(path,root));
		operationSepa.setUcdt_id_org_othr_id(parser.getTagUCDT_ID_ORG_OTHR_ID(path,root));
		operationSepa.setUcdt_id_org_othr_sch_cd(parser.getTagUCDT_ID_ORG_OTHR_SCH_CD(path,root));
		operationSepa.setUcdt_id_org_othr_sch_prtry(parser.getTagUCDT_ID_ORG_OTHR_SCH_PRTRY(path,root));
		operationSepa.setUcdt_id_org_othr_issr(parser.getTagUCDT_ID_ORG_OTHR_ISSR(path,root));
		operationSepa.setUcdt_id_pr_dpbi_da(UtilFunctions.getDateSql(parser.getTagUCDT_ID_PR_DPBI_DA(path,root)));
		operationSepa.setUcdt_id_pr_dpbi_prv(parser.getTagUCDT_ID_PR_DPBI_PRV(path,root));
		operationSepa.setUcdt_id_pr_dpbi_ct(parser.getTagUCDT_ID_PR_DPBI_CT(path,root));
		operationSepa.setUcdt_id_pr_dpbi_cr(parser.getTagUCDT_ID_PR_DPBI_CR(path,root));
		operationSepa.setUcdt_id_prv_othr_id(parser.getTagUCDT_ID_PRV_OTHR_ID(path,root));
		operationSepa.setUcdt_id_prv_othr_sch_cd(parser.getTagUCDT_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setUcdt_id_prv_othr_sch_prtr(parser.getTagUCDT_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setUcdt_id_prv_othr_issr(parser.getTagUCDT_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setDbt_name(parser.getTagDBT_NAME(path,root));
		operationSepa.setDbt_padr_adrline(parser.getTagDBT_PADR_ADRLINE(path,root));
		operationSepa.setDbt_padr_ctry(parser.getTagDBT_PADR_CTRY(path,root));
		operationSepa.setDbt_id_org_bic_bei(parser.getTagDBT_ID_ORG_BIC_BEI(path,root));
		operationSepa.setDbt_id_org_othr_id(parser.getTagDBT_ID_ORG_OTHR_ID(path,root));
		operationSepa.setDbt_id_org_othr_sch_cd(parser.getTagDBT_ID_ORG_OTHR_SCH_CD(path,root));
		operationSepa.setDbt_id_org_othr_sch_prtry(parser.getTagDBT_ID_ORG_OTHR_SCH_PRTRY(path,root));
		operationSepa.setDbt_id_org_othr_issr(parser.getTagDBT_ID_ORG_OTHR_ISSR(path,root));
		operationSepa.setDbt_id_pr_dpbi_dat(UtilFunctions.getDateSql(parser.getTagDBT_ID_PR_DPBI_DAT(path,root)));
		operationSepa.setDbt_id_pr_dpbi_prv(parser.getTagDBT_ID_PR_DPBI_PRV(path,root));
		operationSepa.setDbt_id_pr_dpbi_cty(parser.getTagDBT_ID_PR_DPBI_CTY(path,root));
		operationSepa.setDbt_id_pr_dpbi_cr(parser.getTagDBT_ID_PR_DPBI_CR(path,root));
		operationSepa.setDbt_id_prv_othr_id(parser.getTagDBT_ID_PRV_OTHR_ID(path,root));
		operationSepa.setDbt_id_prv_othr_sch_cd(parser.getTagDBT_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setDbt_id_prv_othr_sch_prtr(parser.getTagDBT_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setDbt_id_prv_othr_issr(parser.getTagDBT_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setDbtacc_id_iban(parser.getTagDBTACC_ID_IBAN(path,root));
		operationSepa.setDbtagt_fi_bic(parser.getTagDBTAGT_FI_BIC(path,root));
		operationSepa.setCdtacc_id_iban(parser.getTagCDTACC_ID_IBAN(path,root));
		operationSepa.setCdtagt_fi_bic(parser.getTagCDTAGT_FI_BIC(path,root));
		operationSepa.setCdt_name(parser.getTagCDT_NAME(path,root));
		operationSepa.setCdt_padr_adrline(parser.getTagCDT_PADR_ADRLINE(path,root));
		operationSepa.setCdt_padr_ctry(parser.getTagCDT_PADR_CTRY(path,root));
		operationSepa.setUdbt_name(parser.getTagUDBT_NAME(path,root));
		operationSepa.setUdbt_id_org_bic_bei(parser.getTagUDBT_ID_ORG_BIC_BEI(path,root));
		operationSepa.setUdbt_id_org_othr_id(parser.getTagUDBT_ID_ORG_OTHR_ID(path,root));
		operationSepa.setUdbt_id_org_othr_sch_cd(parser.getTagUDBT_ID_ORG_OTHR_SCH_CD(path,root));
		operationSepa.setUdbt_id_org_othr_sch_prtr(parser.getTagUDBT_ID_ORG_OTHR_SCH_PRTR(path,root));
		operationSepa.setUdbt_id_org_othr_sch_issr(parser.getTagUDBT_ID_ORG_OTHR_SCH_ISSR(path,root));
		operationSepa.setUdbt_id_pr_dpbi_dat(UtilFunctions.getDateSql(parser.getTagUDBT_ID_PR_DPBI_DAT(path,root)));
		operationSepa.setUdbt_id_pr_dpbi_prv(parser.getTagUDBT_ID_PR_DPBI_PRV(path,root));
		operationSepa.setUdbt_id_pr_dpbi_cty(parser.getTagUDBT_ID_PR_DPBI_CTY(path,root));
		operationSepa.setUdbt_id_pr_dpbi_cry(parser.getTagUDBT_ID_PR_DPBI_CRY(path,root));
		operationSepa.setUdbt_id_prv_othr_id(parser.getTagUDBT_ID_PRV_OTHR_ID(path,root));
		operationSepa.setUdbt_id_prv_othr_sch_cd(parser.getTagUDBT_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setUdbt_id_prv_othr_sch_prtr(parser.getTagUDBT_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setUdbt_id_prv_othr_issr(parser.getTagUDBT_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setInsgagt_fi_bic(parser.getTagINSGAGT_FI_BIC(path,root));
		operationSepa.setInsdagt_fi_bic(parser.getTagINSDAGT_FI_BIC(path,root));
		operationSepa.setRmtinf_ustrd(parser.getTagRMTINF_USTRD(path,root));
		operationSepa.setRmtinf_strd_type_code(parser.getTagRMTINF_STRD_TYPE_CODE(path,root));
		operationSepa.setRmtinf_strd_type_ref(parser.getTagRMTINF_STRD_TYPE_REF(path,root));
		operationSepa.setOrgnltxid(parser.getTagORGNLTXID(path,root));
		operationSepa.setOrggrpinf_orgnlmsgid(parser.getTagORGGRPINF_ORGNLMSGID(path,root));
		operationSepa.setOrggrpinf_orgnlmsgnmid(parser.getTagORGGRPINF_ORGNLMSGNMID(path,root));
		operationSepa.setOrgnlinstrid(parser.getTagORGNLINSTRID(path,root));
		operationSepa.setOrgnlendtoendid(parser.getTagORGNLENDTOENDID(path,root));
		operationSepa.setOrgnlintrbksttlmamt(getBigDecimal(parser.getTagORGNLINTRBKSTTLMAMT(path,root),2));
		operationSepa.setOrgnlintrbksttlmamtc(parser.getTagORGNLINTRBKSTTLMAMTC(path,root));
		operationSepa.setOtr_intrbksttlmdt(UtilFunctions.getDateSql(parser.getTagOTR_INTRBKSTTLMDT(path,root)));
		operationSepa.setCompstnamt(getDouble(parser.getTagCOMPSTNAMT(path,root)));
		operationSepa.setCompstnamtc(parser.getTagCOMPSTNAMTC(path,root));
		operationSepa.setInstdamt(getDouble(parser.getTagINSTDAMT(path,root)));
		operationSepa.setInstdamtc(parser.getTagINSTDAMTC(path,root));				
		operationSepa.setRi_rorg_name(parser.getTagRI_RORG_NAME(path,root));
		operationSepa.setRi_rorg_id_org_bic_bei(parser.getTagRI_RORG_ID_ORG_BIC_BEI(path,root));
		operationSepa.setRi_rsn_cd(parser.getTagRI_RSN_CD(path,root));
		operationSepa.setOtr_reqdcolltndt(parser.getTagOTR_REQDCOLLTNDT(path,root));
		operationSepa.setOtr_csch_id_prv_othr_id(parser.getTagOTR_CSCH_ID_PRV_OTHR_ID(path,root));
		operationSepa.setOtr_csch_id_prv_othr_sch_cd(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setOtr_csch_id_prv_othr_issr(parser.getTagOTR_CSCH_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setOtr_csch_id_prv_othr_sch_prtr(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setOtr_stti_sttlmmtd(parser.getTagOTR_STTI_STTLMMTD(path,root));
		operationSepa.setOtr_stti_sttaid_iban(parser.getTagOTR_STTI_STTAID_IBAN(path,root));
		operationSepa.setOtr_stti_sttaid_o_id(parser.getTagOTR_STTI_STTAID_O_ID(path,root));
		operationSepa.setOtr_stti_sttaid_o_sn_cd(parser.getTagOTR_STTI_STTAID_O_SN_CD(path,root));
		operationSepa.setOtr_stti_sttaid_o_sn_prtr(parser.getTagOTR_STTI_STTAID_O_SN_PRTR(path,root));
		operationSepa.setOtr_stti_sttaid_o_issr(parser.getTagOTR_STTI_STTAID_O_ISSR(path,root));
		operationSepa.setOtr_stti_clrs_cd(parser.getTagOTR_STTI_CLRS_CD(path,root));
		operationSepa.setOtr_stti_clrs_prtry(parser.getTagOTR_STTI_CLRS_PRTRY(path,root));
		operationSepa.setRef_operation_origine (parser.getTagREF_OPERATION_ORIGINE (path,root));
		/** proble dans le xml : des ??? détéectées */
		//operationSepa.setM_a_odac_v9_id_othr_id(parser.getTagM_A_ODAC_V9_ID_OTHR_ID(path,root));
		//operationSepa.setM_a_odac_v9_fi_bic(parser.getTagM_A_ODAC_V9_FI_BIC(path,root));
		operationSepa.setFlag_evolmpm_maeva("EVOLMPM");

		
	}


	private void parseCode980(OperationSepaBean operationSepa, Element root, XPath path) throws XPathExpressionException {
		final ParseXMLSepaSDD980 parser = new ParseXMLSepaSDD980();
		
		operationSepa.setNum_ics(parser.getTagNUM_ICS(path,root));
		operationSepa.setMotif_rejet_annulation(parser.getTagMOTIF_REJET_ANNULATION(path,root));
		operationSepa.setPmtid_txid(parser.getTagPMTID_TXID(path,root));
		operationSepa.setPmttpi_svclvl_cd(parser.getTagPMTTPI_SVCLVL_CD(path,root));
		operationSepa.setPmttpi_lclins_cd(parser.getTagPMTTPI_LCLINS_CD(path,root));
		operationSepa.setPmttpilclins_prtry(parser.getTagPMTTPILCLINS_PRTRY(path,root));
		operationSepa.setPmttpi_seqtp(parser.getTagPMTTPI_SEQTP(path,root));
		operationSepa.setPmttpi_ctgypurp(parser.getTagPMTTPI_CTGYPURP(path,root));
		operationSepa.setChrginf_amt(getDouble(parser.getTagCHRGINF_AMT(path,root)));
		operationSepa.setChrginf_amtc(parser.getTagCHRGINF_AMTC(path,root));
		operationSepa.setChrginf_pty_fi_bic(parser.getTagCHRGINF_PTY_FI_BIC(path,root));
		operationSepa.setM_mndtid(parser.getTagM_MNDTID(path,root));
		operationSepa.setM_dtofsgntr(getDateSql(parser.getTagM_DTOFSGNTR(path,root)));
		operationSepa.setM_amdmntind(parser.getTagM_AMDMNTIND(path,root));
		operationSepa.setM_a_orgnlmndtid(parser.getTagM_A_ORGNLMNDTID(path,root));
		operationSepa.setM_a_s_nm(parser.getTagM_A_S_NM(path,root));
		operationSepa.setM_a_s_id_proid(parser.getTagM_A_S_ID_PROID(path,root));
		operationSepa.setM_a_s_id_pro_sch_cd(parser.getTagM_A_S_ID_PRO_SCH_CD(path,root));
		operationSepa.setM_a_s_id_pro_sch_prtry(parser.getTagM_A_S_ID_PRO_SCH_PRTRY(path,root));
		operationSepa.setM_a_s_id_pro_issr(parser.getTagM_A_S_ID_PRO_ISSR(path,root));
		operationSepa.setM_a_odac_id_iban(parser.getTagM_A_ODAC_ID_IBAN(path,root));
		operationSepa.setM_a_odag_fi_othr_id(parser.getTagM_A_ODAG_FI_OTHR_ID(path,root));
		operationSepa.setM_elctrncsgnt(parser.getTagM_ELCTRNCSGNT(path,root));
		operationSepa.setUcdt_name(parser.getTagUCDT_NAME(path,root));
		operationSepa.setUcdt_id_org_bic_bei(parser.getTagUCDT_ID_ORG_BIC_BEI(path,root));
		operationSepa.setUcdt_id_org_othr_id(parser.getTagUCDT_ID_ORG_OTHR_ID(path,root));
		operationSepa.setUcdt_id_org_othr_sch_cd(parser.getTagUCDT_ID_ORG_OTHR_SCH_CD(path,root));
		operationSepa.setUcdt_id_org_othr_sch_prtry(parser.getTagUCDT_ID_ORG_OTHR_SCH_PRTRY(path,root));
		operationSepa.setUcdt_id_org_othr_issr(parser.getTagUCDT_ID_ORG_OTHR_ISSR(path,root));
		operationSepa.setUcdt_id_pr_dpbi_da(UtilFunctions.getDateSql(parser.getTagUCDT_ID_PR_DPBI_DA(path,root)));
		operationSepa.setUcdt_id_pr_dpbi_prv(parser.getTagUCDT_ID_PR_DPBI_PRV(path,root));
		operationSepa.setUcdt_id_pr_dpbi_ct(parser.getTagUCDT_ID_PR_DPBI_CT(path,root));
		operationSepa.setUcdt_id_pr_dpbi_cr(parser.getTagUCDT_ID_PR_DPBI_CR(path,root));
		operationSepa.setUcdt_id_prv_othr_id(parser.getTagUCDT_ID_PRV_OTHR_ID(path,root));
		operationSepa.setUcdt_id_prv_othr_sch_cd(parser.getTagUCDT_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setUcdt_id_prv_othr_sch_prtr(parser.getTagUCDT_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setUcdt_id_prv_othr_issr(parser.getTagUCDT_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setDbt_name(parser.getTagDBT_NAME(path,root));
		operationSepa.setDbt_padr_adrline(parser.getTagDBT_PADR_ADRLINE(path,root));
		operationSepa.setDbt_padr_ctry(parser.getTagDBT_PADR_CTRY(path,root));
		operationSepa.setDbt_id_org_bic_bei(parser.getTagDBT_ID_ORG_BIC_BEI(path,root));
		operationSepa.setDbt_id_org_othr_id(parser.getTagDBT_ID_ORG_OTHR_ID(path,root));
		operationSepa.setDbt_id_org_othr_sch_cd(parser.getTagDBT_ID_ORG_OTHR_SCH_CD(path,root));
		operationSepa.setDbt_id_org_othr_sch_prtry(parser.getTagDBT_ID_ORG_OTHR_SCH_PRTRY(path,root));
		operationSepa.setDbt_id_org_othr_issr(parser.getTagDBT_ID_ORG_OTHR_ISSR(path,root));
		operationSepa.setDbt_id_pr_dpbi_dat(UtilFunctions.getDateSql(parser.getTagDBT_ID_PR_DPBI_DAT(path,root)));
		operationSepa.setDbt_id_pr_dpbi_prv(parser.getTagDBT_ID_PR_DPBI_PRV(path,root));
		operationSepa.setDbt_id_pr_dpbi_cty(parser.getTagDBT_ID_PR_DPBI_CTY(path,root));
		operationSepa.setDbt_id_pr_dpbi_cr(parser.getTagDBT_ID_PR_DPBI_CR(path,root));
		operationSepa.setDbt_id_prv_othr_id(parser.getTagDBT_ID_PRV_OTHR_ID(path,root));
		operationSepa.setDbt_id_prv_othr_sch_cd(parser.getTagDBT_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setDbt_id_prv_othr_sch_prtr(parser.getTagDBT_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setDbt_id_prv_othr_issr(parser.getTagDBT_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setDbtacc_id_iban(parser.getTagDBTACC_ID_IBAN(path,root));
		operationSepa.setDbtagt_fi_bic(parser.getTagDBTAGT_FI_BIC(path,root));
		operationSepa.setCdtacc_id_iban(parser.getTagCDTACC_ID_IBAN(path,root));
		operationSepa.setCdtagt_fi_bic(parser.getTagCDTAGT_FI_BIC(path,root));
		operationSepa.setCdt_name(parser.getTagCDT_NAME(path,root));
		operationSepa.setCdt_padr_adrline(parser.getTagCDT_PADR_ADRLINE(path,root));
		operationSepa.setCdt_padr_ctry(parser.getTagCDT_PADR_CTRY(path,root));
		operationSepa.setUdbt_name(parser.getTagUDBT_NAME(path,root));
		operationSepa.setUdbt_id_org_bic_bei(parser.getTagUDBT_ID_ORG_BIC_BEI(path,root));
		operationSepa.setUdbt_id_org_othr_id(parser.getTagUDBT_ID_ORG_OTHR_ID(path,root));
		operationSepa.setUdbt_id_org_othr_sch_cd(parser.getTagUDBT_ID_ORG_OTHR_SCH_CD(path,root));
		operationSepa.setUdbt_id_org_othr_sch_prtr(parser.getTagUDBT_ID_ORG_OTHR_SCH_PRTR(path,root));
		operationSepa.setUdbt_id_org_othr_sch_issr(parser.getTagUDBT_ID_ORG_OTHR_SCH_ISSR(path,root));
		operationSepa.setUdbt_id_pr_dpbi_dat(UtilFunctions.getDateSql(parser.getTagUDBT_ID_PR_DPBI_DAT(path,root)));
		operationSepa.setUdbt_id_pr_dpbi_prv(parser.getTagUDBT_ID_PR_DPBI_PRV(path,root));
		operationSepa.setUdbt_id_pr_dpbi_cty(parser.getTagUDBT_ID_PR_DPBI_CTY(path,root));
		operationSepa.setUdbt_id_pr_dpbi_cry(parser.getTagUDBT_ID_PR_DPBI_CRY(path,root));
		operationSepa.setUdbt_id_prv_othr_id(parser.getTagUDBT_ID_PRV_OTHR_ID(path,root));
		operationSepa.setUdbt_id_prv_othr_sch_cd(parser.getTagUDBT_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setUdbt_id_prv_othr_sch_prtr(parser.getTagUDBT_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setUdbt_id_prv_othr_issr(parser.getTagUDBT_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setInsgagt_fi_bic(parser.getTagINSGAGT_FI_BIC(path,root));
		operationSepa.setInsdagt_fi_bic(parser.getTagINSDAGT_FI_BIC(path,root));
		operationSepa.setRmtinf_ustrd(parser.getTagRMTINF_USTRD(path,root));
		operationSepa.setRmtinf_strd_type_code(parser.getTagRMTINF_STRD_TYPE_CODE(path,root));
		operationSepa.setRmtinf_strd_type_ref(parser.getTagRMTINF_STRD_TYPE_REF(path,root));
		operationSepa.setOrgnltxid(parser.getTagORGNLTXID(path,root));
		operationSepa.setOrgnlinstrid(parser.getTagORGNLINSTRID(path,root));
		operationSepa.setOrgnlendtoendid(parser.getTagORGNLENDTOENDID(path,root));
		operationSepa.setTxsts(parser.getTagTXSTS(path,root));
		operationSepa.setOrgnlintrbksttlmamt(getBigDecimal(parser.getTagORGNLINTRBKSTTLMAMT(path,root),2));
		operationSepa.setOrgnlintrbksttlmamtc(parser.getTagORGNLINTRBKSTTLMAMTC(path,root));
		operationSepa.setOtr_intrbksttlmdt(UtilFunctions.getDateSql(parser.getTagOTR_INTRBKSTTLMDT(path,root)));
		operationSepa.setRi_rorg_name(parser.getTagRI_RORG_NAME(path,root));
		operationSepa.setRi_rorg_id_org_bic_bei(parser.getTagRI_RORG_ID_ORG_BIC_BEI(path,root));
		operationSepa.setRi_rsn_cd(parser.getTagRI_RSN_CD(path,root));
		operationSepa.setRi_sn_prtry(parser.getTagRI_SN_PRTRY(path,root));
		operationSepa.setOtr_reqdcolltndt(parser.getTagOTR_REQDCOLLTNDT(path,root));
		operationSepa.setOtr_csch_id_prv_othr_id(parser.getTagOTR_CSCH_ID_PRV_OTHR_ID(path,root));
		operationSepa.setOtr_csch_id_prv_othr_sch_cd(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_CD(path,root));
		operationSepa.setOtr_csch_id_prv_othr_issr(parser.getTagOTR_CSCH_ID_PRV_OTHR_ISSR(path,root));
		operationSepa.setOtr_csch_id_prv_othr_sch_prtr(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_PRTR(path,root));
		operationSepa.setOtr_stti_sttlmmtd(parser.getTagOTR_STTI_STTLMMTD(path,root));
		operationSepa.setOtr_stti_sttaid_iban(parser.getTagOTR_STTI_STTAID_IBAN(path,root));
		operationSepa.setOtr_stti_sttaid_o_id(parser.getTagOTR_STTI_STTAID_O_ID(path,root));
		operationSepa.setOtr_stti_sttaid_o_sn_cd(parser.getTagOTR_STTI_STTAID_O_SN_CD(path,root));
		operationSepa.setOtr_stti_sttaid_o_sn_prtr(parser.getTagOTR_STTI_STTAID_O_SN_PRTR(path,root));
		operationSepa.setOtr_stti_sttaid_o_issr(parser.getTagOTR_STTI_STTAID_O_ISSR(path,root));
		operationSepa.setOtr_stti_clrs_cd(parser.getTagOTR_STTI_CLRS_CD(path,root));
		operationSepa.setOtr_stti_clrs_prtry(parser.getTagOTR_STTI_CLRS_PRTRY(path,root));
		operationSepa.setBic_id_debitor(parser.getTagBIC_ID_Debitor(path,root));
		operationSepa.setBic_id_creditor(parser.getTagBIC_ID_Creditor(path,root));
		operationSepa.setRef_operation_origine (parser.getTagREF_OPERATION_ORIGINE (path,root));
		operationSepa.setIban_debitor (parser.getTagIBAN_DEBITOR (path,root));
		operationSepa.setIban_creditor (parser.getTagIBAN_CREDITOR (path,root));
		operationSepa.setM_a_odac_v9_id_othr_id(parser.getTagM_A_ODAC_V9_ID_OTHR_ID(path,root));
		operationSepa.setM_a_odac_v9_fi_bic(parser.getTagM_A_ODAC_V9_FI_BIC(path,root));
		operationSepa.setBic_id_do(parser.getTagBIC_ID_DO(path,root));
		operationSepa.setIban_do  (parser.getTagIBAN_DO  (path,root));
		operationSepa.setBic_id_beneficiaire(parser.getTagBIC_ID_BENEFICIAIRE(path,root));
		operationSepa.setIban_beneficiaire(parser.getTagIBAN_BENEFICIAIRE(path,root));
		operationSepa.setFlag_evolmpm_maeva("EVOLMPM");

		
	}


	private void parseCode981(OperationSepaBean opebean, Element root, XPath path) throws XPathExpressionException {
		final ParseXMLSepaSDD981 parser = new ParseXMLSepaSDD981();
		
		opebean.setNum_ics(parser.getTagNUM_ICS(path, root));
		opebean.setMotif_rejet_annulation(parser.getTagMOTIF_REJET_ANNULATION(path, root));
		opebean.setPmtid_txid(parser.getTagPMTID_TXID(path, root));
		opebean.setPmttpi_svclvl_cd(parser.getTagPMTTPI_SVCLVL_CD(path, root));
		opebean.setPmttpi_lclins_cd(parser.getTagPMTTPI_LCLINS_CD(path, root));
		opebean.setPmttpilclins_prtry(parser.getTagPMTTPILCLINS_PRTRY(path, root));
		opebean.setPmttpi_seqtp(parser.getTagPMTTPI_SEQTP(path, root));
		opebean.setPmttpi_ctgypurp(parser.getTagPMTTPI_CTGYPURP(path, root));
		opebean.setChrginf_amt(getDouble(parser.getTagCHRGINF_AMT(path, root)));
		opebean.setChrginf_amtc(parser.getTagCHRGINF_AMTC(path, root));
		opebean.setChrginf_pty_fi_bic(parser.getTagCHRGINF_PTY_FI_BIC(path, root));
		opebean.setM_mndtid(parser.getTagM_MNDTID(path, root));
		opebean.setM_dtofsgntr(getDateSql(parser.getTagM_DTOFSGNTR(path, root)));
		opebean.setM_amdmntind(parser.getTagM_AMDMNTIND(path, root));
		opebean.setM_a_orgnlmndtid(parser.getTagM_A_ORGNLMNDTID(path, root));
		opebean.setM_a_s_nm(parser.getTagM_A_S_NM(path, root));
		opebean.setM_a_s_id_proid(parser.getTagM_A_S_ID_PROID(path, root));
		opebean.setM_a_s_id_pro_sch_cd(parser.getTagM_A_S_ID_PRO_SCH_CD(path, root));
		opebean.setM_a_s_id_pro_sch_prtry(parser.getTagM_A_S_ID_PRO_SCH_PRTRY(path, root));
		opebean.setM_a_s_id_pro_issr(parser.getTagM_A_S_ID_PRO_ISSR(path, root));
		opebean.setM_a_odac_id_iban(parser.getTagM_A_ODAC_ID_IBAN(path, root));
		opebean.setM_a_odag_fi_othr_id(parser.getTagM_A_ODAG_FI_OTHR_ID(path, root));
		opebean.setM_elctrncsgnt(parser.getTagM_ELCTRNCSGNT(path, root));
		opebean.setUcdt_name(parser.getTagUCDT_NAME(path, root));
		opebean.setUcdt_id_org_bic_bei(parser.getTagUCDT_ID_ORG_BIC_BEI(path, root));
		opebean.setUcdt_id_org_othr_id(parser.getTagUCDT_ID_ORG_OTHR_ID(path, root));
		opebean.setUcdt_id_org_othr_sch_cd(parser.getTagUCDT_ID_ORG_OTHR_SCH_CD(path, root));
		opebean.setUcdt_id_org_othr_sch_prtry(parser.getTagUCDT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		opebean.setUcdt_id_org_othr_issr(parser.getTagUCDT_ID_ORG_OTHR_ISSR(path, root));
		opebean.setUcdt_id_pr_dpbi_da(getDateSql(parser.getTagUCDT_ID_PR_DPBI_DA(path, root)));
		opebean.setUcdt_id_pr_dpbi_prv(parser.getTagUCDT_ID_PR_DPBI_PRV(path, root));
		opebean.setUcdt_id_pr_dpbi_ct(parser.getTagUCDT_ID_PR_DPBI_CT(path, root));
		opebean.setUcdt_id_pr_dpbi_cr(parser.getTagUCDT_ID_PR_DPBI_CR(path, root));
		opebean.setUcdt_id_prv_othr_id(parser.getTagUCDT_ID_PRV_OTHR_ID(path, root));
		opebean.setUcdt_id_prv_othr_sch_cd(parser.getTagUCDT_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setUcdt_id_prv_othr_sch_prtr(parser.getTagUCDT_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setUcdt_id_prv_othr_issr(parser.getTagUCDT_ID_PRV_OTHR_ISSR(path, root));
		opebean.setDbt_name(parser.getTagDBT_NAME(path, root));
		opebean.setDbt_padr_adrline(parser.getTagDBT_PADR_ADRLINE(path, root));
		opebean.setDbt_padr_ctry(parser.getTagDBT_PADR_CTRY(path, root));
		opebean.setDbt_id_org_bic_bei(parser.getTagDBT_ID_ORG_BIC_BEI(path, root));
		opebean.setDbt_id_org_othr_id(parser.getTagDBT_ID_ORG_OTHR_ID(path, root));
		opebean.setDbt_id_org_othr_sch_cd(parser.getTagDBT_ID_ORG_OTHR_SCH_CD(path, root));
		opebean.setDbt_id_org_othr_sch_prtry(parser.getTagDBT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		opebean.setDbt_id_org_othr_issr(parser.getTagDBT_ID_ORG_OTHR_ISSR(path, root));
		opebean.setDbt_id_pr_dpbi_dat(getDateSql(parser.getTagDBT_ID_PR_DPBI_DAT(path, root)));
		opebean.setDbt_id_pr_dpbi_prv(parser.getTagDBT_ID_PR_DPBI_PRV(path, root));
		opebean.setDbt_id_pr_dpbi_cty(parser.getTagDBT_ID_PR_DPBI_CTY(path, root));
		opebean.setDbt_id_pr_dpbi_cr(parser.getTagDBT_ID_PR_DPBI_CR(path, root));
		opebean.setDbt_id_prv_othr_id(parser.getTagDBT_ID_PRV_OTHR_ID(path, root));
		opebean.setDbt_id_prv_othr_sch_cd(parser.getTagDBT_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setDbt_id_prv_othr_sch_prtr(parser.getTagDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setDbt_id_prv_othr_issr(parser.getTagDBT_ID_PRV_OTHR_ISSR(path, root));
		opebean.setDbtacc_id_iban(parser.getTagDBTACC_ID_IBAN(path, root));
		opebean.setDbtagt_fi_bic(parser.getTagDBTAGT_FI_BIC(path, root));
		opebean.setCdtacc_id_iban(parser.getTagCDTACC_ID_IBAN(path, root));
		opebean.setCdtagt_fi_bic(parser.getTagCDTAGT_FI_BIC(path, root));
		opebean.setCdt_name(parser.getTagCDT_NAME(path, root));
		opebean.setCdt_padr_adrline(parser.getTagCDT_PADR_ADRLINE(path, root));
		opebean.setCdt_padr_ctry(parser.getTagCDT_PADR_CTRY(path, root));
		opebean.setUdbt_name(parser.getTagUDBT_NAME(path, root));
		opebean.setUdbt_id_org_bic_bei(parser.getTagUDBT_ID_ORG_BIC_BEI(path, root));
		opebean.setUdbt_id_org_othr_id(parser.getTagUDBT_ID_ORG_OTHR_ID(path, root));
		opebean.setUdbt_id_org_othr_sch_cd(parser.getTagUDBT_ID_ORG_OTHR_SCH_CD(path, root));
		opebean.setUdbt_id_org_othr_sch_prtr(parser.getTagUDBT_ID_ORG_OTHR_SCH_PRTR(path, root));
		opebean.setUdbt_id_org_othr_sch_issr(parser.getTagUDBT_ID_ORG_OTHR_SCH_ISSR(path, root));
		opebean.setUdbt_id_pr_dpbi_dat(getDateSql(parser.getTagUDBT_ID_PR_DPBI_DAT(path, root)));
		opebean.setUdbt_id_pr_dpbi_prv(parser.getTagUDBT_ID_PR_DPBI_PRV(path, root));
		opebean.setUdbt_id_pr_dpbi_cty(parser.getTagUDBT_ID_PR_DPBI_CTY(path, root));
		opebean.setUdbt_id_pr_dpbi_cry(parser.getTagUDBT_ID_PR_DPBI_CRY(path, root));
		opebean.setUdbt_id_prv_othr_id(parser.getTagUDBT_ID_PRV_OTHR_ID(path, root));
		opebean.setUdbt_id_prv_othr_sch_cd(parser.getTagUDBT_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setUdbt_id_prv_othr_sch_prtr(parser.getTagUDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setUdbt_id_prv_othr_issr(parser.getTagUDBT_ID_PRV_OTHR_ISSR(path, root));
		opebean.setInsgagt_fi_bic(parser.getTagINSGAGT_FI_BIC(path, root));
		opebean.setInsdagt_fi_bic(parser.getTagINSDAGT_FI_BIC(path, root));
		opebean.setRmtinf_ustrd(parser.getTagRMTINF_USTRD(path, root));
		opebean.setRmtinf_strd_type_code(parser.getTagRMTINF_STRD_TYPE_CODE(path, root));
		opebean.setRmtinf_strd_type_ref(parser.getTagRMTINF_STRD_TYPE_REF(path, root));
		opebean.setOrgnltxid(parser.getTagORGNLTXID(path, root));
		opebean.setOrgnlinstrid(parser.getTagORGNLINSTRID(path, root));
		opebean.setOrgnlendtoendid(parser.getTagORGNLENDTOENDID(path, root));
		opebean.setTxsts(parser.getTagTXSTS(path, root));
		opebean.setOrgnlintrbksttlmamt(getBigDecimal(parser.getTagORGNLINTRBKSTTLMAMT(path, root), 2));
		opebean.setOrgnlintrbksttlmamtc(parser.getTagORGNLINTRBKSTTLMAMTC(path, root));
		opebean.setOtr_intrbksttlmdt(getDateSql(parser.getTagOTR_INTRBKSTTLMDT(path, root)));
		opebean.setRi_rorg_name(parser.getTagRI_RORG_NAME(path, root));
		opebean.setRi_rorg_id_org_bic_bei(parser.getTagRI_RORG_ID_ORG_BIC_BEI(path, root));
		opebean.setRi_rsn_cd(parser.getTagRI_RSN_CD(path, root));
		opebean.setRi_sn_prtry(parser.getTagRI_SN_PRTRY(path, root));
		opebean.setOtr_reqdcolltndt(parser.getTagOTR_REQDCOLLTNDT(path, root));
		opebean.setOtr_csch_id_prv_othr_id(parser.getTagOTR_CSCH_ID_PRV_OTHR_ID(path, root));
		opebean.setOtr_csch_id_prv_othr_sch_cd(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setOtr_csch_id_prv_othr_issr(parser.getTagOTR_CSCH_ID_PRV_OTHR_ISSR(path, root));
		opebean.setOtr_csch_id_prv_othr_sch_prtr(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setOtr_stti_sttlmmtd(parser.getTagOTR_STTI_STTLMMTD(path, root));
		opebean.setOtr_stti_sttaid_iban(parser.getTagOTR_STTI_STTAID_IBAN(path, root));
		opebean.setOtr_stti_sttaid_o_id(parser.getTagOTR_STTI_STTAID_O_ID(path, root));
		opebean.setOtr_stti_sttaid_o_sn_cd(parser.getTagOTR_STTI_STTAID_O_SN_CD(path, root));
		opebean.setOtr_stti_sttaid_o_sn_prtr(parser.getTagOTR_STTI_STTAID_O_SN_PRTR(path, root));
		opebean.setOtr_stti_sttaid_o_issr(parser.getTagOTR_STTI_STTAID_O_ISSR(path, root));
		opebean.setOtr_stti_clrs_cd(parser.getTagOTR_STTI_CLRS_CD(path, root));
		opebean.setOtr_stti_clrs_prtry(parser.getTagOTR_STTI_CLRS_PRTRY(path, root));
		opebean.setBic_id_debitor(parser.getTagBIC_ID_Debitor(path, root));
		opebean.setBic_id_creditor(parser.getTagBIC_ID_Creditor(path, root));
		opebean.setRef_operation_origine (parser.getTagREF_OPERATION_ORIGINE (path, root));
		opebean.setIban_debitor (parser.getTagIBAN_DEBTOR (path, root));
		opebean.setIban_creditor (parser.getTagIBAN_CREDITOR (path, root));
		opebean.setM_a_odac_v9_id_othr_id(parser.getTagM_A_ODAC_V9_ID_OTHR_ID(path, root));
		opebean.setM_a_odac_v9_fi_bic(parser.getTagM_A_ODAC_V9_FI_BIC(path, root));
		opebean.setBic_id_do(parser.getTagBIC_ID_DO(path, root));
		opebean.setIban_do  (parser.getTagIBAN_DO  (path, root));
		opebean.setBic_id_beneficiaire(parser.getTagBIC_ID_BENEFICIAIRE(path, root));
		opebean.setIban_beneficiaire(parser.getTagIBAN_BENEFICIAIRE(path, root));
		opebean.setFlag_evolmpm_maeva("EVOLMPM");
	}


	private void parseCode781(OperationSepaBean opebean, Element root, XPath path) throws XPathExpressionException {
		final ParseXMLSepaSDD781 parser = new ParseXMLSepaSDD781();
		
		opebean.setNum_ics(parser.getTagNUM_ICS(path, root));
		opebean.setMotif_rejet_annulation(parser.getTagMOTIF_REJET_ANNULATION(path, root));
		opebean.setPmttpi_svclvl_cd(parser.getTagPMTTPI_SVCLVL_CD(path, root));
		opebean.setPmttpi_lclins_cd(parser.getTagPMTTPI_LCLINS_CD(path, root));
		opebean.setPmttpilclins_prtry(parser.getTagPMTTPILCLINS_PRTRY(path, root));
		opebean.setPmttpi_seqtp(parser.getTagPMTTPI_SEQTP(path, root));
		opebean.setPmttpi_ctgypurp(parser.getTagPMTTPI_CTGYPURP(path, root));
		opebean.setIntrbksttlmamt(getBigDecimal(parser.getTagINTRBKSTTLMAMT(path, root), 2));
		opebean.setIntrbksttlmamtc(parser.getTagINTRBKSTTLMAMTC(path, root));
		opebean.setChrgbr(parser.getTagCHRGBR(path, root));
		opebean.setChrginf_amt(getDouble(parser.getTagCHRGINF_AMT(path, root)));
		opebean.setChrginf_amtc(parser.getTagCHRGINF_AMTC(path, root));
		opebean.setChrginf_pty_fi_bic(parser.getTagCHRGINF_PTY_FI_BIC(path, root));
		opebean.setM_mndtid(parser.getTagM_MNDTID(path, root));
		opebean.setM_dtofsgntr(getDateSql(parser.getTagM_DTOFSGNTR(path, root)));
		opebean.setM_amdmntind(parser.getTagM_AMDMNTIND(path, root));
		opebean.setM_a_orgnlmndtid(parser.getTagM_A_ORGNLMNDTID(path, root));
		opebean.setM_a_s_nm(parser.getTagM_A_S_NM(path, root));
		opebean.setM_a_s_id_proid(parser.getTagM_A_S_ID_PROID(path, root));
		opebean.setM_a_s_id_pro_sch_cd(parser.getTagM_A_S_ID_PRO_SCH_CD(path, root));
		opebean.setM_a_s_id_pro_sch_prtry(parser.getTagM_A_S_ID_PRO_SCH_PRTRY(path, root));
		opebean.setM_a_s_id_pro_issr(parser.getTagM_A_S_ID_PRO_ISSR(path, root));
		opebean.setM_a_odac_id_iban(parser.getTagM_A_ODAC_ID_IBAN(path, root));
		opebean.setM_a_odag_fi_othr_id(parser.getTagM_A_ODAG_FI_OTHR_ID(path, root));
		opebean.setM_elctrncsgnt(parser.getTagM_ELCTRNCSGNT(path, root));
		opebean.setUcdt_name(parser.getTagUCDT_NAME(path, root));
		opebean.setUcdt_id_org_bic_bei(parser.getTagUCDT_ID_ORG_BIC_BEI(path, root));
		opebean.setUcdt_id_org_othr_id(parser.getTagUCDT_ID_ORG_OTHR_ID(path, root));
		opebean.setUcdt_id_org_othr_sch_cd(parser.getTagUCDT_ID_ORG_OTHR_SCH_CD(path, root));
		opebean.setUcdt_id_org_othr_sch_prtry(parser.getTagUCDT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		opebean.setUcdt_id_org_othr_issr(parser.getTagUCDT_ID_ORG_OTHR_ISSR(path, root));
		opebean.setUcdt_id_pr_dpbi_da(getDateSql(parser.getTagUCDT_ID_PR_DPBI_DA(path, root)));
		opebean.setUcdt_id_pr_dpbi_prv(parser.getTagUCDT_ID_PR_DPBI_PRV(path, root));
		opebean.setUcdt_id_pr_dpbi_ct(parser.getTagUCDT_ID_PR_DPBI_CT(path, root));
		opebean.setUcdt_id_pr_dpbi_cr(parser.getTagUCDT_ID_PR_DPBI_CR(path, root));
		opebean.setUcdt_id_prv_othr_id(parser.getTagUCDT_ID_PRV_OTHR_ID(path, root));
		opebean.setUcdt_id_prv_othr_sch_cd(parser.getTagUCDT_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setUcdt_id_prv_othr_sch_prtr(parser.getTagUCDT_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setUcdt_id_prv_othr_issr(parser.getTagUCDT_ID_PRV_OTHR_ISSR(path, root));
		opebean.setDbt_name(parser.getTagDBT_NAME(path, root));
		opebean.setDbt_padr_adrline(parser.getTagDBT_PADR_ADRLINE(path, root));
		opebean.setDbt_padr_ctry(parser.getTagDBT_PADR_CTRY(path, root));
		opebean.setDbt_id_org_bic_bei(parser.getTagDBT_ID_ORG_BIC_BEI(path, root));
		opebean.setDbt_id_org_othr_id(parser.getTagDBT_ID_ORG_OTHR_ID(path, root));
		opebean.setDbt_id_org_othr_sch_cd(parser.getTagDBT_ID_ORG_OTHR_SCH_CD(path, root));
		opebean.setDbt_id_org_othr_sch_prtry(parser.getTagDBT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		opebean.setDbt_id_org_othr_issr(parser.getTagDBT_ID_ORG_OTHR_ISSR(path, root));
		opebean.setDbt_id_pr_dpbi_dat(getDateSql(parser.getTagDBT_ID_PR_DPBI_DAT(path, root)));
		opebean.setDbt_id_pr_dpbi_prv(parser.getTagDBT_ID_PR_DPBI_PRV(path, root));
		opebean.setDbt_id_pr_dpbi_cty(parser.getTagDBT_ID_PR_DPBI_CTY(path, root));
		opebean.setDbt_id_pr_dpbi_cr(parser.getTagDBT_ID_PR_DPBI_CR(path, root));
		opebean.setDbt_id_prv_othr_id(parser.getTagDBT_ID_PRV_OTHR_ID(path, root));
		opebean.setDbt_id_prv_othr_sch_cd(parser.getTagDBT_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setDbt_id_prv_othr_sch_prtr(parser.getTagDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setDbt_id_prv_othr_issr(parser.getTagDBT_ID_PRV_OTHR_ISSR(path, root));
		opebean.setDbtacc_id_iban(parser.getTagDBTACC_ID_IBAN(path, root));
		opebean.setDbtagt_fi_bic(parser.getTagDBTAGT_FI_BIC(path, root));
		opebean.setCdtacc_id_iban(parser.getTagCDTACC_ID_IBAN(path, root));
		opebean.setCdtagt_fi_bic(parser.getTagCDTAGT_FI_BIC(path, root));
		opebean.setCdt_name(parser.getTagCDT_NAME(path, root));
		opebean.setCdt_padr_adrline(parser.getTagCDT_PADR_ADRLINE(path, root));
		opebean.setCdt_padr_ctry(parser.getTagCDT_PADR_CTRY(path, root));
		opebean.setUdbt_name(parser.getTagUDBT_NAME(path, root));
		opebean.setUdbt_id_org_bic_bei(parser.getTagUDBT_ID_ORG_BIC_BEI(path, root));
		opebean.setUdbt_id_org_othr_id(parser.getTagUDBT_ID_ORG_OTHR_ID(path, root));
		opebean.setUdbt_id_org_othr_sch_cd(parser.getTagUDBT_ID_ORG_OTHR_SCH_CD(path, root));
		opebean.setUdbt_id_org_othr_sch_prtr(parser.getTagUDBT_ID_ORG_OTHR_SCH_PRTR(path, root));
		opebean.setUdbt_id_org_othr_sch_issr(parser.getTagUDBT_ID_ORG_OTHR_SCH_ISSR(path, root));
		opebean.setUdbt_id_pr_dpbi_dat(getDateSql(parser.getTagUDBT_ID_PR_DPBI_DAT(path, root)));
		opebean.setUdbt_id_pr_dpbi_prv(parser.getTagUDBT_ID_PR_DPBI_PRV(path, root));
		opebean.setUdbt_id_pr_dpbi_cty(parser.getTagUDBT_ID_PR_DPBI_CTY(path, root));
		opebean.setUdbt_id_pr_dpbi_cry(parser.getTagUDBT_ID_PR_DPBI_CRY(path, root));
		opebean.setUdbt_id_prv_othr_id(parser.getTagUDBT_ID_PRV_OTHR_ID(path, root));
		opebean.setUdbt_id_prv_othr_sch_cd(parser.getTagUDBT_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setUdbt_id_prv_othr_sch_prtr(parser.getTagUDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setUdbt_id_prv_othr_issr(parser.getTagUDBT_ID_PRV_OTHR_ISSR(path, root));
		opebean.setInsgagt_fi_bic(parser.getTagINSGAGT_FI_BIC(path, root));
		opebean.setInsdagt_fi_bic(parser.getTagINSDAGT_FI_BIC(path, root));
		opebean.setRmtinf_ustrd(parser.getTagRMTINF_USTRD(path, root));
		opebean.setRmtinf_strd_type_code(parser.getTagRMTINF_STRD_TYPE_CODE(path, root));
		opebean.setRmtinf_strd_type_ref(parser.getTagRMTINF_STRD_TYPE_REF(path, root));
		opebean.setSup_chemin(parser.getTagSUP_CHEMIN(path, root));
		opebean.setOrgnltxid(parser.getTagORGNLTXID(path, root));
		opebean.setOrggrpinf_orgnlmsgid(parser.getTagORGGRPINF_ORGNLMSGID(path, root));
		opebean.setOrggrpinf_orgnlmsgnmid(parser.getTagORGGRPINF_ORGNLMSGNMID(path, root));
		opebean.setOrgnlinstrid(parser.getTagORGNLINSTRID(path, root));
		opebean.setOrgnlendtoendid(parser.getTagORGNLENDTOENDID(path, root));
		opebean.setOrgnlintrbksttlmamt(getBigDecimal(parser.getTagORGNLINTRBKSTTLMAMT(path, root),2));
		opebean.setOrgnlintrbksttlmamtc(parser.getTagORGNLINTRBKSTTLMAMTC(path, root));
		opebean.setOtr_intrbksttlmdt(getDateSql(parser.getTagOTR_INTRBKSTTLMDT(path, root)));
		opebean.setCompstnamt(getDouble(parser.getTagCOMPSTNAMT(path, root)));
		opebean.setCompstnamtc(parser.getTagCOMPSTNAMTC(path, root));
		opebean.setInstdamt(getDouble(parser.getTagINSTDAMT(path, root)));
		opebean.setInstdamtc(parser.getTagINSTDAMTC(path, root));
		opebean.setRi_rorg_name(parser.getTagRI_RORG_NAME(path, root));
		opebean.setRi_rorg_id_org_bic_bei(parser.getTagRI_RORG_ID_ORG_BIC_BEI(path, root));
		opebean.setRi_rsn_cd(parser.getTagRI_RSN_CD(path, root));
		opebean.setOtr_reqdcolltndt(parser.getTagOTR_REQDCOLLTNDT(path, root));
		opebean.setOtr_csch_id_prv_othr_id(parser.getTagOTR_CSCH_ID_PRV_OTHR_ID(path, root));
		opebean.setOtr_csch_id_prv_othr_sch_cd(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setOtr_csch_id_prv_othr_issr(parser.getTagOTR_CSCH_ID_PRV_OTHR_ISSR(path, root));
		opebean.setOtr_csch_id_prv_othr_sch_prtr(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setOtr_stti_sttlmmtd(parser.getTagOTR_STTI_STTLMMTD(path, root));
		opebean.setOtr_stti_sttaid_iban(parser.getTagOTR_STTI_STTAID_IBAN(path, root));
		opebean.setOtr_stti_sttaid_o_id(parser.getTagOTR_STTI_STTAID_O_ID(path, root));
		opebean.setOtr_stti_sttaid_o_sn_cd(parser.getTagOTR_STTI_STTAID_O_SN_CD(path, root));
		opebean.setOtr_stti_sttaid_o_sn_prtr(parser.getTagOTR_STTI_STTAID_O_SN_PRTR(path, root));
		opebean.setOtr_stti_sttaid_o_issr(parser.getTagOTR_STTI_STTAID_O_ISSR(path, root));
		opebean.setOtr_stti_clrs_cd(parser.getTagOTR_STTI_CLRS_CD(path, root));
		opebean.setOtr_stti_clrs_prtry(parser.getTagOTR_STTI_CLRS_PRTRY(path, root));
		opebean.setRef_operation_origine (parser.getTagREF_OPERATION_ORIGINE (path, root));
		opebean.setM_a_odac_v9_id_othr_id(parser.getTagM_A_ODAC_V9_ID_OTHR_ID(path, root));
		opebean.setM_a_odac_v9_fi_bic(parser.getTagM_A_ODAC_V9_FI_BIC(path, root));
		opebean.setFlag_evolmpm_maeva("EVOLMPM");
	}


	/** 
	 * Méthode pour compléter une opération SEPA de code 681 via le champ xpartt
	 * @param opebean , l'opération SEPA à valoriser
	 * @param root , le document XML xpartt à parser
	 * @param path , XPath, objet obligatoire pour le parsing XML
	 * @throws XPathExpressionException 
	 * */
	private void parseCode681(OperationSepaBean opebean, Element root, XPath path) throws XPathExpressionException {
		final ParseXMLSepaSDD681 parser = new ParseXMLSepaSDD681();
		
		opebean.setNum_ics(parser.getTagNUM_ICS(path, root));
		opebean.setMotif_rejet_annulation(parser.getTagMOTIF_REJET_ANNULATION(path, root));
		opebean.setPmtid_txid(parser.getTagPMTID_TXID(path, root));
		opebean.setPmttpi_svclvl_cd(parser.getTagPMTTPI_SVCLVL_CD(path, root));
		opebean.setPmttpi_lclins_cd(parser.getTagPMTTPI_LCLINS_CD(path, root));
		opebean.setPmttpilclins_prtry(parser.getTagPMTTPILCLINS_PRTRY(path, root));
		opebean.setPmttpi_seqtp(parser.getTagPMTTPI_SEQTP(path, root));
		opebean.setPmttpi_ctgypurp(parser.getTagPMTTPI_CTGYPURP(path, root));
		opebean.setChrginf_amt(getDouble(parser.getTagCHRGINF_AMT(path, root)));
		opebean.setChrginf_amtc(parser.getTagCHRGINF_AMTC(path, root));
		opebean.setChrginf_pty_fi_bic(parser.getTagCHRGINF_PTY_FI_BIC(path, root));
		opebean.setM_mndtid(parser.getTagM_MNDTID(path, root));
		opebean.setM_dtofsgntr(getDateSql(parser.getTagM_DTOFSGNTR(path, root)));
		opebean.setM_amdmntind(parser.getTagM_AMDMNTIND(path, root));
		opebean.setM_a_orgnlmndtid(parser.getTagM_A_ORGNLMNDTID(path, root));
		opebean.setM_a_s_nm(parser.getTagM_A_S_NM(path, root));
		opebean.setM_a_s_id_proid(parser.getTagM_A_S_ID_PROID(path, root));
		opebean.setM_a_s_id_pro_sch_cd(parser.getTagM_A_S_ID_PRO_SCH_CD(path, root));
		opebean.setM_a_s_id_pro_sch_prtry(parser.getTagM_A_S_ID_PRO_SCH_PRTRY(path, root));
		opebean.setM_a_s_id_pro_issr(parser.getTagM_A_S_ID_PRO_ISSR(path, root));
		opebean.setM_a_odac_id_iban(parser.getTagM_A_ODAC_ID_IBAN(path, root));
		opebean.setM_a_odag_fi_othr_id(parser.getTagM_A_ODAG_FI_OTHR_ID(path, root));
		opebean.setM_elctrncsgnt(parser.getTagM_ELCTRNCSGNT(path, root));
		opebean.setUcdt_name(parser.getTagUCDT_NAME(path, root));
		opebean.setUcdt_id_org_bic_bei(parser.getTagUCDT_ID_ORG_BIC_BEI(path, root));
		opebean.setUcdt_id_org_othr_id(parser.getTagUCDT_ID_ORG_OTHR_ID(path, root));
		opebean.setUcdt_id_org_othr_sch_cd(parser.getTagUCDT_ID_ORG_OTHR_SCH_CD(path, root));
		opebean.setUcdt_id_org_othr_sch_prtry(parser.getTagUCDT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		opebean.setUcdt_id_org_othr_issr(parser.getTagUCDT_ID_ORG_OTHR_ISSR(path, root));
		opebean.setUcdt_id_pr_dpbi_da(getDateSql(parser.getTagUCDT_ID_PR_DPBI_DA(path, root)));
		opebean.setUcdt_id_pr_dpbi_prv(parser.getTagUCDT_ID_PR_DPBI_PRV(path, root));
		opebean.setUcdt_id_pr_dpbi_ct(parser.getTagUCDT_ID_PR_DPBI_CT(path, root));
		opebean.setUcdt_id_pr_dpbi_cr(parser.getTagUCDT_ID_PR_DPBI_CR(path, root));
		opebean.setUcdt_id_prv_othr_id(parser.getTagUCDT_ID_PRV_OTHR_ID(path, root));
		opebean.setUcdt_id_prv_othr_sch_cd(parser.getTagUCDT_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setUcdt_id_prv_othr_sch_prtr(parser.getTagUCDT_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setUcdt_id_prv_othr_issr(parser.getTagUCDT_ID_PRV_OTHR_ISSR(path, root));
		opebean.setDbt_name(parser.getTagDBT_NAME(path, root));
		opebean.setDbt_padr_adrline(parser.getTagDBT_PADR_ADRLINE(path, root));
		opebean.setDbt_padr_ctry(parser.getTagDBT_PADR_CTRY(path, root));
		opebean.setDbt_id_org_bic_bei(parser.getTagDBT_ID_ORG_BIC_BEI(path, root));
		opebean.setDbt_id_org_othr_id(parser.getTagDBT_ID_ORG_OTHR_ID(path, root));
		opebean.setDbt_id_org_othr_sch_cd(parser.getTagDBT_ID_ORG_OTHR_SCH_CD(path, root));
		opebean.setDbt_id_org_othr_sch_prtry(parser.getTagDBT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		opebean.setDbt_id_org_othr_issr(parser.getTagDBT_ID_ORG_OTHR_ISSR(path, root));
		opebean.setDbt_id_pr_dpbi_dat(getDateSql(parser.getTagDBT_ID_PR_DPBI_DAT(path, root)));
		opebean.setDbt_id_pr_dpbi_prv(parser.getTagDBT_ID_PR_DPBI_PRV(path, root));
		opebean.setDbt_id_pr_dpbi_cty(parser.getTagDBT_ID_PR_DPBI_CTY(path, root));
		opebean.setDbt_id_pr_dpbi_cr(parser.getTagDBT_ID_PR_DPBI_CR(path, root));
		opebean.setDbt_id_prv_othr_id(parser.getTagDBT_ID_PRV_OTHR_ID(path, root));
		opebean.setDbt_id_prv_othr_sch_cd(parser.getTagDBT_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setDbt_id_prv_othr_sch_prtr(parser.getTagDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setDbt_id_prv_othr_issr(parser.getTagDBT_ID_PRV_OTHR_ISSR(path, root));
		opebean.setDbtacc_id_iban(parser.getTagDBTACC_ID_IBAN(path, root));
		opebean.setDbtagt_fi_bic(parser.getTagDBTAGT_FI_BIC(path, root));
		opebean.setCdtacc_id_iban(parser.getTagCDTACC_ID_IBAN(path, root));
		opebean.setCdtagt_fi_bic(parser.getTagCDTAGT_FI_BIC(path, root));
		opebean.setCdt_name(parser.getTagCDT_NAME(path, root));
		opebean.setCdt_padr_adrline(parser.getTagCDT_PADR_ADRLINE(path, root));
		opebean.setCdt_padr_ctry(parser.getTagCDT_PADR_CTRY(path, root));
		opebean.setUdbt_name(parser.getTagUDBT_NAME(path, root));
		opebean.setUdbt_id_org_bic_bei(parser.getTagUDBT_ID_ORG_BIC_BEI(path, root));
		opebean.setUdbt_id_org_othr_id(parser.getTagUDBT_ID_ORG_OTHR_ID(path, root));
		opebean.setUdbt_id_org_othr_sch_cd(parser.getTagUDBT_ID_ORG_OTHR_SCH_CD(path, root));
		opebean.setUdbt_id_org_othr_sch_prtr(parser.getTagUDBT_ID_ORG_OTHR_SCH_PRTR(path, root));
		opebean.setUdbt_id_org_othr_sch_issr(parser.getTagUDBT_ID_ORG_OTHR_SCH_ISSR(path, root));
		opebean.setUdbt_id_pr_dpbi_dat(getDateSql(parser.getTagUDBT_ID_PR_DPBI_DAT(path, root)));
		opebean.setUdbt_id_pr_dpbi_prv(parser.getTagUDBT_ID_PR_DPBI_PRV(path, root));
		opebean.setUdbt_id_pr_dpbi_cty(parser.getTagUDBT_ID_PR_DPBI_CTY(path, root));
		opebean.setUdbt_id_pr_dpbi_cry(parser.getTagUDBT_ID_PR_DPBI_CRY(path, root));
		opebean.setUdbt_id_prv_othr_id(parser.getTagUDBT_ID_PRV_OTHR_ID(path, root));
		opebean.setUdbt_id_prv_othr_sch_cd(parser.getTagUDBT_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setUdbt_id_prv_othr_sch_prtr(parser.getTagUDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setUdbt_id_prv_othr_issr(parser.getTagUDBT_ID_PRV_OTHR_ISSR(path, root));
		opebean.setInsgagt_fi_bic(parser.getTagINSGAGT_FI_BIC(path, root));
		opebean.setInsdagt_fi_bic(parser.getTagINSDAGT_FI_BIC(path, root));
		opebean.setRmtinf_ustrd(parser.getTagRMTINF_USTRD(path, root));
		opebean.setRmtinf_strd_type_code(parser.getTagRMTINF_STRD_TYPE_CODE(path, root));
		opebean.setRmtinf_strd_type_ref(parser.getTagRMTINF_STRD_TYPE_REF(path, root));
		opebean.setOrgnltxid(parser.getTagORGNLTXID(path, root));
		opebean.setOrgnlinstrid(parser.getTagORGNLINSTRID(path, root));
		opebean.setOrgnlendtoendid(parser.getTagORGNLENDTOENDID(path, root));
		opebean.setTxsts(parser.getTagTXSTS(path, root));
		opebean.setOrgnlintrbksttlmamt(getBigDecimal(parser.getTagORGNLINTRBKSTTLMAMT(path, root), 2));
		opebean.setOrgnlintrbksttlmamtc(parser.getTagORGNLINTRBKSTTLMAMTC(path, root));
		opebean.setOtr_intrbksttlmdt(getDateSql(parser.getTagOTR_INTRBKSTTLMDT(path, root)));
		opebean.setRi_rorg_name(parser.getTagRI_RORG_NAME(path, root));
		opebean.setRi_rorg_id_org_bic_bei(parser.getTagRI_RORG_ID_ORG_BIC_BEI(path, root));
		opebean.setRi_rsn_cd(parser.getTagRI_RSN_CD(path, root));
		opebean.setRi_sn_prtry(parser.getTagRI_SN_PRTRY(path, root));
		opebean.setOtr_reqdcolltndt(parser.getTagOTR_REQDCOLLTNDT(path, root));
		opebean.setOtr_csch_id_prv_othr_id(parser.getTagOTR_CSCH_ID_PRV_OTHR_ID(path, root));
		opebean.setOtr_csch_id_prv_othr_sch_cd(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setOtr_csch_id_prv_othr_issr(parser.getTagOTR_CSCH_ID_PRV_OTHR_ISSR(path, root));
		opebean.setOtr_csch_id_prv_othr_sch_prtr(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setOtr_stti_sttlmmtd(parser.getTagOTR_STTI_STTLMMTD(path, root));
		opebean.setOtr_stti_sttaid_iban(parser.getTagOTR_STTI_STTAID_IBAN(path, root));
		opebean.setOtr_stti_sttaid_o_id(parser.getTagOTR_STTI_STTAID_O_ID(path, root));
		opebean.setOtr_stti_sttaid_o_sn_cd(parser.getTagOTR_STTI_STTAID_O_SN_CD(path, root));
		opebean.setOtr_stti_sttaid_o_sn_prtr(parser.getTagOTR_STTI_STTAID_O_SN_PRTR(path, root));
		opebean.setOtr_stti_sttaid_o_issr(parser.getTagOTR_STTI_STTAID_O_ISSR(path, root));
		opebean.setOtr_stti_clrs_cd(parser.getTagOTR_STTI_CLRS_CD(path, root));
		opebean.setOtr_stti_clrs_prtry(parser.getTagOTR_STTI_CLRS_PRTRY(path, root));
		opebean.setBic_id_debitor(parser.getTagBIC_ID_Debitor(path, root));
		opebean.setBic_id_creditor(parser.getTagBIC_ID_Creditor(path, root));
		opebean.setRef_operation_origine (parser.getTagREF_OPERATION_ORIGINE (path, root));
		opebean.setIban_debitor (parser.getTagIBAN_DEBTOR (path, root));
		opebean.setIban_creditor (parser.getTagIBAN_CREDITOR (path, root));
		opebean.setM_a_odac_v9_id_othr_id(parser.getTagM_A_ODAC_V9_ID_OTHR_ID(path, root));
		opebean.setM_a_odac_v9_fi_bic(parser.getTagM_A_ODAC_V9_FI_BIC(path, root));
		opebean.setBic_id_do(parser.getTagBIC_ID_DO(path, root));
		opebean.setIban_do  (parser.getTagIBAN_DO  (path, root));
		opebean.setBic_id_beneficiaire(parser.getTagBIC_ID_BENEFICIAIRE(path, root));
		opebean.setIban_beneficiaire(parser.getTagIBAN_BENEFICIAIRE(path, root));
		opebean.setFlag_evolmpm_maeva("EVOLMPM");
	}


	
	/** 
	 * Méthode pour compléter une opération SEPA de code 616 via le champ xpartt
	 * @param opebean , l'opération SEPA à valoriser
	 * @param root , le document XML xpartt à parser
	 * @param path , XPath, objet obligatoire pour le parsing XML
	 * */
	private void parseCode616(OperationSepaBean opebean, Element root, XPath path) throws XPathExpressionException {
		final ParseXMLSepaSDD616 parser = new ParseXMLSepaSDD616();
		
		opebean.setNum_ics(parser.getTagNUM_ICS(path, root));
		opebean.setMotif_rejet_annulation(parser.getTagMOTIF_REJET_ANNULATION(path, root));
		opebean.setPmtid_txid(parser.getTagPMTID_TXID(path, root));
		opebean.setPmttpi_svclvl_cd(parser.getTagPMTTPI_SVCLVL_CD(path, root));
		opebean.setPmttpi_lclins_cd(parser.getTagPMTTPI_LCLINS_CD(path, root));
		opebean.setPmttpilclins_prtry(parser.getTagPMTTPILCLINS_PRTRY(path, root));
		opebean.setPmttpi_seqtp(parser.getTagPMTTPI_SEQTP(path, root));
		opebean.setPmttpi_ctgypurp(parser.getTagPMTTPI_CTGYPURP(path, root));
		opebean.setIntrbksttlmamt(getBigDecimal(parser.getTagINTRBKSTTLMAMT(path, root), 2));
		opebean.setIntrbksttlmamtc(parser.getTagINTRBKSTTLMAMTC(path, root));
		opebean.setChrgbr(parser.getTagCHRGBR(path, root));
		opebean.setChrginf_amt(getDouble(parser.getTagCHRGINF_AMT(path, root)));
		opebean.setChrginf_amtc(parser.getTagCHRGINF_AMTC(path, root));
		opebean.setChrginf_pty_fi_bic(parser.getTagCHRGINF_PTY_FI_BIC(path, root));
		opebean.setM_mndtid(parser.getTagM_MNDTID(path, root));
		opebean.setM_dtofsgntr(getDateSql(parser.getTagM_DTOFSGNTR(path, root)));
		opebean.setM_amdmntind(parser.getTagM_AMDMNTIND(path, root));
		opebean.setM_a_orgnlmndtid(parser.getTagM_A_ORGNLMNDTID(path, root));
		opebean.setM_a_s_nm(parser.getTagM_A_S_NM(path, root));
		opebean.setM_a_s_id_proid(parser.getTagM_A_S_ID_PROID(path, root));
		opebean.setM_a_s_id_pro_sch_cd(parser.getTagM_A_S_ID_PRO_SCH_CD(path, root));
		opebean.setM_a_s_id_pro_sch_prtry(parser.getTagM_A_S_ID_PRO_SCH_PRTRY(path, root));
		opebean.setM_a_s_id_pro_issr(parser.getTagM_A_S_ID_PRO_ISSR(path, root));
		opebean.setM_a_odac_id_iban(parser.getTagM_A_ODAC_ID_IBAN(path, root));
		opebean.setM_a_odag_fi_othr_id(parser.getTagM_A_ODAG_FI_OTHR_ID(path, root));
		opebean.setM_elctrncsgnt(parser.getTagM_ELCTRNCSGNT(path, root));
		opebean.setUcdt_name(parser.getTagUCDT_NAME(path, root));
		opebean.setUcdt_id_org_bic_bei(parser.getTagUCDT_ID_ORG_BIC_BEI(path, root));
		opebean.setUcdt_id_org_othr_id(parser.getTagUCDT_ID_ORG_OTHR_ID(path, root));
		opebean.setUcdt_id_org_othr_sch_cd(parser.getTagUCDT_ID_ORG_OTHR_SCH_CD(path, root));
		opebean.setUcdt_id_org_othr_sch_prtry(parser.getTagUCDT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		opebean.setUcdt_id_org_othr_issr(parser.getTagUCDT_ID_ORG_OTHR_ISSR(path, root));
		opebean.setUcdt_id_pr_dpbi_da(getDateSql(parser.getTagUCDT_ID_PR_DPBI_DA(path, root)));
		opebean.setUcdt_id_pr_dpbi_prv(parser.getTagUCDT_ID_PR_DPBI_PRV(path, root));
		opebean.setUcdt_id_pr_dpbi_ct(parser.getTagUCDT_ID_PR_DPBI_CT(path, root));
		opebean.setUcdt_id_pr_dpbi_cr(parser.getTagUCDT_ID_PR_DPBI_CR(path, root));
		opebean.setUcdt_id_prv_othr_id(parser.getTagUCDT_ID_PRV_OTHR_ID(path, root));
		opebean.setUcdt_id_prv_othr_sch_cd(parser.getTagUCDT_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setUcdt_id_prv_othr_sch_prtr(parser.getTagUCDT_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setUcdt_id_prv_othr_issr(parser.getTagUCDT_ID_PRV_OTHR_ISSR(path, root));
		opebean.setDbt_name(parser.getTagDBT_NAME(path, root));
		opebean.setDbt_padr_adrline(parser.getTagDBT_PADR_ADRLINE(path, root));
		opebean.setDbt_padr_ctry(parser.getTagDBT_PADR_CTRY(path, root));
		opebean.setDbt_id_org_bic_bei(parser.getTagDBT_ID_ORG_BIC_BEI(path, root));
		opebean.setDbt_id_org_othr_id(parser.getTagDBT_ID_ORG_OTHR_ID(path, root));
		opebean.setDbt_id_org_othr_sch_cd(parser.getTagDBT_ID_ORG_OTHR_SCH_CD(path, root));
		opebean.setDbt_id_org_othr_sch_prtry(parser.getTagDBT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		opebean.setDbt_id_org_othr_issr(parser.getTagDBT_ID_ORG_OTHR_ISSR(path, root));
		opebean.setDbt_id_pr_dpbi_dat(getDateSql(parser.getTagDBT_ID_PR_DPBI_DAT(path, root)));
		opebean.setDbt_id_pr_dpbi_prv(parser.getTagDBT_ID_PR_DPBI_PRV(path, root));
		opebean.setDbt_id_pr_dpbi_cty(parser.getTagDBT_ID_PR_DPBI_CTY(path, root));
		opebean.setDbt_id_pr_dpbi_cr(parser.getTagDBT_ID_PR_DPBI_CR(path, root));
		opebean.setDbt_id_prv_othr_id(parser.getTagDBT_ID_PRV_OTHR_ID(path, root));
		opebean.setDbt_id_prv_othr_sch_cd(parser.getTagDBT_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setDbt_id_prv_othr_sch_prtr(parser.getTagDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setDbt_id_prv_othr_issr(parser.getTagDBT_ID_PRV_OTHR_ISSR(path, root));
		opebean.setDbtacc_id_iban(parser.getTagDBTACC_ID_IBAN(path, root));
		opebean.setDbtagt_fi_bic(parser.getTagDBTAGT_FI_BIC(path, root));
		opebean.setCdtacc_id_iban(parser.getTagCDTACC_ID_IBAN(path, root));
		opebean.setCdtagt_fi_bic(parser.getTagCDTAGT_FI_BIC(path, root));
		opebean.setCdt_name(parser.getTagCDT_NAME(path, root));
		opebean.setCdt_padr_adrline(parser.getTagCDT_PADR_ADRLINE(path, root));
		opebean.setCdt_padr_ctry(parser.getTagCDT_PADR_CTRY(path, root));
		opebean.setUdbt_name(parser.getTagUDBT_NAME(path, root));
		opebean.setUdbt_id_org_bic_bei(parser.getTagUDBT_ID_ORG_BIC_BEI(path, root));
		opebean.setUdbt_id_org_othr_id(parser.getTagUDBT_ID_ORG_OTHR_ID(path, root));
		opebean.setUdbt_id_org_othr_sch_cd(parser.getTagUDBT_ID_ORG_OTHR_SCH_CD(path, root));
		opebean.setUdbt_id_org_othr_sch_prtr(parser.getTagUDBT_ID_ORG_OTHR_SCH_PRTR(path, root));
		opebean.setUdbt_id_org_othr_sch_issr(parser.getTagUDBT_ID_ORG_OTHR_SCH_ISSR(path, root));
		opebean.setUdbt_id_pr_dpbi_dat(getDateSql(parser.getTagUDBT_ID_PR_DPBI_DAT(path, root)));
		opebean.setUdbt_id_pr_dpbi_prv(parser.getTagUDBT_ID_PR_DPBI_PRV(path, root));
		opebean.setUdbt_id_pr_dpbi_cty(parser.getTagUDBT_ID_PR_DPBI_CTY(path, root));
		opebean.setUdbt_id_pr_dpbi_cry(parser.getTagUDBT_ID_PR_DPBI_CRY(path, root));
		opebean.setUdbt_id_prv_othr_id(parser.getTagUDBT_ID_PRV_OTHR_ID(path, root));
		opebean.setUdbt_id_prv_othr_sch_cd(parser.getTagUDBT_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setUdbt_id_prv_othr_sch_prtr(parser.getTagUDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setUdbt_id_prv_othr_issr(parser.getTagUDBT_ID_PRV_OTHR_ISSR(path, root));
		opebean.setInsgagt_fi_bic(parser.getTagINSGAGT_FI_BIC(path, root));
		opebean.setInsdagt_fi_bic(parser.getTagINSDAGT_FI_BIC(path, root));
		opebean.setRmtinf_ustrd(parser.getTagRMTINF_USTRD(path, root));
		opebean.setRmtinf_strd_type_code(parser.getTagRMTINF_STRD_TYPE_CODE(path, root));
		opebean.setRmtinf_strd_type_ref(parser.getTagRMTINF_STRD_TYPE_REF(path, root));
		opebean.setOrgnltxid(parser.getTagORGNLTXID(path, root));
		opebean.setOrgnlinstrid(parser.getTagORGNLINSTRID(path, root));
		opebean.setOrgnlendtoendid(parser.getTagORGNLENDTOENDID(path, root));
		opebean.setOrgnlintrbksttlmamt(getBigDecimal(parser.getTagORGNLINTRBKSTTLMAMT(path, root), 2));
		opebean.setOrgnlintrbksttlmamtc(parser.getTagORGNLINTRBKSTTLMAMTC(path, root));
		opebean.setOtr_intrbksttlmdt(getDateSql(parser.getTagOTR_INTRBKSTTLMDT(path, root)));
		opebean.setInstdamt(getDouble(parser.getTagINSTDAMT(path, root)));
		opebean.setInstdamtc(parser.getTagINSTDAMTC(path, root));
		opebean.setRi_rorg_name(parser.getTagRI_RORG_NAME(path, root));
		opebean.setRi_rorg_padr_adrline(parser.getTagRI_RORG_PADR_ADRLINE(path, root));
		opebean.setRi_rorg_padr_ctry(parser.getTagRI_RORG_PADR_CTRY(path, root));
		opebean.setRi_rorg_id_org_bic_bei(parser.getTagRI_RORG_ID_ORG_BIC_BEI(path, root));
		opebean.setRi_rorg_id_org_othr_id(parser.getTagRI_RORG_ID_ORG_OTHR_ID(path, root));
		opebean.setRi_rorg_id_org_othr_sch_cd(parser.getTagRI_RORG_ID_ORG_OTHR_SCH_CD(path, root));
		opebean.setRi_rorg_id_org_othr_sch_prtr(parser.getTagRI_RORG_ID_ORG_OTHR_SCH_PRTR(path, root));
		opebean.setRi_rorg_id_org_othr_issr(parser.getTagRI_RORG_ID_ORG_OTHR_ISSR(path, root));
		opebean.setRi_rorg_id_prv_dpbi_dat(getDateSql(parser.getTagRI_RORG_ID_PRV_DPBI_DAT(path, root)));
		opebean.setRi_rorg_id_prv_dpbi_prv(parser.getTagRI_RORG_ID_PRV_DPBI_PRV(path, root));
		opebean.setRi_rorg_id_prv_dpbi_cty(parser.getTagRI_RORG_ID_PRV_DPBI_CTY(path, root));
		opebean.setRi_rorg_id_prv_dpbi_cry(parser.getTagRI_RORG_ID_PRV_DPBI_CRY(path, root));
		opebean.setRi_rorg_id_prv_othr_id(parser.getTagRI_RORG_ID_PRV_OTHR_ID(path, root));
		opebean.setRi_rorg_id_prv_othr_sch_cd(parser.getTagRI_RORG_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setRi_rorg_id_prv_othr_sch_prtr(parser.getTagRI_RORG_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setRi_rorg_id_prv_othr_issr(parser.getTagRI_RORG_ID_PRV_OTHR_ISSR(path, root));
		opebean.setRi_rsn_cd(parser.getTagRI_RSN_CD(path, root));
		opebean.setOtr_reqdcolltndt(parser.getTagOTR_REQDCOLLTNDT(path, root));
		opebean.setOtr_csch_id_prv_othr_id(parser.getTagOTR_CSCH_ID_PRV_OTHR_ID(path, root));
		opebean.setOtr_csch_id_prv_othr_sch_cd(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setOtr_csch_id_prv_othr_issr(parser.getTagOTR_CSCH_ID_PRV_OTHR_ISSR(path, root));
		opebean.setOtr_csch_id_prv_othr_sch_prtr(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setOtr_stti_sttlmmtd(parser.getTagOTR_STTI_STTLMMTD(path, root));
		opebean.setOtr_stti_sttaid_iban(parser.getTagOTR_STTI_STTAID_IBAN(path, root));
		opebean.setOtr_stti_sttaid_o_id(parser.getTagOTR_STTI_STTAID_O_ID(path, root));
		opebean.setOtr_stti_sttaid_o_sn_cd(parser.getTagOTR_STTI_STTAID_O_SN_CD(path, root));
		opebean.setOtr_stti_sttaid_o_sn_prtr(parser.getTagOTR_STTI_STTAID_O_SN_PRTR(path, root));
		opebean.setOtr_stti_sttaid_o_issr(parser.getTagOTR_STTI_STTAID_O_ISSR(path, root));
		opebean.setOtr_stti_clrs_cd(parser.getTagOTR_STTI_CLRS_CD(path, root));
		opebean.setOtr_stti_clrs_prtry(parser.getTagOTR_STTI_CLRS_PRTRY(path, root));
		opebean.setBic_id_debitor(parser.getTagBIC_ID_Debitor(path, root));
		opebean.setBic_id_creditor(parser.getTagBIC_ID_Creditor(path, root));
		opebean.setRef_operation_origine (parser.getTagREF_OPERATION_ORIGINE (path, root));
		opebean.setIban_debitor(parser.getTagIBAN_DEBTOR (path, root));
		opebean.setIban_creditor (parser.getTagIBAN_CREDITOR (path, root));
		opebean.setM_a_odac_v9_id_othr_id(parser.getTagM_A_ODAC_V9_ID_OTHR_ID(path, root));
		opebean.setM_a_odac_v9_fi_bic(parser.getTagM_A_ODAC_V9_FI_BIC(path, root));
		opebean.setBic_id_do(parser.getTagBIC_ID_DO(path, root));
		opebean.setIban_do  (parser.getTagIBAN_DO  (path, root));
		opebean.setBic_id_beneficiaire(parser.getTagBIC_ID_BENEFICIAIRE(path, root));
		opebean.setIban_beneficiaire(parser.getTagIBAN_BENEFICIAIRE(path, root));
		opebean.setFlag_evolmpm_maeva("EVOLMPM");
	}


	
	/** 
	 * Méthode pour compléter une opération SEPA de code 387 via le champ xpartt
	 * @param opebean , l'opération SEPA à valoriser
	 * @param root , le document XML xpartt à parser
	 * @param path , XPath, objet obligatoire pour le parsing XML
	 * */
	private void parseCode387(OperationSepaBean opebean, Element root, XPath path) throws XPathExpressionException {
		final ParseXMLSepaSDD387 parser = new ParseXMLSepaSDD387();
		
		opebean.setNum_ics(parser.getTagNUM_ICS(path, root));
		opebean.setMotif_rejet_annulation(parser.getTagMOTIF_REJET_ANNULATION(path, root));
		opebean.setPmttpi_svclvl_cd(parser.getTagPMTTPI_SVCLVL_CD(path, root));
		opebean.setPmttpi_lclins_cd(parser.getTagPMTTPI_LCLINS_CD(path, root));
		opebean.setPmttpilclins_prtry(parser.getTagPMTTPILCLINS_PRTRY(path, root));
		opebean.setPmttpi_seqtp(parser.getTagPMTTPI_SEQTP(path, root));
		opebean.setPmttpi_ctgypurp(parser.getTagPMTTPI_CTGYPURP(path, root));
		opebean.setPmttpi_ctgypurp_pr(parser.getTagPMTTPI_CTGYPURP_PR(path, root));
		opebean.setM_mndtid(parser.getTagM_MNDTID(path, root));
		opebean.setM_dtofsgntr(getDateSql(parser.getTagM_DTOFSGNTR(path, root)));
		opebean.setM_amdmntind(parser.getTagM_AMDMNTIND(path, root));
		opebean.setM_a_orgnlmndtid(parser.getTagM_A_ORGNLMNDTID(path, root));
		opebean.setM_a_s_nm(parser.getTagM_A_S_NM(path, root));
		opebean.setM_a_s_id_proid(parser.getTagM_A_S_ID_PROID(path, root));
		opebean.setM_a_s_id_pro_sch_cd(parser.getTagM_A_S_ID_PRO_SCH_CD(path, root));
		opebean.setM_a_s_id_pro_sch_prtry(parser.getTagM_A_S_ID_PRO_SCH_PRTRY(path, root));
		opebean.setM_a_s_id_pro_issr(parser.getTagM_A_S_ID_PRO_ISSR(path, root));
		opebean.setM_a_odac_id_iban(parser.getTagM_A_ODAC_ID_IBAN(path, root));
		opebean.setM_a_odag_fi_othr_id(parser.getTagM_A_ODAG_FI_OTHR_ID(path, root));
		opebean.setM_elctrncsgnt(parser.getTagM_ELCTRNCSGNT(path, root));
		opebean.setUcdt_name(parser.getTagUCDT_NAME(path, root));
		opebean.setUcdt_id_org_bic_bei(parser.getTagUCDT_ID_ORG_BIC_BEI(path, root));
		opebean.setUcdt_id_org_othr_id(parser.getTagUCDT_ID_ORG_OTHR_ID(path, root));
		opebean.setUcdt_id_org_othr_sch_cd(parser.getTagUCDT_ID_ORG_OTHR_SCH_CD(path, root));
		opebean.setUcdt_id_org_othr_sch_prtry(parser.getTagUCDT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		opebean.setUcdt_id_org_othr_issr(parser.getTagUCDT_ID_ORG_OTHR_ISSR(path, root));
		opebean.setUcdt_id_pr_dpbi_da(getDateSql(parser.getTagUCDT_ID_PR_DPBI_DA(path, root)));
		opebean.setUcdt_id_pr_dpbi_prv(parser.getTagUCDT_ID_PR_DPBI_PRV(path, root));
		opebean.setUcdt_id_pr_dpbi_ct(parser.getTagUCDT_ID_PR_DPBI_CT(path, root));
		opebean.setUcdt_id_pr_dpbi_cr(parser.getTagUCDT_ID_PR_DPBI_CR(path, root));
		opebean.setUcdt_id_prv_othr_id(parser.getTagUCDT_ID_PRV_OTHR_ID(path, root));
		opebean.setUcdt_id_prv_othr_sch_cd(parser.getTagUCDT_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setUcdt_id_prv_othr_sch_prtr(parser.getTagUCDT_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setUcdt_id_prv_othr_issr(parser.getTagUCDT_ID_PRV_OTHR_ISSR(path, root));
		opebean.setDbt_name(parser.getTagDBT_NAME(path, root));
		opebean.setDbt_padr_adrline(parser.getTagDBT_PADR_ADRLINE(path, root));
		opebean.setDbt_padr_ctry(parser.getTagDBT_PADR_CTRY(path, root));
		opebean.setDbt_id_org_bic_bei(parser.getTagDBT_ID_ORG_BIC_BEI(path, root));
		opebean.setDbt_id_org_othr_id(parser.getTagDBT_ID_ORG_OTHR_ID(path, root));
		opebean.setDbt_id_org_othr_sch_cd(parser.getTagDBT_ID_ORG_OTHR_SCH_CD(path, root));
		opebean.setDbt_id_org_othr_sch_prtry(parser.getTagDBT_ID_ORG_OTHR_SCH_PRTRY(path, root));
		opebean.setDbt_id_org_othr_issr(parser.getTagDBT_ID_ORG_OTHR_ISSR(path, root));
		opebean.setDbt_id_pr_dpbi_dat(getDateSql(parser.getTagDBT_ID_PR_DPBI_DAT(path, root)));
		opebean.setDbt_id_pr_dpbi_prv(parser.getTagDBT_ID_PR_DPBI_PRV(path, root));
		opebean.setDbt_id_pr_dpbi_cty(parser.getTagDBT_ID_PR_DPBI_CTY(path, root));
		opebean.setDbt_id_pr_dpbi_cr(parser.getTagDBT_ID_PR_DPBI_CR(path, root));
		opebean.setDbt_id_prv_othr_id(parser.getTagDBT_ID_PRV_OTHR_ID(path, root));
		opebean.setDbt_id_prv_othr_sch_cd(parser.getTagDBT_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setDbt_id_prv_othr_sch_prtr(parser.getTagDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setDbt_id_prv_othr_issr(parser.getTagDBT_ID_PRV_OTHR_ISSR(path, root));
		opebean.setDbtacc_id_iban(parser.getTagDBTACC_ID_IBAN(path, root));
		opebean.setDbtagt_fi_bic(parser.getTagDBTAGT_FI_BIC(path, root));
		opebean.setCdtacc_id_iban(parser.getTagCDTACC_ID_IBAN(path, root));
		opebean.setCdtagt_fi_bic(parser.getTagCDTAGT_FI_BIC(path, root));
		opebean.setCdt_name(parser.getTagCDT_NAME(path, root));
		opebean.setCdt_padr_adrline(parser.getTagCDT_PADR_ADRLINE(path, root));
		opebean.setCdt_padr_ctry(parser.getTagCDT_PADR_CTRY(path, root));
		opebean.setUdbt_name(parser.getTagUDBT_NAME(path, root));
		opebean.setUdbt_id_org_bic_bei(parser.getTagUDBT_ID_ORG_BIC_BEI(path, root));
		opebean.setUdbt_id_org_othr_id(parser.getTagUDBT_ID_ORG_OTHR_ID(path, root));
		opebean.setUdbt_id_org_othr_sch_cd(parser.getTagUDBT_ID_ORG_OTHR_SCH_CD(path, root));
		opebean.setUdbt_id_org_othr_sch_prtr(parser.getTagUDBT_ID_ORG_OTHR_SCH_PRTR(path, root));
		opebean.setUdbt_id_org_othr_sch_issr(parser.getTagUDBT_ID_ORG_OTHR_SCH_ISSR(path, root));
		opebean.setUdbt_id_pr_dpbi_dat(getDateSql(parser.getTagUDBT_ID_PR_DPBI_DAT(path, root)));
		opebean.setUdbt_id_pr_dpbi_prv(parser.getTagUDBT_ID_PR_DPBI_PRV(path, root));
		opebean.setUdbt_id_pr_dpbi_cty(parser.getTagUDBT_ID_PR_DPBI_CTY(path, root));
		opebean.setUdbt_id_pr_dpbi_cry(parser.getTagUDBT_ID_PR_DPBI_CRY(path, root));
		opebean.setUdbt_id_prv_othr_id(parser.getTagUDBT_ID_PRV_OTHR_ID(path, root));
		opebean.setUdbt_id_prv_othr_sch_cd(parser.getTagUDBT_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setUdbt_id_prv_othr_sch_prtr(parser.getTagUDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setUdbt_id_prv_othr_issr(parser.getTagUDBT_ID_PRV_OTHR_ISSR(path, root));
		opebean.setRmtinf_ustrd(parser.getTagRMTINF_USTRD(path, root));
		opebean.setRmtinf_strd_type_code(parser.getTagRMTINF_STRD_TYPE_CODE(path, root));
		opebean.setRmtinf_strd_type_ref(parser.getTagRMTINF_STRD_TYPE_REF(path, root));
		opebean.setRmtinf_strd_type_is(parser.getTagRMTINF_STRD_TYPE_IS(path, root));
		opebean.setSup_chemin(parser.getTagSUP_CHEMIN(path, root));
		opebean.setOrgnltxid(parser.getTagORGNLTXID(path, root));
		opebean.setOrggrpinf_orgnlmsgid(parser.getTagORGGRPINF_ORGNLMSGID(path, root));
		opebean.setOrggrpinf_orgnlmsgnmid(parser.getTagORGGRPINF_ORGNLMSGNMID(path, root));
		opebean.setOrgnlinstrid(parser.getTagORGNLINSTRID(path, root));
		opebean.setOrgnlendtoendid(parser.getTagORGNLENDTOENDID(path, root));
		opebean.setOrgnlintrbksttlmamt(getBigDecimal(parser.getTagORGNLINTRBKSTTLMAMT(path, root), 2));
		opebean.setOrgnlintrbksttlmamtc(parser.getTagORGNLINTRBKSTTLMAMTC(path, root));
		opebean.setOtr_intrbksttlmdt(getDateSql(parser.getTagOTR_INTRBKSTTLMDT(path, root)));
		opebean.setRi_rorg_name(parser.getTagRI_RORG_NAME(path, root));
		opebean.setRi_rorg_id_org_bic_bei(parser.getTagRI_RORG_ID_ORG_BIC_BEI(path, root));
		opebean.setRi_rsn_cd(parser.getTagRI_RSN_CD(path, root));
		opebean.setRi_sn_prtry(parser.getTagRI_SN_PRTRY(path, root));
		opebean.setOtr_reqdcolltndt(parser.getTagOTR_REQDCOLLTNDT(path, root));
		opebean.setOtr_csch_id_prv_othr_id(parser.getTagOTR_CSCH_ID_PRV_OTHR_ID(path, root));
		opebean.setOtr_csch_id_prv_othr_sch_cd(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_CD(path, root));
		opebean.setOtr_csch_id_prv_othr_issr(parser.getTagOTR_CSCH_ID_PRV_OTHR_ISSR(path, root));
		opebean.setOtr_csch_id_prv_othr_sch_prtr(parser.getTagOTR_CSCH_ID_PRV_OTHR_SCH_PRTR(path, root));
		opebean.setOtr_stti_sttlmmtd(parser.getTagOTR_STTI_STTLMMTD(path, root));
		opebean.setOtr_stti_sttaid_iban(parser.getTagOTR_STTI_STTAID_IBAN(path, root));
		opebean.setOtr_stti_sttaid_o_id(parser.getTagOTR_STTI_STTAID_O_ID(path, root));
		opebean.setOtr_stti_sttaid_o_sn_cd(parser.getTagOTR_STTI_STTAID_O_SN_CD(path, root));
		opebean.setOtr_stti_sttaid_o_sn_prtr(parser.getTagOTR_STTI_STTAID_O_SN_PRTR(path, root));
		opebean.setOtr_stti_sttaid_o_issr(parser.getTagOTR_STTI_STTAID_O_ISSR(path, root));
		opebean.setOtr_stti_clrs_cd(parser.getTagOTR_STTI_CLRS_CD(path, root));
		opebean.setOtr_stti_clrs_prtry(parser.getTagOTR_STTI_CLRS_PRTRY(path, root));
		opebean.setBic_id_debitor(parser.getTagBIC_ID_Debitor(path, root));
		opebean.setBic_id_creditor(parser.getTagBIC_ID_Creditor(path, root));
		opebean.setRef_operation_origine (parser.getTagREF_OPERATION_ORIGINE (path, root));
		opebean.setIban_debitor(parser.getTagIBAN_DEBTOR (path, root));
		opebean.setIban_creditor (parser.getTagIBAN_CREDITOR (path, root));
		opebean.setM_a_odac_v9_id_othr_id(parser.getTagM_A_ODAC_V9_ID_OTHR_ID(path, root));
		opebean.setM_a_odac_v9_fi_bic(parser.getTagM_A_ODAC_V9_FI_BIC(path, root));
		opebean.setBic_id_do(parser.getTagBIC_ID_DO(path, root));
		opebean.setIban_do  (parser.getTagIBAN_DO  (path, root));
		opebean.setBic_id_beneficiaire(parser.getTagBIC_ID_BENEFICIAIRE(path, root));
		opebean.setIban_beneficiaire(parser.getTagIBAN_BENEFICIAIRE(path, root));
		opebean.setFlag_evolmpm_maeva("EVOLMPM");
	}


	/** 
	 * Méthode pour compléter une opération SEPA de code 321 via le champ xpartt
	 * @param opebean , l'opération SEPA à valoriser
	 * @param root , le document XML xpartt à parser
	 * @param path , XPath, objet obligatoire pour le parsing XML
	 * */
	private void parseCode381(OperationSepaBean opebean, Element root, XPath path) throws Exception {
		if(opebean != null && root != null && path != null) {
			
			final ParseXMLSepaSDD parser = new ParseXMLSepaSDD();
			
			opebean.setNum_ics(parser.getTagNUM_ICS(path, root));
			//opebean.setCode_format_pacs(parser.getTagCODE_FORMAT_PACS(path, root));
			opebean.setPmtid_txid(parser.getTagPMTID_TXID(path, root));
			opebean.setPmtid_instrid(parser.getTagPMTID_INSTRID(path, root));
			opebean.setPmtid_endtoendid(parser.getTagPMTID_ENDTOENDID(path, root));
			opebean.setPmttpi_svclvl_cd(parser.getTagPMTTPI_SVCLVL_CD(path, root));
			opebean.setPmttpi_lclins_cd(parser.getTagPMTTPI_LCLINS_CD(path, root));
			opebean.setPmttpilclins_prtry(parser.getTagPMTTPILCLINS_PRTRY(path, root));
			opebean.setPmttpi_seqtp(parser.getTagPMTTPI_SEQTP(path, root));
			opebean.setPmttpi_ctgypurp(parser.getTagPMTTPI_CTGYPURP(path, root));
			opebean.setIntrbksttlmamt(getBigDecimal(getDouble(parser.getTagINTRBKSTTLMAMT(path, root)),2));
			opebean.setIntrbksttlmamtc(parser.getTagINTRBKSTTLMAMTC(path, root));
			opebean.setChrgbr(parser.getTagCHRGBR(path, root));
			opebean.setReqdcolltndt(getDateSql(parser.getTagREQDCOLLTNDT(path, root)));
			opebean.setM_mndtid(parser.getTagM_MNDTID(path, root));
			opebean.setM_dtofsgntr(getDateSql(parser.getTagM_DTOFSGNTR(path, root)));
			opebean.setM_amdmntind(parser.getTagM_AMDMNTIND(path, root));
			opebean.setM_a_orgnlmndtid(parser.getTagM_A_ORGNLMNDTID(path, root));
			opebean.setM_a_s_nm(parser.getTagM_A_S_NM(path, root));
			opebean.setM_a_s_id_proid(parser.getTagM_A_S_ID_PROID(path, root));
			opebean.setM_a_s_id_pro_sch_cd(parser.getTagM_A_S_ID_PRO_SCH_CD(path, root));
			opebean.setM_a_s_id_pro_sch_prtry(parser.getTagM_A_S_ID_PRO_SCH_PRTRY(path, root));
			opebean.setM_a_s_id_pro_issr(parser.getTagM_A_S_ID_PRO_ISSR(path, root));
			opebean.setM_a_odac_id_iban(parser.getTagM_A_ODAC_ID_IBAN(path, root));
			opebean.setM_a_odag_fi_othr_id(parser.getTagM_A_ODAG_FI_OTHR_ID(path, root));
			opebean.setM_elctrncsgnt(parser.getTagM_ELCTRNCSGNT(path, root));
			opebean.setCsch_idproi(parser.getTagCSCH_IDPROI(path, root));
			opebean.setCsch_idproi_cd(parser.getTagCSCH_IDPROI_CD(path, root));
			opebean.setCsch_idproi_prtry(parser.getTagCSCH_IDPROI_PRTRY(path, root));
			opebean.setCsch_idproi_issr(parser.getTagCSCH_IDPROI_ISSR(path, root));
			opebean.setUcdt_name(parser.getTagUCDT_NAME(path, root));
			opebean.setUcdt_id_org_bic_bei(parser.getTagUCDT_ID_ORG_BIC_BEI(path, root));
			opebean.setUcdt_id_org_othr_id(parser.getTagUCDT_ID_ORG_OTHR_ID(path, root));
			opebean.setUcdt_id_org_othr_sch_cd(parser.getTagUCDT_ID_ORG_OTHR_SCH_CD(path, root));
			opebean.setUcdt_id_org_othr_sch_prtry(parser.getTagUCDT_ID_ORG_OTHR_SCH_PRTRY(path, root));
			opebean.setUcdt_id_org_othr_issr(parser.getTagUCDT_ID_ORG_OTHR_ISSR(path, root));
			opebean.setUcdt_id_pr_dpbi_da(getDateSql(parser.getTagUCDT_ID_PR_DPBI_DA(path, root)));
			opebean.setUcdt_id_pr_dpbi_prv(parser.getTagUCDT_ID_PR_DPBI_PRV(path, root));
			opebean.setUcdt_id_pr_dpbi_ct(parser.getTagUCDT_ID_PR_DPBI_CT(path, root));
			opebean.setUcdt_id_pr_dpbi_cr(parser.getTagUCDT_ID_PR_DPBI_CR(path, root));
			opebean.setUcdt_id_prv_othr_id(parser.getTagUCDT_ID_PRV_OTHR_ID(path, root));
			opebean.setUcdt_id_prv_othr_sch_cd(parser.getTagUCDT_ID_PRV_OTHR_SCH_CD(path, root));
			opebean.setUcdt_id_prv_othr_sch_prtr(parser.getTagUCDT_ID_PRV_OTHR_SCH_PRTR(path, root));
			opebean.setUcdt_id_prv_othr_issr(parser.getTagUCDT_ID_PRV_OTHR_ISSR(path, root));
			opebean.setDbt_name(parser.getTagDBT_NAME(path, root));
			opebean.setDbt_padr_adrline(parser.getTagDBT_PADR_ADRLINE(path, root));
			opebean.setDbt_padr_ctry(parser.getTagDBT_PADR_CTRY(path, root));
			opebean.setDbt_id_org_bic_bei(parser.getTagDBT_ID_ORG_BIC_BEI(path, root));
			opebean.setDbt_id_org_othr_id(parser.getTagDBT_ID_ORG_OTHR_ID(path, root));
			opebean.setDbt_id_org_othr_sch_cd(parser.getTagDBT_ID_ORG_OTHR_SCH_CD(path, root));
			opebean.setDbt_id_org_othr_sch_prtry(parser.getTagDBT_ID_ORG_OTHR_SCH_PRTRY(path, root));
			opebean.setDbt_id_org_othr_issr(parser.getTagDBT_ID_ORG_OTHR_ISSR(path, root));
			opebean.setDbt_id_pr_dpbi_dat(getDateSql(parser.getTagDBT_ID_PR_DPBI_DAT(path, root)));
			opebean.setDbt_id_pr_dpbi_prv(parser.getTagDBT_ID_PR_DPBI_PRV(path, root));
			opebean.setDbt_id_pr_dpbi_cty(parser.getTagDBT_ID_PR_DPBI_CTY(path, root));
			opebean.setDbt_id_pr_dpbi_cr(parser.getTagDBT_ID_PR_DPBI_CR(path, root));
			opebean.setDbt_id_prv_othr_id(parser.getTagDBT_ID_PRV_OTHR_ID(path, root));
			opebean.setDbt_id_prv_othr_sch_cd(parser.getTagDBT_ID_PRV_OTHR_SCH_CD(path, root));
			opebean.setDbt_id_prv_othr_sch_prtr(parser.getTagDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
			opebean.setDbt_id_prv_othr_issr(parser.getTagDBT_ID_PRV_OTHR_ISSR(path, root));
			opebean.setDbtacc_id_iban(parser.getTagDBTACC_ID_IBAN(path, root));
			opebean.setDbtagt_fi_bic(parser.getTagDBTAGT_FI_BIC(path, root));
			opebean.setCdtacc_id_iban(parser.getTagCDTACC_ID_IBAN(path, root));
			opebean.setCdtagt_fi_bic(parser.getTagCDTAGT_FI_BIC(path, root));
			opebean.setCdt_name(parser.getTagCDT_NAME(path, root));
			opebean.setCdt_padr_adrline(parser.getTagCDT_PADR_ADRLINE(path, root));
			opebean.setCdt_padr_ctry(parser.getTagCDT_PADR_CTRY(path, root));
			opebean.setUdbt_name(parser.getTagUDBT_NAME(path, root));
			opebean.setUdbt_id_org_bic_bei(parser.getTagUDBT_ID_ORG_BIC_BEI(path, root));
			opebean.setUdbt_id_org_othr_id(parser.getTagUDBT_ID_ORG_OTHR_ID(path, root));
			opebean.setUdbt_id_org_othr_sch_cd(parser.getTagUDBT_ID_ORG_OTHR_SCH_CD(path, root));
			opebean.setUdbt_id_org_othr_sch_prtr(parser.getTagUDBT_ID_ORG_OTHR_SCH_PRTR(path, root));
			opebean.setUdbt_id_org_othr_sch_issr(parser.getTagUDBT_ID_ORG_OTHR_SCH_ISSR(path, root));
			opebean.setUdbt_id_pr_dpbi_dat(getDateSql(parser.getTagUDBT_ID_PR_DPBI_DAT(path, root)));
			opebean.setUdbt_id_pr_dpbi_prv(parser.getTagUDBT_ID_PR_DPBI_PRV(path, root));
			opebean.setUdbt_id_pr_dpbi_cty(parser.getTagUDBT_ID_PR_DPBI_CTY(path, root));
			opebean.setUdbt_id_pr_dpbi_cry(parser.getTagUDBT_ID_PR_DPBI_CRY(path, root));
			opebean.setUdbt_id_prv_othr_id(parser.getTagUDBT_ID_PRV_OTHR_ID(path, root));
			opebean.setUdbt_id_prv_othr_sch_cd(parser.getTagUDBT_ID_PRV_OTHR_SCH_CD(path, root));
			opebean.setUdbt_id_prv_othr_sch_prtr(parser.getTagUDBT_ID_PRV_OTHR_SCH_PRTR(path, root));
			opebean.setUdbt_id_prv_othr_issr(parser.getTagUDBT_ID_PRV_OTHR_ISSR(path, root));
			opebean.setInsgagt_fi_bic(parser.getTagINSGAGT_FI_BIC(path, root));
			opebean.setInsdagt_fi_bic(parser.getTagINSDAGT_FI_BIC(path, root));
			opebean.setRmtinf_ustrd(parser.getTagRMTINF_USTRD(path, root));
			opebean.setRmtinf_strd_type_code(parser.getTagRMTINF_STRD_TYPE_CODE(path, root));
			opebean.setRmtinf_strd_type_ref(parser.getTagRMTINF_STRD_TYPE_REF(path, root));
			opebean.setPur_cd(parser.getTagPUR_CD(path, root));
			opebean.setBic_id_debitor(parser.getTagBIC_ID_Debitor(path, root));
			opebean.setBic_id_creditor(parser.getTagBIC_ID_Creditor(path, root));
			opebean.setIban_debitor (parser.getTagIBAN_DEBTOR (path, root));
			opebean.setIban_creditor (parser.getTagIBAN_CREDITOR (path, root));
			opebean.setM_a_odac_v9_id_othr_id(parser.getTagM_A_ODAC_V9_ID_OTHR_ID(path, root));
			opebean.setM_a_odac_v9_fi_bic(parser.getTagM_A_ODAC_V9_FI_BIC(path, root));
			opebean.setBic_id_do(parser.getTagBIC_ID_DO(path, root));
			opebean.setIban_do  (parser.getTagIBAN_DO  (path, root));
			opebean.setBic_id_beneficiaire(parser.getTagBIC_ID_BENEFICIAIRE(path, root));
			opebean.setIban_beneficiaire(parser.getTagIBAN_BENEFICIAIRE(path, root));
			opebean.setFlag_evolmpm_maeva("EVOLMPM");
		}
		
	}

	// TODO : A mergé
	/** 
	 * Méthode utilitaire de conversion d'un String en date SQL
	 * */
	protected java.sql.Date getDateSql(String dateStr) {
		if (StringUtils.isBlank(dateStr)) {
			return null;
		} else {
			try {
				java.sql.Date dateSql = null;
				final java.util.Date dateUtil = new SimpleDateFormat("yyyy-MM-dd").parse(dateStr);
				if (dateUtil != null) {
					dateSql = new java.sql.Date(dateUtil.getTime());
				}
				return dateSql;
			} catch (ParseException e) {
				e.printStackTrace();
				return null;
			}
		}
		
	}
	
	

			
}
