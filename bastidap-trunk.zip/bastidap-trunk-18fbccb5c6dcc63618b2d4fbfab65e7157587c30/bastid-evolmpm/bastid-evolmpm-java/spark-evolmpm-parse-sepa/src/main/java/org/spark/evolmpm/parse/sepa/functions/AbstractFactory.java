package org.spark.evolmpm.parse.sepa.functions;

import static java.lang.Math.toIntExact;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.SparkSession;
import org.spark.evolmpm.parse.sepa.beans.OperationSepaBean;


public abstract class AbstractFactory {

	
	
    public String getString (Object obj) {
        if (obj==null)  {
            return null;
        } else if (StringUtils.isBlank(obj.toString())) {
			return null;
		} else {  
            return obj.toString();
        }
    }
    
    
    public Integer getInteger(Object obj) {
        if (obj==null)  {
            return null;
        } else if (StringUtils.isBlank(obj.toString())) {
			return null;
		}
        else {  
            return Integer.parseInt(obj.toString());
        }
    }
    
    public Double getDouble(Object obj) {
        if (obj==null)  {
            return null;
        } else if (StringUtils.isBlank(obj.toString())) {
			return null;
		}
        else {  
            return Double.parseDouble(obj.toString());
        }
    }
    
    public Float getFloat(Object obj) {
        if (obj==null)  {
            return null;
        } else if (StringUtils.isBlank(obj.toString())) {
			return null;
		}
        else {  
        	return Float.parseFloat(obj.toString());
        }
    }
    
    public BigDecimal getBigDecimal(Object obj, int precision) {
        if (obj==null)  {
            return null;
        } else if (StringUtils.isBlank(obj.toString())) {
			return null;
		}
        else if (obj.toString().contains(".")||obj.toString().contains(",")){
        	Double bigInt = new Double(obj.toString());
    		return new BigDecimal(bigInt);
        	
        }
        else
        {  
        	BigInteger bigInt = new BigInteger(obj.toString());
            return new BigDecimal(bigInt, precision);
        }
    }
    
    public BigDecimal getBigDecimalSct(Object obj, int precision) {
        if (obj==null)  {
            return null;
        } else if (StringUtils.isBlank(obj.toString())) {
			return null;
		}
        else if (obj.toString().contains(".")||obj.toString().contains(",")){
        	Double bigInt = new Double(obj.toString());
    		return new BigDecimal(bigInt);
        	
        }
        else
        {  
        	BigInteger bigInt = new BigInteger(obj.toString());
            return new BigDecimal(bigInt);
        }
    }
    
    
	public java.util.Date getDateTime(Object obj) {
        if (obj==null)  {
            return null;
        } else if (StringUtils.isBlank(obj.toString())) {
			return null;
		}
        else {  
            try {
                return new SimpleDateFormat("yyyy/dd/MM HH:mm:ss").parse(obj.toString());
            } catch (ParseException e) {
                e.printStackTrace();
                return null;
            }
        }
    }
    
    public java.sql.Date getDateSql(Object obj) {
        if (obj==null)  {
            return null;
        } else if (StringUtils.isBlank(obj.toString())) {
			return null;
		}
        else {  
            try {
            	java.sql.Date dateSql = null;
                final java.util.Date dateUtil = new SimpleDateFormat("yyyy-MM-dd").parse(obj.toString());
                if(dateUtil != null) {
                	dateSql = new Date(dateUtil.getTime()); 
                }
                return dateSql;
            } catch (ParseException e) {
                e.printStackTrace();
                return null;
            }
        }
    }
    
    public java.sql.Timestamp getTimestamp(Object obj) {
        if (obj==null)  {
            return null;
        } else if (StringUtils.isBlank(obj.toString())) {
			return null;
		}
        else {  
            try {
            	java.sql.Timestamp timestamp = null;
                final java.util.Date dateUtil = new SimpleDateFormat("yyyy/dd/MM HH:mm:ss").parse(obj.toString());
                if(dateUtil != null) {
                	timestamp = new java.sql.Timestamp(dateUtil.getTime());
                			new Date(dateUtil.getTime()); 
                }
                return timestamp;
            } catch (ParseException e) {
                e.printStackTrace();
                return null;
            }
        }
    }
    
    
    /** Some Functions */
	/**
	 * DateDiff -- compute the difference between two dates.
	 */
	public static int DateDiff (Date dt1, Date dt2) {		
	    
	    // Get msec from each, ansd subtract.
		if (dt2 != null && dt1 != null && dt2.after(dt1)) {
		       return toIntExact(dt2.getTime() - dt1.getTime());
		} else if (dt2 != null && dt1 != null && dt2.equals(dt1)) {
			   return (Integer) null;
		}
		return (Integer) null; 
		
	}
		
	/* add 5 days
	private void add5Day(OperationSepaBean operationSepa, Date datePre) {
		java.sql.Date maDate = null;
		if(datePre != null) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(datePre);
			cal.set(Calendar.DATE, 5);
			maDate = new java.sql.Date(cal.getTime().getTime());
		}
		return maDate;
	}  */
	
	
	public static boolean useList(List<String> arr, String targetValue){
		return Arrays.asList(arr).contains(targetValue);
	}
	/**
	 * Concatenation de la date de presentation
	 * @param datePresentation
	 * @param heurePresentation
	 * @return java.sql.Timestamp au format yyyy-MM-dd hh:mm:ss
	 * @throws ParseException
	 */
	public java.sql.Timestamp concatDateHeure(java.sql.Date datePresentation, String heurePresentation )
			throws ParseException {
		if(datePresentation != null) {
			final String hour = StringUtils.substring(heurePresentation, 0,2);
			final String minute = StringUtils.substring(heurePresentation, 2,4);
			final String second = StringUtils.substring(heurePresentation, 4,6);
			
			final SimpleDateFormat formatter = new SimpleDateFormat("YYYY-MM-DD");				
			
			final StringBuilder dateBuilder = new StringBuilder();
			dateBuilder.append(formatter.format(new Date(datePresentation.getTime())))
			.append(" ").append(hour)
			.append(":").append(minute)
			.append(":").append(second);
			
			return getDateTimestamp(dateBuilder.toString());
					
		}
		return null;
		
	}

	/**
	 * @param obj
	 * @return java.sql.Timestamp
	 * @throws ParseException
	 */
	public java.sql.Timestamp getDateTimestamp(Object obj) throws ParseException {
		if (obj != null) {
			if(StringUtils.isNotBlank(obj.toString())) {
			    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			    java.util.Date parsedTimeStamp = dateFormat.parse(obj.toString());
			    return new Timestamp(parsedTimeStamp.getTime());    
			}
	    }
		return null; 
	}

	
	@SuppressWarnings("unchecked")
	public Dataset<org.apache.spark.sql.Row> createOperationSepaDF(SparkSession session, JavaRDD<OperationSepaBean> rdd) {
		//Dataset<org.apache.spark.sql.Row> OperationSepa = session.createDataset(rdd.rdd(), Encoders.bean(OperationSepaBean.class));
		Dataset<org.apache.spark.sql.Row> OperationSepa = session.createDataFrame(rdd, OperationSepaBean.class);
		return OperationSepa;
		
	}
    
    

}
