package org.spark.evolmpm.parse.sepa;

import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.fs.Path;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import org.spark.evolmpm.parse.sepa.data.ReadData;
import org.spark.evolmpm.parse.sepa.data.WriteData;

import org.spark.evolmpm.parse.sepa.functions.DataInputFactory;
import org.spark.evolmpm.parse.sepa.functions.OperationSepaFactory;
import org.spark.evolmpm.parse.sepa.beans.OperationSepaBean;
import org.spark.evolmpm.parse.sepa.constant.ParseSepaConstant;
import org.spark.evolmpm.parse.sepa.beans.DataInputBean;
import fr.bdf.bastid.util.bean.LineAcqFile;
import fr.bdf.bastid.util.filereader.AcqFileReader;

import org.spark.evolmpm.parse.sepa.utils.UtilFunctions;

public class LoadOperationsSepaMain implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 85501186295781902L;
	
	public static String getTime() {
		return "[" + new SimpleDateFormat("HH:mm:ss").format(new Date())
				+ "] - ";
	}
	
	public static Boolean isTimeStampValid(String inputString)
    { 
        SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS");
        try{
           format.parse(inputString);
           return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		if(args.length != 4){
            System.out.println("INFO:" + LoadOperationsSepaMain.getTime() + " Missing arguments. Usage: " + 
                    new java.io.File(LoadOperationsSepaMain.class.getProtectionDomain().
                            getCodeSource().
                            getLocation().
                            getPath()).getName() 
                    + " <pathToConfigFile>"
                    + " <acqFilePath>"
                    + " <idTrt>"
                    + " <pathDiff>"
                    );
            System.exit(0);
        }
        
	
        String pathToConfigFile = args[0];
        String acqFilePath = args[1];
        String idTrt = args[2];
        String pathDiff= args[3]; //hdfs path is different in DEV and the others envs
        
             
        
        System.out.println("INFO:" + LoadOperationsSepaMain.getTime() + " pathToConfigFile " + pathToConfigFile);
       System.out.println("INFO:" + LoadOperationsSepaMain.getTime() + " acqFilePath " + acqFilePath);
        System.out.println("INFO:" + LoadOperationsSepaMain.getTime() + " idTrt " + idTrt);
        System.out.println("INFO:" + LoadOperationsSepaMain.getTime() + " pathDiff " + pathDiff);
        
		
		
		/** Init configuration and contexts */ 
		final SparkSession session = SparkSession.builder()
				.master("local[*]")
				.appName("ParseSepa")
				.config("spark.sql.warehouse.dir", "/apps/hive/warehouse")
				.config("spark.sql.hive.convertMetastoreOrc", "false")
				.enableHiveSupport()
				.getOrCreate();
		
	   session.sparkContext().hadoopConfiguration().addResource(new Path(pathToConfigFile));
	   
	   Logger.getRootLogger().setLevel(Level.WARN);
	   AcqFileReader afr = new AcqFileReader(acqFilePath);
		
	   Map<String, List<LineAcqFile>> mapAcqFileLines = getMapAcqFileLines(afr);
	   
	   
		List<LineAcqFile> listIdAcqSepa = mapAcqFileLines
				.get(ParseSepaConstant.TH70_TABLE.toUpperCase());

		if (!validAcqDelta(listIdAcqSepa)) {
			Logger.getRootLogger().error(
					"At least one of the delta acquisition ids is missing");
			System.exit(0);
		}   
	   
	   
		
	   
	   
	   
		/** get data from the source table th70 et th7a */       
        ReadData reader = new ReadData(session, listIdAcqSepa);
        String lastPartition = reader.getLastPartition();
        Dataset<Row> sepaTableDF = reader.getSepaData(lastPartition);
        System.out.println("INFO:" + LoadOperationsSepaMain.getTime() + "sepaTableDF : " + "sepaTableDF count : " + sepaTableDF.count()); 
            
        /** writing to target table*/
        WriteData writer = new WriteData(session,idTrt,pathDiff); 
        
        /** make transformations, select columns in the correct order */
        Dataset<Row> sepaTablePrepDF = writer.prepareSepaData(sepaTableDF);  
        System.out.println("INFO:" + LoadOperationsSepaMain.getTime() + "sepaTablePrepDF : " + sepaTablePrepDF.count());
        
        /** create an RDD from the DataFrame in order to parse the Sepa operations
        contained in the xpartt column */
        JavaRDD<DataInputBean> DataInputRDD = sepaTablePrepDF.toJavaRDD().map(new DataInputFactory());
 	    System.out.println("INFO:" + getTime() + "DataInputRDD count : " + DataInputRDD.count());
 	    System.out.println("sepaTablePrepDF.toJavaRDD().getNumPartitions() = " + sepaTablePrepDF.toJavaRDD().getNumPartitions());
 	    
 	   
 	   /** parse DataInput column and return an OperationSepaBean */
 	    JavaRDD<OperationSepaBean> OperationSepaRDD = DataInputRDD.map(new OperationSepaFactory());    
 	    System.out.println("INFO:" + getTime() + "OperationSepaRDD count : " + OperationSepaRDD.count()); 	
 	    
 	    System.out.println("OperationSepaRDD.getNumPartitions() = " + OperationSepaRDD.getNumPartitions());
 	   
 	   /** Transform RDD to dataframe */
 	    Dataset<Row> OperationSepa = UtilFunctions.createOperationSepaDF(session, OperationSepaRDD);
 	    System.out.println("INFO:" + getTime() + "OperationSepa.printSchema() : ");
 	    //OperationSepa.printSchema();
 	    //OperationSepa.show();
 	    
 	   /** alimenter les 4 dernieres colones */ 
 	   Dataset<Row> OperationSepaFinal = writer.OperationSepaFinal(OperationSepa);
 	   //OperationSepa.select("rio", "iban_do","cle_rib_do_sr","iban_beneficiaire","cle_rib_beneficiaire_sr").show();
 	   
 	   /** write to target table operations_sepa*/
       writer.writeSepaData(OperationSepaFinal);
        
	}
	/**
	 * Method that gets the acquisition ids needed for the treatment.
	 * 
	 * @param afr
	 *            the acquisition file reader
	 * @return the map that contains the acquisition ids needed for the
	 *         treatment
	 */
	private static Map<String, List<LineAcqFile>> getMapAcqFileLines(
			AcqFileReader afr) {
		Map<String, List<LineAcqFile>> mapAcqFileLines = null;
		try {
			mapAcqFileLines = afr.getAcqFileLines();
		} catch (IOException e) {
			Logger.getRootLogger().error(
					"An error occured when reading the file", e);
			System.exit(0);
		}

		if (mapAcqFileLines == null || mapAcqFileLines.isEmpty()) {
			Logger.getRootLogger().error(
					"The acquisition id map is null or empty");
			System.exit(0);
		}
		return mapAcqFileLines;
	}
	private static boolean validAcqDelta(List<LineAcqFile> listIdAcqHistMess) {
		return listIdAcqHistMess != null && !listIdAcqHistMess.isEmpty();
	}
}
