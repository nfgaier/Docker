package org.spark.evolmpm.parse.sepa.data;


import static org.apache.spark.sql.functions.col;
import static org.apache.spark.sql.functions.concat;

import static org.apache.spark.sql.functions.date_format;
import static org.apache.spark.sql.functions.datediff;
import static org.apache.spark.sql.functions.lit;
import static org.apache.spark.sql.functions.substring;

import static org.apache.spark.sql.functions.when;
import static org.apache.spark.sql.functions.regexp_extract;

import java.io.Serializable;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import org.apache.spark.sql.types.DataTypes;
import org.spark.evolmpm.parse.sepa.constant.ParseSepaConstant;


public class WriteData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5559409520572793569L;

	private SparkSession sqlContext;   
	private String idtrt;  
	private String pathDiff;
        
    /**
     * @param sqlContext
     * @param idtrt
     */
    public WriteData(SparkSession sqlContext, String idtrt, String pathDiff ) {
        super();
        this.sqlContext = sqlContext;
        this.idtrt = idtrt;
        this.pathDiff = pathDiff;
      
    }
    

    
    public Dataset<Row> prepareSepaData (Dataset<Row> data) {
    
    //transform data
    Dataset<Row> sepaTablePrepDF = data.select(col("id_operation").cast("string").as("id_operation"),       
            col("coops").cast("string").as("code_operation"),
            col("coclc").cast("string").as("code_client_conventionne"),
            col("idefe").as("id_systeme_echange"),
            col("idiba1").as("iban_debitor_sr"),
            col("idees4").as("bic_id_debitor_sr"),
            col("iddss2").as("bic_id_creditor_sr"),
            col("idiba2").as("iban_creditor_sr"),
            col("cofamo").cast("string").as("code_famille_operation"),
            col("tyopec").as("type_operation"),
            col("seopec").as("sens_echange"),
            col("nuprm").as("num_remise"),
            col("nurms1").cast("string").as("num_remise_tech"),
            concat(date_format(col("ddpre"),"yyyy-MM-dd"), lit(" "), substring(col("hepre"), 1, 2), lit(":"),substring(col("hepre"), 3, 2), lit(":"),substring(col("hepre"), 5, 2)).cast(DataTypes.TimestampType).as("date_pec_amont"),
            col("hepre").cast("string").as("heure_pec_amont"),
            concat(date_format(col("ddpre1"),"yyyy-MM-dd"), lit(" "), substring(col("hepre1"), 0, 2), lit(":"),substring(col("hepre1"), 3, 2), lit(":"),substring(col("hepre1"), 5, 2)).cast(DataTypes.TimestampType).as("date_presentation_remise"),
            col("hepre1").cast("string").as("heure_presentation_remise"),
            col("rfopi").as("rio"),
            col("e8rme").cast("date").as("date_echange"),
            col("ddops2").cast("date").as("date_reglement"),
            col("e8trav").cast("date").as("date_traitement_aval_recu"),
            col("cocll").as("etblt_concerne"),
            col("inopr").as("ind_rejet"),
            col("debemb").as("flag_debrayage_embargo"),
            col("xtimts").as("xtimts"),
            col("xpartt").as("xpartt"),
            col("rfopso").as("ref_operation_origine"),
            col("dtjco").cast("date").as("date_comptable_evolmpm"),
            col("rfopsc").as("pmtid_txid_src"),
            col("mtopa2").cast("Decimal(18,2)").as("mnt_compense_sit"),
            col("codoar").as("code_flux_arch"),
            col("nopart").cast("string").as("num_partition"),
            //col("tyegs").as("type_enregistrement"),
            col("type_enregistrement").as("type_enregistrement"),
            col("rfopso").as("orgnltxid_src"),
            col("idopso").as("orgnlinstrid_src"),
            col("rfeeso").as("orgnlendtoendid_src"),
            //when(col("e8rme").$greater(col("ddops2")), datediff(col("e8rme"), col("ddops2")).as("delai_reglement"))
            //.otherwise(null).cast("Decimal(8,0)").as("delai_reglement"),
            //JIRA 557 : on autorise les délais de réglements négatifs.
            datediff(col("e8rme"), col("ddops2")).cast("Decimal(8,0)").as("delai_reglement"),
            // infos bastid
            /** anomalie
            concat(substring(lit(idtrt),1,4),lit("-"),substring(lit(idtrt),5,2),lit("-"),substring(lit(idtrt),8,2)).as("date_insert"),
            */
            col("date_insert").as("date_insert"),
            col("date_ope").as("date_ope"),
            lit(idtrt).as("id_traitement"),
            
            // donneur d'ordre et beneficiare        
            when(col("coops").isin(320,326,330,340,390,680,681,780,781,980,981), col("idiba1"))
            .when(col("coops").isin(329,380,381,386,387,615,616,720,730,920), col("idiba2"))
            .otherwise(null).as("iban_do_sr"), 
            
            when(col("coops").isin(320,326,329,330,340,390,616,680,681,720,730,780,781,920,980), col("idees4"))
            .when(col("coops").isin(380,381,386,387,615,981), col("iddss2"))
            .otherwise(null).as("bic_id_do_sr"),   
            
            when(col("coops").isin(320,326,329,330,340,390,616,680,681,720,730,780,781,920,980), col("iddss2"))
            .when(col("coops").isin(380,381,386,387,615,981), col("idees4"))
            .otherwise(null).as("bic_id_beneficiaire_sr"),
            
            when(col("coops").isin(329,380,381,386,387,615,616,720,730,920), col("idiba1"))
            .when(col("coops").isin(320,326,330,340,390,680,681,780,781,980,981), col("idiba2"))
            .otherwise(null).as("iban_beneficiaire_sr"),   
            
            substring(when(col("coops").isin(320,326,330,340,390,680,681,780,781,980,981), col("idiba1"))
              		 .when(col("coops").isin(329,380,381,386,387,615,616,720,730,920), col("idiba2"))
              		.otherwise(null).as("iban_do_sr"), 1, 2).as("code_pays_do_sr"),            
               substring(when(col("coops").isin(320,326,330,340,390,680,681,780,781,980,981), col("idiba1"))
               		 .when(col("coops").isin(380,381,386,387,615,616,720,730,920), col("idiba2"))
               		 .otherwise(null).as("iban_do_sr"), 3, 2).as("cle_iban_do_sr"), 
               
	           // informations debitor (1)
	           substring(col("idiba1"),1,2).as("code_pays_debitor_sr"),
	           substring(col("idiba1"),3,2).as("cle_iban_debitor_sr"),       
	          
	           // informations du compte creditor (1)
	           substring(col("idiba2"),1,2).as("code_pays_creditor_sr"),
	           substring(col("idiba2"),3,2).as("cle_iban_creditor_sr"),
          
          
	          // informations du bénéficiare (1)
	          substring(when(col("coops").isin(329,380,381,386,387,615,616,720,730,920), col("idiba1"))
	                  .when(col("coops").isin(320,326,330,340,390,680,681,780,781,980,981), col("idiba2"))
	                  .otherwise(null).as("iban_beneficiaire_sr"),1,2).as("code_pays_beneficiaire_sr"),          
	          substring(when(col("coops").isin(329,380,381,386,387,615,616,720,730,920), col("idiba1"))
	                  .when(col("coops").isin(320,326,330,340,390,680,681,780,781,980,981), col("idiba2"))
	                  .otherwise(null).as("iban_beneficiaire_sr"),3,2).as("cle_iban_beneficiaire_sr"),        
   
		     col("id_type_ope").cast("Decimal").as("id_type_operation"),
		     
		     // colonnes à alimenter apres création des tables de ref
		     lit(null).cast("decimal").as("id_client"),
		     lit(null).cast("string").as("code_grp_remettant"),
		     lit(null).cast("string").as("lib_grp_remettant"),
		     lit(null).cast("decimal").as("id_ics"),
		     lit(null).cast("decimal").as("id_compte_do_sr"),
		     lit(null).cast("decimal").as("id_client_do_sr"),
		     lit(null).cast("decimal").as("id_compte_beneficiaire_sr"),
		     lit(null).cast("decimal").as("id_client_beneficiaire_sr")		    
		     
		    );
    
     System.out.println(" debut affichage");
    		sepaTablePrepDF.select(col("date_presentation_remise")).filter(col("rio").isin(lit("ac07627ab-bda5-4423-b724"),lit("b130001  99999RKVAARNZ297"))).show();     
    		  System.out.println(" finn affichage");
		    Dataset<Row>  sepaTablePrepDF_2= sepaTablePrepDF.select(col("*"),
		    		
		    		// informations du donneur d'ordre (2)
		    		when(col("code_pays_do_sr").equalTo("FR"),substring(col("iban_do_sr"), 5, 5))
		            .otherwise(null).as("code_banque_do_sr"),
		            when(col("code_pays_do_sr").equalTo("FR"),substring(col("iban_do_sr"), 10, 5))
		            .otherwise(null).as("code_guichet_do_sr"), 
		            when(col("code_pays_do_sr").equalTo("FR"),substring(col("iban_do_sr"), 15, 11))
		            .otherwise(null).as("num_cpte_do_sr"),		            
		            when(col("code_pays_do_sr").equalTo("FR"), regexp_extract(col("iban_do_sr"), ".*([A-Za-z0-9]{2}$)", 1))
		            .otherwise(null).as("cle_rib_do_sr"),
		    		
		            // informations bénéficiaire (2)
		            when(col("code_pays_beneficiaire_sr").equalTo("FR"), substring(col("iban_beneficiaire_sr"), 5, 5))
		            .otherwise(null).as("code_banque_beneficiaire_sr"),
		            when(col("code_pays_beneficiaire_sr").equalTo("FR"), substring(col("iban_beneficiaire_sr"), 10, 5))
		            .otherwise(null).as("code_guichet_beneficiaire_sr"),
		            when(col("code_pays_beneficiaire_sr").equalTo("FR"), substring(col("iban_beneficiaire_sr"), 15, 11))
		            .otherwise(null).as("num_cpte_beneficiaire_sr"),		           
		            when(col("code_pays_beneficiaire_sr").equalTo("FR"), regexp_extract(col("iban_beneficiaire_sr"), ".*([A-Za-z0-9]{2}$)", 1))
		            .otherwise(null).as("cle_rib_beneficiaire_sr"),         
		            
		            // informations debitor (2)          
		            when(col("code_pays_debitor_sr").equalTo("FR"), substring(col("iban_debitor_sr"), 5, 5))
		            .otherwise(null).as("code_banque_debitor_sr"),
		            when(col("code_pays_debitor_sr").equalTo("FR"), substring(col("iban_debitor_sr"), 10, 5))
		            .otherwise(null).as("code_guichet_debitor_sr"),
		            when(col("code_pays_debitor_sr").equalTo("FR"), substring(col("iban_debitor_sr"), 15, 11))
		            .otherwise(null).as("num_cpte_debitor_sr"),		            
		            when(col("code_pays_debitor_sr").equalTo("FR"), regexp_extract(col("iban_debitor_sr"), ".*([A-Za-z0-9]{2}$)", 1))
		            .otherwise(null).as("cle_rib_debitor_sr"),
		            
		         // informations du compte creditor (2)          
		            when(col("code_pays_creditor_sr").equalTo("FR"), substring(col("iban_creditor_sr"), 5, 5))
		            .otherwise(null).as("code_banque_creditor_sr"),
		            when(col("code_pays_creditor_sr").equalTo("FR"), substring(col("iban_creditor_sr"), 10, 5))
		            .otherwise(null).as("code_guichet_creditor_sr"),
		            when(col("code_pays_creditor_sr").equalTo("FR"), substring(col("iban_creditor_sr"), 15, 11))
		            .otherwise(null).as("num_cpte_creditor_sr"),
		            // informations creditor (2)		         
		            when(col("code_pays_creditor_sr").equalTo("FR"), regexp_extract(col("iban_creditor_sr"), ".*([A-Za-z0-9]{2}$)", 1))
		            .otherwise(null).as("cle_rib_creditor_sr")              
                        
         );
    
    	
  //return in the same order as the target tables columns
    return sepaTablePrepDF_2.select(
    		col("id_operation"),
			 col("code_operation"),
			 col("code_client_conventionne"),
			 col("id_client"),
			 col("code_grp_remettant"),
			 col("lib_grp_remettant"),
			 col("id_ics"),
			 col("id_systeme_echange"),
			 col("iban_do_sr"),
			 col("code_pays_do_sr"),
			 col("cle_iban_do_sr"),
			 col("code_banque_do_sr"),
			 col("code_guichet_do_sr"),
			 col("num_cpte_do_sr"),
			 col("cle_rib_do_sr"),
			 col("bic_id_do_sr"),
			 col("id_compte_do_sr"),
			 col("id_client_do_sr"),
			 col("bic_id_beneficiaire_sr"),
			 col("iban_beneficiaire_sr"),
			 col("code_pays_beneficiaire_sr"),
			 col("cle_iban_beneficiaire_sr"),
			 col("code_banque_beneficiaire_sr"),
			 col("code_guichet_beneficiaire_sr"),
			 col("num_cpte_beneficiaire_sr"),
			 col("cle_rib_beneficiaire_sr"),
			 col("id_compte_beneficiaire_sr"),
			 col("id_client_beneficiaire_sr"),
			 col("iban_debitor_sr"),
			 col("code_pays_debitor_sr"),
			 col("cle_iban_debitor_sr"),
			 col("code_banque_debitor_sr"),
			 col("code_guichet_debitor_sr"),
			 col("num_cpte_debitor_sr"),
			 col("cle_rib_debitor_sr"),
			 col("bic_id_debitor_sr"),
			 col("bic_id_creditor_sr"),
			 col("iban_creditor_sr"),
			 col("code_pays_creditor_sr"),
			 col("cle_iban_creditor_sr"),
			 col("code_banque_creditor_sr"),
			 col("code_guichet_creditor_sr"),
			 col("num_cpte_creditor_sr"),
			 col("cle_rib_creditor_sr"),
			 col("code_famille_operation"),
			 col("id_type_operation"),
			 col("delai_reglement"),
			 col("type_operation"),
			 col("sens_echange"),
			 col("num_remise"),
			 col("num_remise_tech"),
			 col("date_pec_amont"),
			 col("heure_pec_amont"),
			 col("date_presentation_remise"),
			 col("heure_presentation_remise"),
			 col("rio"),
			 col("date_echange"),
			 col("date_reglement"),
			 col("date_traitement_aval_recu"),
			 col("etblt_concerne"),
			 col("ind_rejet"),
			 col("flag_debrayage_embargo"),
			 col("xtimts"),
			 col("ref_operation_origine"),
			 col("date_comptable_evolmpm"),
			 col("pmtid_txid_src"),
			 col("mnt_compense_sit"),
			 col("code_flux_arch"),
			 col("num_partition"),
			 col("type_enregistrement"),
			 col("orgnltxid_src"),
			 col("orgnlinstrid_src"),
			 col("orgnlendtoendid_src"),
			 col("xpartt"),			 
			 col("date_insert"), 
		     col("date_ope").as("date_ope"),
			 col("id_traitement")
			 ); 
    
    }


    public Dataset<Row> OperationSepaFinal (Dataset<Row> data) {
    	
    	    	 return data.select(
    			 col("id_operation"),
    			 col("code_operation"),
    			 col("code_client_conventionne"),
    			 col("id_client").cast("Decimal").as("id_client"),
    			 col("code_grp_remettant"),
    			 col("lib_grp_remettant"),
    			 col("id_ics").cast("Decimal").as("id_ics"),
    			 col("id_systeme_echange"),
    			 col("iban_do_sr"),
    			 col("code_pays_do_sr"),
    			 col("cle_iban_do_sr"),
    			 col("code_banque_do_sr"),
    			 col("code_guichet_do_sr"),
    			 col("num_cpte_do_sr"),
    			 col("cle_rib_do_sr"),
    			 col("bic_id_do_sr"),
    			 col("id_compte_do_sr").cast("Decimal").as("id_compte_do_sr"),
    			 col("id_client_do_sr").cast("Decimal").as("id_client_do_sr"),
    			 col("bic_id_beneficiaire_sr"),
    			 col("iban_beneficiaire_sr"),
    			 col("code_pays_beneficiaire_sr"),
    			 col("cle_iban_beneficiaire_sr"),
    			 col("code_banque_beneficiaire_sr"),
    			 col("code_guichet_beneficiaire_sr"),
    			 col("num_cpte_beneficiaire_sr"),
    			 col("cle_rib_beneficiaire_sr"),
    			 col("id_compte_beneficiaire_sr").cast("Decimal").as("id_compte_beneficiaire_sr"),
    			 col("id_client_beneficiaire_sr").cast("Decimal").as("id_client_beneficiaire_sr"),
    			 col("iban_debitor_sr"),
    			 col("code_pays_debitor_sr"),
    			 col("cle_iban_debitor_sr"),
    			 col("code_banque_debitor_sr"),
    			 col("code_guichet_debitor_sr"),
    			 col("num_cpte_debitor_sr"),
    			 col("cle_rib_debitor_sr"),
    			 col("bic_id_debitor_sr"),
    			 col("bic_id_creditor_sr"),
    			 col("iban_creditor_sr"),
    			 col("code_pays_creditor_sr"),
    			 col("cle_iban_creditor_sr"),
    			 col("code_banque_creditor_sr"),
    			 col("code_guichet_creditor_sr"),
    			 col("num_cpte_creditor_sr"),
    			 col("cle_rib_creditor_sr"),
    			 col("code_famille_operation"),
    			 col("id_type_operation").cast("Decimal").as("id_type_operation"),
    			 col("delai_reglement").cast("Decimal(8,0)").as("delai_reglement"),
    			 col("type_operation"),
    			 col("sens_echange"),
    			 col("num_remise"),
    			 col("num_remise_tech"),
    			 col("date_pec_amont"),
    			 col("heure_pec_amont"),
    			 col("date_presentation_remise"),
    			 col("heure_presentation_remise"),
    			 col("rio"),
    			 col("date_echange").cast("Timestamp").as("date_echange"),
    			 col("date_reglement").cast("Timestamp").as("date_reglement"),
    			 col("date_traitement_aval_recu").cast("Timestamp").as("date_traitement_aval_recu"),
    			 col("etblt_concerne"),
    			 col("ind_rejet"),
    			 col("flag_debrayage_embargo"),
    			 col("xtimts"),
    			 col("ref_operation_origine"),
    			 col("date_comptable_evolmpm").cast("Timestamp").as("date_comptable_evolmpm"),
    			 col("pmtid_txid_src"),
    			 col("mnt_compense_sit").cast("Decimal(20,2)").as("mnt_compense_sit"),
    			 col("code_flux_arch"),
    			 col("num_partition"),
    			 col("type_enregistrement"),
    			 col("orgnltxid_src"),
    			 col("orgnlinstrid_src"),
    			 col("orgnlendtoendid_src"),
    			 col("num_ics"),
    			 col("motif_rejet_annulation"),
    			 col("pmtid_txid"),
    			 col("pmtid_instrid"),
    			 col("pmtid_endtoendid"),
    			 col("pmttpi_svclvl_cd"),
    			 col("pmttpi_lclins_cd"),
    			 col("pmttpilclins_prtry"),
    			 col("pmttpi_seqtp"),
    			 col("pmttpi_ctgypurp"),
    			 col("pmttpi_ctgypurp_pr"),
    			 col("intrbksttlmamt").cast("Decimal(17,2)").as("intrbksttlmamt"),
    			 col("intrbksttlmamtc"),
    			 col("chrgbr"),
    			 col("chrginf_amt").cast("Decimal(17,2)").as("chrginf_amt"),
    			 col("chrginf_amtc"),
    			 col("chrginf_pty_fi_bic"),
    			 col("reqdcolltndt"),
    			 col("m_mndtid"),
    			 col("m_dtofsgntr"),
    			 col("m_amdmntind"),
    			 col("m_a_orgnlmndtid"),
    			 col("m_a_s_nm"),
    			 col("m_a_s_id_proid"),
    			 col("m_a_s_id_pro_sch_cd"),
    			 col("m_a_s_id_pro_sch_prtry"),
    			 col("m_a_s_id_pro_issr"),
    			 col("m_a_odac_id_iban"),
    			 col("m_a_odag_fi_othr_id"),
    			 col("m_elctrncsgnt"),
    			 col("csch_idproi"),
    			 col("csch_idproi_cd"),
    			 col("csch_idproi_prtry"),
    			 col("csch_idproi_issr"),
    			 col("ucdt_name"),
    			 col("ucdt_id_org_bic_bei"),
    			 col("ucdt_id_org_othr_id"),
    			 col("ucdt_id_org_othr_sch_cd"),
    			 col("ucdt_id_org_othr_sch_prtry"),
    			 col("ucdt_id_org_othr_issr"),
    			 col("ucdt_id_pr_dpbi_da"),
    			 col("ucdt_id_pr_dpbi_prv"),
    			 col("ucdt_id_pr_dpbi_ct"),
    			 col("ucdt_id_pr_dpbi_cr"),
    			 col("ucdt_id_prv_othr_id"),
    			 col("ucdt_id_prv_othr_sch_cd"),
    			 col("ucdt_id_prv_othr_sch_prtr"),
    			 col("ucdt_id_prv_othr_issr"),
    			 col("dbt_name"),
    			 col("dbt_padr_adrline"),
    			 col("dbt_padr_ctry"),
    			 col("dbt_id_org_bic_bei"),
    			 col("dbt_id_org_othr_id"),
    			 col("dbt_id_org_othr_sch_cd"),
    			 col("dbt_id_org_othr_sch_prtry"),
    			 col("dbt_id_org_othr_issr"),
    			 col("dbt_id_pr_dpbi_dat"),
    			 col("dbt_id_pr_dpbi_prv"),
    			 col("dbt_id_pr_dpbi_cty"),
    			 col("dbt_id_pr_dpbi_cr"),
    			 col("dbt_id_prv_othr_id"),
    			 col("dbt_id_prv_othr_sch_cd"),
    			 col("dbt_id_prv_othr_sch_prtr"),
    			 col("dbt_id_prv_othr_issr"),
    			 col("dbtacc_id_iban"),
    			 col("dbtagt_fi_bic"),
    			 col("cdtacc_id_iban"),
    			 col("cdtagt_fi_bic"),
    			 col("cdt_name"),
    			 col("cdt_padr_adrline"),
    			 col("cdt_padr_ctry"),
    			 col("cdt_id_org_bic_bei"),
    			 col("cdt_id_org_othr_id"),
    			 col("cdt_id_org_othr_sch_cd"),
    			 col("cdt_id_org_othr_sch_prtry"),
    			 col("cdt_id_org_othr_issr"),
    			 col("cdt_id_pr_dpbi_dat"),
    			 col("cdt_id_pr_dpbi_prv"),
    			 col("cdt_id_pr_dpbi_cty"),
    			 col("cdt_id_pr_dpbi_cry"),
    			 col("cdt_id_prv_othr_id"),
    			 col("cdt_id_prv_othr_sch_cd"),
    			 col("cdt_id_prv_othr_sch_prtr"),
    			 col("cdt_id_prv_othr_issr"),
    			 col("udbt_name"),
    			 col("udbt_id_org_bic_bei"),
    			 col("udbt_id_org_othr_id"),
    			 col("udbt_id_org_othr_sch_cd"),
    			 col("udbt_id_org_othr_sch_prtr"),
    			 col("udbt_id_org_othr_sch_issr"),
    			 col("udbt_id_pr_dpbi_dat"),
    			 col("udbt_id_pr_dpbi_prv"),
    			 col("udbt_id_pr_dpbi_cty"),
    			 col("udbt_id_pr_dpbi_cry"),
    			 col("udbt_id_prv_othr_id"),
    			 col("udbt_id_prv_othr_sch_cd"),
    			 col("udbt_id_prv_othr_sch_prtr"),
    			 col("udbt_id_prv_othr_issr"),
    			 col("insgagt_fi_bic"),
    			 col("insdagt_fi_bic"),
    			 col("rmtinf_ustrd"),
    			 col("rmtinf_strd_type_code"),
    			 col("rmtinf_strd_type_ref"),
    			 col("rmtinf_strd_type_is"),
    			 col("sup_chemin"),
    			 col("pur_cd"),
    			 col("orgnltxid"),
    			 col("orggrpinf_orgnlmsgid"),
    			 col("orggrpinf_orgnlmsgnmid"),
    			 col("orgnlinstrid"),
    			 col("orgnlendtoendid"),
    			 col("txsts"),
    			 col("orgnlintrbksttlmamt").cast("Decimal(17,2)").as("orgnlintrbksttlmamt"),
    			 col("orgnlintrbksttlmamtc"),
    			 col("otr_intrbksttlmdt"),
    			 col("compstnamt").cast("Decimal(17,2)").as("compstnamt"),
    			 col("compstnamtc"),
    			 col("instdamt").cast("Decimal(17,2)").as("instdamt"),
    			 col("instdamtc"),
    			 col("ri_rorg_name"),
    			 col("ri_rorg_padr_adrline"),
    			 col("ri_rorg_padr_ctry"),
    			 col("ri_rorg_id_org_bic_bei"),
    			 col("ri_rorg_id_org_othr_id"),
    			 col("ri_rorg_id_org_othr_sch_cd"),
    			 col("ri_rorg_id_org_othr_sch_prtr"),
    			 col("ri_rorg_id_org_othr_issr"),
    			 col("ri_rorg_id_prv_dpbi_dat"),
    			 col("ri_rorg_id_prv_dpbi_prv"),
    			 col("ri_rorg_id_prv_dpbi_cty"),
    			 col("ri_rorg_id_prv_dpbi_cry"),
    			 col("ri_rorg_id_prv_othr_id"),
    			 col("ri_rorg_id_prv_othr_sch_cd"),
    			 col("ri_rorg_id_prv_othr_sch_prtr"),
    			 col("ri_rorg_id_prv_othr_issr"),
    			 col("ri_rsn_cd"),
    			 col("ri_sn_prtry"),
    			 col("ri_addtlinf1"),
    			 col("ri_addtlinf2"),
    			 col("otr_reqdcolltndt"),
    			 col("otr_csch_id_prv_othr_id"),
    			 col("otr_csch_id_prv_othr_sch_cd"),
    			 col("otr_csch_id_prv_othr_issr"),
    			 col("otr_csch_id_prv_othr_sch_prtr"),
    			 col("otr_stti_sttlmmtd"),
    			 col("otr_stti_sttaid_iban"),
    			 col("otr_stti_sttaid_o_id"),
    			 col("otr_stti_sttaid_o_sn_cd"),
    			 col("otr_stti_sttaid_o_sn_prtr"),
    			 col("otr_stti_sttaid_o_issr"),
    			 col("otr_stti_clrs_cd"),
    			 col("otr_stti_clrs_prtry"),
    			 col("bic_id_debitor"),
    			 col("bic_id_creditor"),
    			 col("ot_instrid"),
    			 col("ot_endtoendid"),
    			 col("ot_txid"),
    			 col("ot_crlsysref"),
    			 col("ot_first_agt_fi_bic"),
    			 col("m_orgnl_pty_name"),
    			 col("m_orgnl_pty_padr_typ"),
    			 col("m_orgnl_pty_padr_dpt"),
    			 col("m_orgnl_pty_padr_sbdpt"),
    			 col("m_orgnl_pty_padr_stnm"),
    			 col("m_orgnl_pty_padr_bdnm"),
    			 col("m_orgnl_pty_padr_pscd"),
    			 col("m_orgnl_pty_padr_twnm"),
    			 col("m_orgnl_pty_padr_ctsd"),
    			 col("m_orgnl_pty_padr_ctry"),
    			 col("m_orgnl_pty_padr_adli1"),
    			 col("m_orgnl_pty_padr_adli2"),
    			 col("m_orgnl_pty_padr_adli3"),
    			 col("m_orgnl_pty_padr_adli4"),
    			 col("m_orgnl_pty_padr_adli5"),
    			 col("m_orgnl_pty_padr_adli6"),
    			 col("m_orgnl_pty_padr_adli7"),
    			 col("m_orgnl_pty_id_oi_bic"),
    			 col("m_orgnl_pty_id_oi_id"),
    			 col("m_orgnl_pty_id_oi_o_sn_cd"),
    			 col("m_orgnl_pty_id_oi_sn_pty"),
    			 col("m_orgnl_pty_id_oi_o_issr"),
    			 col("m_orgnl_pty_id_pr_bi_dat"),
    			 col("m_orgnl_pty_id_pr_bi_prv"),
    			 col("m_orgnl_pty_id_pr_bi_cty"),
    			 col("m_orgnl_pty_id_pr_bi_cry"),
    			 col("m_orgnl_pty_id_pr_o_id"),
    			 col("m_orgnl_pty_id_pr_o_sn_cd"),
    			 col("m_orgnl_pty_id_pr_o_sn_pty"),
    			 col("m_orgnl_pty_id_pr_o_issr"),
    			 col("m_orgnl_pty_ctrr"),
    			 col("m_orgnl_ctct_dt_nmpr"),
    			 col("m_orgnl_ctct_dt_nm"),
    			 col("m_orgnl_ctct_dt_phnm"),
    			 col("m_orgnl_ctct_dt_mbnm"),
    			 col("m_orgnl_ctct_dt_fxnm"),
    			 col("m_orgnl_ctct_dt_emadr"),
    			 col("m_orgnl_ctct_dt_other"),
    			 col("m_orgnl_accnt_iban"),
    			 col("m_orgnl_accnt_o_id"),
    			 col("m_orgnl_agt_fi_bic"),
    			 col("m_updid_pty_name"),
    			 col("m_updid_pty_padr_typ"),
    			 col("m_updid_pty_padr_dpt"),
    			 col("m_updid_pty_padr_sbdpt"),
    			 col("m_updid_pty_padr_stnm"),
    			 col("m_updid_pty_padr_bdnm"),
    			 col("m_updid_pty_padr_pscd"),
    			 col("m_updid_pty_padr_twnm"),
    			 col("m_updid_pty_padr_ctsd"),
    			 col("m_updid_pty_padr_ctr"),
    			 col("m_updid_pty_padr_adli1"),
    			 col("m_updid_pty_padr_adli2"),
    			 col("m_updid_pty_padr_adli3"),
    			 col("m_updid_pty_padr_adli4"),
    			 col("m_updid_pty_padr_adli5"),
    			 col("m_updid_pty_padr_adli6"),
    			 col("m_updid_pty_padr_adli7"),
    			 col("m_updid_pty_id_bic"),
    			 col("m_updid_id_o_id"),
    			 col("m_updid_pty_id_o_sn_cd"),
    			 col("m_updid_pty_id_o_sd_pty"),
    			 col("m_updid_pty_id_o_issr"),
    			 col("m_updid_pty_id_pr_bi_dat"),
    			 col("m_updid_pty_id_pr_bi_prv"),
    			 col("m_updid_pty_id_pr_bi_cty"),
    			 col("m_updid_pty_id_pr_bi_cry"),
    			 col("m_updid_pty_id_pr_o_id"),
    			 col("m_updid_pty_id_pr_o_sn_cd"),
    			 col("m_updid_pty_id_pr_o_sn_pty"),
    			 col("m_updid_pty_id_pr_o_issr"),
    			 col("m_updid_pty_ctrr"),
    			 col("m_updid_ctct_dt_nmpr"),
    			 col("m_updid_ctct_dt_nm"),
    			 col("m_updid_ctct_dt_phnm"),
    			 col("m_updid_ctct_dt_mbnm"),
    			 col("m_updid_ctct_dt_fxnm"),
    			 col("m_updid_ctct_dt_emadr"),
    			 col("m_updid_ctct_dt_other"),
    			 col("m_updid_acct_iban"),
    			 col("m_updid_acct_o_id"),
    			 col("m_updid_agt_fi_bic"),
    			 col("m_add_inf"),
    			 col("m_id"),
    			 col("iban_debitor"),
    			 col("iban_creditor"),
    			 col("m_a_odac_v9_id_othr_id"),
    			 col("m_a_odac_v9_fi_bic"),
    			 col("bic_id_do"),
    			 col("iban_do"),
    			 col("bic_id_beneficiaire"),
    			 col("iban_beneficiaire"),
    			 col("flag_evolmpm_maeva"),
    			 col("date_insert"),    
    		     col("date_ope").as("date_ope"),
    			 col("id_traitement")   
    	            
    	    		);
    	            
    
    } 	            

	/**
	 * Write Dataset<Row> as orc file in the HDFS path of the target table
	 * Add partition to target table.
	 * @param data
	 **/   
	public void writeSepaData (Dataset<Row> data) {  
					 
	    data.write().partitionBy("id_traitement")	    
	    		    .format("orc")
	    		    .mode("append")
	    		    .save(ParseSepaConstant.SEPA_HDFS_PATH_ROOT + pathDiff + ParseSepaConstant.SEPA_HDFS_PATH_TABLE);  
	      
	    String alterTableStmt = "ALTER TABLE " + ParseSepaConstant.HIVE_WRK_LAYER+"." + ParseSepaConstant.TARGET_SEPA_TABLE 
	            			 + " ADD IF NOT EXISTS PARTITION (id_traitement='"+ idtrt +"') location '"+ParseSepaConstant.SEPA_HDFS_PATH_ROOT + pathDiff + ParseSepaConstant.SEPA_HDFS_PATH_TABLE+"/id_traitement="+ idtrt +"'" ;
	    System.out.println("INFO: " +  alterTableStmt);
	    sqlContext.sql(alterTableStmt);
	}
	

}
