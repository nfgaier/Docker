package org.spark.evolmpm.parse.minos;

import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.fs.Path;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.spark.evolmpm.parse.minos.constant.ParseMinosConstant;
import org.spark.evolmpm.parse.minos.data.DataProcessor;
import org.spark.evolmpm.parse.minos.data.ReadData;
import org.spark.evolmpm.parse.minos.data.WriteData;

import fr.bdf.bastid.util.bean.LineAcqFile;
import fr.bdf.bastid.util.filereader.AcqFileReader;


public class ParseMinosMain implements Serializable {

    private static final long serialVersionUID = -1038992202477473392L;
    
    public static String getTime() {
        return "[" + new SimpleDateFormat("HH:mm:ss" ).format(new Date()) + "] - ";
    }   

    public static Boolean isTimeStampValid(String inputString)
    { 
        SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS");
        try{
           format.parse(inputString);
           return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }
    
    public static void main( String[] args ) {
    	
    	if(args.length != 4){
    		System.out.println("INFO:" + ParseMinosMain.getTime() + " Missing arguments. Usage: " + 
                    new java.io.File(ParseMinosMain.class.getProtectionDomain().
                            getCodeSource().
                            getLocation().
                            getPath()).getName() 
                    + " <hadoop configuration file>"
					+ " <path to id acquisition file>"
					+ " <timestamp_trt>"
                    + " <path diff>");
            System.exit(0);
        }
        
        String pathToConfigFile = args[0];
        String acqFilePath = args[1];
        String idTrt = args[2];
        String pathDiff= args[3]; //hdfs path is different in DEV and the others envs
        
        System.out.println("INFO:" + ParseMinosMain.getTime() + " pathToConfigFile " + pathToConfigFile);
        System.out.println("INFO:" + ParseMinosMain.getTime() + " acqFilePath " + acqFilePath);
        System.out.println("INFO:" + ParseMinosMain.getTime() + " idTrt " + idTrt);
        System.out.println("INFO:" + ParseMinosMain.getTime() + " pathDiff " + pathDiff);
        
		final SparkSession session = SparkSession.builder()
				.appName("ParseMinosMain")
				.config("spark.sql.warehouse.dir", "/apps/hive/warehouse")
				.config("spark.sql.hive.convertMetastoreOrc", "false")
				.enableHiveSupport()
				.getOrCreate();
		
        session.sparkContext().hadoopConfiguration().addResource(new Path(pathToConfigFile));
		
        AcqFileReader afr = new AcqFileReader(acqFilePath);
        
        Map<String, List<LineAcqFile>> mapAcqFileLines = getMapAcqFileLines(afr);
		
		List<LineAcqFile> listIdAcqMinos = mapAcqFileLines
				.get(ParseMinosConstant.MINOS_TABLE.toUpperCase());

		if (!validAcqDelta(listIdAcqMinos)) {
			Logger.getRootLogger().error(
					"At least one of the delta acquisition ids is missing");
			System.exit(0);
		}

        
        Logger.getRootLogger().setLevel(Level.WARN);
        
        
		//reading source data
        ReadData reader = new ReadData(session,listIdAcqMinos);
        
        //data processor 
        DataProcessor processor = new DataProcessor(session, idTrt);
        
        //writing to target table
        WriteData writer = new WriteData(session,idTrt,pathDiff);
        
        //read data from th70 table
        Dataset<Row> minosTableDF = reader.getMinosData();       
        System.out.println("INFO:" + ParseMinosMain.getTime() + "minosTableDF : " + minosTableDF.count());
        //minosTableDF.printSchema();
        
        //make some transformations
        Dataset<Row> minosTablePrepDF = processor.prepareMinosData(minosTableDF).persist();    
        System.out.println("INFO:" + ParseMinosMain.getTime() + "minosTablePrepDF : " + minosTablePrepDF.count());
        //minosTablePrepDF.printSchema();
        
        //read data from ref_type_operation table
        Dataset<Row> refTableDS = reader.getRefOpeTypeData();        
        System.out.println("INFO:" + ParseMinosMain.getTime() + "refTableDS : " + refTableDS.count());
        //refTableDS.printSchema();
        
        //join the ref_type_operation table and select columns in the correct order
        Dataset<Row> minosTableFinalDS = processor.join(minosTablePrepDF, refTableDS);
        System.out.println("INFO:" + ParseMinosMain.getTime() + "minosTableFinalDS : " + minosTableFinalDS.count());
        //minosTableFinalDS.printSchema();
        
        //wirte to target table operations_minos
        writer.writeMinosData(minosTableFinalDS);
        
        session.close();
        
    }
    
	/**
	 * Method that gets the acquisition ids needed for the treatment.
	 * 
	 * @param afr
	 *            the acquisition file reader
	 * @return the map that contains the acquisition ids needed for the
	 *         treatment
	 */
	private static Map<String, List<LineAcqFile>> getMapAcqFileLines(
			AcqFileReader afr) {
		Map<String, List<LineAcqFile>> mapAcqFileLines = null;
		try {
			mapAcqFileLines = afr.getAcqFileLines();
		} catch (IOException e) {
			Logger.getRootLogger().error(
					"An error occured when reading the file", e);
			System.exit(0);
		}

		if (mapAcqFileLines == null || mapAcqFileLines.isEmpty()) {
			Logger.getRootLogger().error(
					"The acquisition id map is null or empty");
			System.exit(0);
		}
		return mapAcqFileLines;
	}
	
	/**
	 * Method that verifies if the acquisition ids for delta tables are valid.
	 * 
	 * @param listIdAcqHistMess
	 *            the list of acquisition ids 
	 * @return true if all the acquisition ids are valid, false if not
	 */
	private static boolean validAcqDelta(List<LineAcqFile> listIdAcqHistMess) {
		return listIdAcqHistMess != null && !listIdAcqHistMess.isEmpty();
	}
}