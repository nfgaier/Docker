package org.spark.evolmpm.parse.minos.data;

import java.io.Serializable;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.spark.evolmpm.parse.minos.constant.ParseMinosConstant;

public class WriteData implements Serializable {

    private static final long serialVersionUID = -789223906365051372L;

    private SparkSession sqlContext;
    private String idtrt;
    private String pathDiff;
        
    /**
     * @param sqlContext
     * @param idtrt
     */
    public WriteData(SparkSession sqlContext, String idtrt, String pathDiff ) {
        super();
        this.sqlContext = sqlContext;
        this.idtrt = idtrt;
        this.pathDiff = pathDiff;
    }
   
    /**
     * Write Dataset<Row> as orc file in the HDFS path of the target table
     * Add partition to target table.
     * @param data
     */
    public void writeMinosData (Dataset<Row> data) {
        
        data.write().partitionBy("id_traitement")
        		    .format("orc")
        		    .mode("append")
        		    .save(ParseMinosConstant.MINOS_HDFS_PATH_ROOT + pathDiff + ParseMinosConstant.MINOS_HDFS_PATH_TABLE);
        String alterTableStmt = "ALTER TABLE " + ParseMinosConstant.HIVE_WRK_LAYER+"." + ParseMinosConstant.TARGET_MINOS_TABLE 
                			 + " ADD IF NOT EXISTS PARTITION (id_traitement='"+ idtrt +"') location '"+ParseMinosConstant.MINOS_HDFS_PATH_ROOT + pathDiff + ParseMinosConstant.MINOS_HDFS_PATH_TABLE+"/id_traitement="+ idtrt +"'" ;
        System.out.println("INFO: " +  alterTableStmt);
        sqlContext.sql(alterTableStmt);
    }

}