package org.spark.evolmpm.parse.minos.data;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.spark.evolmpm.parse.minos.constant.ParseMinosConstant;

import fr.bdf.bastid.util.bean.LineAcqFile;

public class ReadData implements Serializable {

	private static final long serialVersionUID = 1643057746251108370L;

	private SparkSession sqlContext;
	private List<LineAcqFile> listIdAcq;

	/**
	 * @param sqlContext
	 * @param idAcqStart
	 */
	public ReadData(SparkSession sqlContext, List<LineAcqFile> listIdAcq) {
		super();
		this.sqlContext = sqlContext;
		this.listIdAcq = listIdAcq;
	}

    /**
     * Reads th70 table data, creates an unique id for each transaction, prepares the date_pec_amont column
     * @return Dataset<Row>
     */
    public Dataset<Row> getMinosData() {
    	String query = "select  concat(row_number() over (order by date_insert),'" + listIdAcq.get(0).getIdAcq() + "')  as id_operation, "
                + "cast(concat(concat(concat(concat(concat(concat(date_format(ddpre, 'YYYY-MM-dd'),' '),substr(hepre,0,2)),':'),substr(hepre,3,2)),':'),substr(hepre,5,2)) as timestamp) as date_pec_amont, "
                + "rfopi,"
                + "tyopec,"
                + "seopec,"
                + "ddops2,"
                + "mtopa2,"
                + "coops,"
                + "cofamo,"
                + "nuprm,"
                + "coclc,"
                + "idees4,"
                + "idiba1,"
                + "iddss2,"
                + "idiba2,"
                + "e8rme,"
                + "ddpre,"
                + "hepre,"
                + "nurms1,"
                + "ddpre1,"
                + "hepre1,"
                + "e8trav,"
                + "idefe,"
                + "xtimts,"
                + "cocll,"
                + "rfopsc,"
                + "codoar,"
                + "inopr,"
                + "nopart,"
                + "xpart1,"
                + "xpartt,"
                + "rfopso,"
                + "rfeeso,"
                + "idopso,"
                + "dtjco,"
                + "debemb,"
                + "date_insert,"
                + "date_ope"
             // + "cast(concat(concat(concat(concat(substr(date_insert,7,4),'-'), substr(date_insert,4,2)),'-'), substr(date_insert,0,2)) as date) date_insert"
             // + "cast(concat(concat(concat(concat(substr(date_insert,0,4),'-'), substr(date_insert,6,2)),'-'), substr(date_insert,9,2)) as date) date_insert"
          + " from " + ParseMinosConstant.HIVE_RAW_LAYER+"."+ParseMinosConstant.MINOS_TABLE 
                    + this.getWhereClause(listIdAcq) + " and tyopec = 'M' ";
		System.out.println("INFO:" + "[" + new SimpleDateFormat("HH:mm:ss" ).format(new Date()) + "] - " 
				+ "getMinosData query : " + query );

    	
        return sqlContext.sql(query);
    }
    
	/**
	 * Read ref_type_operation table data
	 * 
	 * @return
	 */
	public Dataset<Row> getRefOpeTypeData() {

		StringBuilder sqlBuilder = new StringBuilder(
				"select id_type_ope, code_ope, sscode_ope, date_deb_val, date_fin_val, ind_connexe");
		sqlBuilder.append(" from ");
		sqlBuilder.append(getCompleteTableName(
				ParseMinosConstant.HIVE_RAW_LAYER,
				ParseMinosConstant.REF_OPE_TABLE));
		sqlBuilder
				.append(" where id_traitement in ( select first_value(id_traitement)");
		sqlBuilder
				.append(" over (partition by id_traitement order by id_traitement desc)");
		sqlBuilder.append(" from ");
		sqlBuilder.append(getCompleteTableName(
				ParseMinosConstant.HIVE_RAW_LAYER,
				ParseMinosConstant.REF_OPE_TABLE));
		sqlBuilder.append(" limit 1 )");

		String request = sqlBuilder.toString();
		System.out.println("Load ref_type_operation request : " + request);

		return sqlContext.sql(request);
	}

	/**
	 * return full table name
	 * 
	 * @param schema
	 * @param table
	 * @return
	 */
	private Object getCompleteTableName(String schema, String table) {
		return schema + "." + table;
	}

	/**
	 * Method that constructs the where part of the request.
	 * 
	 * @param listIdAcq
	 *            the list of id_acquisition / date_ope
	 * @return the where part of the request
	 */
	private String getWhereClause(List<LineAcqFile> listIdAcq) {
		StringBuilder sb = new StringBuilder(" WHERE (");
		for (LineAcqFile line : listIdAcq) {
			//sb.append(" (dtjco = '").append(line.getJourFonc())
			sb.append(" (date_ope = '").append(line.getJourFonc())
					.append("' AND id_traitement = '").append(line.getIdAcq())
					.append("') OR");
		}

		System.out.println("INFO:" + "[" + new SimpleDateFormat("HH:mm:ss" ).format(new Date()) + "] - " 
				+ "getWhereClause : " + sb.substring(0, sb.length() - 3));

		return sb.substring(0, sb.length() - 3)+")";
	}

}
