package org.spark.evolmpm.parse.minos.data;

import static org.apache.spark.sql.functions.callUDF;
import static org.apache.spark.sql.functions.coalesce;
import static org.apache.spark.sql.functions.col;

import static org.apache.spark.sql.functions.trim;
import static org.apache.spark.sql.functions.concat;
import static org.apache.spark.sql.functions.datediff;
import static org.apache.spark.sql.functions.lit;
import static org.apache.spark.sql.functions.when;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.api.java.UDF2;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Decimal;

public class DataProcessor implements Serializable{

	private static final long serialVersionUID = 8399760490896647896L;

	private SparkSession sqlContext;
	private String idtrt;

	/**
	 * @param sqlContext
	 * @param idtrt
	 */
	public DataProcessor(SparkSession sqlContext, String idtrt) {
		super();
		this.sqlContext = sqlContext;
		this.idtrt = idtrt;
	}

    
    /**
     * Apply transformations to the source data
     * Sort columns before insertion in target table 
     * @param data
     * @return Dataset<Row>
     */
    public Dataset<Row> prepareMinosData (Dataset<Row> data) {
        
        /**
         * Format an 6 character string YYMMDD to an java.sql.Date 
         * @param input
         * @return java.sql.Date
         */
        UDF1 <String, java.sql.Date > fromString6toDate = new UDF1<String, java.sql.Date >() {
            /**
             * 
             */
            private static final long serialVersionUID = 3853112536644776225L;

            public java.sql.Date call(final String input) throws Exception {
                if (input != null && input.trim() != null && input.length() == 6) {
                    
                    SimpleDateFormat format = new SimpleDateFormat("yyMMdd");
                    format.setLenient(false) ;
                    try {
                        java.util.Date date = format.parse(input);
                        return new java.sql.Date(date.getTime());  
                    } catch (ParseException e) {
                       e.printStackTrace();
                       return null;
                    }
                }
                else {
                    return null;
                }
            }
        };
        
        
        /**
         * Format an 8 character string YYYYMMDD to an java.sql.Date 
         * @param input
         * @return java.sql.Date
         */
        UDF1 <String, java.sql.Date > fromString8toDate = new UDF1<String, java.sql.Date >() {
            /**
             * 
             */
            private static final long serialVersionUID = 3853112536644776225L;

            public java.sql.Date call(final String input) throws Exception {
                if (input != null && input.trim() != null && input.length() == 8) {
                    
                    SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
                    format.setLenient(false) ;
                    try {
                        java.util.Date date = format.parse(input);
                        return new java.sql.Date(date.getTime());  
                    } catch (ParseException e) {
                       e.printStackTrace();
                       return null;
                    }
                }
                else {
                    return null;
                }
            }
        };

        /**
         * Extract from the currency code (ex EUR2) the last character
         * Use it to adjust the floating point of the commission by dividing the commission by 10^2 (for EUR2)
         * @param input
         * @return Double
         */
        UDF2 <String,String, Decimal> fromStingToDouble = new UDF2 <String,String, Decimal >() {
        	 
            private static final long serialVersionUID = 3853112536644776225L;

            public Decimal call(final String comm, final String dev ) throws Exception {
                if (comm != null && comm.trim() != null 
                		&& dev != null && dev.trim() != null &&  dev.length() == 4) {
                    String tmpfactor = dev.substring(3);
                    try {
                    	//Double factor =  Math.pow(10,Integer.parseInt(tmpfactor));
                    	Double commTmp = Double.parseDouble(comm);
                    	//Double res = new Double(commTmp/factor);
                    	Decimal retdec = new Decimal();
                    	retdec.set(commTmp.longValue(), 18, Integer.parseInt(tmpfactor));
                    	return retdec;
                    	 
                    } catch (Exception e) {
                       e.printStackTrace();
                       return null;
                    }
                }
                else {
                    return null;
                }
            }
        };
        
        /**
         * Use parseInt to trim the leading 0s from a string (ex. 0000002)
         * @param input
         * @return Integer
         */
        UDF1 <String, Integer > fromStringtoInteger = new UDF1<String, Integer >() {
            /**
             * 
             */
            private static final long serialVersionUID = 3853112536644776225L;

            public Integer call(final String input) throws Exception {
                if (input != null && input.trim() != null) {
                                       
                    try {
                    	return Integer.parseInt(input);  
                    } catch (Exception e) {
                       e.printStackTrace();
                       return null;
                    }
                }
                else {
                    return null;
                }
            }
        };
        
        //register user defined functions to the hive context
        sqlContext.udf().register("fromString6toDate", fromString6toDate, DataTypes.DateType);
        sqlContext.udf().register("fromString8toDate", fromString8toDate, DataTypes.DateType);
        sqlContext.udf().register("fromStingToDouble", fromStingToDouble, DataTypes.createDecimalType(18,4));
        sqlContext.udf().register("fromStringtoInteger", fromStringtoInteger, DataTypes.IntegerType);

        //transform data
        Dataset<Row> minosTablePrepDF = data.select(col("id_operation"),
                col("rfopi").as("rio"),
                col("rfopsc").as("ref_operation"),
                col("coops").as("code_operation"),
                col("cofamo").as("code_famille_operation"),
                col("tyopec").as("type_operation"),
                col("seopec").as("sens_echange"),
                col("idefe").as("systeme_echange"),
                col("e8rme").as("date_echange"),
                col("ddops2").as("date_reglement"),
                col("e8trav").as("date_traitement_aval_recu"),
                datediff(col("e8rme"), col("ddops2")).as("delai_reglement_ope"),
                col("date_pec_amont"),
                col("nuprm").as("num_remise"),
                col("nurms1").as("num_remise_tech"),
                col("mtopa2").as("mnt_compense_sit"),
                concat(col("ddpre1").cast(DataTypes.StringType).substr(1,10),lit(" "),col("hepre1").substr(1, 2),lit(":"),col("hepre1").substr(3, 2),lit(":"),col("hepre1").substr(5, 2)).cast(DataTypes.TimestampType).as("date_presentation_remise"),
                col("coclc").as("code_client_conventionne"),
                col("idees4").as("bic_do"),
                col("idiba1").as("iban_do"),
                col("idiba1").substr(1, 2).as("code_pays_do"),
                col("idiba1").substr(3, 2).as("cle_iban_do"),
                col("idiba1").substr(5, 5).as("code_banque_do"),
                col("idiba1").substr(10, 5).as("code_guichet_do"),
                col("idiba1").substr(15, 11).as("num_cpte_do"),
                col("idiba1").substr(26, 2).as("cle_rib_do"),
                col("iddss2").as("bic_dest"),
                col("idiba2").as("iban_dest"),
                col("idiba2").substr(1, 2).as("code_pays_dest"),
                col("idiba2").substr(3, 2).as("cle_iban_dest"),
                col("idiba2").substr(5, 5).as("code_banque_dest"),
                col("idiba2").substr(10, 5).as("code_guichet_dest"),
                col("idiba2").substr(15, 11).as("num_cpte_dest"),
                col("idiba2").substr(26, 2).as("cle_rib_dest"),
                col("cocll").as("etblt_concerne"),
                col("nopart").as("num_partition"),
                col("codoar").as("code_flux_arch"),
                col("inopr").as("ind_rejet"),
                col("rfopso").as("ref_ope_origine"),
                col("rfeeso").as("end_to_end_ope_ori"),
                col("idopso").as("id_instruction_ope_ori"),
                concat(coalesce(col("xpart1"),lit("")),coalesce(col("xpartt"),lit(""))).as("zone_operation"),
                col("dtjco").as("date_comptable_evolmpm"),
                col("debemb").as("flag_debrayage_embargo"),
                col("xtimts").as("xtimts"),
                col("xpart1"),
                col("xpartt"),
                callUDF("fromStringtoInteger", col("xpart1").substr(3,4)).as("s2_long_ope"),
                trim(col("xpart1").substr(7,2)).as("s3_code_article"),
                trim(col("xpart1").substr(9,3)).as("s4_code_ope"),
                callUDF("fromStringtoInteger", col("xpart1").substr(12,1)).as("s5_type_id_do"),
                col("xpart1").substr(13,7).as("s6_id_etblt_do"),
                callUDF("fromStringtoInteger", col("xpart1").substr(20,1)).as("s7_type_id_dest"),
                trim(col("xpart1").substr(21,7)).as("s8_id_etblt_dest"),
                trim(col("xpart1").substr(28,5)).as("s9_critere_rout_secondaire"),
                trim(col("xpart1").substr(33,4)).as("s10_code_devise"),
                callUDF("fromStingToDouble",col("xpart1").substr(37,16),col("xpart1").substr(33,4)).as("s11_mnt_compense"),
                callUDF("fromString6toDate",col("xpart1").substr(53,6)).as("s12_date_reglement_demande"),
                callUDF("fromStringtoInteger", col("xpart1").substr(59,1)).as("s13_ind_modif_ddr"),
                callUDF("fromStringtoInteger", col("xpart1").substr(60,1)).as("s14_code_commission"),
                callUDF("fromStringtoInteger", col("xpart1").substr(61,6)).as("s15_commission_interbancaire"),
                callUDF("fromStringtoInteger", col("xpart1").substr(67,1)).as("s16_zone_reservee_declaration"),
                callUDF("fromStringtoInteger", col("xpart1").substr(68,2)).as("s17_code_anomalie"),
                trim(col("xpart1").substr(70,11)).as("s18_zone_reservee"),
                col("date_insert"),col("date_ope").as("date_ope"))
        		.withColumn("b1_sous_code_ope",when(col("xpartt").substr(1,4).notEqual(lit("    ")),  trim(col("xpartt").substr(1,4))).otherwise(lit(null)))
                .withColumn("b_ic_sous_code_ope",when(col("code_operation").equalTo(lit("160")), trim(col("xpartt").substr(1,4))).otherwise(lit(null)))
                .withColumn("b_ic_ref_ope",when(col("code_operation").equalTo(lit("160")), trim(col("xpartt").substr(5,24))).otherwise(lit(null)))
                .withColumn("b_ic_zone_banquier_remettant",when(col("code_operation").equalTo(lit("160")), trim(col("xpartt").substr(29,50))).otherwise(lit(null)))
                .withColumn("b_ic_num_cheque_cmc7_4",when(col("code_operation").equalTo(lit("160")), trim(col("xpartt").substr(79,7))).otherwise(lit(null)))
                .withColumn("b_ic_zone_interbancaire_cmc7_3",when(col("code_operation").equalTo(lit("160")), trim(col("xpartt").substr(86,12))).otherwise(lit(null)))
                .withColumn("b_ic_zone_interieure_cmc7_2",when(col("code_operation").equalTo(lit("160")), trim(col("xpartt").substr(98,12))).otherwise(lit(null)))
                .withColumn("b_ic_ind_balance_paiement",when(col("code_operation").equalTo(lit("160")), trim(col("xpartt").substr(110,1))).otherwise(lit(null)))
                .withColumn("b_ic_zone_usage_etblmt",when(col("code_operation").equalTo(lit("160")), trim(col("xpartt").substr(111,30))).otherwise(lit(null)))
                .withColumn("b_ic_indice_circulation",when(col("code_operation").equalTo(lit("160")), trim(col("xpartt").substr(141,1))).otherwise(lit(null)))
                .withColumn("b_ic_ind_cepc_concerne",when(col("code_operation").equalTo(lit("160")), trim(col("xpartt").substr(142,1))).otherwise(lit(null)))
                .withColumn("b_ic_zone_reservee_ic",when(col("code_operation").equalTo(lit("160")), trim(col("xpartt").substr(143,34))).otherwise(lit(null)))
                .withColumn("b_ric_code_motif",when(col("code_operation").equalTo(lit("560")), trim(col("xpartt").substr(1,4))).otherwise(lit(null)))
                .withColumn("b_ric_ref_ope",when(col("code_operation").equalTo(lit("560")), trim(col("xpartt").substr(5,24))).otherwise(lit(null)))
                .withColumn("b_ric_indice_delai",when(col("code_operation").equalTo(lit("560")), trim(col("xpartt").substr(29,1))).otherwise(lit(null)))
                .withColumn("b_ric_ind_restit_physque",when(col("code_operation").equalTo(lit("560")), trim(col("xpartt").substr(30,1))).otherwise(lit(null)))
                .withColumn("b_ric_indic_certif_non_pmt",when(col("code_operation").equalTo(lit("560")), trim(col("xpartt").substr(31,1))).otherwise(lit(null)))
                .withColumn("b_ric_nature_interdiction",when(col("code_operation").equalTo(lit("560")), trim(col("xpartt").substr(32,1))).otherwise(lit(null)))
                .withColumn("b_ric_date_interdiction",when(col("code_operation").equalTo(lit("560")), callUDF("fromString8toDate",col("xpartt").substr(33,8))).otherwise(lit(null)))
                .withColumn("b_ric_date_presentation",when(col("code_operation").equalTo(lit("560")), callUDF("fromString8toDate",col("xpartt").substr(41,8))).otherwise(lit(null)))
                .withColumn("b_ric_num_cheque",when(col("code_operation").equalTo(lit("560")), trim(col("xpartt").substr(49,7))).otherwise(lit(null)))
                .withColumn("b_ric_nom_tireur",when(col("code_operation").equalTo(lit("560")), trim(col("xpartt").substr(56,24))).otherwise(lit(null)))
                .withColumn("b_ric_lib_abre_domicil",when(col("code_operation").equalTo(lit("560")), trim(col("xpartt").substr(80,24))).otherwise(lit(null)))
                .withColumn("b_ric_num_cpte_tireur",when(col("code_operation").equalTo(lit("560")), trim(col("xpartt").substr(104,11))).otherwise(lit(null)))
                .withColumn("b_ric_coord_expediteur",when(col("code_operation").equalTo(lit("560")), trim(col("xpartt").substr(115,90))).otherwise(lit(null)))
                .withColumn("b_ric_zone_usage_etblmt",when(col("code_operation").equalTo(lit("560")), trim(col("xpartt").substr(205,30))).otherwise(lit(null)))
                .withColumn("b_ric_zone_reservee",when(col("code_operation").equalTo(lit("560")), trim(col("xpartt").substr(235,70))).otherwise(lit(null)))
                .withColumn("b_aic_code_motif",when(col("code_operation").equalTo(lit("420")), trim(col("xpartt").substr(1,4))).otherwise(lit(null)))
                .withColumn("b_aic_ref_ope",when(col("code_operation").equalTo(lit("420")), trim(col("xpartt").substr(5,24))).otherwise(lit(null)))
                .withColumn("b_aic_zone_usage_etabl",when(col("code_operation").equalTo(lit("420")), trim(col("xpartt").substr(29,30))).otherwise(lit(null)))
                .withColumn("b_aic_zone_reservee",when(col("code_operation").equalTo(lit("420")), trim(col("xpartt").substr(59,246))).otherwise(lit(null)))
                .withColumn("b_raic_code_motif",when(col("code_operation").equalTo(lit("820")), trim(col("xpartt").substr(1,4))).otherwise(lit(null)))
                .withColumn("b_raic_ref_ope",when(col("code_operation").equalTo(lit("820")), trim(col("xpartt").substr(5,24))).otherwise(lit(null)))
                .withColumn("b_raic_zone_usage_etabl",when(col("code_operation").equalTo(lit("820")), trim(col("xpartt").substr(29,30))).otherwise(lit(null)))
                .withColumn("b_raic_zone_reservee",when(col("code_operation").equalTo(lit("820")), trim(col("xpartt").substr(59,54))).otherwise(lit(null)))
                .withColumn("b_aric_code_motif",when(col("code_operation").equalTo(lit("421")), trim(col("xpartt").substr(1,4))).otherwise(lit(null)))
                .withColumn("b_aric_ref_ope",when(col("code_operation").equalTo(lit("421")), trim(col("xpartt").substr(5,24))).otherwise(lit(null)))
                
                .withColumn("b_aric_zone_usage_etblt",when(col("code_operation").equalTo(lit("421")), trim(col("xpartt").substr(29,30))).otherwise(lit(null)))
                .withColumn("b_aric_zone_reservee",when(col("code_operation").equalTo(lit("421")), trim(col("xpartt").substr(59,54))).otherwise(lit(null)))
                .withColumn("b_raric_code_motif",when(col("code_operation").equalTo(lit("821")), trim(col("xpartt").substr(1,4))).otherwise(lit(null)))
                .withColumn("b_raric_ref_ope",when(col("code_operation").equalTo(lit("821")), trim(col("xpartt").substr(5,24))).otherwise(lit(null)))
                .withColumn("b_raric_zone_usage_etblt",when(col("code_operation").equalTo(lit("821")), trim(col("xpartt").substr(29,30))).otherwise(lit(null)))
                .withColumn("b_raric_zone_reservee",when(col("code_operation").equalTo(lit("821")), trim(col("xpartt").substr(59,54))).otherwise(lit(null)))
                .withColumn("b_odr_nature_ope",when(col("code_operation").equalTo(lit("167")), trim(col("xpartt").substr(1,4))).otherwise(lit(null)))
                .withColumn("b_odr_ref_ope",when(col("code_operation").equalTo(lit("167")), trim(col("xpartt").substr(5,24))).otherwise(lit(null)))
                .withColumn("b_odr_motif",when(col("code_operation").equalTo(lit("167")), trim(col("xpartt").substr(29,4))).otherwise(lit(null)))
                .withColumn("b_odr_coord_expediteur",when(col("code_operation").equalTo(lit("167")), trim(col("xpartt").substr(33,90))).otherwise(lit(null)))
                .withColumn("b_odr_zone_usage_etblmt",when(col("code_operation").equalTo(lit("167")), trim(col("xpartt").substr(123,30))).otherwise(lit(null)))
                .withColumn("b_odr_zone_lib_contact",when(col("code_operation").equalTo(lit("167")), trim(col("xpartt").substr(153,120))).otherwise(lit(null)))
                .withColumn("b_odr_date_reglement",when(col("code_operation").equalTo(lit("167")), callUDF("fromString8toDate",col("xpartt").substr(273,8))).otherwise(lit(null)))
                .withColumn("b_odr_zone_reservee",when(col("code_operation").equalTo(lit("167")), trim(col("xpartt").substr(281,24))).otherwise(lit(null)))
                .withColumn("b_ocr_nature_ope",when(col("code_operation").equalTo(lit("168")), trim(col("xpartt").substr(1,4))).otherwise(lit(null)))
                .withColumn("b_ocr_ref_ope",when(col("code_operation").equalTo(lit("168")), trim(col("xpartt").substr(5,24))).otherwise(lit(null)))
                .withColumn("b_ocr_motif",when(col("code_operation").equalTo(lit("168")), trim(col("xpartt").substr(29,4))).otherwise(lit(null)))
                .withColumn("b_ocr_coord_expediteur",when(col("code_operation").equalTo(lit("168")), trim(col("xpartt").substr(33,90))).otherwise(lit(null)))
                .withColumn("b_ocr_zone_usage_etblmt",when(col("code_operation").equalTo(lit("168")), trim(col("xpartt").substr(123,30))).otherwise(lit(null)))
                .withColumn("b_ocr_zone_lib_contact",when(col("code_operation").equalTo(lit("168")), trim(col("xpartt").substr(153,120))).otherwise(lit(null)))
                .withColumn("b_ocr_date_reglement",when(col("code_operation").equalTo(lit("168")), callUDF("fromString8toDate",col("xpartt").substr(273,8))).otherwise(lit(null)))
                .withColumn("b_ocr_zone_reservee",when(col("code_operation").equalTo(lit("168")), trim(col("xpartt").substr(281,24))).otherwise(lit(null)))
                .withColumn("b_dtc_nature_demande",when(col("code_operation").equalTo(lit("166")),trim( col("xpartt").substr(1,4))).otherwise(lit(null)))
                .withColumn("b_dtc_ref_ope",when(col("code_operation").equalTo(lit("166")), trim(col("xpartt").substr(5,24))).otherwise(lit(null)))
                .withColumn("b_dtc_coord_exp",when(col("code_operation").equalTo(lit("166")), trim(col("xpartt").substr(29,90))).otherwise(lit(null)))
                .withColumn("b_dtc_zone_etablt",when(col("code_operation").equalTo(lit("166")), trim(col("xpartt").substr(119,30))).otherwise(lit(null)))
                .withColumn("b_dtc_ident_emetteur",when(col("code_operation").equalTo(lit("166")), trim(col("xpartt").substr(149,30))).otherwise(lit(null)))
                .withColumn("b_dtc_zone_reservee",when(col("code_operation").equalTo(lit("166")), trim(col("xpartt").substr(179,126))).otherwise(lit(null)))
                .withColumn("b_onc_nature_ope",when(col("code_operation").equalTo(lit("169")), trim(col("xpartt").substr(1,4))).otherwise(lit(null)))
                .withColumn("b_onc_ref_ope",when(col("code_operation").equalTo(lit("169")), trim(col("xpartt").substr(5,24))).otherwise(lit(null)))
                .withColumn("b_onc_coord_exp",when(col("code_operation").equalTo(lit("169")), trim(col("xpartt").substr(29,90))).otherwise(lit(null)))
                .withColumn("b_onc_zone_etblt",when(col("code_operation").equalTo(lit("169")), trim(col("xpartt").substr(119,30))).otherwise(lit(null)))
                .withColumn("b_onc_zone_libelle",when(col("code_operation").equalTo(lit("169")), trim(col("xpartt").substr(149,120))).otherwise(lit(null)))
                .withColumn("b_onc_cat_onc",when(col("code_operation").equalTo(lit("169")), trim(col("xpartt").substr(269,2))).otherwise(lit(null)))
                .withColumn("b_onc_zone_reservee",when(col("code_operation").equalTo(lit("169")), trim(col("xpartt").substr(271,34))).otherwise(lit(null)))
                .withColumn("b_lcr_sous_code_ope",when(col("code_operation").equalTo(lit("060")), trim(col("xpartt").substr(1,4))).otherwise(lit(null)))
                .withColumn("b_lcr_ref_ope",when(col("code_operation").equalTo(lit("060")),trim( col("xpartt").substr(5,16))).otherwise(lit(null)))
                .withColumn("b_lcr_presentateur",when(col("code_operation").equalTo(lit("060")), trim(col("xpartt").substr(21,10))).otherwise(lit(null)))
                .withColumn("b_lcr_coord_client_cedant",when(col("code_operation").equalTo(lit("060")), trim(col("xpartt").substr(31,16))).otherwise(lit(null)))
                .withColumn("b_lcr_coord_client_tire",when(col("code_operation").equalTo(lit("060")), trim(col("xpartt").substr(47,14))).otherwise(lit(null)))
                .withColumn("b_lcr_nom_tireur",when(col("code_operation").equalTo(lit("060")), trim(col("xpartt").substr(61,24))).otherwise(lit(null)))
           
                .withColumn("b_lcr_zone_reservee_1",when(col("code_operation").equalTo(lit("060")), trim(col("xpartt").substr(103,10))).otherwise(lit(null)))
                .withColumn("b_lcr_nom_tire",when(col("code_operation").equalTo(lit("060")), trim(col("xpartt").substr(113,24))).otherwise(lit(null)))
                .withColumn("b_lcr_acceptation",when(col("code_operation").equalTo(lit("060")), trim(col("xpartt").substr(137,1))).otherwise(lit(null)))
                .withColumn("b_lcr_code_entree",when(col("code_operation").equalTo(lit("060")), trim(col("xpartt").substr(138,1))).otherwise(lit(null)))
                .withColumn("b_lcr_ref_tireur",when(col("code_operation").equalTo(lit("060")), trim(col("xpartt").substr(139,10))).otherwise(lit(null)))
                .withColumn("b_lcr_ref_tire",when(col("code_operation").equalTo(lit("060")), trim(col("xpartt").substr(149,10))).otherwise(lit(null)))
                .withColumn("b_lcr_num_siren_tireur",when(col("code_operation").equalTo(lit("060")), trim(col("xpartt").substr(159,15))).otherwise(lit(null)))
                .withColumn("b_lcr_zone_reservee_2",when(col("code_operation").equalTo(lit("060")), trim(col("xpartt").substr(174,3))).otherwise(lit(null)))
                .withColumn("b_lcr_lib_domicil",when(col("code_operation").equalTo(lit("060")), trim(col("xpartt").substr(177,24))).otherwise(lit(null)))
                .withColumn("b_lcr_zone_reservee_3",when(col("code_operation").equalTo(lit("060")), trim(col("xpartt").substr(201,13))).otherwise(lit(null)))
                .withColumn("b_lcr_ind_balance_paiments",when(col("code_operation").equalTo(lit("060")), trim(col("xpartt").substr(214,1))).otherwise(lit(null)))
                .withColumn("b_lcr_zone_reservee_4",when(col("code_operation").equalTo(lit("060")), trim(col("xpartt").substr(215,26))).otherwise(lit(null)))
                .withColumn("b_rjt_code_motif",when(col("code_operation").equalTo(lit("460")), trim(col("xpartt").substr(1,4))).otherwise(lit(null)))
                .withColumn("b_rjt_ref_ope",when(col("code_operation").equalTo(lit("460")), trim(col("xpartt").substr(5,16))).otherwise(lit(null)))
                .withColumn("b_rjt_ref_presentateur",when(col("code_operation").equalTo(lit("460")), trim(col("xpartt").substr(21,10))).otherwise(lit(null)))
                .withColumn("b_rjt_num_siren_dest",when(col("code_operation").equalTo(lit("460")), trim(col("xpartt").substr(31,9))).otherwise(lit(null)))
                .withColumn("b_rjt_zone_reservee",when(col("code_operation").equalTo(lit("460")), trim(col("xpartt").substr(40,9))).otherwise(lit(null)))
                .withColumn("b_vrf_code_motif",when(col("code_operation").equalTo(lit("069")), trim(col("xpartt").substr(1,4))).otherwise(lit(null)))
                .withColumn("b_vrf_ref_ope",when(col("code_operation").equalTo(lit("069")), trim(col("xpartt").substr(5,16))).otherwise(lit(null)))
                .withColumn("b_vrf_ref_presentateur",when(col("code_operation").equalTo(lit("069")), trim(col("xpartt").substr(21,10))).otherwise(lit(null)))
                .withColumn("b_vrf_coord_client_cedant",when(col("code_operation").equalTo(lit("069")), trim(col("xpartt").substr(31,16))).otherwise(lit(null)))
                .withColumn("b_vrf_coord_client_tire",when(col("code_operation").equalTo(lit("069")), trim(col("xpartt").substr(47,14))).otherwise(lit(null)))
                .withColumn("b_vrf_nom_tireur",when(col("code_operation").equalTo(lit("069")), trim(col("xpartt").substr(61,24))).otherwise(lit(null)))
           
                .withColumn("b_vrf_zone_reservee1",when(col("code_operation").equalTo(lit("069")), trim(col("xpartt").substr(103,10))).otherwise(lit(null)))
                .withColumn("b_vrf_nom_tire",when(col("code_operation").equalTo(lit("069")), trim(col("xpartt").substr(113,24))).otherwise(lit(null)))
                .withColumn("b_vrf_acceptation",when(col("code_operation").equalTo(lit("069")), trim(col("xpartt").substr(137,1))).otherwise(lit(null)))
                .withColumn("b_vrf_code_entree",when(col("code_operation").equalTo(lit("069")), trim(col("xpartt").substr(138,1))).otherwise(lit(null)))
                .withColumn("b_vrf_ref_tireur",when(col("code_operation").equalTo(lit("069")), trim(col("xpartt").substr(139,10))).otherwise(lit(null)))
                .withColumn("b_vrf_ref_tire",when(col("code_operation").equalTo(lit("069")), trim(col("xpartt").substr(149,10))).otherwise(lit(null)))
                .withColumn("b_vrf_num_siren_tireur",when(col("code_operation").equalTo(lit("069")), trim(col("xpartt").substr(159,15))).otherwise(lit(null)))
                .withColumn("b_vrf_zone_reservee2",when(col("code_operation").equalTo(lit("069")), trim(col("xpartt").substr(174,3))).otherwise(lit(null)))
                .withColumn("b_vrf_lib_abre_domicil",when(col("code_operation").equalTo(lit("069")), trim(col("xpartt").substr(177,24))).otherwise(lit(null)))
                .withColumn("b_vrf_zone_reservee3",when(col("code_operation").equalTo(lit("069")), trim(col("xpartt").substr(201,13))).otherwise(lit(null)))
                .withColumn("b_vrf_ind_balance_paiement",when(col("code_operation").equalTo(lit("069")), trim(col("xpartt").substr(214,1))).otherwise(lit(null)))
                .withColumn("b_vrf_zone_reservee4",when(col("code_operation").equalTo(lit("069")), trim(col("xpartt").substr(215,26))).otherwise(lit(null)))
                .withColumn("b_arlcr_code_motif",when(col("code_operation").equalTo(lit("416")), trim(col("xpartt").substr(1,4))).otherwise(lit(null)))
                .withColumn("b_arlcr_ref_ope",when(col("code_operation").equalTo(lit("416")), trim(col("xpartt").substr(5,16))).otherwise(lit(null)))
                .withColumn("b_arlcr_ref_presentateur",when(col("code_operation").equalTo(lit("416")), trim(col("xpartt").substr(21,10))).otherwise(lit(null)))
                .withColumn("b_arlcr_zone_reservee",when(col("code_operation").equalTo(lit("416")), trim(col("xpartt").substr(31,18))).otherwise(lit(null)))
                .withColumn("b_corrige_code_motif",when(col("code_operation").equalTo(lit("469")), trim(col("xpartt").substr(1,4))).otherwise(lit(null)))
                .withColumn("b_corrige_ref_ope",when(col("code_operation").equalTo(lit("469")), trim(col("xpartt").substr(5,16))).otherwise(lit(null)))
                .withColumn("b_corrige_ref_presentateur",when(col("code_operation").equalTo(lit("469")), trim(col("xpartt").substr(21,10))).otherwise(lit(null)))
                .withColumn("b_corrige_zone_reservee_1",when(col("code_operation").equalTo(lit("469")), trim(col("xpartt").substr(31,16))).otherwise(lit(null)))
                .withColumn("b_corrige_coord_client_dest",when(col("code_operation").equalTo(lit("469")), trim(col("xpartt").substr(47,14))).otherwise(lit(null)))
                .withColumn("b_corrige_id_client_dest",when(col("code_operation").equalTo(lit("469")), trim(col("xpartt").substr(61,7))).otherwise(lit(null)))
                .withColumn("b_corrige_crit_routage_second",when(col("code_operation").equalTo(lit("469")), trim(col("xpartt").substr(68,5))).otherwise(lit(null)))
                .withColumn("b_corrige_zone_reservee_2",when(col("code_operation").equalTo(lit("469")), trim(col("xpartt").substr(73,64))).otherwise(lit(null)))
                .withColumn("b_corrige_lib_abre_domicil",when(col("code_operation").equalTo(lit("469")), trim(col("xpartt").substr(137,24))).otherwise(lit(null)))
                .withColumn("b_corrige_zone_reservee_3",when(col("code_operation").equalTo(lit("469")), trim(col("xpartt").substr(161,16))).otherwise(lit(null)))
                .withColumn("b_drec_code_motif",when(col("code_operation").equalTo(lit("062")), trim(col("xpartt").substr(1,4))).otherwise(lit(null)))
                .withColumn("b_drec_ref_ope",when(col("code_operation").equalTo(lit("062")), trim(col("xpartt").substr(5,16))).otherwise(lit(null)))
                .withColumn("b_drec_ref_presentateur",when(col("code_operation").equalTo(lit("062")), trim(col("xpartt").substr(21,10))).otherwise(lit(null)))
                .withColumn("b_drec_zone_reservee",when(col("code_operation").equalTo(lit("062")), trim(col("xpartt").substr(31,18))).otherwise(lit(null)))
                .withColumn("b_dlci_zone_reservee_1",when(col("code_operation").equalTo(lit("065")), trim(col("xpartt").substr(1,4))).otherwise(lit(null)))
                .withColumn("b_dlci_ref_ope",when(col("code_operation").equalTo(lit("065")), trim(col("xpartt").substr(5,16))).otherwise(lit(null)))
                .withColumn("b_dlci_ref_presentateur",when(col("code_operation").equalTo(lit("065")), trim(col("xpartt").substr(21,10))).otherwise(lit(null)))
                .withColumn("b_dlci_zone_reservee_2",when(col("code_operation").equalTo(lit("065")), trim(col("xpartt").substr(31,18))).otherwise(lit(null)))
				     .withColumn("b_lcr_date_echeance",when(col("code_operation").equalTo(lit("060")), callUDF("fromString6toDate",col("xpartt").substr(85,6))).otherwise(lit(null)))
                .withColumn("b_lcr_date_creation",when(col("code_operation").equalTo(lit("060")), callUDF("fromString6toDate",col("xpartt").substr(91,6))).otherwise(lit(null)))
                .withColumn("b_lcr_date_entree_ptf",when(col("code_operation").equalTo(lit("060")), callUDF("fromString6toDate",col("xpartt").substr(97,6))).otherwise(lit(null)))
				     .withColumn("b_vrf_date_echeance_lcr",when(col("code_operation").equalTo(lit("069")), callUDF("fromString6toDate",col("xpartt").substr(85,6))).otherwise(lit(null)))
                .withColumn("b_vrf_date_creation",when(col("code_operation").equalTo(lit("069")), callUDF("fromString6toDate",col("xpartt").substr(91,6))).otherwise(lit(null)))
                .withColumn("b_vrf_date_entree_ptf",when(col("code_operation").equalTo(lit("069")), callUDF("fromStringtoInteger", col("xpartt").substr(97,6))).otherwise(lit(null)))
       		.withColumn("b2_ref_ope",
       				when(col("s4_code_ope").equalTo(lit("160")), trim(col("xpartt").substr(5,24)))
       				.when(col("s4_code_ope").equalTo(lit("560")), trim(col("xpartt").substr(5,24)))
       				.when(col("s4_code_ope").equalTo(lit("420")), trim(col("xpartt").substr(5,24)))
       				.when(col("s4_code_ope").equalTo(lit("820")), trim(col("xpartt").substr(5,24)))
       				.when(col("s4_code_ope").equalTo(lit("421")), trim(col("xpartt").substr(5,24)))
       				.when(col("s4_code_ope").equalTo(lit("821")), trim(col("xpartt").substr(5,24)))
       				.when(col("s4_code_ope").equalTo(lit("167")), trim(col("xpartt").substr(5,24)))
       				.when(col("s4_code_ope").equalTo(lit("168")), trim(col("xpartt").substr(5,24)))
       				.when(col("s4_code_ope").equalTo(lit("166")), trim(col("xpartt").substr(5,24)))
       				.when(col("s4_code_ope").equalTo(lit("169")), trim(col("xpartt").substr(5,24)))
       				.when(col("s4_code_ope").equalTo(lit("060")), trim(col("xpartt").substr(5,16)))
       				.when(col("s4_code_ope").equalTo(lit("460")), trim(col("xpartt").substr(5,16)))
       				.when(col("s4_code_ope").equalTo(lit("069")), trim(col("xpartt").substr(5,16)))
       				.when(col("s4_code_ope").equalTo(lit("416")), trim(col("xpartt").substr(5,16)))
       				.when(col("s4_code_ope").equalTo(lit("469")), trim(col("xpartt").substr(5,16)))
       				.when(col("s4_code_ope").equalTo(lit("062")), trim(col("xpartt").substr(5,16)))
       				.when(col("s4_code_ope").equalTo(lit("065")), trim(col("xpartt").substr(5,16))).otherwise(lit(null)))
       		.withColumn("b3_ref_presentateur",
       				 when(col("s4_code_ope").equalTo(lit("060")), trim(col("xpartt").substr(21,10)))
       				.when(col("s4_code_ope").equalTo(lit("460")), trim(col("xpartt").substr(21,10)))
       				.when(col("s4_code_ope").equalTo(lit("069")), trim(col("xpartt").substr(21,10)))
       				.when(col("s4_code_ope").equalTo(lit("416")), trim(col("xpartt").substr(21,10)))
       				.when(col("s4_code_ope").equalTo(lit("469")), trim(col("xpartt").substr(21,10)))
       				.when(col("s4_code_ope").equalTo(lit("062")), trim(col("xpartt").substr(21,10)))
       				.when(col("s4_code_ope").equalTo(lit("065")), trim(col("xpartt").substr(21,10))).otherwise(lit(null)))
                .withColumn("id_client",lit(null).cast(DataTypes.IntegerType))
                .withColumn("code_grp_remettant",lit(""))
                .withColumn("lib_grp_remettant",lit(""))
                .withColumn("id_compte_do",lit(null).cast(DataTypes.IntegerType))
                .withColumn("id_compte_dest",lit(null).cast(DataTypes.IntegerType))
                .withColumn("id_traitement",lit(idtrt));
        
        return minosTablePrepDF;
    }
    
    public Dataset<Row> join(Dataset<Row> minosTablePrepDF, Dataset<Row> refTableDF){
		Dataset<Row> minosTableFinalDF = minosTablePrepDF.join(
				refTableDF,
				minosTablePrepDF
						.col("code_operation")
						.equalTo(refTableDF.col("code_ope"))
						.and(minosTablePrepDF.col("date_reglement").between(
								refTableDF.col("date_deb_val"),
								refTableDF.col("date_fin_val")))
						.and((minosTablePrepDF.col("b1_sous_code_ope")
								.equalTo(refTableDF.col("sscode_ope")))
								.or(((minosTablePrepDF.col("b1_sous_code_ope")
										.isNull()).and(refTableDF.col(
										"sscode_ope").equalTo("0000"))))),
				"left").persist();
    	
    	//return in the same order as the target tables columns
        return minosTableFinalDF.select(col("id_operation"),
                col("rio"),
                col("ref_operation"),
                col("code_operation"),
                col("id_type_ope").as("id_type_operation"),
                col("code_famille_operation"),
                col("type_operation"),
                col("sens_echange"),
                col("systeme_echange"),
                col("date_echange"),
                col("date_reglement"),
                col("date_traitement_aval_recu"),
                col("delai_reglement_ope"),
                col("date_pec_amont"),
                col("num_remise"),
                col("num_remise_tech"),
                col("mnt_compense_sit"),
                col("date_presentation_remise"),
                col("code_client_conventionne"),
                col("id_client"),
                col("code_grp_remettant"),
                col("lib_grp_remettant"),
                col("id_compte_do"),
                col("bic_do"),
                col("iban_do"),
                col("code_pays_do"),
                col("cle_iban_do"),
                col("code_banque_do"),
                col("code_guichet_do"),
                col("num_cpte_do"),
                col("cle_rib_do"),
                col("id_compte_dest"),
                col("bic_dest"),
                col("iban_dest"),
                col("code_pays_dest"),
                col("cle_iban_dest"),
                col("code_banque_dest"),
                col("code_guichet_dest"),
                col("num_cpte_dest"),
                col("cle_rib_dest"),
                col("etblt_concerne"),
                col("num_partition"),
                col("code_flux_arch"),
                col("ind_rejet"),
                col("ind_connexe"),
                col("ref_ope_origine"),
                col("end_to_end_ope_ori"),
                col("id_instruction_ope_ori"),
                col("zone_operation"),
                col("date_comptable_evolmpm"),
                col("flag_debrayage_embargo"),
                col("xtimts"),
                col("s2_long_ope"),
                col("s3_code_article"),
                col("s4_code_ope"),
                col("s5_type_id_do"),
                col("s6_id_etblt_do"),
                col("s7_type_id_dest"),
                col("s8_id_etblt_dest"),
                col("s9_critere_rout_secondaire"),
                col("s10_code_devise"),
                col("s11_mnt_compense"),
                col("s12_date_reglement_demande"),
                col("s13_ind_modif_ddr"),
                col("s14_code_commission"),
                col("s15_commission_interbancaire"),
                col("s16_zone_reservee_declaration"),
                col("s17_code_anomalie"),
                col("s18_zone_reservee"),
                col("b1_sous_code_ope"),
                col("b2_ref_ope"),
                col("b3_ref_presentateur"),
                col("b_ic_sous_code_ope"),
                col("b_ic_ref_ope"),
                col("b_ic_zone_banquier_remettant"),
                col("b_ic_num_cheque_cmc7_4"),
                col("b_ic_zone_interbancaire_cmc7_3"),
                col("b_ic_zone_interieure_cmc7_2"),
                col("b_ic_ind_balance_paiement"),
                col("b_ic_zone_usage_etblmt"),
                col("b_ic_indice_circulation"),
                col("b_ic_ind_cepc_concerne"),
                col("b_ic_zone_reservee_ic"),
                col("b_ric_code_motif"),
                col("b_ric_ref_ope"),
                col("b_ric_indice_delai"),
                col("b_ric_ind_restit_physque"),
                col("b_ric_indic_certif_non_pmt"),
                col("b_ric_nature_interdiction"),
                col("b_ric_date_interdiction"),
                col("b_ric_date_presentation"),
                col("b_ric_num_cheque"),
                col("b_ric_nom_tireur"),
                col("b_ric_lib_abre_domicil"),
                col("b_ric_num_cpte_tireur"),
                col("b_ric_coord_expediteur"),
                col("b_ric_zone_usage_etblmt"),
                col("b_ric_zone_reservee"),
                col("b_aic_code_motif"),
                col("b_aic_ref_ope"),
                col("b_aic_zone_usage_etabl"),
                col("b_aic_zone_reservee"),
                col("b_raic_code_motif"),
                col("b_raic_ref_ope"),
                col("b_raic_zone_usage_etabl"),
                col("b_raic_zone_reservee"),
                col("b_aric_code_motif"),
                col("b_aric_ref_ope"),
                col("b_aric_zone_usage_etblt"),
                col("b_aric_zone_reservee"),
                col("b_raric_code_motif"),
                col("b_raric_ref_ope"),
                col("b_raric_zone_usage_etblt"),
                col("b_raric_zone_reservee"),
                col("b_odr_nature_ope"),
                col("b_odr_ref_ope"),
                col("b_odr_motif"),
                col("b_odr_coord_expediteur"),
                col("b_odr_zone_usage_etblmt"),
                col("b_odr_zone_lib_contact"),
                col("b_odr_date_reglement"),
                col("b_odr_zone_reservee"),
                col("b_ocr_nature_ope"),
                col("b_ocr_ref_ope"),
                col("b_ocr_motif"),
                col("b_ocr_coord_expediteur"),
                col("b_ocr_zone_usage_etblmt"),
                col("b_ocr_zone_lib_contact"),
                col("b_ocr_date_reglement"),
                col("b_ocr_zone_reservee"),
                col("b_dtc_nature_demande"),
                col("b_dtc_ref_ope"),
                col("b_dtc_coord_exp"),
                col("b_dtc_zone_etablt"),
                col("b_dtc_ident_emetteur"),
                col("b_dtc_zone_reservee"),
                col("b_onc_nature_ope"),
                col("b_onc_ref_ope"),
                col("b_onc_coord_exp"),
                col("b_onc_zone_etblt"),
                col("b_onc_zone_libelle"),
                col("b_onc_cat_onc"),
                col("b_onc_zone_reservee"),
                col("b_lcr_sous_code_ope"),
                col("b_lcr_ref_ope"),
                col("b_lcr_presentateur"),
                col("b_lcr_coord_client_cedant"),
                col("b_lcr_coord_client_tire"),
                col("b_lcr_nom_tireur"),
                col("b_lcr_date_echeance"),
                col("b_lcr_date_creation"),
                col("b_lcr_date_entree_ptf"),
                col("b_lcr_zone_reservee_1"),
                col("b_lcr_nom_tire"),
                col("b_lcr_acceptation"),
                col("b_lcr_code_entree"),
                col("b_lcr_ref_tireur"),
                col("b_lcr_ref_tire"),
                col("b_lcr_num_siren_tireur"),
                col("b_lcr_zone_reservee_2"),
                col("b_lcr_lib_domicil"),
                col("b_lcr_zone_reservee_3"),
                col("b_lcr_ind_balance_paiments"),
                col("b_lcr_zone_reservee_4"),
                col("b_rjt_code_motif"),
                col("b_rjt_ref_ope"),
                col("b_rjt_ref_presentateur"),
                col("b_rjt_num_siren_dest"),
                col("b_rjt_zone_reservee"),
                col("b_vrf_code_motif"),
                col("b_vrf_ref_ope"),
                col("b_vrf_ref_presentateur"),
                col("b_vrf_coord_client_cedant"),
                col("b_vrf_coord_client_tire"),
                col("b_vrf_nom_tireur"),
                col("b_vrf_date_echeance_lcr"),
                col("b_vrf_date_creation"),
                col("b_vrf_date_entree_ptf"),
                col("b_vrf_zone_reservee1"),
                col("b_vrf_nom_tire"),
                col("b_vrf_acceptation"),
                col("b_vrf_code_entree"),
                col("b_vrf_ref_tireur"),
                col("b_vrf_ref_tire"),
                col("b_vrf_num_siren_tireur"),
                col("b_vrf_zone_reservee2"),
                col("b_vrf_lib_abre_domicil"),
                col("b_vrf_zone_reservee3"),
                col("b_vrf_ind_balance_paiement"),
                col("b_vrf_zone_reservee4"),
                col("b_arlcr_code_motif"),
                col("b_arlcr_ref_ope"),
                col("b_arlcr_ref_presentateur"),
                col("b_arlcr_zone_reservee"),
                col("b_corrige_code_motif"),
                col("b_corrige_ref_ope"),
                col("b_corrige_ref_presentateur"),
                col("b_corrige_zone_reservee_1"),
                col("b_corrige_coord_client_dest"),
                col("b_corrige_id_client_dest"),
                col("b_corrige_crit_routage_second"),
                col("b_corrige_zone_reservee_2"),
                col("b_corrige_lib_abre_domicil"),
                col("b_corrige_zone_reservee_3"),
                col("b_drec_code_motif"),
                col("b_drec_ref_ope"),
                col("b_drec_ref_presentateur"),
                col("b_drec_zone_reservee"),
                col("b_dlci_zone_reservee_1"),
                col("b_dlci_ref_ope"),
                col("b_dlci_ref_presentateur"),
                col("b_dlci_zone_reservee_2"),
                col("date_insert"),
                col("date_ope").as("date_ope"),
                col("id_traitement"));
	}

}
