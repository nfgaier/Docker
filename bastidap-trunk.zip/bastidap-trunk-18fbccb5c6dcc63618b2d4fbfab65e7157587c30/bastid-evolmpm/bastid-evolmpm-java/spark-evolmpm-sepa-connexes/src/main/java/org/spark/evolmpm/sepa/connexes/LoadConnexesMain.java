package org.spark.evolmpm.sepa.connexes;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.spark.evolmpm.sepa.connexes.constant.ParseSepaConstant;
import org.spark.evolmpm.sepa.connexes.data.DataProcessor;
import org.spark.evolmpm.sepa.connexes.data.ReadData;
import org.spark.evolmpm.sepa.connexes.data.WriteData;

import fr.bdf.bastid.util.bean.LineAcqFile;
import fr.bdf.bastid.util.filereader.AcqFileReader;

public class LoadConnexesMain implements Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = -900302352898891679L;
	
	public static String getTime() {
		return "[" + new SimpleDateFormat("HH:mm:ss").format(new Date())
				+ "] - ";
	}
	
		

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
	
		// CODE POUR MERGE DES PROJETS ALIMENTATION TABLES CONNEXES SEPA
		
		// Check if all parameters have been send
        if(args.length != 4){
            System.out.println("ERROR:" + LoadConnexesMain.getTime() + " Missing arguments. Usage: " + 
                    new java.io.File(LoadConnexesMain.class.getProtectionDomain().
                            getCodeSource().
                            getLocation().
                            getPath()).getName() + " <configuration file> "
                            		+ "<id_Trt> "
                            		+ "<property_file_name> "
                            		+ "<path to id acquisition file>");
            System.exit(0);
        }
       
        // Affect parameters
        String pathToConfigFile = args[0];
        //String idAcq= args[1];
        String idTrt= args[1];
        String propertyFile = args[2];
		String acqFilePath = args[3];

        
        /** Init configuration and contexts */
        SparkConf conf = new SparkConf();
      	final SparkSession session = SparkSession.builder()
      				.appName("SepaConnexess")
      				.config(conf)
      				.config("hive.fetch.task.conversion", "minimal")
      				.config("spark.sql.warehouse.dir", "/apps/hive/warehouse")
      				.config("spark.sql.hive.convertMetastoreOrc", "false")
      				.enableHiveSupport()
      				.getOrCreate();
      	
      	session.sparkContext().hadoopConfiguration().addResource(new Path(pathToConfigFile));
      	 Logger.getRootLogger().setLevel(Level.WARN);
      	 
      	// Chargement du fichier contenant les id d'acquisition et constitution de la liste de lignes
 		AcqFileReader afr = new AcqFileReader(acqFilePath);
 		Map<String, List<LineAcqFile>> mapAcqFileLines = getMapAcqFileLines(afr);
		List<LineAcqFile> listIdAcqOpeSepa = mapAcqFileLines.get(ParseSepaConstant.OPE_SEPA_TABLE.toUpperCase());
      	 
 		
        // Chargement des paramètres à partir du fichier de paramètres
 		Properties filePropertiesReader = new Properties(); 
 		FileInputStream fileProperties = null;
 		
 		// Vérifier si le fichier de paramètres existe et initilialiser le fichier de propriété en java
 		try {
 			fileProperties = new FileInputStream(propertyFile);
 			filePropertiesReader.load(fileProperties);
 		} catch (Exception e) {
 			System.out.println("ERROR:" + LoadConnexesMain.getTime() + " Fichier de parametres introuvable " );
 			System.exit(1);
		}
 		
 		// Vérifier si le fichier de paramètres est vide
 		if (filePropertiesReader.isEmpty()){
 			System.out.println("ERROR:" + LoadConnexesMain.getTime() + " Fichier de parametres vide " );
 			System.exit(1);
 		}
        
 		// Récupérer les valeurs des paramètres
 		final String codeOpeSepaParameter = filePropertiesReader.getProperty("LISTE_CODE_OPE_SEPA") ;
 		final String workHdfsPathParameter = filePropertiesReader.getProperty("WORK_HDFS_PATH") ;

 		// Vérifier que les paramètres ne sont pas vides
 		if(StringUtils.isBlank(codeOpeSepaParameter)) {
			System.out.println("ERROR:" + LoadConnexesMain.getTime() + " Aucun code opération à traiter dans les paramètres " );
 			System.exit(1);
 		} else if(StringUtils.isBlank(workHdfsPathParameter)) {
			System.out.println("ERROR:" + LoadConnexesMain.getTime() + " Aucun path hdfs renseigner pour le work_layer" );
 			System.exit(1);
 		}
 		
 		// Initialisation des constantes
 		ParseSepaConstant constants = new ParseSepaConstant();
 		
 		// Initialiser la liste des code opérations à traiter
 		final List<String> codeOpeList = new ArrayList<String>();
 		if(codeOpeSepaParameter.contains(",")) {
 			codeOpeList.addAll(Arrays.asList(codeOpeSepaParameter.split(",")));
 		} else {
 			codeOpeList.add(codeOpeSepaParameter);
 		}
 		
		// Initialisation du reader, processor et writer
		ReadData reader = new ReadData(session, listIdAcqOpeSepa);
		DataProcessor processor = new DataProcessor(idTrt);
		WriteData writer = new WriteData(session, idTrt, workHdfsPathParameter);
 		
 		// Boucle sur la liste des code operations pour traitement
 		codeOpeList.stream().forEach((codeOpeLambda) -> {
 			
 			// Lecture des données connexes
 			Dataset<Row> connexData = reader.getSepaB2BData(idTrt, codeOpeLambda);
 			
 			System.out.println("idTrt = " + idTrt);
 			System.out.println("codeOpeLambda = " + codeOpeLambda);
 			System.out.println("connexData.count() = " + connexData.count());
 			
 			// Formattage des données suivant la tables cibles (champs différents)
 			Dataset<Row> preparedData = processor.prepareData(connexData, codeOpeLambda);
 			
 			System.out.println("INFO:" + LoadConnexesMain.getTime() + " , Loading code operation  : "+codeOpeLambda+ " , "
 					+ "to table : "+ constants.getSepaTables().get(codeOpeLambda)+ " , HDFS PATH : "+workHdfsPathParameter);
 			
 			// ecriture dans la table cible
 			writer.writeSepaData(preparedData, workHdfsPathParameter, constants.getSepaTables().get(codeOpeLambda));
 		});

		
 		
   }
		

	/**
	 * Method that gets the acquisition ids needed for the treatment.
	 * 
	 * @param afr
	 *            the acquisition file reader
	 * @return the map that contains the acquisition ids needed for the
	 *         treatment
	 */
	private static Map<String, List<LineAcqFile>> getMapAcqFileLines(
			AcqFileReader afr) {
		Map<String, List<LineAcqFile>> mapAcqFileLines = null;
		try {
			mapAcqFileLines = afr.getAcqFileLines();
		} catch (IOException e) {
			Logger.getRootLogger().error(
					"An error occured when reading the file", e);
			System.exit(0);
		}

		if (mapAcqFileLines == null || mapAcqFileLines.isEmpty()) {
			Logger.getRootLogger().error(
					"The acquisition id map is null or empty");
			System.exit(0);
		}
		return mapAcqFileLines;
	}

	
}

