package org.spark.evolmpm.sepa.connexes.data;


import java.io.Serializable;
import java.util.List;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import fr.bdf.bastid.util.bean.LineAcqFile;


public class ReadData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7622419554016705317L;
	/**
	 * 
	 */	
	private SparkSession sqlContext;
	private List<LineAcqFile> listIdAcq;
        
    /**
     * @param sqlContext
     * @param idAcqStart
     */
    public ReadData(SparkSession sqlContext, List<LineAcqFile> listIdAcq) {
        super();
        this.sqlContext = sqlContext;   
        this.listIdAcq = listIdAcq;
    }
    
  /**  public Dataset<Row> getSepaData() {
    	
    	return sqlContext.sql("select * from " + ParseSepaConstant.HIVE_WRK_LAYER+"."+ParseSepaConstant.OPE_SEPA_TABLE);  
                                      
    }
    */
    
    public Dataset<Row> getSepaB2BData(String idtrt, String codeOpe) {
       
    	System.out.println("select * from  (select parent.id_operation as id_ope_initiale, " +
		        					"conn.id_operation,                    conn.m_a_odac_id_iban,                  conn.ri_rorg_id_prv_dpbi_dat,             conn.m_updid_pty_id_pr_o_sn_cd, " +
		        					"conn.code_operation,                  conn.m_a_odag_fi_othr_id,               conn.ri_rorg_id_prv_dpbi_prv,             conn.m_updid_pty_id_pr_o_sn_pty, " +
		        					"conn.code_client_conventionne,        conn.m_elctrncsgnt,                     conn.ri_rorg_id_prv_dpbi_cty,             conn.m_updid_pty_id_pr_o_issr, " +
		        					"conn.id_client,                       conn.csch_idproi,                       conn.ri_rorg_id_prv_dpbi_cry,             conn.m_updid_pty_ctrr, " +
		        					"conn.code_grp_remettant,              conn.csch_idproi_cd,                    conn.ri_rorg_id_prv_othr_id,              conn.m_updid_ctct_dt_nmpr, " +
		        					"conn.lib_grp_remettant,               conn.csch_idproi_prtry,                 conn.ri_rorg_id_prv_othr_sch_cd,          conn.m_updid_ctct_dt_nm, " +
		        					"conn.id_ics,                          conn.csch_idproi_issr,                  conn.ri_rorg_id_prv_othr_sch_prtr,        conn.m_updid_ctct_dt_phnm, " +
		        					"conn.id_systeme_echange,              conn.ucdt_name,                         conn.ri_rorg_id_prv_othr_issr,            conn.m_updid_ctct_dt_mbnm, " +
		        					"conn.iban_do_sr,                      conn.ucdt_id_org_bic_bei,               conn.ri_rsn_cd,                           conn.m_updid_ctct_dt_fxnm, " +
		        					"conn.code_pays_do_sr,                 conn.ucdt_id_org_othr_id,               conn.ri_sn_prtry,                         conn.m_updid_ctct_dt_emadr, " +
		        					"conn.cle_iban_do_sr,                  conn.ucdt_id_org_othr_sch_cd,           conn.ri_addtlinf1,                        conn.m_updid_ctct_dt_other, " +
		        					"conn.code_banque_do_sr,               conn.ucdt_id_org_othr_sch_prtry,        conn.ri_addtlinf2,                        conn.m_updid_acct_iban, " +
		        					"conn.code_guichet_do_sr,              conn.ucdt_id_org_othr_issr,             conn.otr_reqdcolltndt,                    conn.m_updid_acct_o_id, " +
		        					"conn.num_cpte_do_sr,                  conn.ucdt_id_pr_dpbi_da,                conn.otr_csch_id_prv_othr_id,             conn.m_updid_agt_fi_bic, " +
		        					"conn.cle_rib_do_sr,                   conn.ucdt_id_pr_dpbi_prv,               conn.otr_csch_id_prv_othr_sch_cd,         conn.m_add_inf, " +
		        					"conn.bic_id_do_sr,                    conn.ucdt_id_pr_dpbi_ct,                conn.otr_csch_id_prv_othr_issr,           conn.m_id, " +
		        					"conn.id_compte_do_sr,                 conn.ucdt_id_pr_dpbi_cr,                conn.otr_csch_id_prv_othr_sch_prtr,       conn.iban_debitor, " +
		        					"conn.id_client_do_sr,                 conn.ucdt_id_prv_othr_id,               conn.otr_stti_sttlmmtd,                   conn.iban_creditor, " +
		        					"conn.bic_id_beneficiaire_sr,          conn.ucdt_id_prv_othr_sch_cd,           conn.otr_stti_sttaid_iban,                conn.m_a_odac_v9_id_othr_id, " +
		        					"conn.iban_beneficiaire_sr,            conn.ucdt_id_prv_othr_sch_prtr,         conn.otr_stti_sttaid_o_id,                conn.m_a_odac_v9_fi_bic, " +
		        					"conn.code_pays_beneficiaire_sr,       conn.ucdt_id_prv_othr_issr,             conn.otr_stti_sttaid_o_sn_cd,             conn.bic_id_do, " +
		        					"conn.cle_iban_beneficiaire_sr,        conn.dbt_name,                          conn.otr_stti_sttaid_o_sn_prtr,           conn.iban_do, " +
		        					"conn.code_banque_beneficiaire_sr,     conn.dbt_padr_adrline,                  conn.otr_stti_sttaid_o_issr,              conn.bic_id_beneficiaire, " +
		        					"conn.code_guichet_beneficiaire_sr,    conn.dbt_padr_ctry,                     conn.otr_stti_clrs_cd,                    conn.iban_beneficiaire, " +
		        					"conn.num_cpte_beneficiaire_sr,        conn.dbt_id_org_bic_bei,                conn.otr_stti_clrs_prtry,                 conn.flag_evolmpm_maeva, " +
		        					"conn.cle_rib_beneficiaire_sr,         conn.dbt_id_org_othr_id,                conn.bic_id_debitor,                      conn.date_insert, " +
		        					"conn.id_compte_beneficiaire_sr,       conn.dbt_id_org_othr_sch_cd,            conn.bic_id_creditor,                     conn.date_ope, " +
		        					"conn.id_client_beneficiaire_sr,       conn.dbt_id_org_othr_sch_prtry,         conn.ot_instrid,                     	 conn.id_traitement, " +
		        					"conn.iban_debitor_sr,                 conn.dbt_id_org_othr_issr,              conn.ot_endtoendid, " +
		        					"conn.code_pays_debitor_sr,            conn.dbt_id_pr_dpbi_dat,                conn.ot_txid, " +
		        					"conn.cle_iban_debitor_sr,             conn.dbt_id_pr_dpbi_prv,                conn.ot_crlsysref, " +
		        					"conn.code_banque_debitor_sr,          conn.dbt_id_pr_dpbi_cty,                conn.ot_first_agt_fi_bic, " +
		        					"conn.code_guichet_debitor_sr,         conn.dbt_id_pr_dpbi_cr,                 conn.m_orgnl_pty_name, " +
		        					"conn.num_cpte_debitor_sr,             conn.dbt_id_prv_othr_id,                conn.m_orgnl_pty_padr_typ, " +
		        					"conn.cle_rib_debitor_sr,              conn.dbt_id_prv_othr_sch_cd,            conn.m_orgnl_pty_padr_dpt, " +
		        					"conn.bic_id_debitor_sr,               conn.dbt_id_prv_othr_sch_prtr,          conn.m_orgnl_pty_padr_sbdpt, " +
		        					"conn.bic_id_creditor_sr,              conn.dbt_id_prv_othr_issr,              conn.m_orgnl_pty_padr_stnm, " +
		        					"conn.iban_creditor_sr,                conn.dbtacc_id_iban,                    conn.m_orgnl_pty_padr_bdnm, " +
		        					"conn.code_pays_creditor_sr,           conn.dbtagt_fi_bic,                     conn.m_orgnl_pty_padr_pscd, " +
		        					"conn.cle_iban_creditor_sr,            conn.cdtacc_id_iban,                    conn.m_orgnl_pty_padr_twnm, " +
		        					"conn.code_banque_creditor_sr,         conn.cdtagt_fi_bic,                     conn.m_orgnl_pty_padr_ctsd, " +
		        					"conn.code_guichet_creditor_sr,        conn.cdt_name,                          conn.m_orgnl_pty_padr_ctry, " +
		        					"conn.num_cpte_creditor_sr,            conn.cdt_padr_adrline,                  conn.m_orgnl_pty_padr_adli1, " +
		        					"conn.cle_rib_creditor_sr,             conn.cdt_padr_ctry,                     conn.m_orgnl_pty_padr_adli2, " +
		        					"conn.code_famille_operation,          conn.cdt_id_org_bic_bei,                conn.m_orgnl_pty_padr_adli3, " +
		        					"conn.id_type_operation,               conn.cdt_id_org_othr_id,                conn.m_orgnl_pty_padr_adli4, " +
		        					"conn.delai_reglement,                 conn.cdt_id_org_othr_sch_cd,            conn.m_orgnl_pty_padr_adli5, " +
		        					"conn.type_operation,                  conn.cdt_id_org_othr_sch_prtry,         conn.m_orgnl_pty_padr_adli6, " +
		        					"conn.sens_echange,                    conn.cdt_id_org_othr_issr,              conn.m_orgnl_pty_padr_adli7, " +
		        					"conn.num_remise,                      conn.cdt_id_pr_dpbi_dat,                conn.m_orgnl_pty_id_oi_bic, " +
		        					"conn.num_remise_tech,                 conn.cdt_id_pr_dpbi_prv,                conn.m_orgnl_pty_id_oi_id, " +
		        					"conn.date_pec_amont,                  conn.cdt_id_pr_dpbi_cty,                conn.m_orgnl_pty_id_oi_o_sn_cd, " +
		        					"conn.heure_pec_amont,                 conn.cdt_id_pr_dpbi_cry,                conn.m_orgnl_pty_id_oi_sn_pty, " +
		        					"conn.date_presentation_remise,        conn.cdt_id_prv_othr_id,                conn.m_orgnl_pty_id_oi_o_issr, " +
		        					"conn.heure_presentation_remise,       conn.cdt_id_prv_othr_sch_cd,            conn.m_orgnl_pty_id_pr_bi_dat, " +
		        					"conn.rio,                             conn.cdt_id_prv_othr_sch_prtr,          conn.m_orgnl_pty_id_pr_bi_prv, " +
		        					"conn.date_echange,                    conn.cdt_id_prv_othr_issr,              conn.m_orgnl_pty_id_pr_bi_cty, " +
		        					"conn.date_reglement,                  conn.udbt_name,                         conn.m_orgnl_pty_id_pr_bi_cry, " +
		        					"conn.date_traitement_aval_recu,       conn.udbt_id_org_bic_bei,               conn.m_orgnl_pty_id_pr_o_id, " +
		        					"conn.etblt_concerne,                  conn.udbt_id_org_othr_id,               conn.m_orgnl_pty_id_pr_o_sn_cd, " +
		        					"conn.ind_rejet,                       conn.udbt_id_org_othr_sch_cd,           conn.m_orgnl_pty_id_pr_o_sn_pty, " +
		        					"conn.flag_debrayage_embargo,          conn.udbt_id_org_othr_sch_prtr,         conn.m_orgnl_pty_id_pr_o_issr, " +
		        					"conn.xtimts,                          conn.udbt_id_org_othr_sch_issr,         conn.m_orgnl_pty_ctrr, " +
		        					"conn.ref_operation_origine,           conn.udbt_id_pr_dpbi_dat,               conn.m_orgnl_ctct_dt_nmpr, " +
		        					"conn.date_comptable_evolmpm,          conn.udbt_id_pr_dpbi_prv,               conn.m_orgnl_ctct_dt_nm, " +
		        					"conn.pmtid_txid_src,                  conn.udbt_id_pr_dpbi_cty,               conn.m_orgnl_ctct_dt_phnm, " +
		        					"conn.mnt_compense_sit,                conn.udbt_id_pr_dpbi_cry,               conn.m_orgnl_ctct_dt_mbnm, " +
		        					"conn.code_flux_arch,                  conn.udbt_id_prv_othr_id,               conn.m_orgnl_ctct_dt_fxnm, " +
		        					"conn.num_partition,                   conn.udbt_id_prv_othr_sch_cd,           conn.m_orgnl_ctct_dt_emadr, " +
		        					"conn.type_enregistrement,             conn.udbt_id_prv_othr_sch_prtr,         conn.m_orgnl_ctct_dt_other, " +
		        					"conn.orgnltxid_src,                   conn.udbt_id_prv_othr_issr,             conn.m_orgnl_accnt_iban, " +
		        					"conn.orgnlinstrid_src,                conn.insgagt_fi_bic,                    conn.m_orgnl_accnt_o_id, " +
		        					"conn.orgnlendtoendid_src,             conn.insdagt_fi_bic,                    conn.m_orgnl_agt_fi_bic, " +
		        					"conn.num_ics,                         conn.rmtinf_ustrd,                      conn.m_updid_pty_name, " +
		        					"conn.motif_rejet_annulation,          conn.rmtinf_strd_type_code,             conn.m_updid_pty_padr_typ, " +
		        					"conn.pmtid_txid,                      conn.rmtinf_strd_type_ref,              conn.m_updid_pty_padr_dpt, " +
		        					"conn.pmtid_instrid,                   conn.rmtinf_strd_type_is,               conn.m_updid_pty_padr_sbdpt, " +
		        					"conn.pmtid_endtoendid,                conn.sup_chemin,                        conn.m_updid_pty_padr_stnm, " +
		        					"conn.pmttpi_svclvl_cd,                conn.pur_cd,                            conn.m_updid_pty_padr_bdnm, " +
		        					"conn.pmttpi_lclins_cd,                conn.orgnltxid,                         conn.m_updid_pty_padr_pscd, " +
		        					"conn.pmttpilclins_prtry,              conn.orggrpinf_orgnlmsgid,              conn.m_updid_pty_padr_twnm, " +
		        					"conn.pmttpi_seqtp,                    conn.orggrpinf_orgnlmsgnmid,            conn.m_updid_pty_padr_ctsd, " +
		        					"conn.pmttpi_ctgypurp,                 conn.orgnlinstrid,                      conn.m_updid_pty_padr_ctr, " +
		        					"conn.pmttpi_ctgypurp_pr,              conn.orgnlendtoendid,                   conn.m_updid_pty_padr_adli1, " +
		        					"conn.intrbksttlmamt,                  conn.txsts,                             conn.m_updid_pty_padr_adli2, " +
		        					"conn.intrbksttlmamtc,                 conn.orgnlintrbksttlmamt,               conn.m_updid_pty_padr_adli3, " +
		        					"conn.chrgbr,                          conn.orgnlintrbksttlmamtc,              conn.m_updid_pty_padr_adli4, " +
		        					"conn.chrginf_amt,                     conn.otr_intrbksttlmdt,                 conn.m_updid_pty_padr_adli5, " +
		        					"conn.chrginf_amtc,                    conn.compstnamt,                        conn.m_updid_pty_padr_adli6, " +
		        					"conn.chrginf_pty_fi_bic,              conn.compstnamtc,                       conn.m_updid_pty_padr_adli7, " +
		        					"conn.reqdcolltndt,                    conn.instdamt,                          conn.m_updid_pty_id_bic, " +
		        					"conn.m_mndtid,                        conn.instdamtc,                         conn.m_updid_id_o_id, " +
		        					"conn.m_dtofsgntr,                     conn.ri_rorg_name,                      conn.m_updid_pty_id_o_sn_cd, " +
		        					"conn.m_amdmntind,                     conn.ri_rorg_padr_adrline,              conn.m_updid_pty_id_o_sd_pty, " +
		        					"conn.m_a_orgnlmndtid,                 conn.ri_rorg_padr_ctry,                 conn.m_updid_pty_id_o_issr, " +
		        					"conn.m_a_s_nm,                        conn.ri_rorg_id_org_bic_bei,            conn.m_updid_pty_id_pr_bi_dat, " +
		        					"conn.m_a_s_id_proid,                  conn.ri_rorg_id_org_othr_id,            conn.m_updid_pty_id_pr_bi_prv, " +
		        					"conn.m_a_s_id_pro_sch_cd,             conn.ri_rorg_id_org_othr_sch_cd,        conn.m_updid_pty_id_pr_bi_cty, " +
		        					"conn.m_a_s_id_pro_sch_prtry,          conn.ri_rorg_id_org_othr_sch_prtr,      conn.m_updid_pty_id_pr_bi_cry, " +
		        					"conn.m_a_s_id_pro_issr,               conn.ri_rorg_id_org_othr_issr,          conn.m_updid_pty_id_pr_o_id, " +
		        					"row_number() over (partition by conn.id_operation order by parent.id_traitement desc) as dedoubNum " +
        		"from evolmpm_work_layer.operations_sepa conn " +
        		"left join evolmpm_work_layer.operations_sepa parent " +
        		"on conn.otr_intrbksttlmdt = to_date(parent.date_reglement) and conn.orgnltxid = parent.pmtid_txid " +
        		"where conn.code_operation='"+codeOpe+"' "+this.getWhereClauseConnexe(listIdAcq)+") as sub where dedoubNum=1 ");
    	return sqlContext.sql(
    		"select * from  (select parent.id_operation as id_ope_initiale, " +
		        					"conn.id_operation,                    conn.m_a_odac_id_iban,                  conn.ri_rorg_id_prv_dpbi_dat,             conn.m_updid_pty_id_pr_o_sn_cd, " +
		        					"conn.code_operation,                  conn.m_a_odag_fi_othr_id,               conn.ri_rorg_id_prv_dpbi_prv,             conn.m_updid_pty_id_pr_o_sn_pty, " +
		        					"conn.code_client_conventionne,        conn.m_elctrncsgnt,                     conn.ri_rorg_id_prv_dpbi_cty,             conn.m_updid_pty_id_pr_o_issr, " +
		        					"conn.id_client,                       conn.csch_idproi,                       conn.ri_rorg_id_prv_dpbi_cry,             conn.m_updid_pty_ctrr, " +
		        					"conn.code_grp_remettant,              conn.csch_idproi_cd,                    conn.ri_rorg_id_prv_othr_id,              conn.m_updid_ctct_dt_nmpr, " +
		        					"conn.lib_grp_remettant,               conn.csch_idproi_prtry,                 conn.ri_rorg_id_prv_othr_sch_cd,          conn.m_updid_ctct_dt_nm, " +
		        					"conn.id_ics,                          conn.csch_idproi_issr,                  conn.ri_rorg_id_prv_othr_sch_prtr,        conn.m_updid_ctct_dt_phnm, " +
		        					"conn.id_systeme_echange,              conn.ucdt_name,                         conn.ri_rorg_id_prv_othr_issr,            conn.m_updid_ctct_dt_mbnm, " +
		        					"conn.iban_do_sr,                      conn.ucdt_id_org_bic_bei,               conn.ri_rsn_cd,                           conn.m_updid_ctct_dt_fxnm, " +
		        					"conn.code_pays_do_sr,                 conn.ucdt_id_org_othr_id,               conn.ri_sn_prtry,                         conn.m_updid_ctct_dt_emadr, " +
		        					"conn.cle_iban_do_sr,                  conn.ucdt_id_org_othr_sch_cd,           conn.ri_addtlinf1,                        conn.m_updid_ctct_dt_other, " +
		        					"conn.code_banque_do_sr,               conn.ucdt_id_org_othr_sch_prtry,        conn.ri_addtlinf2,                        conn.m_updid_acct_iban, " +
		        					"conn.code_guichet_do_sr,              conn.ucdt_id_org_othr_issr,             conn.otr_reqdcolltndt,                    conn.m_updid_acct_o_id, " +
		        					"conn.num_cpte_do_sr,                  conn.ucdt_id_pr_dpbi_da,                conn.otr_csch_id_prv_othr_id,             conn.m_updid_agt_fi_bic, " +
		        					"conn.cle_rib_do_sr,                   conn.ucdt_id_pr_dpbi_prv,               conn.otr_csch_id_prv_othr_sch_cd,         conn.m_add_inf, " +
		        					"conn.bic_id_do_sr,                    conn.ucdt_id_pr_dpbi_ct,                conn.otr_csch_id_prv_othr_issr,           conn.m_id, " +
		        					"conn.id_compte_do_sr,                 conn.ucdt_id_pr_dpbi_cr,                conn.otr_csch_id_prv_othr_sch_prtr,       conn.iban_debitor, " +
		        					"conn.id_client_do_sr,                 conn.ucdt_id_prv_othr_id,               conn.otr_stti_sttlmmtd,                   conn.iban_creditor, " +
		        					"conn.bic_id_beneficiaire_sr,          conn.ucdt_id_prv_othr_sch_cd,           conn.otr_stti_sttaid_iban,                conn.m_a_odac_v9_id_othr_id, " +
		        					"conn.iban_beneficiaire_sr,            conn.ucdt_id_prv_othr_sch_prtr,         conn.otr_stti_sttaid_o_id,                conn.m_a_odac_v9_fi_bic, " +
		        					"conn.code_pays_beneficiaire_sr,       conn.ucdt_id_prv_othr_issr,             conn.otr_stti_sttaid_o_sn_cd,             conn.bic_id_do, " +
		        					"conn.cle_iban_beneficiaire_sr,        conn.dbt_name,                          conn.otr_stti_sttaid_o_sn_prtr,           conn.iban_do, " +
		        					"conn.code_banque_beneficiaire_sr,     conn.dbt_padr_adrline,                  conn.otr_stti_sttaid_o_issr,              conn.bic_id_beneficiaire, " +
		        					"conn.code_guichet_beneficiaire_sr,    conn.dbt_padr_ctry,                     conn.otr_stti_clrs_cd,                    conn.iban_beneficiaire, " +
		        					"conn.num_cpte_beneficiaire_sr,        conn.dbt_id_org_bic_bei,                conn.otr_stti_clrs_prtry,                 conn.flag_evolmpm_maeva, " +
		        					"conn.cle_rib_beneficiaire_sr,         conn.dbt_id_org_othr_id,                conn.bic_id_debitor,                      conn.date_insert, " +
		        					"conn.id_compte_beneficiaire_sr,       conn.dbt_id_org_othr_sch_cd,            conn.bic_id_creditor,                     conn.date_ope, " +
		        					"conn.id_client_beneficiaire_sr,       conn.dbt_id_org_othr_sch_prtry,         conn.ot_instrid,                     	 conn.id_traitement, " +
		        					"conn.iban_debitor_sr,                 conn.dbt_id_org_othr_issr,              conn.ot_endtoendid, " +
		        					"conn.code_pays_debitor_sr,            conn.dbt_id_pr_dpbi_dat,                conn.ot_txid, " +
		        					"conn.cle_iban_debitor_sr,             conn.dbt_id_pr_dpbi_prv,                conn.ot_crlsysref, " +
		        					"conn.code_banque_debitor_sr,          conn.dbt_id_pr_dpbi_cty,                conn.ot_first_agt_fi_bic, " +
		        					"conn.code_guichet_debitor_sr,         conn.dbt_id_pr_dpbi_cr,                 conn.m_orgnl_pty_name, " +
		        					"conn.num_cpte_debitor_sr,             conn.dbt_id_prv_othr_id,                conn.m_orgnl_pty_padr_typ, " +
		        					"conn.cle_rib_debitor_sr,              conn.dbt_id_prv_othr_sch_cd,            conn.m_orgnl_pty_padr_dpt, " +
		        					"conn.bic_id_debitor_sr,               conn.dbt_id_prv_othr_sch_prtr,          conn.m_orgnl_pty_padr_sbdpt, " +
		        					"conn.bic_id_creditor_sr,              conn.dbt_id_prv_othr_issr,              conn.m_orgnl_pty_padr_stnm, " +
		        					"conn.iban_creditor_sr,                conn.dbtacc_id_iban,                    conn.m_orgnl_pty_padr_bdnm, " +
		        					"conn.code_pays_creditor_sr,           conn.dbtagt_fi_bic,                     conn.m_orgnl_pty_padr_pscd, " +
		        					"conn.cle_iban_creditor_sr,            conn.cdtacc_id_iban,                    conn.m_orgnl_pty_padr_twnm, " +
		        					"conn.code_banque_creditor_sr,         conn.cdtagt_fi_bic,                     conn.m_orgnl_pty_padr_ctsd, " +
		        					"conn.code_guichet_creditor_sr,        conn.cdt_name,                          conn.m_orgnl_pty_padr_ctry, " +
		        					"conn.num_cpte_creditor_sr,            conn.cdt_padr_adrline,                  conn.m_orgnl_pty_padr_adli1, " +
		        					"conn.cle_rib_creditor_sr,             conn.cdt_padr_ctry,                     conn.m_orgnl_pty_padr_adli2, " +
		        					"conn.code_famille_operation,          conn.cdt_id_org_bic_bei,                conn.m_orgnl_pty_padr_adli3, " +
		        					"conn.id_type_operation,               conn.cdt_id_org_othr_id,                conn.m_orgnl_pty_padr_adli4, " +
		        					"conn.delai_reglement,                 conn.cdt_id_org_othr_sch_cd,            conn.m_orgnl_pty_padr_adli5, " +
		        					"conn.type_operation,                  conn.cdt_id_org_othr_sch_prtry,         conn.m_orgnl_pty_padr_adli6, " +
		        					"conn.sens_echange,                    conn.cdt_id_org_othr_issr,              conn.m_orgnl_pty_padr_adli7, " +
		        					"conn.num_remise,                      conn.cdt_id_pr_dpbi_dat,                conn.m_orgnl_pty_id_oi_bic, " +
		        					"conn.num_remise_tech,                 conn.cdt_id_pr_dpbi_prv,                conn.m_orgnl_pty_id_oi_id, " +
		        					"conn.date_pec_amont,                  conn.cdt_id_pr_dpbi_cty,                conn.m_orgnl_pty_id_oi_o_sn_cd, " +
		        					"conn.heure_pec_amont,                 conn.cdt_id_pr_dpbi_cry,                conn.m_orgnl_pty_id_oi_sn_pty, " +
		        					"conn.date_presentation_remise,        conn.cdt_id_prv_othr_id,                conn.m_orgnl_pty_id_oi_o_issr, " +
		        					"conn.heure_presentation_remise,       conn.cdt_id_prv_othr_sch_cd,            conn.m_orgnl_pty_id_pr_bi_dat, " +
		        					"conn.rio,                             conn.cdt_id_prv_othr_sch_prtr,          conn.m_orgnl_pty_id_pr_bi_prv, " +
		        					"conn.date_echange,                    conn.cdt_id_prv_othr_issr,              conn.m_orgnl_pty_id_pr_bi_cty, " +
		        					"conn.date_reglement,                  conn.udbt_name,                         conn.m_orgnl_pty_id_pr_bi_cry, " +
		        					"conn.date_traitement_aval_recu,       conn.udbt_id_org_bic_bei,               conn.m_orgnl_pty_id_pr_o_id, " +
		        					"conn.etblt_concerne,                  conn.udbt_id_org_othr_id,               conn.m_orgnl_pty_id_pr_o_sn_cd, " +
		        					"conn.ind_rejet,                       conn.udbt_id_org_othr_sch_cd,           conn.m_orgnl_pty_id_pr_o_sn_pty, " +
		        					"conn.flag_debrayage_embargo,          conn.udbt_id_org_othr_sch_prtr,         conn.m_orgnl_pty_id_pr_o_issr, " +
		        					"conn.xtimts,                          conn.udbt_id_org_othr_sch_issr,         conn.m_orgnl_pty_ctrr, " +
		        					"conn.ref_operation_origine,           conn.udbt_id_pr_dpbi_dat,               conn.m_orgnl_ctct_dt_nmpr, " +
		        					"conn.date_comptable_evolmpm,          conn.udbt_id_pr_dpbi_prv,               conn.m_orgnl_ctct_dt_nm, " +
		        					"conn.pmtid_txid_src,                  conn.udbt_id_pr_dpbi_cty,               conn.m_orgnl_ctct_dt_phnm, " +
		        					"conn.mnt_compense_sit,                conn.udbt_id_pr_dpbi_cry,               conn.m_orgnl_ctct_dt_mbnm, " +
		        					"conn.code_flux_arch,                  conn.udbt_id_prv_othr_id,               conn.m_orgnl_ctct_dt_fxnm, " +
		        					"conn.num_partition,                   conn.udbt_id_prv_othr_sch_cd,           conn.m_orgnl_ctct_dt_emadr, " +
		        					"conn.type_enregistrement,             conn.udbt_id_prv_othr_sch_prtr,         conn.m_orgnl_ctct_dt_other, " +
		        					"conn.orgnltxid_src,                   conn.udbt_id_prv_othr_issr,             conn.m_orgnl_accnt_iban, " +
		        					"conn.orgnlinstrid_src,                conn.insgagt_fi_bic,                    conn.m_orgnl_accnt_o_id, " +
		        					"conn.orgnlendtoendid_src,             conn.insdagt_fi_bic,                    conn.m_orgnl_agt_fi_bic, " +
		        					"conn.num_ics,                         conn.rmtinf_ustrd,                      conn.m_updid_pty_name, " +
		        					"conn.motif_rejet_annulation,          conn.rmtinf_strd_type_code,             conn.m_updid_pty_padr_typ, " +
		        					"conn.pmtid_txid,                      conn.rmtinf_strd_type_ref,              conn.m_updid_pty_padr_dpt, " +
		        					"conn.pmtid_instrid,                   conn.rmtinf_strd_type_is,               conn.m_updid_pty_padr_sbdpt, " +
		        					"conn.pmtid_endtoendid,                conn.sup_chemin,                        conn.m_updid_pty_padr_stnm, " +
		        					"conn.pmttpi_svclvl_cd,                conn.pur_cd,                            conn.m_updid_pty_padr_bdnm, " +
		        					"conn.pmttpi_lclins_cd,                conn.orgnltxid,                         conn.m_updid_pty_padr_pscd, " +
		        					"conn.pmttpilclins_prtry,              conn.orggrpinf_orgnlmsgid,              conn.m_updid_pty_padr_twnm, " +
		        					"conn.pmttpi_seqtp,                    conn.orggrpinf_orgnlmsgnmid,            conn.m_updid_pty_padr_ctsd, " +
		        					"conn.pmttpi_ctgypurp,                 conn.orgnlinstrid,                      conn.m_updid_pty_padr_ctr, " +
		        					"conn.pmttpi_ctgypurp_pr,              conn.orgnlendtoendid,                   conn.m_updid_pty_padr_adli1, " +
		        					"conn.intrbksttlmamt,                  conn.txsts,                             conn.m_updid_pty_padr_adli2, " +
		        					"conn.intrbksttlmamtc,                 conn.orgnlintrbksttlmamt,               conn.m_updid_pty_padr_adli3, " +
		        					"conn.chrgbr,                          conn.orgnlintrbksttlmamtc,              conn.m_updid_pty_padr_adli4, " +
		        					"conn.chrginf_amt,                     conn.otr_intrbksttlmdt,                 conn.m_updid_pty_padr_adli5, " +
		        					"conn.chrginf_amtc,                    conn.compstnamt,                        conn.m_updid_pty_padr_adli6, " +
		        					"conn.chrginf_pty_fi_bic,              conn.compstnamtc,                       conn.m_updid_pty_padr_adli7, " +
		        					"conn.reqdcolltndt,                    conn.instdamt,                          conn.m_updid_pty_id_bic, " +
		        					"conn.m_mndtid,                        conn.instdamtc,                         conn.m_updid_id_o_id, " +
		        					"conn.m_dtofsgntr,                     conn.ri_rorg_name,                      conn.m_updid_pty_id_o_sn_cd, " +
		        					"conn.m_amdmntind,                     conn.ri_rorg_padr_adrline,              conn.m_updid_pty_id_o_sd_pty, " +
		        					"conn.m_a_orgnlmndtid,                 conn.ri_rorg_padr_ctry,                 conn.m_updid_pty_id_o_issr, " +
		        					"conn.m_a_s_nm,                        conn.ri_rorg_id_org_bic_bei,            conn.m_updid_pty_id_pr_bi_dat, " +
		        					"conn.m_a_s_id_proid,                  conn.ri_rorg_id_org_othr_id,            conn.m_updid_pty_id_pr_bi_prv, " +
		        					"conn.m_a_s_id_pro_sch_cd,             conn.ri_rorg_id_org_othr_sch_cd,        conn.m_updid_pty_id_pr_bi_cty, " +
		        					"conn.m_a_s_id_pro_sch_prtry,          conn.ri_rorg_id_org_othr_sch_prtr,      conn.m_updid_pty_id_pr_bi_cry, " +
		        					"conn.m_a_s_id_pro_issr,               conn.ri_rorg_id_org_othr_issr,          conn.m_updid_pty_id_pr_o_id, " +
		        					"row_number() over (partition by conn.id_operation order by parent.id_traitement desc) as dedoubNum " +
        		"from evolmpm_work_layer.operations_sepa conn " +
        		"left join evolmpm_work_layer.operations_sepa parent " +
        		"on conn.otr_intrbksttlmdt = to_date(parent.date_reglement) and conn.orgnltxid = parent.pmtid_txid " +
        		"where conn.code_operation='"+codeOpe+"' "+this.getWhereClauseConnexe(listIdAcq)+") as sub where dedoubNum=1 "
        		);  	                                    
    }
    
	/**
	 * Method that constructs the where part of the request. 
	 * @param listIdAcq the list of id_acquisition / date_ope for FOFA_HIST_MESSAGE
	 * @return the where part of the request
	 */
	private String getWhereClauseConnexe(List<LineAcqFile> listIdAcq) {
		StringBuilder sb = new StringBuilder(" AND (");
		for (LineAcqFile lineAlerte : listIdAcq) {
			sb.append(" (conn.date_ope = '").append(lineAlerte.getJourFonc())
			.append("' AND conn.id_traitement = '").append(lineAlerte.getIdAcq()).append("') OR");
		}
		
		return sb.substring(0, sb.length() - 3)+")";
	}
    
         
       
}



