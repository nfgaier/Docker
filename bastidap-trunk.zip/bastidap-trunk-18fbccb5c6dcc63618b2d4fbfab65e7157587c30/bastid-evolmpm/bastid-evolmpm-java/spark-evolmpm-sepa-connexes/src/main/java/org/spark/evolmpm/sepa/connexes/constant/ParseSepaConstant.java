package org.spark.evolmpm.sepa.connexes.constant;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ParseSepaConstant implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1802917498562728796L;
	
		private Map<String, String> sepaTables;
		
		//hive databases    
	    public static final String HIVE_WRK_LAYER = "evolmpm_work_layer";
	    
	    // HDFS path
	    public static final String SEPA_HDFS_PATH_ROOT = "/data/source/";   
	    
	    // input table
	    public static final String OPE_SEPA_TABLE = "operations_sepa";   
	    
	    /** output table */ 
	    //bastid 455
	    public static final String OPERATIONS_SEPA_SDD_B2B_RECALL_387 = "operations_sepa_sdd_b2b_recall_387";
	    public static final String OPERATIONS_SEPA_SDD_B2B_REVERSAL_616 = "operations_sepa_sdd_b2b_reversal_616";
	    public static final String OPERATIONS_SEPA_SDD_B2B_REJET_681 = "operations_sepa_sdd_b2b_rejet_681";
	    public static final String OPERATIONS_SEPA_SDD_B2B_RETURN_781 = "operations_sepa_sdd_b2b_return_781";
	    public static final String OPERATIONS_SEPA_SDD_B2B_REJTECH_981 = "operations_sepa_sdd_b2b_rejtech_981";
	    
	    //bastid 454/512
	    public static final String OPERATIONS_SEPA_SDD_RECALL_386 = "operations_sepa_sdd_recall_386";
	    public static final String OPERATIONS_SEPA_SDD_REVERSAL_615 = "operations_sepa_sdd_reversal_615";
	    public static final String OPERATIONS_SEPA_SDD_REJET_680 = "operations_sepa_sdd_rejet_680";
	    public static final String OPERATIONS_SEPA_SDD_RETURN_780 = "operations_sepa_sdd_return_780";
	    public static final String OPERATIONS_SEPA_SDD_REJTECH_980 = "operations_sepa_sdd_rejtech_980";
	    
	    //bastid 452/511
	    public static final String SEPA_TABLE_RECALL= "operations_sepa_sct_recall_326";
	    public static final String SEPA_TABLE_REPNEG_RECALL = "operations_sepa_sct_repneg_recall_329";
	    public static final String SEPA_TABLE_SCT_REVERSAL = "operations_sepa_sct_reversal_330";
	    public static final String SEPA_TABLE_RETURN = "operations_sepa_sct_return_720";
	    public static final String SEPA_RETURN_SCT_REVERSAL = "operations_sepa_return_sct_reversal_730";
	    public static final String SEPA_TABLE_SCT_REJTECH = "operations_sepa_sct_rejtech_920";
	    
	    //bastid 501
	    public static final String SEPA_VIREMENT_320 = "operations_sepa_virement_320";
	    public static final String SEPA_PRELEVEMENT_380 = "operations_sepa_prelevement_380";
	    public static final String SEPA_PRELEVEMENT_B2B = "operations_sepa_prelevement_b2b";
	    	    
	    /** Code Operations */
	    //bastid 455
	    public static final String CODE_SDD_B2B_RECALL_387 = "387";
	    public static final String CODE_SDD_B2B_REVERSAL_616 = "616";
	    public static final String CODE_SDD_B2B_REJET_681 = "681";
	    public static final String CODE_SDD_B2B_RETURN_781 = "781";
	    public static final String CODE_SDD_B2B_REJTECH_981 = "981";
	    
	    //bastid 454/512
	    public static final String CODE_SDD_RECALL_386 = "386";
	    public static final String CODE_SDD_REVERSAL_615 = "615";
	    public static final String CODE_SDD_REJET_680 = "680";
	    public static final String CODE_SDD_RETURN_780 = "780";
	    public static final String CODE_SDD_REJTECH_980 = "980";
		
	    //bastid 452/511
	    public static final String CODE_OPE_RECALL="326";
	    public static final String CODE_OPE_REPNEG_RECALL= "329";
	    public static final String CODE_OPE_SCT_REVERSAL = "330";
	    public static final String CODE_OPE_RETURN="720";
	    public static final String CODE_OPE_SCT_RETURN_SCT_REVERSAL= "730";
	    public static final String CODE_OPE_SCT_REJTECH= "920";
	    
	    //BASTID-501
	    public static final String CODE_VIREMENT_320 ="320";
	    public static final String CODE_PRELEVEMENT_380 = "380";
	    public static final String CODE_PRELEVEMENT_B2B = "381";
	    
	    /** 
	     * Constructeur
	     * */
	    public ParseSepaConstant() {
	    	this.sepaTables = new HashMap<String, String>();
	    	
	    	// BASTID-455
	    	this.sepaTables.put(CODE_SDD_B2B_RECALL_387, OPERATIONS_SEPA_SDD_B2B_RECALL_387);
	    	this.sepaTables.put(CODE_SDD_B2B_REVERSAL_616, OPERATIONS_SEPA_SDD_B2B_REVERSAL_616);
	    	this.sepaTables.put(CODE_SDD_B2B_REJET_681, OPERATIONS_SEPA_SDD_B2B_REJET_681);
	    	this.sepaTables.put(CODE_SDD_B2B_RETURN_781, OPERATIONS_SEPA_SDD_B2B_RETURN_781);
	    	this.sepaTables.put(CODE_SDD_B2B_REJTECH_981, OPERATIONS_SEPA_SDD_B2B_REJTECH_981);
	    	
	    	// BASTID-454/512
	    	this.sepaTables.put(CODE_SDD_RECALL_386, OPERATIONS_SEPA_SDD_RECALL_386);
	    	this.sepaTables.put(CODE_SDD_REVERSAL_615, OPERATIONS_SEPA_SDD_REVERSAL_615);
	    	this.sepaTables.put(CODE_SDD_REJET_680, OPERATIONS_SEPA_SDD_REJET_680);
	    	this.sepaTables.put(CODE_SDD_RETURN_780, OPERATIONS_SEPA_SDD_RETURN_780);
	    	this.sepaTables.put(CODE_SDD_REJTECH_980, OPERATIONS_SEPA_SDD_REJTECH_980);
	    	
	    	// BASTID-452/511
	    	this.sepaTables.put(CODE_OPE_RECALL,    SEPA_TABLE_RECALL);
	        this.sepaTables.put(CODE_OPE_REPNEG_RECALL, SEPA_TABLE_REPNEG_RECALL);
	        this.sepaTables.put(CODE_OPE_SCT_REVERSAL, SEPA_TABLE_SCT_REVERSAL);
	        this.sepaTables.put(CODE_OPE_RETURN, SEPA_TABLE_RETURN);
	        this.sepaTables.put(CODE_OPE_SCT_RETURN_SCT_REVERSAL, SEPA_RETURN_SCT_REVERSAL);
	        this.sepaTables.put(CODE_OPE_SCT_REJTECH, SEPA_TABLE_SCT_REJTECH);
	        
	        //BASTID-501
	        this.sepaTables.put(CODE_VIREMENT_320,    SEPA_VIREMENT_320);
	        this.sepaTables.put(CODE_PRELEVEMENT_380, SEPA_PRELEVEMENT_380);
	        this.sepaTables.put(CODE_PRELEVEMENT_B2B, SEPA_PRELEVEMENT_B2B);
	    }



		/**
		 * @return the sepaTables
		 */
		public Map<String, String> getSepaTables() {
			return sepaTables;
		}


		/**
		 * @param sepaTables the sepaTables to set
		 */
		public void setSepaTables(Map<String, String> sepaTables) {
			this.sepaTables = sepaTables;
		}
	      

	     
}


