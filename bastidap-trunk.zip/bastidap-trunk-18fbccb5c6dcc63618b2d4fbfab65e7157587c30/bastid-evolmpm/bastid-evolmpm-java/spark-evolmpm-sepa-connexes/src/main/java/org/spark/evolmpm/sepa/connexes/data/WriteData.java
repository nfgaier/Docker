package org.spark.evolmpm.sepa.connexes.data;

import java.io.Serializable;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.spark.evolmpm.sepa.connexes.constant.ParseSepaConstant;

public class WriteData implements Serializable {

	    /**
		 * 
	    */
		private static final long serialVersionUID = 1478211239019402411L;
		private SparkSession sqlContext;   
		private String idtrt;  
		@SuppressWarnings("unused")
		private String pathDiff;
	
		
		/**
		 * Constructor with parameters 
		 */
		public WriteData(SparkSession sqlContext,  String idtrt, String pathDiff) {
	        super();
	        this.sqlContext = sqlContext;
	        
	        this.idtrt = idtrt;
	        this.pathDiff = pathDiff;
	    }
	
		/**
		 * Write DataFrame as orc file in the HDFS path of the target table Add
		 * partition to target table.
		 * 
		 * @param data
		 */
		public void writeSepaData(Dataset<Row> data, String hdfsTablePath, String tableName) {
			try {
				data.write().partitionBy("id_traitement").format("orc").mode("append").save(hdfsTablePath+"/"+tableName);
				String alterTableStmt = "ALTER TABLE " + ParseSepaConstant.HIVE_WRK_LAYER + "." + tableName
						+ " ADD IF NOT EXISTS PARTITION (id_traitement='" + idtrt + "') "
						+ "location '" + hdfsTablePath+"/"+tableName
						+ "/id_traitement=" + idtrt + "'";
				System.out.println("INFO: " + alterTableStmt);
				sqlContext.sql(alterTableStmt);
			} catch (Exception e) {
				System.out.println("ERROR : " + e);
			}

		}
	 

}

