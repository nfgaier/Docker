/**
 * 
 */
package org.spark.evolmpm.decoupage.minos.constant;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;





public class DecoupageMinosConstant implements Serializable {


	private static final long serialVersionUID = -3313272778272724611L;
	//hive databases
    public static final String HIVE_WRK_LAYER = "evolmpm_work_layer";
    public static final String HIVE_RAW_LAYER = "evolmpm_raw_layer";
    public static final String MINOS_TABLE = "operations_minos";
    public static final String REF_MOTIF_ANNULATION = "operations_minos";
    public static final String REF_PARAM_REPIM = "REF_PARAM_REPIM"; 
    public static final  ArrayList<String> CLIENT_SNCF_CODES = new ArrayList<String>(Arrays.asList("21", "23")) ; 
    public static final  ArrayList<String> REPIM_CODES_REJET = new ArrayList<String>(Arrays.asList("61", "60")) ; 
    public static final  ArrayList<String> REPIM_CARACTERE_1 = new ArrayList<String>(Arrays.asList("8", "9")) ; 
    public static final  ArrayList<String> REPIM_CARACTERE_11 = new ArrayList<String>(Arrays.asList("1", "2")) ; 
    
    @SuppressWarnings("serial")
    public static final HashMap<String, String> MINOS_TABLES = new HashMap<String , String>() {
    	{
        put(CODE_OPE_IC,    MINOS_TABLE_IC);
        put(CODE_OPE_LCR, MINOS_TABLE_LCR);
        put(CODE_OPE_DREC, MINOS_TABLE_DREC);
        put(CODE_OPE_DLCI, MINOS_TABLE_DLCI);
        put(CODE_OPE_VRF, MINOS_TABLE_VRF);
        put(CODE_OPE_ARLCR, MINOS_TABLE_ARLCR);
        put(CODE_OPE_RJT, MINOS_TABLE_RJT);
        put(CODE_OPE_COR, MINOS_TABLE_COR);
        
        put(CODE_OPE_RIC, MINOS_TABLE_RIC);
        put(CODE_OPE_AIC, MINOS_TABLE_AIC);
        put(CODE_OPE_RAIC, MINOS_TABLE_RAIC);
        put(CODE_OPE_ARIC, MINOS_TABLE_ARIC);
        put(CODE_OPE_RARIC, MINOS_TABLE_RARIC);
        put(CODE_OPE_DTC, MINOS_TABLE_DTC);
        put(CODE_OPE_ODR, MINOS_TABLE_ODR);
        put(CODE_OPE_OCR, MINOS_TABLE_OCR);
        put(CODE_OPE_ONC, MINOS_TABLE_ONC);
    }
    	};
    
   
    /** Liste des tables MINOS  */
    public static final String MINOS_TABLE_IC = "operations_minos_ic";
    public static final String MINOS_TABLE_LCR = "operations_minos_lcr";
    public static final String MINOS_TABLE_DREC = "operations_minos_drec";
    public static final String MINOS_TABLE_DLCI = "operations_minos_dlci";
    public static final String MINOS_TABLE_VRF = "operations_minos_vrf";
    public static final String MINOS_TABLE_ARLCR = "operations_minos_arlcr";
    public static final String MINOS_TABLE_RJT = "operations_minos_rjt";
    public static final String MINOS_TABLE_COR = "operations_minos_cor";
    
    public static final String MINOS_TABLE_RIC = "operations_minos_ric";
    public static final String MINOS_TABLE_AIC = "operations_minos_aic";
    public static final String MINOS_TABLE_RAIC = "operations_minos_raic";
    public static final String MINOS_TABLE_ARIC = "operations_minos_aric";
    public static final String MINOS_TABLE_RARIC = "operations_minos_raric";
    public static final String MINOS_TABLE_DTC = "operations_minos_dtc";
    public static final String MINOS_TABLE_ODR = "operations_minos_odr";
    public static final String MINOS_TABLE_OCR = "operations_minos_ocr";
    public static final String MINOS_TABLE_ONC = "operations_minos_onc";
    
    
    /*Liste des code operation */
   
    //LCR
    public static final String CODE_OPE_LCR =   "060";
    public static final String CODE_OPE_DREC=   "062";
    public static final String CODE_OPE_DLCI =  "065";
    public static final String CODE_OPE_VRF=    "069";
    public static final String CODE_OPE_ARLCR = "416";
    public static final String CODE_OPE_RJT=    "460";
    public static final String CODE_OPE_COR =   "469";
    
    //IC
    public static final String CODE_OPE_IC =    "160";
    public static final String CODE_OPE_RIC=    "560";
    public static final String CODE_OPE_AIC =   "420";
    public static final String CODE_OPE_RAIC=   "820";
    public static final String CODE_OPE_ARIC =  "421";
    public static final String CODE_OPE_RARIC=  "821";
    public static final String CODE_OPE_DTC =   "166";  
    public static final String CODE_OPE_ODR =   "167";
    public static final String CODE_OPE_OCR=    "168";
    public static final String CODE_OPE_ONC =   "169"; 
    
    public static final String PROPERTIES_FILE_NAME= "decoupage_minos.properties";
    					
    
}
