/**
 * 
 */
package org.spark.evolmpm.decoupage.minos.data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import static org.apache.spark.sql.functions.col;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.spark.evolmpm.decoupage.minos.constant.DecoupageMinosConstant;

import fr.bdf.bastid.util.bean.LineAcqFile;



public class ReadData implements Serializable {
    
    private static final long serialVersionUID = 1643057746251108370L;
 
    private SparkSession sqlContext;
    private String idTrt;
    private String codeOpe;
	private List<LineAcqFile> listIdAcq;

    /**
     * @param sqlContext
     * @param idTrt
     */
    public ReadData(SparkSession sqlContext, String idTrt, String codeOpe,  List<LineAcqFile> listIdAcq) {
        super();
        this.sqlContext = sqlContext;
        this.idTrt = idTrt;
        this.codeOpe = codeOpe;
        this.listIdAcq = listIdAcq;
    }
    
    /**
     * Reads MINOS_TABLE table data
     * @return DataFrame
     */
    public Dataset<Row> getMinosData() {
    
//    return   sqlContext.table(DecoupageMinosConstant.HIVE_WRK_LAYER+"."+DecoupageMinosConstant.MINOS_TABLE )
//    		.where(col("id_traitement").equalTo(idTrt).and(col("code_operation").equalTo(codeOpe)));
    	
    	return sqlContext.sql("select * from " + DecoupageMinosConstant.HIVE_WRK_LAYER+"."+DecoupageMinosConstant.MINOS_TABLE
    			+ " where code_operation = '"+codeOpe+"' "
    			+ this.getWhereClause(listIdAcq));
    }
    
    
    /**
     * Reads MINOS_TABLE table data
     * @return DataFrame
     */
    public Dataset<Row> getMinosConnexData( String codeOpePos , String refOpePos, int refOpeSize, String typeOpe) {
    	
    return   sqlContext.sql("select * from ("
    						   + " select conn.*, parent.id_operation as id_ope_initiale,parent.date_echange as date_echange_initiale, "
    						   + " row_number() over (partition by conn.id_operation order by parent.id_traitement desc) as dedoubNum "
    		                   + " from "+ DecoupageMinosConstant.HIVE_WRK_LAYER+"."+DecoupageMinosConstant.MINOS_TABLE 
    		                   + " conn left join "+ DecoupageMinosConstant.HIVE_WRK_LAYER+"."+DecoupageMinosConstant.MINOS_TABLE 
    		                   + " parent on substr(conn.zone_operation,"+codeOpePos+",3) = parent.s4_code_ope "
    		                   + " and substr(conn.zone_operation,"+refOpePos+","+ refOpeSize+") = parent.b_"+typeOpe+"_ref_ope "
    		                  + " and REGEXP_REPLACE(trim(parent.b_"+typeOpe+"_ref_ope), '^0+', '') !='' "
    		                   + " where conn.code_operation='"+this.codeOpe+"' "
    		                   + this.getWhereClauseConnexe(listIdAcq)
    		                   + ") as sub where dedoubNum=1 ")   ;
	

    }
    
//	public Dataset<Row> getRefParamRepimIc(Dataset<Row> refParamAgg) {
//     	 RelationalGroupedDataset icRefPerim = refParamAgg.groupBy(col("code_type_client_2c"));
//		return icRefPerim.agg(max(col("montant_limite")).as("montant_limite"));
//	}
	
	
public Dataset<Row> getRefParamRepim() {
		
		Date date = new Date(); 
		int year = Integer.valueOf(String.format("%1$tY",date));
		
		
		System.out.println("annee actuelle "+ year);
		StringBuilder sqlBuilder = new StringBuilder(	
				"select annee_calendrier ,code_type_client_2c,code_type_client_4c,libelle_type_client,montant_limite,date_debut,date_fin,date_representation from ");
		sqlBuilder.append(DecoupageMinosConstant.HIVE_RAW_LAYER);
		sqlBuilder.append(".");
		sqlBuilder.append(DecoupageMinosConstant.REF_PARAM_REPIM);	
		
		sqlBuilder.append(" where  id_traitement in ( select first_value(id_traitement)");
		sqlBuilder
				.append(" over (partition by id_traitement order by id_traitement desc)");
		sqlBuilder.append(" from ");
		sqlBuilder.append(DecoupageMinosConstant.HIVE_RAW_LAYER);
		sqlBuilder.append(".");
		sqlBuilder.append(DecoupageMinosConstant.REF_PARAM_REPIM);	
		sqlBuilder	.append(" ref  where ref.annee_calendrier =   ");
		sqlBuilder	.append(year);
		sqlBuilder.append(" limit 1 )  ");

		String request = sqlBuilder.toString();
		System.out.println("Load REF_PARAM_REPIM request : " + request);
		return sqlContext.sql(request);
		
	}
	
	

/**
 * Method that constructs the where part of the request. 
 * @param listIdAcq the list of id_acquisition / date_ope for FOFA_HIST_MESSAGE
 * @return the where part of the request
 */
private String getWhereClause(List<LineAcqFile> listIdAcq) {
	StringBuilder sb = new StringBuilder(" AND (");
	for (LineAcqFile lineAlerte : listIdAcq) {
		sb.append(" (date_ope = '").append(lineAlerte.getJourFonc())
		.append("' AND id_traitement = '").append(lineAlerte.getIdAcq()).append("') OR");
	}
	
	return sb.substring(0, sb.length() - 3)+" )";
}
	

/**
 * Method that constructs the where part of the request. 
 * @param listIdAcq the list of id_acquisition / date_ope for FOFA_HIST_MESSAGE
 * @return the where part of the request
 */
private String getWhereClauseConnexe(List<LineAcqFile> listIdAcq) {
	StringBuilder sb = new StringBuilder(" AND ( ");
	for (LineAcqFile lineAlerte : listIdAcq) {
		sb.append(" (conn.date_ope = '").append(lineAlerte.getJourFonc())
		.append("' AND conn.id_traitement = '").append(lineAlerte.getIdAcq()).append("') OR");
	}
	
	return sb.substring(0, sb.length() - 3)+" )";
}
	

	
}
