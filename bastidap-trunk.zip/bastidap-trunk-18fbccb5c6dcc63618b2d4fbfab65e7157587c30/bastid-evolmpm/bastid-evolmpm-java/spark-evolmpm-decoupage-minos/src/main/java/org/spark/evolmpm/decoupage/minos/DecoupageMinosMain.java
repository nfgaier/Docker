package org.spark.evolmpm.decoupage.minos;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Date;
import java.util.Properties;


import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.spark.evolmpm.decoupage.minos.constant.DecoupageMinosConstant;
import org.spark.evolmpm.decoupage.minos.data.ReadData;
import org.spark.evolmpm.decoupage.minos.data.WriteData;

import fr.bdf.bastid.util.bean.LineAcqFile;
import fr.bdf.bastid.util.filereader.AcqFileReader;


public class DecoupageMinosMain   implements Serializable {

    private static final long serialVersionUID = -1038992202477473392L;
    
    public static String getTime() {
        return "[" + new SimpleDateFormat("HH:mm:ss" ).format(new Date()) + "] - ";
    }   

    
   
    public static void main( String[] args ) throws IOException {
        
        if(args.length != 4){
            System.out.println("ERROR:" + DecoupageMinosMain.getTime() + " Missing arguments. Usage: " + 
                    new java.io.File(DecoupageMinosMain.class.getProtectionDomain().
                            getCodeSource().
                            getLocation().
                            getPath()).getName() + " <configuration file> "
                    		+ "<id_Trt> "
                    		+ "<property_file_name> "
                    		+ "<path to id acquisition file>");
            System.exit(0);
        }
       
        String pathToConfigFile = args[0];
        String idTrt= args[1];
        String propertyFile = args[2];
		String acqFilePath = args[3];
        
        /** Init configuration and contexts */
        SparkConf conf = new SparkConf();
      	final SparkSession session = SparkSession.builder()
      				.appName("Decoupage_Minos")
      				.config(conf)
      				.config("hive.fetch.task.conversion", "minimal")
      				.config("spark.sql.warehouse.dir", "/apps/hive/warehouse")
      				.config("spark.sql.hive.convertMetastoreOrc", "false")
      				.enableHiveSupport()
      				.getOrCreate();
      	session.sparkContext().hadoopConfiguration().addResource(new Path(pathToConfigFile));

      	
      	// Chargement du fichier contenant les id d'acquisition et constitution de la liste de lignes
 		AcqFileReader afr = new AcqFileReader(acqFilePath);
 		Map<String, List<LineAcqFile>> mapAcqFileLines = getMapAcqFileLines(afr);
		List<LineAcqFile> listIdAcqOpeMinos = mapAcqFileLines.get(DecoupageMinosConstant.MINOS_TABLE.toUpperCase());
      	 
      	
 		
        // Chargement des paramètres à partir du fichier de paramètres
 		Properties filePropertiesReader = new Properties(); 
 		FileInputStream fileProperties = null;
 		
 		// Vérifier si le fichier de paramètres existe et initilialiser le fichier de propriété en java
 		try {
 			fileProperties = new FileInputStream(propertyFile);
 			filePropertiesReader.load(fileProperties);
 		} catch (Exception e) {
 			System.out.println("ERROR:" + DecoupageMinosMain.getTime() + " Fichier de parametres introuvable " );
 			System.exit(1);
		}
 		
 		// Vérifier si le fichier de paramètres est vide
 		if (filePropertiesReader.isEmpty()){
 			System.out.println("ERROR:" + DecoupageMinosMain.getTime() + " Fichier de parametres vide " );
 			System.exit(1);
 		}
     		// Initialisation des variables avec leurs valeurs dans le fichier de paramètres
     		final String listeCodeOpeMinosProp = filePropertiesReader.getProperty("LISTE_CODE_OPE_MINOS") ;
     		final String workHdfsPath = filePropertiesReader.getProperty("WORK_HDFS_PATH") ;
      
     	    Logger.getRootLogger().setLevel(Level.WARN);
     	    List<String> listeCodeOpeMinos = new ArrayList<>() ;
      
           if (StringUtils.isNotBlank(listeCodeOpeMinosProp) && listeCodeOpeMinosProp.contains(",") )
                		  {
        	   				listeCodeOpeMinos= Arrays.asList(listeCodeOpeMinosProp.split(","));
                		  }
                  else {
                	  listeCodeOpeMinos.add(listeCodeOpeMinosProp);
                  }
           
            for (String codeOpe : listeCodeOpeMinos)
                 {
                      System.out.println(codeOpe);
                      //class for reading source data (operations_minos)
                      ReadData reader = new ReadData(session,idTrt,codeOpe,listIdAcqOpeMinos);
                      Dataset<Row> minosTableDF ;
                      String tableCible="";
                    //class for writing to target table
                      WriteData writer = new WriteData(session,idTrt);
                	  //make transformations, select columns in the correct order
                      Dataset<Row> minosDecoupePrepDF =null ;
                      Dataset<Row> refTableDS =null ; 
                 
                      switch (codeOpe) {
                      case DecoupageMinosConstant.CODE_OPE_IC:
                    	  minosTableDF = reader.getMinosData();
                    	  Dataset<Row> icDecoupePrep =  writer.prepareMinosIcData(minosTableDF);
                    	//read data from ref_param_repim table
                    	  if (refTableDS == null )
                    	  { 
                    		  refTableDS = reader.getRefParamRepim(); 
                    	  }     
                          System.out.println("INFO:" + DecoupageMinosMain.getTime() +"refTableDS : " + refTableDS.count());
                     
                          		// refTableDS.printSchema();
                          		//  refTableDS.show();
                          
                          //join the ref_param_repim table and select columns in the correct order
                          minosDecoupePrepDF = writer.joinIcRef(icDecoupePrep, refTableDS);
                          System.out.println("INFO:" + DecoupageMinosMain.getTime() + "minosDecoupePrepDF : " + minosDecoupePrepDF.count());
                          break ;                  
                      case DecoupageMinosConstant.CODE_OPE_RIC:
                    	  if (refTableDS == null )
                    	  { 
                    		  refTableDS = reader.getRefParamRepim(); 
                    	  }
                    	  minosTableDF = reader.getMinosConnexData("393", "469", 24,"ic");
                    	  Dataset<Row> ricDecoupePrep =  writer.prepareMinosRicData(minosTableDF);
                    	  //join the ref_param_repim table and select columns in the correct order
                          minosDecoupePrepDF = writer.joinRicRef(ricDecoupePrep, refTableDS);
                          System.out.println("INFO:" + DecoupageMinosMain.getTime() + "minosDecoupePrepDF : " + minosDecoupePrepDF.count());
                    	  break;
                      case DecoupageMinosConstant.CODE_OPE_AIC:
                    	  System.out.println("Parsing CODE_OPE_AIC");
                    	  minosTableDF = reader.getMinosConnexData("393", "469", 24,"ic");
                    	  minosDecoupePrepDF =  writer.prepareMinosAicData(minosTableDF);
                    	  break;
                      case DecoupageMinosConstant.CODE_OPE_RAIC:
                    	  System.out.println("Parsing CODE_OPE_RAIC");
                    	  minosTableDF = reader.getMinosConnexData("585", "661", 24,"ic");
                    	  minosDecoupePrepDF =  writer.prepareMinosRaicData(minosTableDF);
                    	  break;
                      case DecoupageMinosConstant.CODE_OPE_ARIC:
                     	  System.out.println("Parsing CODE_OPE_ARIC");
                    	  minosTableDF = reader.getMinosConnexData("585", "661", 24,"ic");
                    	  minosDecoupePrepDF =  writer.prepareMinosAricData(minosTableDF);
                    	  break;
                      case DecoupageMinosConstant.CODE_OPE_RARIC:
                     	  System.out.println("Parsing CODE_OPE_RARIC");
                    	  minosTableDF = reader.getMinosConnexData("777", "853", 24,"ic");
                    	  minosDecoupePrepDF =  writer.prepareMinosRaricData(minosTableDF);
                    	  break;
                      case DecoupageMinosConstant.CODE_OPE_DTC:
                       	  System.out.println("Parsing CODE_OPE_DTC");
                    	  minosTableDF = reader.getMinosConnexData("393", "469", 24,"ic");
                    	  minosDecoupePrepDF =  writer.prepareMinosDtcData(minosTableDF);
                    	  break;
                      case DecoupageMinosConstant.CODE_OPE_ODR:
                       	  System.out.println("Parsing CODE_OPE_ODR");
                    	  minosTableDF = reader.getMinosConnexData("393", "469", 24,"ic");
                    	  minosDecoupePrepDF =  writer.prepareMinosOdrData(minosTableDF);
                    	  break;
                      case DecoupageMinosConstant.CODE_OPE_OCR:
                       	  System.out.println("Parsing CODE_OPE_OCR");
                    	  minosTableDF = reader.getMinosConnexData("393", "469", 24,"ic");
                    	  minosDecoupePrepDF =  writer.prepareMinosOcrData(minosTableDF);
                    	  break;
                      case DecoupageMinosConstant.CODE_OPE_ONC:
                       	  System.out.println("Parsing CODE_OPE_ONC");
                    	  minosTableDF = reader.getMinosConnexData("393", "469", 24,"ic");
                    	  minosDecoupePrepDF =  writer.prepareMinosOncData(minosTableDF);
                    	  break;
                      case DecoupageMinosConstant.CODE_OPE_LCR:
                    	  minosTableDF = reader.getMinosData();
                    	  minosDecoupePrepDF =  writer.prepareMinosLcrData(minosTableDF);
                          break ;
                      case DecoupageMinosConstant.CODE_OPE_DREC:
                    	  minosTableDF = reader.getMinosConnexData("137","213", 16,"lcr");
                    	  minosDecoupePrepDF =  writer.prepareMinosDrecData(minosTableDF);
                          // minosDecoupePrepDF.printSchema();
                    	  //   minosDecoupePrepDF.show();
                    	  break ;
                      case DecoupageMinosConstant.CODE_OPE_DLCI:
                    	  minosTableDF = reader.getMinosConnexData("265","341", 16,"lcr");
                    	  minosDecoupePrepDF =  writer.prepareMinosDlciData(minosTableDF);
                          break ;
                      case DecoupageMinosConstant.CODE_OPE_VRF:
                    	  minosTableDF = reader.getMinosData();
                    	  minosDecoupePrepDF =  writer.prepareMinosVrfData(minosTableDF);
                    	  break ;
                      case DecoupageMinosConstant.CODE_OPE_ARLCR:
                    	  minosTableDF = reader.getMinosConnexData("265","341", 16,"lcr");
                    	  minosDecoupePrepDF =  writer.prepareMinosArlcrData(minosTableDF);
                    	  break ;
                      case DecoupageMinosConstant.CODE_OPE_RJT:
                    	  minosTableDF = reader.getMinosConnexData("137","213", 16,"lcr");
                    	  minosDecoupePrepDF =  writer.prepareMinosRjtData(minosTableDF);
                          break ;
                      case DecoupageMinosConstant.CODE_OPE_COR:
                      	  minosTableDF = reader.getMinosConnexData("265","341", 16,"lcr" );
                    	  minosDecoupePrepDF =  writer.prepareMinosCorData(minosTableDF);
                          break ;
                    	  
                      default:
                        System.out.println("ERROR:" + DecoupageMinosMain.getTime() + " Code opération invalide : "+ codeOpe);
               			System.exit(1);
                  }
                      //write to target table operations_minos_****
                      tableCible= DecoupageMinosConstant.MINOS_TABLES.get(codeOpe);
                      writer.writeMinosData(minosDecoupePrepDF,workHdfsPath+"/"+tableCible,tableCible);  
                  }       
         
    }
    

	/**
	 * Method that gets the acquisition ids needed for the treatment.
	 * 
	 * @param afr
	 *            the acquisition file reader
	 * @return the map that contains the acquisition ids needed for the
	 *         treatment
	 */
	private static Map<String, List<LineAcqFile>> getMapAcqFileLines(
			AcqFileReader afr) {
		Map<String, List<LineAcqFile>> mapAcqFileLines = null;
		try {
			mapAcqFileLines = afr.getAcqFileLines();
		} catch (IOException e) {
			Logger.getRootLogger().error(
					"An error occured when reading the file", e);
			System.exit(0);
		}

		if (mapAcqFileLines == null || mapAcqFileLines.isEmpty()) {
			Logger.getRootLogger().error(
					"The acquisition id map is null or empty");
			System.exit(0);
		}
		return mapAcqFileLines;
	}
}
