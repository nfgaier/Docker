/**
 * 
 */
package org.spark.evolmpm.decoupage.minos.data;

import static org.apache.spark.sql.functions.callUDF;
import static org.apache.spark.sql.functions.col;
import static org.apache.spark.sql.functions.trim;
import static org.apache.spark.sql.functions.concat;
import static org.apache.spark.sql.functions.regexp_replace;

import static org.apache.spark.sql.functions.when;

import static org.apache.spark.sql.functions.not;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import org.apache.spark.sql.Dataset;

import org.apache.spark.sql.RelationalGroupedDataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.api.java.UDF2;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Decimal;
import org.spark.evolmpm.decoupage.minos.constant.DecoupageMinosConstant;

import static org.apache.spark.sql.functions.lit;
import static org.apache.spark.sql.functions.max;

public class WriteData implements Serializable {

	private static final long serialVersionUID = -789223906365051372L;

	private SparkSession sqlContext;
	private String idtrt;

	/**
	 * @param sqlContext
	 * @param idtrt
	 */
	public WriteData(SparkSession sqlContext, String idtrt) {
		super();
		this.sqlContext = sqlContext;
		this.idtrt = idtrt;
		this.sqlContext.udf().register("fromString6toDate", fromString6toDate, DataTypes.DateType);
		this.sqlContext.udf().register("fromString8toDate", fromString8toDate, DataTypes.DateType);
		this.sqlContext.udf().register("fromStingToDouble", fromStingToDouble, DataTypes.createDecimalType(18, 4));
		this.sqlContext.udf().register("fromStringtoInteger", fromStringtoInteger, DataTypes.IntegerType);
	}

	/**
	 * Extract from the currency code (ex EUR2) the last character Use it to
	 * adjust the floating point of the commission by dividing the commission by
	 * 10^2 (for EUR2)
	 * 
	 * @param input
	 * @return Double
	 */
	UDF2<String, String, Decimal> fromStingToDouble = new UDF2<String, String, Decimal>() {

		private static final long serialVersionUID = 3853112536644776225L;

		public Decimal call(final String comm, final String dev) throws Exception {
			if (StringUtils.isNotBlank(comm)  && StringUtils.isNotBlank(dev) && dev.length() == 4) {
				String tmpfactor = dev.substring(3).trim();
				try {
					//Double factor = Math.pow(10, Integer.parseInt(tmpfactor));
					Double commTmp = Double.parseDouble(comm.trim());
					// Double res = new Double(commTmp/factor);
					Decimal retdec = new Decimal();
					retdec.set(commTmp.longValue(), 18, Integer.parseInt(tmpfactor));
					return retdec;

				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			} else {
				return null;
			}
		}
	};

	/**
	 * Format an 6 character string YYMMDD to an java.sql.Date
	 * 
	 * @param input
	 * @return java.sql.Date
	 */
	UDF1<String, java.sql.Date> fromString6toDate = new UDF1<String, java.sql.Date>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 4843964641492910743L;

		public java.sql.Date call(final String input) throws Exception {
			if (input != null && input.trim() != null && input.trim().length() == 6) {

				SimpleDateFormat format = new SimpleDateFormat("yyMMdd");
				format.setLenient(Boolean.FALSE);
				try {
					java.util.Date date = format.parse(input.trim());
					return new java.sql.Date(date.getTime());
				} catch (ParseException e) {
					e.printStackTrace();
					return null;
				}
			} else {
				return null;
			}
		}
	};

	/**
	 * Format an 8 character string YYYYMMDD to an java.sql.Date
	 * 
	 * @param input
	 * @return java.sql.Date
	 */
	UDF1<String, java.sql.Date> fromString8toDate = new UDF1<String, java.sql.Date>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = -3081231781260404228L;

		public java.sql.Date call(final String input) throws Exception {
			if (input != null && input.trim() != null && input.trim().length() == 8) {

				SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
				format.setLenient(Boolean.FALSE);
				try {
					java.util.Date date = format.parse(input.trim());
					return new java.sql.Date(date.getTime());
				} catch (ParseException e) {
					e.printStackTrace();
					return null;
				}
			} else {
				return null;
			}
		}
	};

	/**
	 * Use parseInt to trim the leading 0s from a string (ex. 0000002)
	 * 
	 * @param input
	 * @return Integer
	 */
	UDF1<String, Integer> fromStringtoInteger = new UDF1<String, Integer>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 3853112536644776225L;

		public Integer call(final String input) throws Exception {
			// if (input != null && input.trim() != null) {
			if (StringUtils.isNotBlank(input)) {
				try {
					return Integer.parseInt(input.trim());
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			} else {
				return null;
			}
		}
	};

	

	/**
	 * @param v1
	 * @return
	 * @throws Exception
	 */
	public List<Object> dsToList(Dataset<Row> v1)  {

		ArrayList<Object> list = new ArrayList<Object>();
		
		for ( Row r : v1.collectAsList()) {
			list.add(lit(r.getAs("code_type_client_2c").toString()));
		}
		
		return list;
	}
	
	
	/**
	 * Apply transformations to the source data Sort columns before insertion in
	 * target table
	 * 
	 * @param data
	 * @return DataFrame
	 */
	public Dataset<Row> prepareMinosIcData(Dataset<Row> data) {

				return data.select(col("id_operation"), col("rio"), col("ref_operation"), col("code_operation").as("code_ope"),
				col("id_type_operation").as("id_type_ope"), col("code_famille_operation"), col("type_operation"),
				col("sens_echange"), col("systeme_echange"), col("date_echange"), col("date_reglement"),
				col("date_traitement_aval_recu"), col("delai_reglement_ope"), col("date_pec_amont"), col("num_remise"),
				col("num_remise_tech"), col("mnt_compense_sit"), col("date_presentation_remise"),
				col("code_client_conventionne"), col("id_client"), col("code_grp_remettant"), col("lib_grp_remettant"),
				col("id_compte_do"), col("bic_do").as("guichet_do"), col("iban_do"), col("code_pays_do"),
				col("cle_iban_do"), col("code_banque_do"), col("code_guichet_do"), col("num_cpte_do"),
				col("cle_rib_do"), col("id_compte_dest"), col("bic_dest").as("guichet_dest"), col("iban_dest"),
				col("code_pays_dest"), col("cle_iban_dest"), col("code_banque_dest"), col("code_guichet_dest"),
				col("num_cpte_dest"), col("cle_rib_dest"), col("etblt_concerne"), col("num_partition"),
				col("code_flux_arch"), col("ind_connexe"), col("zone_operation"), col("date_comptable_evolmpm"),
				col("flag_debrayage_embargo"), col("xtimts"), col("s2_long_ope"), col("s3_code_article"),
				col("s4_code_ope"), col("s5_type_id_do"), col("s6_id_etblt_do"), col("s7_type_id_dest"),
				col("s8_id_etblt_dest"), col("s9_critere_rout_secondaire"), col("s10_code_devise"),
				col("s11_mnt_compense"), col("s12_date_reglement_demande"), col("s13_ind_modif_ddr"),
				col("s14_code_commission"), col("s15_commission_interbancaire"), col("s16_zone_reservee_declaration"),
				col("s17_code_anomalie"), col("s18_zone_reservee"), col("b_ic_sous_code_ope"), col("b_ic_ref_ope"),
				col("b_ic_zone_banquier_remettant"), col("b_ic_num_cheque_cmc7_4"),
				col("b_ic_zone_interbancaire_cmc7_3"), col("b_ic_zone_interieure_cmc7_2"),
				col("b_ic_ind_balance_paiement"), col("b_ic_zone_usage_etblmt"), col("b_ic_indice_circulation"),
				col("b_ic_ind_cepc_concerne"), col("b_ic_zone_reservee_ic"),
				trim(col("b_ic_zone_banquier_remettant").substr(2, 3)).as("code_guichet_gestionnaire"),
				trim(col("b_ic_zone_banquier_remettant").substr(5, 10)).as("compte_encaissement"),
				trim(col("b_ic_zone_banquier_remettant").substr(15, 2)).as("code_type_client"),
				trim(col("b_ic_zone_banquier_remettant").substr(20, 1)).as("delai_credit"),
				trim(col("b_ic_zone_banquier_remettant").substr(21, 7)).as("numero_tr"),
				
				trim(col("b_ic_zone_banquier_remettant").substr(5, 3)).as("code_guichet_encaissement"),
				trim(col("b_ic_zone_banquier_remettant").substr(3, 5)).as("code_guichet_encaissement_a"),
				trim(col("b_ic_zone_banquier_remettant").substr(8,7)).as("compte_encaissement_client"),
				trim(concat(lit("0000"),col("b_ic_zone_banquier_remettant").substr(8,7))).as("compte_encaissement_client_a"),
				trim(col("b_ic_zone_banquier_remettant").substr(17,3)).as("code_guichet_remise"),
				trim(col("b_ic_zone_banquier_remettant").substr(28,1)).as("indice_circulation"),
				
				callUDF("fromStingToDouble", col("b_ic_zone_banquier_remettant").substr(39, 12),
						lit("0002")).as("montant_tr"),
				
				trim(col("b_ic_ref_ope").substr(1, 1)).as("application_emettrice"),
				trim(col("b_ic_ref_ope").substr(2, 3)).as("guichet_refop"),
				trim(col("b_ic_ref_ope").substr(5, 3)).as("centre_archivage"),
				trim(col("b_ic_ref_ope").substr(8, 3)).as("guichet_remise"),
				trim(col("b_ic_ref_ope").substr(11, 1)).as("indice_generation"),
				trim(col("b_ic_ref_ope").substr(1, 17)).as("ref_op_debut"),
				col("date_insert"),col("date_ope").as("date_ope") )
				.withColumn("ref_ope_origine",
						     when(col("ref_operation").substr(1, 1).isin(DecoupageMinosConstant.REPIM_CARACTERE_1.toArray()).and(col("ref_operation").substr(11, 1).isin(DecoupageMinosConstant.REPIM_CARACTERE_11.toArray())), regexp_replace(col("ref_operation"), "(^.)(.{9})(.)","0$20"))
								.otherwise(col("ref_operation"))
						    )
				.withColumn("id_traitement",lit(idtrt))
              ;

	}

	
	 public Dataset<Row> joinIcRef(Dataset<Row> minosDecoupPrep, Dataset<Row> refTableDF){
	  	 RelationalGroupedDataset icRefPerim = refTableDF.groupBy(col("code_type_client_2c"));
	  	 Dataset<Row> dataRefAgg = icRefPerim.agg(max(col("montant_limite")).as("montant_limite"));

	  	 Dataset<Row> dataTemp = minosDecoupPrep.join(
		    		dataRefAgg,
					minosDecoupPrep
							.col("code_type_client")
							.equalTo(dataRefAgg.col("code_type_client_2c"))
							.and(minosDecoupPrep.col("s11_mnt_compense").$less$eq(dataRefAgg.col("montant_limite"))
									.or(dataRefAgg.col("montant_limite").isNull()))
							,
					"left").persist();
	    	
	    	//return in the same order as the target tables columns
			Dataset<Row> dataFinal = 
			dataTemp.select(col("id_operation"), col("rio"), col("ref_operation"), col("code_ope"),
			col("id_type_ope"), col("code_famille_operation"), col("type_operation"),
			col("sens_echange"), col("systeme_echange"), col("date_echange"), col("date_reglement"),
			col("date_traitement_aval_recu"), col("delai_reglement_ope"), col("date_pec_amont"), col("num_remise"),
			col("num_remise_tech"), col("mnt_compense_sit"), col("date_presentation_remise"),
			col("code_client_conventionne"), col("id_client"), col("code_grp_remettant"), col("lib_grp_remettant"),
			col("id_compte_do"), col("guichet_do"), col("iban_do"), col("code_pays_do"),
			col("cle_iban_do"), col("code_banque_do"), col("code_guichet_do"), col("num_cpte_do"),
			col("cle_rib_do"), col("id_compte_dest"), col("guichet_dest"), col("iban_dest"),
			col("code_pays_dest"), col("cle_iban_dest"), col("code_banque_dest"), col("code_guichet_dest"),
			col("num_cpte_dest"), col("cle_rib_dest"), col("etblt_concerne"), col("num_partition"),
			col("code_flux_arch"), col("ind_connexe"), col("zone_operation"), col("date_comptable_evolmpm"),
			col("flag_debrayage_embargo"), col("xtimts"), col("s2_long_ope"), col("s3_code_article"),
			col("s4_code_ope"), col("s5_type_id_do"), col("s6_id_etblt_do"), col("s7_type_id_dest"),
			col("s8_id_etblt_dest"), col("s9_critere_rout_secondaire"), col("s10_code_devise"),
			col("s11_mnt_compense"), col("s12_date_reglement_demande"), col("s13_ind_modif_ddr"),
			col("s14_code_commission"), col("s15_commission_interbancaire"), col("s16_zone_reservee_declaration"),
			col("s17_code_anomalie"), col("s18_zone_reservee"), col("b_ic_sous_code_ope"), col("b_ic_ref_ope"),
			col("b_ic_zone_banquier_remettant"), col("b_ic_num_cheque_cmc7_4"),
			col("b_ic_zone_interbancaire_cmc7_3"), col("b_ic_zone_interieure_cmc7_2"),
			col("b_ic_ind_balance_paiement"), col("b_ic_zone_usage_etblmt"), col("b_ic_indice_circulation"),
			col("b_ic_ind_cepc_concerne"), col("b_ic_zone_reservee_ic"),
			col("code_guichet_gestionnaire"),
			col("compte_encaissement"),
			col("code_type_client"),
			col("delai_credit"),
			col("numero_tr"),
			col("application_emettrice"),
			col("guichet_refop"),
			col("centre_archivage"),
			col("guichet_remise"),
			col("indice_generation"),col("ref_op_debut"),
			col("date_insert"), 
			col("date_ope").as("date_ope"),
			col("id_traitement"),
			col("code_type_client_2c"),
			col("ref_ope_origine"),
			col("code_guichet_encaissement"),
			col("code_guichet_encaissement_a"),
			col("compte_encaissement_client"),
			col("compte_encaissement_client_a"),
			col("code_guichet_remise"),
			col("indice_circulation"),
			col("montant_tr"),
			trim(concat(col("code_guichet_encaissement_a"),col("compte_encaissement_client_a"))).as("compte_encaissement_a")
			)
			.withColumn("flag_repim",
					when(col("code_type_client_2c").isNotNull(),
								when(col("ref_operation").substr(1, 1).isin(DecoupageMinosConstant.REPIM_CARACTERE_1.toArray()), lit("O")).otherwise(lit("N")))
					.otherwise(lit("N")))
			.withColumn("num_representation",
					when(col("code_type_client_2c").isNotNull(),
							when(col("ref_operation").substr(1, 1).isin(DecoupageMinosConstant.REPIM_CARACTERE_1.toArray()), col("ref_operation").substr(11, 1).cast(DataTypes.IntegerType)).otherwise(lit(null).cast(DataTypes.IntegerType)))
					.otherwise(lit(null).cast(DataTypes.IntegerType)))
			;
			
	
			return 
					dataFinal.select(col("id_operation"), col("rio"), col("ref_operation"), col("code_ope"),
					col("id_type_ope"), col("code_famille_operation"), col("type_operation"),
					col("sens_echange"), col("systeme_echange"), col("date_echange"), col("date_reglement"),
					col("date_traitement_aval_recu"), col("delai_reglement_ope"), col("date_pec_amont"), col("num_remise"),
					col("num_remise_tech"), col("mnt_compense_sit"), col("date_presentation_remise"),
					col("code_client_conventionne"), col("id_client"), col("code_grp_remettant"), col("lib_grp_remettant"),
					col("id_compte_do"), col("guichet_do"), col("iban_do"), col("code_pays_do"),
					col("cle_iban_do"), col("code_banque_do"), col("code_guichet_do"), col("num_cpte_do"),
					col("cle_rib_do"), col("id_compte_dest"), col("guichet_dest"), col("iban_dest"),
					col("code_pays_dest"), col("cle_iban_dest"), col("code_banque_dest"), col("code_guichet_dest"),
					col("num_cpte_dest"), col("cle_rib_dest"), col("etblt_concerne"), col("num_partition"),
					col("code_flux_arch"), col("ind_connexe"), col("zone_operation"), col("date_comptable_evolmpm"),
					col("flag_debrayage_embargo"), col("xtimts"), col("s2_long_ope"), col("s3_code_article"),
					col("s4_code_ope"), col("s5_type_id_do"), col("s6_id_etblt_do"), col("s7_type_id_dest"),
					col("s8_id_etblt_dest"), col("s9_critere_rout_secondaire"), col("s10_code_devise"),
					col("s11_mnt_compense"), col("s12_date_reglement_demande"), col("s13_ind_modif_ddr"),
					col("s14_code_commission"), col("s15_commission_interbancaire"), col("s16_zone_reservee_declaration"),
					col("s17_code_anomalie"), col("s18_zone_reservee"), col("b_ic_sous_code_ope"), col("b_ic_ref_ope"),
					col("b_ic_zone_banquier_remettant"), col("b_ic_num_cheque_cmc7_4"),
					col("b_ic_zone_interbancaire_cmc7_3"), col("b_ic_zone_interieure_cmc7_2"),
					col("b_ic_ind_balance_paiement"), col("b_ic_zone_usage_etblmt"), col("b_ic_indice_circulation"),
					col("b_ic_ind_cepc_concerne"), col("b_ic_zone_reservee_ic"),col("code_guichet_gestionnaire"),
					col("code_type_client"),
					col("code_guichet_encaissement"),
					col("code_guichet_encaissement_a"),
					col("compte_encaissement_client"),
					col("compte_encaissement_client_a"),
					col("compte_encaissement"),
					col("compte_encaissement_a"),
					col("code_guichet_remise"),
					col("delai_credit"),
					col("numero_tr"),
					col("indice_circulation"),
					col("montant_tr"),
					col("application_emettrice"),
					col("guichet_refop"),
					col("centre_archivage"),
					col("guichet_remise"),
					col("indice_generation"),
					col("ref_op_debut"),col("flag_repim"),col("ref_ope_origine"),col("num_representation"),
					col("date_insert"), 
					col("date_ope").as("date_ope"),
					col("id_traitement")
					)
			;
		}
	
	
	
	 
	 
	/**
	 * Apply transformations to the source data LCR Sort columns before
	 * insertion in target table
	 * 
	 * @param data
	 * @return DataFrame
	 */
	public Dataset<Row> prepareMinosLcrData(Dataset<Row> data) {

		return data.select(col("id_operation"), col("rio"), col("ref_operation"), col("code_operation"),
				col("id_type_operation"), col("code_famille_operation"), col("type_operation"), col("sens_echange"),
				col("systeme_echange"), col("date_echange"), col("date_reglement"), col("date_traitement_aval_recu"),
				col("delai_reglement_ope"), col("date_pec_amont"), col("num_remise"), col("num_remise_tech"),
				col("mnt_compense_sit"), col("date_presentation_remise"), col("code_client_conventionne"),
				col("id_client"), col("code_grp_remettant"), col("lib_grp_remettant"), col("id_compte_do"),
				col("bic_do"), col("iban_do"), col("code_pays_do"), col("cle_iban_do"), col("code_banque_do"),
				col("code_guichet_do"), col("num_cpte_do"), col("cle_rib_do"), col("id_compte_dest"), col("bic_dest"),
				col("iban_dest"), col("code_pays_dest"), col("cle_iban_dest"), col("code_banque_dest"),
				col("code_guichet_dest"), col("num_cpte_dest"), col("cle_rib_dest"), col("etblt_concerne"),
				col("num_partition"), col("code_flux_arch"), col("ind_connexe"), col("zone_operation"),
				col("date_comptable_evolmpm"), col("flag_debrayage_embargo"), col("xtimts"), col("s2_long_ope"),
				col("s3_code_article"), col("s4_code_ope"), col("s5_type_id_do"), col("s6_id_etblt_do"),
				col("s7_type_id_dest"), col("s8_id_etblt_dest"), col("s9_critere_rout_secondaire"),
				col("s10_code_devise"), col("s11_mnt_compense"), col("s12_date_reglement_demande"),
				col("s13_ind_modif_ddr"), col("s14_code_commission"), col("s15_commission_interbancaire"),
				col("s16_zone_reservee_declaration"), col("s17_code_anomalie"), col("s18_zone_reservee"),
				col("b_lcr_sous_code_ope"), col("b_lcr_ref_ope"), col("b_lcr_presentateur"),
				col("b_lcr_coord_client_cedant"), col("b_lcr_coord_client_tire"), col("b_lcr_nom_tireur"),
				col("b_lcr_date_echeance"), col("b_lcr_date_creation"), col("b_lcr_date_entree_ptf"),
				col("b_lcr_zone_reservee_1"), col("b_lcr_nom_tire"), col("b_lcr_acceptation"), col("b_lcr_code_entree"),
				col("b_lcr_ref_tireur"), col("b_lcr_ref_tire"), col("b_lcr_num_siren_tireur"),
				col("b_lcr_zone_reservee_2"), col("b_lcr_lib_domicil"), col("b_lcr_zone_reservee_3"),
				col("b_lcr_ind_balance_paiments"), col("b_lcr_zone_reservee_4"), 
				 col("date_insert"), col("date_ope").as("date_ope"))
				.withColumn("id_traitement",lit(idtrt));
	}

	/**
	 * Apply transformations to the source data DREC
	 * 
	 * @param data
	 * @return DataFrame
	 */
	public Dataset<Row> prepareMinosDrecData(Dataset<Row> data) {
		// transform data
		return data.select(col("id_operation").as("id_ope_connexe"), col("id_ope_initiale"), col("rio"),
				col("ref_operation"), col("code_operation"), col("id_type_operation"), col("code_famille_operation"),
				col("type_operation"), col("sens_echange"), col("systeme_echange"), col("date_echange"),
				col("date_reglement"), col("date_traitement_aval_recu"), col("delai_reglement_ope"),
				col("date_pec_amont"), col("num_remise"), col("num_remise_tech"), col("mnt_compense_sit"),
				col("date_presentation_remise"), col("code_client_conventionne"), col("id_client"),
				col("code_grp_remettant"), col("lib_grp_remettant"), col("id_compte_do"), col("bic_do"), col("iban_do"),
				col("code_pays_do"), col("cle_iban_do"), col("code_banque_do"), col("code_guichet_do"),
				col("num_cpte_do"), col("cle_rib_do"), col("id_compte_dest"), col("bic_dest"), col("iban_dest"),
				col("code_pays_dest"), col("cle_iban_dest"), col("code_banque_dest"), col("code_guichet_dest"),
				col("num_cpte_dest"), col("cle_rib_dest"), col("etblt_concerne"), col("num_partition"),
				col("code_flux_arch"), col("ind_connexe"), col("zone_operation"), col("date_comptable_evolmpm"),
				col("flag_debrayage_embargo"), col("xtimts"), col("s2_long_ope"), col("s3_code_article"),
				col("s4_code_ope"), col("s5_type_id_do"), col("s6_id_etblt_do"), col("s7_type_id_dest"),
				col("s8_id_etblt_dest"), col("s9_critere_rout_secondaire"), col("s10_code_devise"),
				col("s11_mnt_compense"), col("s12_date_reglement_demande"), col("s13_ind_modif_ddr"),
				col("s14_code_commission"), col("s15_commission_interbancaire"), col("s16_zone_reservee_declaration"),
				col("s17_code_anomalie"), col("s18_zone_reservee"), col("b_drec_code_motif"), col("b_drec_ref_ope"),
				col("b_drec_ref_presentateur"), col("b_drec_zone_reservee"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(131, 4)).as("oi_s2_long_ope"),
				trim(col("zone_operation").substr(135, 2)).as("oi_s3_code_article"),
				trim(col("zone_operation").substr(137, 3)).as("oi_s4_code_ope"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(140, 1)).as("oi_s5_type_id_do"),
				trim(col("zone_operation").substr(141, 7)).as("oi_s6_id_etblt_do"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(148, 1)).as("oi_s7_type_id_dest"),
				trim(col("zone_operation").substr(149, 7)).as("oi_s8_id_etblt_dest"),
				trim(col("zone_operation").substr(156, 5)).as("oi_s9_critere_rout_secondaire"),
				trim(col("zone_operation").substr(161, 4)).as("oi_s10_code_devise"),
				// transformer le montant en double en prenant en compte le
				// nombre de décimales contenue dans le champ devise
				callUDF("fromStingToDouble", col("zone_operation").substr(165, 16),
						col("zone_operation").substr(161, 4)).as("oi_s11_mnt_compense"),
				callUDF("fromString6toDate", col("zone_operation").substr(181, 6)).as("oi_s12_date_reglement_demande"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(187, 1)).as("oi_s13_ind_modif_ddr"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(188, 1)).as("oi_s14_code_commission"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(189, 6))
						.as("oi_s15_commission_interbancaire"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(195, 1))
						.as("oi_s16_zone_reservee_declaration"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(196, 2)).as("oi_s17_code_anomalie"),
				trim(col("zone_operation").substr(198, 11)).as("oi_s18_zone_reservee"),
				trim(col("zone_operation").substr(209, 4)).as("oi_b_lcr_sous_code_ope"),
				trim(col("zone_operation").substr(213, 16)).as("oi_b_lcr_ref_ope"),
				trim(col("zone_operation").substr(229, 10)).as("oi_b_lcr_presentateur"),
				trim(col("zone_operation").substr(239, 16)).as("oi_b_lcr_coord_client_cedant"),
				trim(col("zone_operation").substr(255, 14)).as("oi_b_lcr_coord_client_tire"),
				trim(col("zone_operation").substr(269, 24)).as("oi_b_lcr_nom_tireur"),
				callUDF("fromString6toDate", col("zone_operation").substr(293, 6)).as("oi_b_lcr_date_echeance"),
				callUDF("fromString6toDate", col("zone_operation").substr(299, 6)).as("oi_b_lcr_date_creation"),
				callUDF("fromString6toDate", col("zone_operation").substr(305, 6)).as("oi_b_lcr_date_entree_ptf"),
				trim(col("zone_operation").substr(311, 10)).as("oi_b_lcr_zone_reservee_1"),
				trim(col("zone_operation").substr(321, 24)).as("oi_b_lcr_nom_tire"),
				trim(col("zone_operation").substr(345, 1)).as("oi_b_lcr_acceptation"),
				trim(col("zone_operation").substr(346, 1)).as("oi_b_lcr_code_entree"),
				trim(col("zone_operation").substr(347, 10)).as("oi_b_lcr_ref_tireur"),
				trim(col("zone_operation").substr(357, 10)).as("oi_b_lcr_ref_tire"),
				trim(col("zone_operation").substr(367, 15)).as("oi_b_lcr_num_siren_tireur"),
				trim(col("zone_operation").substr(382, 3)).as("oi_b_lcr_zone_reservee_2"),
				trim(col("zone_operation").substr(385, 24)).as("oi_b_lcr_lib_domicil"),
				trim(col("zone_operation").substr(409, 13)).as("oi_b_lcr_zone_reservee_3"),
				trim(col("zone_operation").substr(422, 1)).as("oi_b_lcr_ind_balance_paiments"),
				trim(col("zone_operation").substr(423, 26)).as("oi_b_lcr_zone_reservee_4"), 
				col("date_insert"), col("date_ope").as("date_ope"))
				.withColumn("id_traitement",lit(idtrt));
	}

	/*
	 * Apply transformations to the source data DREC
	 * 
	 * @param data
	 * 
	 * @return DataFrame
	 */
	public Dataset<Row> prepareMinosDlciData(Dataset<Row> data) {
		// transform data
		return data.select(col("id_operation").as("id_ope_connexe"), col("id_ope_initiale"), col("rio"),
				col("ref_operation"), col("code_operation"), col("id_type_operation"), col("code_famille_operation"),
				col("type_operation"), col("sens_echange"), col("systeme_echange"), col("date_echange"),
				col("date_reglement"), col("date_traitement_aval_recu"), col("delai_reglement_ope"),
				col("date_pec_amont"), col("num_remise"), col("num_remise_tech"), col("mnt_compense_sit"),
				col("date_presentation_remise"), col("code_client_conventionne"), col("id_client"),
				col("code_grp_remettant"), col("lib_grp_remettant"), col("id_compte_do"), col("bic_do"), col("iban_do"),
				col("code_pays_do"), col("cle_iban_do"), col("code_banque_do"), col("code_guichet_do"),
				col("num_cpte_do"), col("cle_rib_do"), col("id_compte_dest"), col("bic_dest"), col("iban_dest"),
				col("code_pays_dest"), col("cle_iban_dest"), col("code_banque_dest"), col("code_guichet_dest"),
				col("num_cpte_dest"), col("cle_rib_dest"), col("etblt_concerne"), col("num_partition"),
				col("code_flux_arch"), col("ind_connexe"), col("zone_operation"), col("date_comptable_evolmpm"),
				col("flag_debrayage_embargo"), col("xtimts"), col("s2_long_ope"), col("s3_code_article"),
				col("s4_code_ope"), col("s5_type_id_do"), col("s6_id_etblt_do"), col("s7_type_id_dest"),
				col("s8_id_etblt_dest"), col("s9_critere_rout_secondaire"), col("s10_code_devise"),
				col("s11_mnt_compense"), col("s12_date_reglement_demande"), col("s13_ind_modif_ddr"),
				col("s14_code_commission"), col("s15_commission_interbancaire"), col("s16_zone_reservee_declaration"),
				col("s17_code_anomalie"), col("s18_zone_reservee"), col("b_dlci_zone_reservee_1"),
				col("b_dlci_ref_ope"), col("b_dlci_ref_presentateur"), col("b_dlci_zone_reservee_2"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(131, 4)).as("rjt_s2_long_ope"),
				trim(col("zone_operation").substr(135, 2)).as("rjt_s3_code_article"),
				trim(col("zone_operation").substr(137, 3)).as("rjt_s4_code_ope"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(140, 1)).as("rjt_s5_type_id_do"),
				trim(col("zone_operation").substr(141, 7)).as("rjt_s6_id_etblt_do"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(148, 1)).as("rjt_s7_type_id_dest"),
				trim(col("zone_operation").substr(149, 7)).as("rjt_s8_id_etblt_dest"),
				trim(col("zone_operation").substr(156, 5)).as("rjt_s9_critere_rout_secondaire"),
				trim(col("zone_operation").substr(161, 4)).as("rjt_s10_code_devise"),
				// transformer le montant en double en prenant en compte le
				// nombre de décimales contenue dans le champ devise
				callUDF("fromStingToDouble", col("zone_operation").substr(165, 16),
						col("zone_operation").substr(161, 4)).as("rjt_s11_mnt_compense"),
				callUDF("fromString6toDate", col("zone_operation").substr(181, 6)).as("rjt_s12_date_reglement_demande"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(187, 1)).as("rjt_s13_ind_modif_ddr"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(188, 1)).as("rjt_s14_code_commission"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(189, 6))
						.as("rjt_s15_commission_interbancaire"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(195, 1))
						.as("rjt_s16_zone_reservee_declaration"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(196, 2)).as("rjt_s17_code_anomalie"),
				trim(col("zone_operation").substr(198, 11)).as("rjt_s18_zone_reservee"),
				trim(col("zone_operation").substr(209, 4)).as("rjt_code_motif"),
				trim(col("zone_operation").substr(213, 16)).as("rjt_ref_ope"),
				trim(col("zone_operation").substr(229, 10)).as("rjt_ref_presentateur"),
				trim(col("zone_operation").substr(239, 9)).as("rjt_num_siren_dest"),
				trim(col("zone_operation").substr(248, 9)).as("rjt_zone_reservee"),

				callUDF("fromStringtoInteger", col("zone_operation").substr(259, 4)).as("oi_s2_long_ope"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(263, 2)).as("oi_s3_code_article"),
				trim(col("zone_operation").substr(265, 3)).as("oi_s4_code_ope"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(268, 1)).as("oi_s5_type_id_do"),
				trim(col("zone_operation").substr(269, 7)).as("oi_s6_id_etblt_do"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(276, 1)).as("oi_s7_type_id_dest"),
				trim(col("zone_operation").substr(277, 7)).as("oi_s8_id_etblt_dest"),
				trim(col("zone_operation").substr(284, 5)).as("oi_s9_critere_rout_secondaire"),
				trim(col("zone_operation").substr(289, 4)).as("oi_s10_code_devise"),
				callUDF("fromStingToDouble", col("zone_operation").substr(293, 16),
						col("zone_operation").substr(289, 4)).as("oi_s11_mnt_compense"),

				callUDF("fromString6toDate", col("zone_operation").substr(309, 6)).as("oi_s12_date_reglement_demande"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(315, 1)).as("oi_s13_ind_modif_ddr"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(316, 1)).as("oi_s14_code_commission"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(317, 6))
						.as("oi_s15_commission_interbancaire"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(323, 1))
						.as("oi_s16_zone_reservee_declaration"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(324, 2)).as("oi_s17_code_anomalie"),
				trim(col("zone_operation").substr(326, 11)).as("oi_s18_zone_reservee"),
				trim(col("zone_operation").substr(337, 4)).as("oi_b_lcr_sous_code_ope"),
				trim(col("zone_operation").substr(341, 16)).as("oi_b_lcr_ref_ope"),
				trim(col("zone_operation").substr(357, 10)).as("oi_b_lcr_presentateur"),
				trim(col("zone_operation").substr(367, 16)).as("oi_b_lcr_coord_client_cedant"),
				trim(col("zone_operation").substr(383, 14)).as("oi_b_lcr_coord_client_tire"),
				trim(col("zone_operation").substr(397, 24)).as("oi_b_lcr_nom_tireur"),
				callUDF("fromString6toDate", col("zone_operation").substr(421, 6)).as("oi_b_lcr_date_echeance"),
				callUDF("fromString6toDate", col("zone_operation").substr(427, 6)).as("oi_b_lcr_date_creation"),
				callUDF("fromString6toDate", col("zone_operation").substr(433, 6)).as("oi_b_lcr_date_entree_ptf"),
				trim(col("zone_operation").substr(439, 10)).as("oi_b_lcr_zone_reservee_1"),
				trim(col("zone_operation").substr(449, 24)).as("oi_b_lcr_nom_tire"),
				trim(col("zone_operation").substr(473, 1)).as("oi_b_lcr_acceptation"),
				trim(col("zone_operation").substr(474, 1)).as("oi_b_lcr_code_entree"),
				trim(col("zone_operation").substr(475, 10)).as("oi_b_lcr_ref_tireur"),
				trim(col("zone_operation").substr(485, 10)).as("oi_b_lcr_ref_tire"),
				trim(col("zone_operation").substr(495, 15)).as("oi_b_lcr_num_siren_tireur"),
				trim(col("zone_operation").substr(510, 3)).as("oi_b_lcr_zone_reservee_2"),
				trim(col("zone_operation").substr(513, 24)).as("oi_b_lcr_lib_domicil"),
				trim(col("zone_operation").substr(537, 13)).as("oi_b_lcr_zone_reservee_3"),
				trim(col("zone_operation").substr(550, 1)).as("oi_b_lcr_ind_balance_paiments"),
				trim(col("zone_operation").substr(551, 26)).as("oi_b_lcr_zone_reservee_4"), 
				col("date_insert"), col("date_ope").as("date_ope"))
				.withColumn("id_traitement",lit(idtrt));
	}

	/*
	 * Apply transformations to the source data DREC
	 * 
	 * @param data
	 * 
	 * @return DataFrame
	 */
	public Dataset<Row> prepareMinosArlcrData(Dataset<Row> data ) {

         //transform data
       return  data.select(
    		   col("id_operation").as("id_ope_connexe") ,
    		   col("id_ope_initiale") ,
    		   col("rio"),
    		   col("ref_operation"),
    		   col("code_operation"),
    		   col("id_type_operation"),
    		   col("code_famille_operation"),
    		   col("type_operation"),
    		   col("sens_echange"),
    		   col("systeme_echange"),
    		   col("date_echange"),
    		   col("date_reglement"),
    		   col("date_traitement_aval_recu"),
    		   col("delai_reglement_ope"),
    		   col("date_pec_amont"),
    		   col("num_remise"),
    		   col("num_remise_tech"),
    		   col("mnt_compense_sit"),
    		   col("date_presentation_remise"),
    		   col("code_client_conventionne"),
    		   col("id_client"),
    		   col("code_grp_remettant"),
    		   col("lib_grp_remettant"),
    		   col("id_compte_do"),
    		   col("bic_do"),
    		   col("iban_do"),
    		   col("code_pays_do"),
    		   col("cle_iban_do"),
    		   col("code_banque_do"),
    		   col("code_guichet_do"),
    		   col("num_cpte_do"),
    		   col("cle_rib_do"),
    		   col("id_compte_dest"),
    		   col("bic_dest"),
    		   col("iban_dest"),
    		   col("code_pays_dest"),
    		   col("cle_iban_dest"),
    		   col("code_banque_dest"),
    		   col("code_guichet_dest"),
    		   col("num_cpte_dest"),
    		   col("cle_rib_dest"),
    		   col("etblt_concerne"),
    		   col("num_partition"),
    		   col("code_flux_arch"),
    		   col("ind_connexe"),
    		   col("zone_operation"),
    		   col("date_comptable_evolmpm"),
    		   col("flag_debrayage_embargo"),
    		   col("xtimts"),
    		   col("s2_long_ope"),
    		   col("s3_code_article"),
    		   col("s4_code_ope"),
    		   col("s5_type_id_do"),
    		   col("s6_id_etblt_do"),
    		   col("s7_type_id_dest"),
    		   col("s8_id_etblt_dest"),
    		   col("s9_critere_rout_secondaire"),
    		   col("s10_code_devise"),
    		   col("s11_mnt_compense"),
    		   col("s12_date_reglement_demande"),
    		   col("s13_ind_modif_ddr"),
    		   col("s14_code_commission"),
    		   col("s15_commission_interbancaire"),
    		   col("s16_zone_reservee_declaration"),
    		   col("s17_code_anomalie"),
    		   col("s18_zone_reservee"),
    		   col("b_arlcr_code_motif"),
    		   col("b_arlcr_ref_ope"),
    		   col("b_arlcr_ref_presentateur"),
    		   col("b_arlcr_zone_reservee"),
    		   callUDF("fromStringtoInteger", col("zone_operation").substr(131,4)).as("rjt_s2_long_ope") ,
    		   trim(col("zone_operation").substr(135,2)).as ("rjt_s3_code_article")  ,
    				   trim(col("zone_operation").substr(137,3)).as ("rjt_s4_code_ope")  ,
    		   callUDF("fromStringtoInteger", col("zone_operation").substr(140,1)).as("rjt_s5_type_id_do") ,
    		   trim(col("zone_operation").substr(141,7)).as ("rjt_s6_id_etblt_do")  ,		   
    		   callUDF("fromStringtoInteger",col("zone_operation").substr(148,1)).as ("rjt_s7_type_id_dest")  ,
    		   trim(col("zone_operation").substr(149,7)).as ("rjt_s8_id_etblt_dest")  ,
    		   trim(col("zone_operation").substr(156,5)).as ("rjt_s9_critere_rout_secondaire")  ,
    		   trim(col("zone_operation").substr(161,4)).as ("rjt_s10_code_devise")  ,
    		   callUDF("fromStingToDouble",col("zone_operation").substr(165,16),col("zone_operation").substr(161,4)).as ("rjt_s11_mnt_compense") ,
    		   callUDF("fromString6toDate",col("zone_operation").substr(181,6)).as ("rjt_s12_date_reglement_demande")  ,
    		   callUDF("fromStringtoInteger",col("zone_operation").substr(187,1)).as ("rjt_s13_ind_modif_ddr")  ,
    		   callUDF("fromStringtoInteger",col("zone_operation").substr(188,1)).as ("rjt_s14_code_commission")  ,
    		   callUDF("fromStringtoInteger",col("zone_operation").substr(189,6)).as ("rjt_s15_commission_interbancaire")  ,
    		   callUDF("fromStringtoInteger", col("zone_operation").substr(195,1)).as ("rjt_s16_zone_reservee_declaration")  ,
    		   callUDF("fromStringtoInteger",col("zone_operation").substr(196,2)).as ("rjt_s17_code_anomalie")  ,
    		   trim(col("zone_operation").substr(198,11)).as ("rjt_s18_zone_reservee")  ,
    		   trim(col("zone_operation").substr(209,4)).as ("rjt_code_motif")  ,
    		   trim(col("zone_operation").substr(213,16)).as ("rjt_ref_ope")  ,
    		   trim(col("zone_operation").substr(229,10)).as ("rjt_ref_presentateur")  ,
    		   trim(col("zone_operation").substr(239,9)).as ("rjt_num_siren_dest")  ,
    		   trim(col("zone_operation").substr(248,9)).as ("rjt_zone_reservee")  ,
    		   callUDF("fromStringtoInteger",col("zone_operation").substr(259,4)).as ("oi_s2_long_ope")  ,
    		   trim(col("zone_operation").substr(263,2)).as ("oi_s3_code_article")  ,
    		   trim(col("zone_operation").substr(265,3)).as ("oi_s4_code_ope")  ,
    		   callUDF("fromStringtoInteger",col("zone_operation").substr(268,1)).as ("oi_s5_type_id_do")  ,
    		   trim(col("zone_operation").substr(269,7)).as ("oi_s6_id_etblt_do")  ,
    		   callUDF("fromStringtoInteger",col("zone_operation").substr(276,1)).as ("oi_s7_type_id_dest")  ,
    		   trim(col("zone_operation").substr(277,7)).as ("oi_s8_id_etblt_dest")  ,
    		   trim(col("zone_operation").substr(284,5)).as ("oi_s9_critere_rout_secondaire")  ,
    		   trim(col("zone_operation").substr(289,4)).as ("oi_s10_code_devise")  ,
    		   callUDF("fromStingToDouble",col("zone_operation").substr(293,16),col("zone_operation").substr(289,4)).as ("oi_s11_mnt_compense") ,

    		   callUDF("fromString6toDate",col("zone_operation").substr(309,6)).as ("oi_s12_date_reglement_demande")  ,
    		   callUDF("fromStringtoInteger",col("zone_operation").substr(315,1)).as ("oi_s13_ind_modif_ddr")  ,
    		   callUDF("fromStringtoInteger",col("zone_operation").substr(316,1)).as ("oi_s14_code_commission")  ,
    		   callUDF("fromStringtoInteger",col("zone_operation").substr(317,6)).as ("oi_s15_commission_interbancaire")  ,
    		   callUDF("fromStringtoInteger",col("zone_operation").substr(323,1)).as ("oi_s16_zone_reservee_declaration")  ,
    		   callUDF("fromStringtoInteger",col("zone_operation").substr(324,2)).as ("oi_s17_code_anomalie")  ,
    		   trim(col("zone_operation").substr(326,11)).as ("oi_s18_zone_reservee")  ,
    		   trim(col("zone_operation").substr(337,4)).as ("oi_b_lcr_sous_code_ope")  ,
    		   trim(col("zone_operation").substr(341,16)).as ("oi_b_lcr_ref_ope")  ,
    		   trim(col("zone_operation").substr(357,10)).as ("oi_b_lcr_presentateur")  ,
    		   trim(col("zone_operation").substr(367,16)).as ("oi_b_lcr_coord_client_cedant")  ,
    		   trim(col("zone_operation").substr(383,14)).as ("oi_b_lcr_coord_client_tire")  ,
    		   trim(col("zone_operation").substr(397,24)).as ("oi_b_lcr_nom_tireur")  ,
    		   callUDF("fromString6toDate",col("zone_operation").substr(421,6)).as ("oi_b_lcr_date_echeance")  ,
    		   callUDF("fromString6toDate",col("zone_operation").substr(427,6)).as ("oi_b_lcr_date_creation")  ,
    		   callUDF("fromString6toDate",col("zone_operation").substr(433,6)).as ("oi_b_lcr_date_entree_ptf")  ,
    		   trim(col("zone_operation").substr(439,10)).as ("oi_b_lcr_zone_reservee_1")  ,
    		   trim(col("zone_operation").substr(449,24)).as ("oi_b_lcr_nom_tire")  ,
    		   trim(col("zone_operation").substr(473,1)).as ("oi_b_lcr_acceptation")  ,
    		   trim(col("zone_operation").substr(474,1)).as ("oi_b_lcr_code_entree")  ,
    		   trim(col("zone_operation").substr(475,10)).as ("oi_b_lcr_ref_tireur")  ,
    		   trim(col("zone_operation").substr(485,10)).as ("oi_b_lcr_ref_tire")  ,
    		   trim(col("zone_operation").substr(495,15)).as ("oi_b_lcr_num_siren_tireur")  ,
    		   trim(col("zone_operation").substr(510,3)).as ("oi_b_lcr_zone_reservee_2")  ,
    		   trim(col("zone_operation").substr(513,24)).as ("oi_b_lcr_lib_domicil")  ,
    		   trim(col("zone_operation").substr(537,13)).as ("oi_b_lcr_zone_reservee_3")  ,
    		   trim(col("zone_operation").substr(550,1)).as ("oi_b_lcr_ind_balance_paiments")  ,
    		   trim(col("zone_operation").substr(551,26)).as ("oi_b_lcr_zone_reservee_4")  ,
    		   col("date_insert"), col("date_ope").as("date_ope"))
    		   .withColumn("id_traitement",lit(idtrt));
   }

	/*
	 * Apply transformations to the source data RJT
	 * 
	 * @param data
	 * 
	 * @return DataFrame
	 */
	public Dataset<Row> prepareMinosRjtData(Dataset<Row> data) {

		// transform data
		return data.select(col("id_operation").as("id_ope_connexe"), col("id_ope_initiale"), col("rio"),
				col("ref_operation"), col("code_operation"), col("id_type_operation"), col("code_famille_operation"),
				col("type_operation"), col("sens_echange"), col("systeme_echange"), col("date_echange"),
				col("date_reglement"), col("date_traitement_aval_recu"), col("delai_reglement_ope"),
				col("date_pec_amont"), col("num_remise"), col("num_remise_tech"), col("mnt_compense_sit"),
				col("date_presentation_remise"), col("code_client_conventionne"), col("id_client"),
				col("code_grp_remettant"), col("lib_grp_remettant"), col("id_compte_do"), col("bic_do"), col("iban_do"),
				col("code_pays_do"), col("cle_iban_do"), col("code_banque_do"), col("code_guichet_do"),
				col("num_cpte_do"), col("cle_rib_do"), col("id_compte_dest"), col("bic_dest"), col("iban_dest"),
				col("code_pays_dest"), col("cle_iban_dest"), col("code_banque_dest"), col("code_guichet_dest"),
				col("num_cpte_dest"), col("cle_rib_dest"), col("etblt_concerne"), col("num_partition"),
				col("code_flux_arch"), col("ind_connexe"), col("zone_operation"), col("date_comptable_evolmpm"),
				col("flag_debrayage_embargo"), col("xtimts"), col("s2_long_ope"), col("s3_code_article"),
				col("s4_code_ope"), col("s5_type_id_do"), col("s6_id_etblt_do"), col("s7_type_id_dest"),
				col("s8_id_etblt_dest"), col("s9_critere_rout_secondaire"), col("s10_code_devise"),
				col("s11_mnt_compense"), col("s12_date_reglement_demande"), col("s13_ind_modif_ddr"),
				col("s14_code_commission"), col("s15_commission_interbancaire"), col("s16_zone_reservee_declaration"),
				col("s17_code_anomalie"), col("s18_zone_reservee"), col("b_rjt_code_motif"), col("b_rjt_ref_ope"),
				col("b_rjt_ref_presentateur"), col("b_rjt_num_siren_dest"), col("b_rjt_zone_reservee"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(131, 4)).as("oi_s2_long_ope"),
				trim(col("zone_operation").substr(135, 2)).as("oi_s3_code_article"),
				trim(col("zone_operation").substr(137, 3)).as("oi_s4_code_ope"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(140, 1)).as("oi_s5_type_id_do"),
				trim(col("zone_operation").substr(141, 7)).as("oi_s6_id_etblt_do"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(148, 1)).as("oi_s7_type_id_dest"),
				trim(col("zone_operation").substr(149, 7)).as("oi_s8_id_etblt_dest"),
				trim(col("zone_operation").substr(156, 5)).as("oi_s9_critere_rout_secondaire"),
				trim(col("zone_operation").substr(161, 4)).as("oi_s10_code_devise"),
				callUDF("fromStingToDouble", col("zone_operation").substr(165, 16),col("zone_operation").substr(161, 4)).as("oi_s11_mnt_compense"),
				callUDF("fromString6toDate", col("zone_operation").substr(181, 6)).as("oi_s12_date_reglement_demande"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(187, 1)).as("oi_s13_ind_modif_ddr"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(188, 1)).as("oi_s14_code_commission"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(189, 6))		.as("oi_s15_commission_interbancaire"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(195, 1))						.as("oi_s16_zone_reservee_declaration"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(196, 2)).as("oi_s17_code_anomalie"),
				trim(col("zone_operation").substr(198, 11)).as("oi_s18_zone_reservee"),
				trim(col("zone_operation").substr(209, 4)).as("oi_b_lcr_sous_code_ope"),
				trim(col("zone_operation").substr(213, 16)).as("oi_b_lcr_ref_ope"),
				trim(col("zone_operation").substr(229, 10)).as("oi_b_lcr_presentateur"),
				trim(col("zone_operation").substr(239, 16)).as("oi_b_lcr_coord_client_cedant"),
				trim(col("zone_operation").substr(255, 14)).as("oi_b_lcr_coord_client_tire"),
				trim(col("zone_operation").substr(269, 24)).as("oi_b_lcr_nom_tireur"),
				callUDF("fromString6toDate", col("zone_operation").substr(293, 6)).as("oi_b_lcr_date_echeance"),
				callUDF("fromString6toDate", col("zone_operation").substr(299, 6)).as("oi_b_lcr_date_creation"),
				callUDF("fromString6toDate", col("zone_operation").substr(305, 6)).as("oi_b_lcr_date_entree_ptf"),
				trim(col("zone_operation").substr(311, 10)).as("oi_b_lcr_zone_reservee_1"),
			    trim(col("zone_operation").substr(321, 24)).as("oi_b_lcr_nom_tire"),
				trim(col("zone_operation").substr(345, 1)).as("oi_b_lcr_acceptation"),
				trim(col("zone_operation").substr(346, 1)).as("oi_b_lcr_code_entree"),
				trim(col("zone_operation").substr(347, 10)).as("oi_b_lcr_ref_tireur"),
				trim(col("zone_operation").substr(357, 10)).as("oi_b_lcr_ref_tire"),
				trim(col("zone_operation").substr(367, 15)).as("oi_b_lcr_num_siren_tireur"),
				trim(col("zone_operation").substr(382, 3)).as("oi_b_lcr_zone_reservee_2"),
				trim(col("zone_operation").substr(385, 24)).as("oi_b_lcr_lib_domicil"),
				trim(col("zone_operation").substr(409, 13)).as("oi_b_lcr_zone_reservee_3"),
				trim(col("zone_operation").substr(422, 1)).as("oi_b_lcr_ind_balance_paiments"),
				trim(col("zone_operation").substr(423, 26)).as("oi_b_lcr_zone_reservee_4"), 
				col("date_insert"), col("date_ope").as("date_ope"))
				.withColumn("id_traitement",lit(idtrt));
	}

	/*
	 * Apply transformations to the source data COR
	 * 
	 * @param data
	 * 
	 * @return DataFrame
	 */
	public Dataset<Row> prepareMinosCorData(Dataset<Row> data) {

		// transform data
		return data.select(col("id_operation").as("id_ope_connexe"), col("id_ope_initiale"), col("rio"),
				col("ref_operation"), col("code_operation"), col("id_type_operation"), col("code_famille_operation"),
				col("type_operation"), col("sens_echange"), col("systeme_echange"), col("date_echange"),
				col("date_reglement"), col("date_traitement_aval_recu"), col("delai_reglement_ope"),
				col("date_pec_amont"), col("num_remise"), col("num_remise_tech"), col("mnt_compense_sit"),
				col("date_presentation_remise"), col("code_client_conventionne"), col("id_client"),
				col("code_grp_remettant"), col("lib_grp_remettant"), col("id_compte_do"), col("bic_do"), col("iban_do"),
				col("code_pays_do"), col("cle_iban_do"), col("code_banque_do"), col("code_guichet_do"),
				col("num_cpte_do"), col("cle_rib_do"), col("id_compte_dest"), col("bic_dest"), col("iban_dest"),
				col("code_pays_dest"), col("cle_iban_dest"), col("code_banque_dest"), col("code_guichet_dest"),
				col("num_cpte_dest"), col("cle_rib_dest"), col("etblt_concerne"), col("num_partition"),
				col("code_flux_arch"), col("ind_connexe"), col("zone_operation"), col("date_comptable_evolmpm"),
				col("flag_debrayage_embargo"), col("xtimts"), col("s2_long_ope"), col("s3_code_article"),
				col("s4_code_ope"), col("s5_type_id_do"), col("s6_id_etblt_do"), col("s7_type_id_dest"),
				col("s8_id_etblt_dest"), col("s9_critere_rout_secondaire"), col("s10_code_devise"),
				col("s11_mnt_compense"), col("s12_date_reglement_demande"), col("s13_ind_modif_ddr"),
				col("s14_code_commission"), col("s15_commission_interbancaire"), col("s16_zone_reservee_declaration"),
				col("s17_code_anomalie"), col("s18_zone_reservee"), col("b_corrige_code_motif"),
				col("b_corrige_ref_ope"), col("b_corrige_ref_presentateur"), col("b_corrige_zone_reservee_1"),
				col("b_corrige_coord_client_dest"), col("b_corrige_id_client_dest"),
				col("b_corrige_crit_routage_second"), col("b_corrige_zone_reservee_2"),
				col("b_corrige_lib_abre_domicil"), col("b_corrige_zone_reservee_3"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(259, 4)).as("oi_s2_long_ope"),
				trim(col("zone_operation").substr(263, 2)).as("oi_s3_code_article"),
				trim(col("zone_operation").substr(265, 3)).as("oi_s4_code_ope"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(268, 1)).as("oi_s5_type_id_do"),
				trim(col("zone_operation").substr(269, 7)).as("oi_s6_id_etblt_do"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(276, 1)).as("oi_s7_type_id_dest"),
				trim(col("zone_operation").substr(277, 7)).as("oi_s8_id_etblt_dest"),
				trim(col("zone_operation").substr(284, 5)).as("oi_s9_critere_rout_secondaire"),
				trim(col("zone_operation").substr(289, 4)).as("oi_s10_code_devise"),
				callUDF("fromStingToDouble", col("zone_operation").substr(293, 16),col("zone_operation").substr(289, 4)).as("oi_s11_mnt_compense"),
				callUDF("fromString6toDate", col("zone_operation").substr(309, 6)).as("oi_s12_date_reglement_demande"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(315, 1)).as("oi_s13_ind_modif_ddr"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(316, 1)).as("oi_s14_code_commission"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(317, 6))
						.as("oi_s15_commission_interbancaire"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(323, 1))
						.as("oi_s16_zone_reservee_declaration"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(324, 2)).as("oi_s17_code_anomalie"),
				trim(col("zone_operation").substr(326, 11)).as("oi_s18_zone_reservee"),
				trim(col("zone_operation").substr(337, 4)).as("oi_b_lcr_sous_code_ope"),
				trim(col("zone_operation").substr(341, 16)).as("oi_b_lcr_ref_ope"),
				trim(col("zone_operation").substr(357, 10)).as("oi_b_lcr_presentateur"),
				trim(col("zone_operation").substr(367, 16)).as("oi_b_lcr_coord_client_cedant"),
				trim(col("zone_operation").substr(383, 14)).as("oi_b_lcr_coord_client_tire"),
				trim(col("zone_operation").substr(397, 24)).as("oi_b_lcr_nom_tireur"),
				callUDF("fromString6toDate", col("zone_operation").substr(421, 6)).as("oi_b_lcr_date_echeance"),
				callUDF("fromString6toDate", col("zone_operation").substr(427, 6)).as("oi_b_lcr_date_creation"),
				callUDF("fromString6toDate", col("zone_operation").substr(433, 6)).as("oi_b_lcr_date_entree_ptf"),
				trim(col("zone_operation").substr(439, 10)).as("oi_b_lcr_zone_reservee_1"),
				trim(col("zone_operation").substr(449, 24)).as("oi_b_lcr_nom_tire"),
				trim(col("zone_operation").substr(473, 1)).as("oi_b_lcr_acceptation"),
				trim(col("zone_operation").substr(474, 1)).as("oi_b_lcr_code_entree"),
				trim(col("zone_operation").substr(475, 10)).as("oi_b_lcr_ref_tireur"),
				trim(col("zone_operation").substr(485, 10)).as("oi_b_lcr_ref_tire"),
				trim(col("zone_operation").substr(495, 15)).as("oi_b_lcr_num_siren_tireur"),
				trim(col("zone_operation").substr(510, 3)).as("oi_b_lcr_zone_reservee_2"),
				trim(col("zone_operation").substr(513, 24)).as("oi_b_lcr_lib_domicil"),
				trim(col("zone_operation").substr(537, 13)).as("oi_b_lcr_zone_reservee_3"),
				trim(col("zone_operation").substr(550, 1)).as("oi_b_lcr_ind_balance_paiments"),
				trim(col("zone_operation").substr(551, 26)).as("oi_b_lcr_zone_reservee_4"), 
				col("date_insert"), col("date_ope").as("date_ope"))
				.withColumn("id_traitement",lit(idtrt));
	}

	/**
	 * Apply transformations to the source data VRF Sort columns before
	 * insertion in target table
	 * 
	 * @param data
	 * @return DataFrame
	 */
	public Dataset<Row> prepareMinosVrfData(Dataset<Row> data) {

		// transform data
		Dataset<Row> minosVrfTable = data.select(col("id_operation").as("id_ope_connexe"), col("rio"),
				col("ref_operation"), col("code_operation"), col("id_type_operation"), col("code_famille_operation"),
				col("type_operation"), col("sens_echange"), col("systeme_echange"), col("date_echange"),
				col("date_reglement"), col("date_traitement_aval_recu"), col("delai_reglement_ope"),
				col("date_pec_amont"), col("num_remise"), col("num_remise_tech"), col("mnt_compense_sit"),
				col("date_presentation_remise"), col("code_client_conventionne"), col("id_client"),
				col("code_grp_remettant"), col("lib_grp_remettant"), col("id_compte_do"), col("bic_do"), col("iban_do"),
				col("code_pays_do"), col("cle_iban_do"), col("code_banque_do"), col("code_guichet_do"),
				col("num_cpte_do"), col("cle_rib_do"), col("id_compte_dest"), col("bic_dest"), col("iban_dest"),
				col("code_pays_dest"), col("cle_iban_dest"), col("code_banque_dest"), col("code_guichet_dest"),
				col("num_cpte_dest"), col("cle_rib_dest"), col("etblt_concerne"), col("num_partition"),
				col("code_flux_arch"), col("ind_connexe"), col("zone_operation"), col("date_comptable_evolmpm"),
				col("flag_debrayage_embargo"), col("xtimts"), col("s2_long_ope"), col("s3_code_article"),
				col("s4_code_ope"), col("s5_type_id_do"), col("s6_id_etblt_do"), col("s7_type_id_dest"),
				col("s8_id_etblt_dest"), col("s9_critere_rout_secondaire"), col("s10_code_devise"),
				col("s11_mnt_compense"), col("s12_date_reglement_demande"), col("s13_ind_modif_ddr"),
				col("s14_code_commission"), col("s15_commission_interbancaire"), col("s16_zone_reservee_declaration"),
				col("s17_code_anomalie"), col("s18_zone_reservee"), col("b_vrf_code_motif"), col("b_vrf_ref_ope"),
				col("b_vrf_ref_presentateur"), col("b_vrf_coord_client_cedant"), col("b_vrf_coord_client_tire"),
				col("b_vrf_nom_tireur"), col("b_vrf_date_echeance_lcr"), col("b_vrf_date_creation"),
				col("b_vrf_date_entree_ptf"), col("b_vrf_zone_reservee1"), col("b_vrf_nom_tire"),
				col("b_vrf_acceptation"), col("b_vrf_code_entree"), col("b_vrf_ref_tireur"), col("b_vrf_ref_tire"),
				col("b_vrf_num_siren_tireur"), col("b_vrf_zone_reservee2"), col("b_vrf_lib_abre_domicil"),
				col("b_vrf_zone_reservee3"), col("b_vrf_ind_balance_paiement"), col("b_vrf_zone_reservee4"),
				col("date_insert"), col("date_ope").as("date_ope"))
				.withColumn("id_ope_initiale", lit(null).cast(DataTypes.IntegerType))
				.withColumn("id_traitement",lit(idtrt));

		return minosVrfTable.select(col("id_ope_connexe"), col("id_ope_initiale"), col("rio"), col("ref_operation"),
				col("code_operation"), col("id_type_operation"), col("code_famille_operation"), col("type_operation"),
				col("sens_echange"), col("systeme_echange"), col("date_echange"), col("date_reglement"),
				col("date_traitement_aval_recu"), col("delai_reglement_ope"), col("date_pec_amont"), col("num_remise"),
				col("num_remise_tech"), col("mnt_compense_sit"), col("date_presentation_remise"),
				col("code_client_conventionne"), col("id_client"), col("code_grp_remettant"), col("lib_grp_remettant"),
				col("id_compte_do"), col("bic_do"), col("iban_do"), col("code_pays_do"), col("cle_iban_do"),
				col("code_banque_do"), col("code_guichet_do"), col("num_cpte_do"), col("cle_rib_do"),
				col("id_compte_dest"), col("bic_dest"), col("iban_dest"), col("code_pays_dest"), col("cle_iban_dest"),
				col("code_banque_dest"), col("code_guichet_dest"), col("num_cpte_dest"), col("cle_rib_dest"),
				col("etblt_concerne"), col("num_partition"), col("code_flux_arch"), col("ind_connexe"),
				col("zone_operation"), col("date_comptable_evolmpm"), col("flag_debrayage_embargo"), col("xtimts"),
				col("s2_long_ope"), col("s3_code_article"), col("s4_code_ope"), col("s5_type_id_do"),
				col("s6_id_etblt_do"), col("s7_type_id_dest"), col("s8_id_etblt_dest"),
				col("s9_critere_rout_secondaire"), col("s10_code_devise"), col("s11_mnt_compense"),
				col("s12_date_reglement_demande"), col("s13_ind_modif_ddr"), col("s14_code_commission"),
				col("s15_commission_interbancaire"), col("s16_zone_reservee_declaration"), col("s17_code_anomalie"),
				col("s18_zone_reservee"), col("b_vrf_code_motif"), col("b_vrf_ref_ope"), col("b_vrf_ref_presentateur"),
				col("b_vrf_coord_client_cedant"), col("b_vrf_coord_client_tire"), col("b_vrf_nom_tireur"),
				col("b_vrf_date_echeance_lcr"), col("b_vrf_date_creation"), col("b_vrf_date_entree_ptf"),
				col("b_vrf_zone_reservee1"), col("b_vrf_nom_tire"), col("b_vrf_acceptation"), col("b_vrf_code_entree"),
				col("b_vrf_ref_tireur"), col("b_vrf_ref_tire"), col("b_vrf_num_siren_tireur"),
				col("b_vrf_zone_reservee2"), col("b_vrf_lib_abre_domicil"), col("b_vrf_zone_reservee3"),
				col("b_vrf_ind_balance_paiement"), col("b_vrf_zone_reservee4"), col("date_insert"),
				col("date_ope").as("date_ope"), col("id_traitement"));

	}

	// BASTID-258

	/**
	 * Apply transformations to the source data Sort columns before insertion in
	 * target table
	 * 
	 * @param data
	 * @return DataFrame
	 */
	public Dataset<Row> prepareMinosRicData(Dataset<Row> data) {

		
		return data.select(col("id_operation").as("id_ope_connexe"), col("id_ope_initiale").as("id_ope_initiale"),
				col("rio").as("rio"), col("ref_operation").as("ref_operation"),
				col("code_operation").as("code_operation"), col("id_type_operation").as("id_type_operation"),
				col("code_famille_operation").as("code_famille_operation"), col("type_operation").as("type_operation"),
				col("sens_echange").as("sens_echange"), col("systeme_echange").as("systeme_echange"),
				col("date_echange").as("date_echange"), col("date_reglement").as("date_reglement"),
				col("date_traitement_aval_recu").as("date_traitement_aval_recu"),
				col("delai_reglement_ope").as("delai_reglement_ope"), col("date_pec_amont").as("date_pec_amont"),
				col("num_remise").as("num_remise"), col("num_remise_tech").as("num_remise_tech"),
				col("mnt_compense_sit").as("mnt_compense_sit"),
				col("date_presentation_remise").as("date_presentation_remise"),
				col("code_client_conventionne").as("code_client_conventionne"), col("id_client").as("id_client"),
				col("code_grp_remettant").as("code_grp_remettant"), col("lib_grp_remettant").as("lib_grp_remettant"),
				col("id_compte_do").as("id_compte_do"), col("bic_do").as("bic_do"), col("iban_do").as("iban_do"),
				col("code_pays_do").as("code_pays_do"), col("cle_iban_do").as("cle_iban_do"),
				col("code_banque_do").as("code_banque_do"), col("code_guichet_do").as("code_guichet_do"),
				col("num_cpte_do").as("num_cpte_do"), col("cle_rib_do").as("cle_rib_do"),
				col("id_compte_dest").as("id_compte_dest"), col("bic_dest").as("bic_dest"),
				col("iban_dest").as("iban_dest"), col("code_pays_dest").as("code_pays_dest"),
				col("cle_iban_dest").as("cle_iban_dest"), col("code_banque_dest").as("code_banque_dest"),
				col("code_guichet_dest").as("code_guichet_dest"), col("num_cpte_dest").as("num_cpte_dest"),
				col("cle_rib_dest").as("cle_rib_dest"), col("etblt_concerne").as("etblt_concerne"),
				col("num_partition").as("num_partition"), col("code_flux_arch").as("code_flux_arch"),
				col("ind_connexe").as("ind_connexe"), col("zone_operation").as("zone_operation"),
				col("date_comptable_evolmpm").as("date_comptable_evolmpm"),
				col("flag_debrayage_embargo").as("flag_debrayage_embargo"), col("xtimts").as("xtimts"),
				col("s2_long_ope").as("s2_long_ope"), col("s3_code_article").as("s3_code_article"),
				col("s4_code_ope").as("s4_code_ope"), col("s5_type_id_do").as("s5_type_id_do"),
				col("s6_id_etblt_do").as("s6_id_etblt_do"), col("s7_type_id_dest").as("s7_type_id_dest"),
				col("s8_id_etblt_dest").as("s8_id_etblt_dest"),
				col("s9_critere_rout_secondaire").as("s9_critere_rout_secondaire"),
				col("s10_code_devise").as("s10_code_devise"), col("s11_mnt_compense").as("s11_mnt_compense"),
				col("s12_date_reglement_demande").as("s12_date_reglement_demande"),
				col("s13_ind_modif_ddr").as("s13_ind_modif_ddr"), col("s14_code_commission").as("s14_code_commission"),
				col("s15_commission_interbancaire").as("s15_commission_interbancaire"),
				col("s16_zone_reservee_declaration").as("s16_zone_reservee_declaration"),
				col("s17_code_anomalie").as("s17_code_anomalie"), col("s18_zone_reservee").as("s18_zone_reservee"),
				col("b_ric_code_motif").as("b_ric_code_motif"), col("b_ric_ref_ope").as("b_ric_ref_ope"),
				col("b_ric_indice_delai").as("b_ric_indice_delai"),
				col("b_ric_ind_restit_physque").as("b_ric_ind_restit_physque"),
				col("b_ric_indic_certif_non_pmt").as("b_ric_indic_certif_non_pmt"),
				col("b_ric_nature_interdiction").as("b_ric_nature_interdiction"),
				col("b_ric_date_interdiction").as("b_ric_date_interdiction"),
				col("b_ric_date_presentation").as("b_ric_date_presentation"),
				col("b_ric_num_cheque").as("b_ric_num_cheque"), col("b_ric_nom_tireur").as("b_ric_nom_tireur"),
				col("b_ric_lib_abre_domicil").as("b_ric_lib_abre_domicil"),
				col("b_ric_num_cpte_tireur").as("b_ric_num_cpte_tireur"),
				col("b_ric_coord_expediteur").as("b_ric_coord_expediteur"),
				col("b_ric_zone_usage_etblmt").as("b_ric_zone_usage_etblmt"),
				col("b_ric_zone_reservee").as("b_ric_zone_reservee"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(387, 4)).as("oi_s2_long_ope"),
				trim(col("zone_operation").substr(391, 2)).as("oi_s3_code_article"),
				trim(col("zone_operation").substr(393, 3)).as("oi_s4_code_ope"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(396, 1)).as("oi_s5_type_id_do"),
				trim(col("zone_operation").substr(397, 7)).as("oi_s6_id_etblt_do"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(404, 1)).as("oi_s7_type_id_dest"),
				trim(col("zone_operation").substr(405, 7)).as("oi_s8_id_etblt_dest"),
				trim(col("zone_operation").substr(412, 5)).as("oi_s9_critere_rout_secondaire"),
				trim(col("zone_operation").substr(417, 4)).as("oi_s10_code_devise"),
				callUDF("fromStingToDouble", col("zone_operation").substr(421, 16),
						col("zone_operation").substr(417, 4)).as("oi_s11_mnt_compense"),
				callUDF("fromString6toDate", col("zone_operation").substr(437, 6)).as("oi_s12_date_reglement_demande"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(443, 1)).as("oi_s13_ind_modif_ddr"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(444, 1)).as("oi_s14_code_commission"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(445, 6))
						.as("oi_s15_commission_interbancaire"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(451, 1))
						.as("oi_s16_zone_reservee_declaration"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(452, 2)).as("oi_s17_code_anomalie"),
				trim(col("zone_operation").substr(454, 11)).as("oi_s18_zone_reservee"),
				trim(col("zone_operation").substr(465, 4)).as("oi_b_ic_sous_code_ope"),
				trim(col("zone_operation").substr(469, 24)).as("oi_b_ic_ref_ope"),
				trim(col("zone_operation").substr(493, 50)).as("oi_b_ic_zone_banquier_remettant"),
				trim(col("zone_operation").substr(543, 7)).as("oi_b_ic_num_cheque_cmc7_4"),
			   trim(col("zone_operation").substr(550, 12)).as("oi_b_ic_zone_interbancaire_cmc7_3"),
				trim(col("zone_operation").substr(562, 12)).as("oi_b_ic_zone_interieure_cmc7_2"),
				trim(col("zone_operation").substr(574, 1)).as("oi_b_ic_ind_balance_paiement"),
				trim(col("zone_operation").substr(575, 30)).as("oi_b_ic_zone_usage_etblmt"),
				trim(col("zone_operation").substr(605, 1)).as("oi_b_ic_indice_circulation"),
				trim(col("zone_operation").substr(606, 1)).as("oi_b_ic_ind_cepc_concerne"),
				trim(col("zone_operation").substr(607, 34)).as("oi_b_ic_zone_reservee_ic"),
				col("zone_operation").substr(507, 2).as("code_type_client"),
				col("date_echange_initiale"),
				col("b_ric_code_motif").substr(1, 2).as("b_ric_code_motif_2c"),
				col("date_insert").as("date_insert"), col("date_ope").as("date_ope"))
				.withColumn("id_traitement",lit(idtrt));

		 
	}
	
	
	 public Dataset<Row> joinRicRef(Dataset<Row> minosDecoupPrep, Dataset<Row> refTableDF){

		 
		
		 
		 Dataset<Row> ricRefPerim = refTableDF.select(col("code_type_client_2c").cast(DataTypes.StringType)).distinct();
		
	  	 Dataset<Row> dataTemp = minosDecoupPrep.join(
	  			refTableDF,
					minosDecoupPrep
							.col("code_type_client")
							.equalTo(refTableDF.col("code_type_client_2c"))
							.and(minosDecoupPrep.col("date_echange_initiale").$greater$eq(refTableDF.col("date_debut")).and(col("date_echange_initiale").$less$eq(refTableDF.col("date_fin")))
									).and(col("b_ric_code_motif_2c").isin(lit("61"),lit("60")))
							,
					"left").persist();
	    	dataTemp.printSchema();
	    	
		  	List<Object> listeClients = dsToList(ricRefPerim) ; 
		 	    
	    	//return in the same order as the target tables columns
			Dataset<Row> dataFinal = 
			dataTemp.select(col("id_ope_connexe"), col("id_ope_initiale"),col("rio"), col("ref_operation"),
					col("code_operation"), col("id_type_operation"),col("code_famille_operation"), col("type_operation"),
					col("sens_echange"), col("systeme_echange"),col("date_echange"), col("date_reglement"),
					col("date_traitement_aval_recu"),col("delai_reglement_ope"), col("date_pec_amont"),
					col("num_remise"), col("num_remise_tech"),col("mnt_compense_sit"),	col("date_presentation_remise"),
					col("code_client_conventionne"), col("id_client"),col("code_grp_remettant"), col("lib_grp_remettant"),
					col("id_compte_do"), col("bic_do"), col("iban_do"),col("code_pays_do"), col("cle_iban_do"),
					col("code_banque_do"), col("code_guichet_do"),col("num_cpte_do"), col("cle_rib_do"),
					col("id_compte_dest"), col("bic_dest"),	col("iban_dest"), col("code_pays_dest"),
					col("cle_iban_dest"), col("code_banque_dest"),col("code_guichet_dest"), col("num_cpte_dest"),
					col("cle_rib_dest"), col("etblt_concerne"),	col("num_partition"), col("code_flux_arch"),
					col("ind_connexe"), col("zone_operation"),	col("date_comptable_evolmpm"),col("flag_debrayage_embargo"), col("xtimts"),
					col("s2_long_ope"), col("s3_code_article"),	col("s4_code_ope"), col("s5_type_id_do"),
					col("s6_id_etblt_do"), col("s7_type_id_dest"),col("s8_id_etblt_dest"),
					col("s9_critere_rout_secondaire"),col("s10_code_devise"), col("s11_mnt_compense"),
					col("s12_date_reglement_demande"),	col("s13_ind_modif_ddr"), col("s14_code_commission"),
					col("s15_commission_interbancaire"),col("s16_zone_reservee_declaration"),
					col("s17_code_anomalie"), col("s18_zone_reservee"),	col("b_ric_code_motif"), col("b_ric_ref_ope"),
					col("b_ric_indice_delai"),	col("b_ric_ind_restit_physque"),
					col("b_ric_indic_certif_non_pmt"),col("b_ric_nature_interdiction"),
					col("b_ric_date_interdiction"),	col("b_ric_date_presentation"),	col("b_ric_num_cheque"), col("b_ric_nom_tireur"),
					col("b_ric_lib_abre_domicil"),col("b_ric_num_cpte_tireur"),	col("b_ric_coord_expediteur"),
					col("b_ric_zone_usage_etblmt"),	col("b_ric_zone_reservee"),	col("oi_s2_long_ope"),
					col("oi_s3_code_article"),col("oi_s4_code_ope"),col("oi_s5_type_id_do"),
					col("oi_s6_id_etblt_do"),col("oi_s7_type_id_dest"),	col("oi_s8_id_etblt_dest"),
					col("oi_s9_critere_rout_secondaire"),col("oi_s10_code_devise"),
					col("oi_s11_mnt_compense"),col("oi_s12_date_reglement_demande"),
					col("oi_s13_ind_modif_ddr"),col("oi_s14_code_commission"),
					col("oi_s15_commission_interbancaire"),	col("oi_s16_zone_reservee_declaration"),
					col("oi_s17_code_anomalie"),col("oi_s18_zone_reservee"),
					col("oi_b_ic_sous_code_ope"),col("oi_b_ic_ref_ope"),
					col("oi_b_ic_zone_banquier_remettant"),	col("oi_b_ic_num_cheque_cmc7_4"),
					col("oi_b_ic_zone_interbancaire_cmc7_3"),col("oi_b_ic_zone_interieure_cmc7_2"),
					col("oi_b_ic_ind_balance_paiement"),col("oi_b_ic_zone_usage_etblmt"),
					col("oi_b_ic_indice_circulation"),	col("oi_b_ic_ind_cepc_concerne"),
					col("oi_b_ic_zone_reservee_ic"),col("code_type_client"),
					col("code_type_client_2c"),
					col("date_representation"),
					col("oi_b_ic_ref_ope").substr(1, 1).as("ic_ref_caractere_1"),
					col("oi_b_ic_ref_ope").substr(11, 1).as("ic_ref_caractere_11"),
					col("b_ric_code_motif_2c"),
					col("date_echange_initiale"),
					col("date_insert"), col("date_ope").as("date_ope"), col("id_traitement")
			)
			.withColumn("date_representation_prevue",
					when(col("code_type_client_2c").isNotNull().and(not(col("code_type_client").isin(DecoupageMinosConstant.CLIENT_SNCF_CODES.toArray()))).and(not(col("ic_ref_caractere_1").isin(DecoupageMinosConstant.REPIM_CARACTERE_1.toArray())).or(not(col("ic_ref_caractere_11").equalTo(lit("1")))).or(col("date_echange_initiale").$greater(col("date_echange")))),
								col("date_representation"))
					.otherwise(when(col("code_type_client_2c").isNotNull().and(col("code_type_client").isin(DecoupageMinosConstant.CLIENT_SNCF_CODES.toArray())).and(not(col("ic_ref_caractere_1").isin(DecoupageMinosConstant.REPIM_CARACTERE_1.toArray())).or(not(col("ic_ref_caractere_11").equalTo(lit("2")))).or(col("date_echange_initiale").$greater(col("date_echange")))),
							col("date_representation")).otherwise(lit(null).cast(DataTypes.DateType))))
			
			.withColumn("flag_repim",
					when(col("code_type_client").isin(listeClients.toArray()).and(col("b_ric_code_motif_2c").isin(DecoupageMinosConstant.REPIM_CODES_REJET.toArray())),
								lit("O")).otherwise(lit("N")))
			
			.withColumn("ref_ope_origine",
					when(col("code_type_client").isin(listeClients.toArray()).and(col("b_ric_code_motif_2c").isin(DecoupageMinosConstant.REPIM_CODES_REJET.toArray())),
							when(col("ic_ref_caractere_1").isin(DecoupageMinosConstant.REPIM_CARACTERE_1.toArray()).and(col("ic_ref_caractere_11").isin(DecoupageMinosConstant.REPIM_CARACTERE_11.toArray())), regexp_replace(col("oi_b_ic_ref_ope"), "(^.)(.{9})(.)","0$20"))
					.otherwise(col("oi_b_ic_ref_ope")))
					.otherwise(lit(null)))
			
			.withColumn("ref_repim_attendu",
	     		when(col("code_type_client").isin(listeClients.toArray()).and(not(col("ic_ref_caractere_1").isin(DecoupageMinosConstant.REPIM_CARACTERE_1.toArray()))).and(not(col("ic_ref_caractere_11").isin(DecoupageMinosConstant.REPIM_CARACTERE_11.toArray()))),
	     				when(col("b_ric_code_motif_2c").equalTo(lit("60")), regexp_replace(col("oi_b_ic_ref_ope"), "(^.)(.{9})(.)","9$21"))
	     				.otherwise(when(col("b_ric_code_motif_2c").equalTo(lit("61")), regexp_replace(col("oi_b_ic_ref_ope"), "(^.)(.{9})(.)","8$21"))))
			.otherwise(when(col("code_type_client").isin(DecoupageMinosConstant.CLIENT_SNCF_CODES.toArray()).and(col("ic_ref_caractere_1").isin(DecoupageMinosConstant.REPIM_CARACTERE_1.toArray())).and(col("ic_ref_caractere_11").equalTo(lit("1"))),regexp_replace(col("oi_b_ic_ref_ope"), "(.{10})(.)","$12")).otherwise(lit(null))))
			
			.withColumn("num_representation",
					when(col("code_type_client").isin(listeClients.toArray()).and(not(col("ic_ref_caractere_1").isin(DecoupageMinosConstant.REPIM_CARACTERE_1.toArray()))).and(not(col("ic_ref_caractere_11").isin(DecoupageMinosConstant.REPIM_CARACTERE_11.toArray()))).and(col("b_ric_code_motif_2c").isin(DecoupageMinosConstant.REPIM_CODES_REJET.toArray())),
							 lit("1").cast(DataTypes.IntegerType))
					.otherwise(when(col("code_type_client").isin(DecoupageMinosConstant.CLIENT_SNCF_CODES.toArray()).and(col("ic_ref_caractere_1").isin(DecoupageMinosConstant.REPIM_CARACTERE_1.toArray())).and(col("ic_ref_caractere_11").equalTo(lit("1"))).and(col("b_ric_code_motif_2c").isin(DecoupageMinosConstant.REPIM_CODES_REJET.toArray())),lit("2").cast(DataTypes.IntegerType)).otherwise(lit(null).cast(DataTypes.IntegerType))))
			
			.withColumn("rejet_definitif",
					when(col("code_type_client").isin(listeClients.toArray()).and(not(col("code_type_client").isin(DecoupageMinosConstant.CLIENT_SNCF_CODES.toArray()))).and(col("ic_ref_caractere_1").isin(DecoupageMinosConstant.REPIM_CARACTERE_1.toArray())).and(col("ic_ref_caractere_11").equalTo(lit("1"))).and(col("date_echange").$greater(col("date_echange_initiale"))),
							lit("O"))
					.otherwise(when(col("code_type_client").isin(DecoupageMinosConstant.CLIENT_SNCF_CODES.toArray()).and(col("ic_ref_caractere_1").isin(DecoupageMinosConstant.REPIM_CARACTERE_1.toArray())).and(col("ic_ref_caractere_11").equalTo(lit("2"))).and(col("date_echange").$greater(col("date_echange_initiale"))),
							lit("O")).otherwise(lit(null))))
			;

			return 
					dataFinal.select(col("id_ope_connexe"), col("id_ope_initiale"),col("rio"), col("ref_operation"),
							col("code_operation"), col("id_type_operation"),col("code_famille_operation"), col("type_operation"),
							col("sens_echange"), col("systeme_echange"),col("date_echange"), col("date_reglement"),
							col("date_traitement_aval_recu"),col("delai_reglement_ope"), col("date_pec_amont"),
							col("num_remise"), col("num_remise_tech"),col("mnt_compense_sit"),	col("date_presentation_remise"),
							col("code_client_conventionne"), col("id_client"),col("code_grp_remettant"), col("lib_grp_remettant"),
							col("id_compte_do"), col("bic_do"), col("iban_do"),col("code_pays_do"), col("cle_iban_do"),
							col("code_banque_do"), col("code_guichet_do"),col("num_cpte_do"), col("cle_rib_do"),
							col("id_compte_dest"), col("bic_dest"),	col("iban_dest"), col("code_pays_dest"),
							col("cle_iban_dest"), col("code_banque_dest"),col("code_guichet_dest"), col("num_cpte_dest"),
							col("cle_rib_dest"), col("etblt_concerne"),	col("num_partition"), col("code_flux_arch"),
							col("ind_connexe"), col("zone_operation"),	col("date_comptable_evolmpm"),col("flag_debrayage_embargo"), col("xtimts"),
							col("s2_long_ope"), col("s3_code_article"),	col("s4_code_ope"), col("s5_type_id_do"),
							col("s6_id_etblt_do"), col("s7_type_id_dest"),col("s8_id_etblt_dest"),
							col("s9_critere_rout_secondaire"),col("s10_code_devise"), col("s11_mnt_compense"),
							col("s12_date_reglement_demande"),	col("s13_ind_modif_ddr"), col("s14_code_commission"),
							col("s15_commission_interbancaire"),col("s16_zone_reservee_declaration"),
							col("s17_code_anomalie"), col("s18_zone_reservee"),	col("b_ric_code_motif"), col("b_ric_ref_ope"),
							col("b_ric_indice_delai"),	col("b_ric_ind_restit_physque"),
							col("b_ric_indic_certif_non_pmt"),col("b_ric_nature_interdiction"),
							col("b_ric_date_interdiction"),	col("b_ric_date_presentation"),	col("b_ric_num_cheque"), col("b_ric_nom_tireur"),
							col("b_ric_lib_abre_domicil"),col("b_ric_num_cpte_tireur"),	col("b_ric_coord_expediteur"),
							col("b_ric_zone_usage_etblmt"),	col("b_ric_zone_reservee"),	col("oi_s2_long_ope"),
							col("oi_s3_code_article"),col("oi_s4_code_ope"),col("oi_s5_type_id_do"),
							col("oi_s6_id_etblt_do"),col("oi_s7_type_id_dest"),	col("oi_s8_id_etblt_dest"),
							col("oi_s9_critere_rout_secondaire"),col("oi_s10_code_devise"),
							col("oi_s11_mnt_compense"),col("oi_s12_date_reglement_demande"),
							col("oi_s13_ind_modif_ddr"),col("oi_s14_code_commission"),
							col("oi_s15_commission_interbancaire"),	col("oi_s16_zone_reservee_declaration"),
							col("oi_s17_code_anomalie"),col("oi_s18_zone_reservee"),
							col("oi_b_ic_sous_code_ope"),col("oi_b_ic_ref_ope"),
							col("oi_b_ic_zone_banquier_remettant"),	col("oi_b_ic_num_cheque_cmc7_4"),
							col("oi_b_ic_zone_interbancaire_cmc7_3"),col("oi_b_ic_zone_interieure_cmc7_2"),
							col("oi_b_ic_ind_balance_paiement"),col("oi_b_ic_zone_usage_etblmt"),
							col("oi_b_ic_indice_circulation"),	col("oi_b_ic_ind_cepc_concerne"),
							col("oi_b_ic_zone_reservee_ic"),col("code_type_client"), 
							col("date_representation_prevue"),col("flag_repim"),col("ref_ope_origine"),col("ref_repim_attendu"),
							col("num_representation"),col("rejet_definitif"),col("date_insert"),
							col("date_ope").as("date_ope"), col("id_traitement")
					)
			;
		}

	/**
	 * Apply transformations to the source data Sort columns before insertion in
	 * target table
	 * 
	 * @param data
	 * @return DataFrame
	 */
	public Dataset<Row> prepareMinosAicData(Dataset<Row> data) {

		return data.select(col("id_operation").as("id_ope_connexe"), col("id_ope_initiale").as("id_ope_initiale"),
				col("rio").as("rio"), col("ref_operation").as("ref_operation"),
				col("code_operation").as("code_operation"), col("id_type_operation").as("id_type_operation"),
				col("code_famille_operation").as("code_famille_operation"), col("type_operation").as("type_operation"),
				col("sens_echange").as("sens_echange"), col("systeme_echange").as("systeme_echange"),
				col("date_echange").as("date_echange"), col("date_reglement").as("date_reglement"),
				col("date_traitement_aval_recu").as("date_traitement_aval_recu"),
				col("delai_reglement_ope").as("delai_reglement_ope"), col("date_pec_amont").as("date_pec_amont"),
				col("num_remise").as("num_remise"), col("num_remise_tech").as("num_remise_tech"),
				col("mnt_compense_sit").as("mnt_compense_sit"),
				col("date_presentation_remise").as("date_presentation_remise"),
				col("code_client_conventionne").as("code_client_conventionne"), col("id_client").as("id_client"),
				col("code_grp_remettant").as("code_grp_remettant"), col("lib_grp_remettant").as("lib_grp_remettant"),
				col("id_compte_do").as("id_compte_do"), col("bic_do").as("bic_do"), col("iban_do").as("iban_do"),
				col("code_pays_do").as("code_pays_do"), col("cle_iban_do").as("cle_iban_do"),
				col("code_banque_do").as("code_banque_do"), col("code_guichet_do").as("code_guichet_do"),
				col("num_cpte_do").as("num_cpte_do"), col("cle_rib_do").as("cle_rib_do"),
				col("id_compte_dest").as("id_compte_dest"), col("bic_dest").as("bic_dest"),
				col("iban_dest").as("iban_dest"), col("code_pays_dest").as("code_pays_dest"),
				col("cle_iban_dest").as("cle_iban_dest"), col("code_banque_dest").as("code_banque_dest"),
				col("code_guichet_dest").as("code_guichet_dest"), col("num_cpte_dest").as("num_cpte_dest"),
				col("cle_rib_dest").as("cle_rib_dest"), col("etblt_concerne").as("etblt_concerne"),
				col("num_partition").as("num_partition"), col("code_flux_arch").as("code_flux_arch"),
				col("ind_connexe").as("ind_connexe"), col("zone_operation").as("zone_operation"),
				col("date_comptable_evolmpm").as("date_comptable_evolmpm"),
				col("flag_debrayage_embargo").as("flag_debrayage_embargo"), col("xtimts").as("xtimts"),
				col("s2_long_ope").as("s2_long_ope"), col("s3_code_article").as("s3_code_article"),
				col("s4_code_ope").as("s4_code_ope"), col("s5_type_id_do").as("s5_type_id_do"),
				col("s6_id_etblt_do").as("s6_id_etblt_do"), col("s7_type_id_dest").as("s7_type_id_dest"),
				col("s8_id_etblt_dest").as("s8_id_etblt_dest"),
				col("s9_critere_rout_secondaire").as("s9_critere_rout_secondaire"),
				col("s10_code_devise").as("s10_code_devise"), col("s11_mnt_compense").as("s11_mnt_compense"),
				col("s12_date_reglement_demande").as("s12_date_reglement_demande"),
				col("s13_ind_modif_ddr").as("s13_ind_modif_ddr"), col("s14_code_commission").as("s14_code_commission"),
				col("s15_commission_interbancaire").as("s15_commission_interbancaire"),
				col("s16_zone_reservee_declaration").as("s16_zone_reservee_declaration"),
				col("s17_code_anomalie").as("s17_code_anomalie"), col("s18_zone_reservee").as("s18_zone_reservee"),
				col("b_aic_code_motif").as("b_aic_code_motif"), col("b_aic_ref_ope").as("b_aic_ref_ope"),
				col("b_aic_zone_usage_etabl").as("b_aic_zone_usage_etabl"),
				col("b_aic_zone_reservee").as("b_aic_zone_reservee"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(387, 4)).as("oi_s2_long_ope"),
				trim(col("zone_operation").substr(391, 2)).as("oi_s3_code_article"),
				trim(col("zone_operation").substr(393, 3)).as("oi_s4_code_ope"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(396, 1)).as("oi_s5_type_id_do"),
				trim(col("zone_operation").substr(397, 7)).as("oi_s6_id_etblt_do"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(404, 1)).as("oi_s7_type_id_dest"),
				trim(col("zone_operation").substr(405, 7)).as("oi_s8_id_etblt_dest"),
				trim(col("zone_operation").substr(412, 5)).as("oi_s9_critere_rout_secondaire"),
				trim(col("zone_operation").substr(417, 4)).as("oi_s10_code_devise"),
				callUDF("fromStingToDouble", col("zone_operation").substr(421, 16),
						col("zone_operation").substr(417, 4)).as("oi_s11_mnt_compense"),
				callUDF("fromString6toDate", col("zone_operation").substr(437, 6)).as("oi_s12_date_reglement_demande"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(443, 1)).as("oi_s13_ind_modif_ddr"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(444, 1)).as("oi_s14_code_commission"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(445, 6))
						.as("oi_s15_commission_interbancaire"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(451, 1))
						.as("oi_s16_zone_reservee_declaration"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(452, 2)).as("oi_s17_code_anomalie"),
				trim(col("zone_operation").substr(454, 11)).as("oi_s18_zone_reservee"),
				trim(col("zone_operation").substr(465, 4)).as("oi_b_ic_sous_code_ope"),
				trim(col("zone_operation").substr(469, 24)).as("oi_b_ic_ref_ope"),
				trim(col("zone_operation").substr(493, 50)).as("oi_b_ic_zone_banquier_remettant"),
				trim(col("zone_operation").substr(543, 7)).as("oi_b_ic_num_cheque_cmc7_4"),
				trim(col("zone_operation").substr(550, 12)).as("oi_b_ic_zone_interbancaire_cmc7_3"),
				trim(col("zone_operation").substr(562, 12)).as("oi_b_ic_zone_interieure_cmc7_2"),
				trim(col("zone_operation").substr(574, 1)).as("oi_b_ic_ind_balance_paiement"),
				trim(col("zone_operation").substr(575, 30)).as("oi_b_ic_zone_usage_etblmt"),
				trim(col("zone_operation").substr(605, 1)).as("oi_b_ic_indice_circulation"),
				trim(col("zone_operation").substr(606, 1)).as("oi_b_ic_ind_cepc_concerne"),
				trim(col("zone_operation").substr(607, 34)).as("oi_b_ic_zone_reservee_ic"),
				col("date_insert").as("date_insert"), col("date_ope").as("date_ope"))
				.withColumn("id_traitement",lit(idtrt));

	}

	/**
	 * Apply transformations to the source data Sort columns before insertion in
	 * target table
	 * 
	 * @param data
	 * @return DataFrame
	 */
	public Dataset<Row> prepareMinosRaicData(Dataset<Row> data) {

		return data.select(col("id_operation").as("id_ope_connexe"), col("id_ope_initiale").as("id_ope_initiale"),
				col("rio").as("rio"), col("ref_operation").as("ref_operation"),
				col("code_operation").as("code_operation"), col("id_type_operation").as("id_type_operation"),
				col("code_famille_operation").as("code_famille_operation"), col("type_operation").as("type_operation"),
				col("sens_echange").as("sens_echange"), col("systeme_echange").as("systeme_echange"),
				col("date_echange").as("date_echange"), col("date_reglement").as("date_reglement"),
				col("date_traitement_aval_recu").as("date_traitement_aval_recu"),
				col("delai_reglement_ope").as("delai_reglement_ope"), col("date_pec_amont").as("date_pec_amont"),
				col("num_remise").as("num_remise"), col("num_remise_tech").as("num_remise_tech"),
				col("mnt_compense_sit").as("mnt_compense_sit"),
				col("date_presentation_remise").as("date_presentation_remise"),
				col("code_client_conventionne").as("code_client_conventionne"), col("id_client").as("id_client"),
				col("code_grp_remettant").as("code_grp_remettant"), col("lib_grp_remettant").as("lib_grp_remettant"),
				col("id_compte_do").as("id_compte_do"), col("bic_do").as("bic_do"), col("iban_do").as("iban_do"),
				col("code_pays_do").as("code_pays_do"), col("cle_iban_do").as("cle_iban_do"),
				col("code_banque_do").as("code_banque_do"), col("code_guichet_do").as("code_guichet_do"),
				col("num_cpte_do").as("num_cpte_do"), col("cle_rib_do").as("cle_rib_do"),
				col("id_compte_dest").as("id_compte_dest"), col("bic_dest").as("bic_dest"),
				col("iban_dest").as("iban_dest"), col("code_pays_dest").as("code_pays_dest"),
				col("cle_iban_dest").as("cle_iban_dest"), col("code_banque_dest").as("code_banque_dest"),
				col("code_guichet_dest").as("code_guichet_dest"), col("num_cpte_dest").as("num_cpte_dest"),
				col("cle_rib_dest").as("cle_rib_dest"), col("etblt_concerne").as("etblt_concerne"),
				col("num_partition").as("num_partition"), col("code_flux_arch").as("code_flux_arch"),
				col("ind_connexe").as("ind_connexe"), col("zone_operation").as("zone_operation"),
				col("date_comptable_evolmpm").as("date_comptable_evolmpm"),
				col("flag_debrayage_embargo").as("flag_debrayage_embargo"), col("xtimts").as("xtimts"),
				col("s2_long_ope").as("s2_long_ope"), col("s3_code_article").as("s3_code_article"),
				col("s4_code_ope").as("s4_code_ope"), col("s5_type_id_do").as("s5_type_id_do"),
				col("s6_id_etblt_do").as("s6_id_etblt_do"), col("s7_type_id_dest").as("s7_type_id_dest"),
				col("s8_id_etblt_dest").as("s8_id_etblt_dest"),
				col("s9_critere_rout_secondaire").as("s9_critere_rout_secondaire"),
				col("s10_code_devise").as("s10_code_devise"), col("s11_mnt_compense").as("s11_mnt_compense"),
				col("s12_date_reglement_demande").as("s12_date_reglement_demande"),
				col("s13_ind_modif_ddr").as("s13_ind_modif_ddr"), col("s14_code_commission").as("s14_code_commission"),
				col("s15_commission_interbancaire").as("s15_commission_interbancaire"),
				col("s16_zone_reservee_declaration").as("s16_zone_reservee_declaration"),
				col("s17_code_anomalie").as("s17_code_anomalie"), col("s18_zone_reservee").as("s18_zone_reservee"),
				col("b_raic_code_motif").as("b_raic_code_motif"), col("b_raic_ref_ope").as("b_raic_ref_ope"),
				col("b_raic_zone_usage_etabl").as("b_raic_zone_usage_etabl"),
				col("b_raic_zone_reservee").as("b_raic_zone_reservee"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(195, 4)).as("aic_s2_long_ope"),
				trim(col("zone_operation").substr(199, 2)).as("aic_s3_code_article"),
				trim(col("zone_operation").substr(201, 3)).as("aic_s4_code_ope"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(204, 1)).as("aic_s5_type_id_do"),
				trim(col("zone_operation").substr(205, 7)).as("aic_s6_id_etblt_do"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(212, 1)).as("aic_s7_type_id_dest"),
				trim(col("zone_operation").substr(213, 7)).as("aic_s8_id_etblt_dest"),
				trim(col("zone_operation").substr(220, 5)).as("aic_s9_critere_rout_secondaire"),
				trim(col("zone_operation").substr(225, 4)).as("aic_s10_code_devise"),
				callUDF("fromStingToDouble", col("zone_operation").substr(229, 16),
						col("zone_operation").substr(225, 4)).as("aic_s11_mnt_compense"),
				callUDF("fromString6toDate", col("zone_operation").substr(245, 6)).as("aic_s12_date_reglement_demande"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(251, 1)).as("aic_s13_ind_modif_ddr"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(252, 1)).as("aic_s14_code_commission"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(253, 6))
						.as("aic_s15_commission_interbancaire"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(259, 1))
						.as("aic_s16_zone_reservee_declaration"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(260, 2)).as("aic_s17_code_anomalie"),
				trim(col("zone_operation").substr(262, 11)).as("aic_s18_zone_reservee"),
				trim(col("zone_operation").substr(273, 4)).as("aic_code_motif"),
				trim(col("zone_operation").substr(277, 24)).as("aic_ref_ope"),
				trim(col("zone_operation").substr(301, 30)).as("aic_zone_usage_etabl"),
				trim(col("zone_operation").substr(331, 246)).as("aic_zone_reservee"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(579, 4)).as("oi_s2_long_ope"),
				trim(col("zone_operation").substr(583, 2)).as("oi_s3_code_article"),
				trim(col("zone_operation").substr(585, 3)).as("oi_s4_code_ope"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(588, 1)).as("oi_s5_type_id_do"),
				trim(col("zone_operation").substr(589, 7)).as("oi_s6_id_etblt_do"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(596, 1)).as("oi_s7_type_id_dest"),
				trim(col("zone_operation").substr(597, 7)).as("oi_s8_id_etblt_dest"),
				trim(col("zone_operation").substr(604, 5)).as("oi_s9_critere_rout_secondaire"),
				trim(col("zone_operation").substr(609, 4)).as("oi_s10_code_devise"),
				callUDF("fromStingToDouble", col("zone_operation").substr(613, 16),
						col("zone_operation").substr(609, 4)).as("oi_s11_mnt_compense"),
				callUDF("fromString6toDate", col("zone_operation").substr(629, 6)).as("oi_s12_date_reglement_demande"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(635, 1)).as("oi_s13_ind_modif_ddr"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(636, 1)).as("oi_s14_code_commission"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(637, 6))
						.as("oi_s15_commission_interbancaire"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(643, 1))
						.as("oi_s16_zone_reservee_declaration"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(644, 2)).as("oi_s17_code_anomalie"),
				trim(col("zone_operation").substr(646, 11)).as("oi_s18_zone_reservee"),
				trim(col("zone_operation").substr(657, 4)).as("oi_b_ic_sous_code_ope"),
				trim(col("zone_operation").substr(661, 24)).as("oi_b_ic_ref_ope"),
				trim(col("zone_operation").substr(685, 50)).as("oi_b_ic_zone_banquier_remettant"),
				trim(col("zone_operation").substr(735, 7)).as("oi_b_ic_num_cheque_cmc7_4"),
				trim(col("zone_operation").substr(742, 12)).as("oi_b_ic_zone_interbancaire_cmc7_3"),
				trim(col("zone_operation").substr(754, 12)).as("oi_b_ic_zone_interieure_cmc7_2"),
				trim(col("zone_operation").substr(766, 1)).as("oi_b_ic_ind_balance_paiement"),
				trim(col("zone_operation").substr(767, 30)).as("oi_b_ic_zone_usage_etblmt"),
				trim(col("zone_operation").substr(797, 1)).as("oi_b_ic_indice_circulation"),
				trim(col("zone_operation").substr(798, 1)).as("oi_b_ic_ind_cepc_concerne"),
				trim(col("zone_operation").substr(799, 34)).as("oi_b_ic_zone_reservee_ic"),
				col("date_insert").as("date_insert"), 
				col("date_ope").as("date_ope"))
				.withColumn("id_traitement",lit(idtrt));

	}

	/**
	 * Apply transformations to the source data Sort columns before insertion in
	 * target table
	 * 
	 * @param data
	 * @return DataFrame
	 */
	public Dataset<Row> prepareMinosAricData(Dataset<Row> data) {

		return data.select(col("id_operation").as("id_ope_connexe"), col("id_ope_initiale").as("id_ope_initiale"),
				col("rio").as("rio"), col("ref_operation").as("ref_operation"),
				col("code_operation").as("code_operation"), col("id_type_operation").as("id_type_operation"),
				col("code_famille_operation").as("code_famille_operation"), col("type_operation").as("type_operation"),
				col("sens_echange").as("sens_echange"), col("systeme_echange").as("systeme_echange"),
				col("date_echange").as("date_echange"), col("date_reglement").as("date_reglement"),
				col("date_traitement_aval_recu").as("date_traitement_aval_recu"),
				col("delai_reglement_ope").as("delai_reglement_ope"), col("date_pec_amont").as("date_pec_amont"),
				col("num_remise").as("num_remise"), col("num_remise_tech").as("num_remise_tech"),
				col("mnt_compense_sit").as("mnt_compense_sit"),
				col("date_presentation_remise").as("date_presentation_remise"),
				col("code_client_conventionne").as("code_client_conventionne"), col("id_client").as("id_client"),
				col("code_grp_remettant").as("code_grp_remettant"), col("lib_grp_remettant").as("lib_grp_remettant"),
				col("id_compte_do").as("id_compte_do"), col("bic_do").as("bic_do"), col("iban_do").as("iban_do"),
				col("code_pays_do").as("code_pays_do"), col("cle_iban_do").as("cle_iban_do"),
				col("code_banque_do").as("code_banque_do"), col("code_guichet_do").as("code_guichet_do"),
				col("num_cpte_do").as("num_cpte_do"), col("cle_rib_do").as("cle_rib_do"),
				col("id_compte_dest").as("id_compte_dest"), col("bic_dest").as("bic_dest"),
				col("iban_dest").as("iban_dest"), col("code_pays_dest").as("code_pays_dest"),
				col("cle_iban_dest").as("cle_iban_dest"), col("code_banque_dest").as("code_banque_dest"),
				col("code_guichet_dest").as("code_guichet_dest"), col("num_cpte_dest").as("num_cpte_dest"),
				col("cle_rib_dest").as("cle_rib_dest"), col("etblt_concerne").as("etblt_concerne"),
				col("num_partition").as("num_partition"), col("code_flux_arch").as("code_flux_arch"),
				col("ind_connexe").as("ind_connexe"), col("zone_operation").as("zone_operation"),
				col("date_comptable_evolmpm").as("date_comptable_evolmpm"),
				col("flag_debrayage_embargo").as("flag_debrayage_embargo"), col("xtimts").as("xtimts"),
				col("s2_long_ope").as("s2_long_ope"), col("s3_code_article").as("s3_code_article"),
				col("s4_code_ope").as("s4_code_ope"), col("s5_type_id_do").as("s5_type_id_do"),
				col("s6_id_etblt_do").as("s6_id_etblt_do"), col("s7_type_id_dest").as("s7_type_id_dest"),
				col("s8_id_etblt_dest").as("s8_id_etblt_dest"),
				col("s9_critere_rout_secondaire").as("s9_critere_rout_secondaire"),
				col("s10_code_devise").as("s10_code_devise"), col("s11_mnt_compense").as("s11_mnt_compense"),
				col("s12_date_reglement_demande").as("s12_date_reglement_demande"),
				col("s13_ind_modif_ddr").as("s13_ind_modif_ddr"), col("s14_code_commission").as("s14_code_commission"),
				col("s15_commission_interbancaire").as("s15_commission_interbancaire"),
				col("s16_zone_reservee_declaration").as("s16_zone_reservee_declaration"),
				col("s17_code_anomalie").as("s17_code_anomalie"), col("s18_zone_reservee").as("s18_zone_reservee"),
				col("b_aric_code_motif").as("b_aric_code_motif"), col("b_aric_ref_ope").as("b_aric_ref_ope"),
				col("b_aric_zone_usage_etblt").as("b_aric_zone_usage_etblt"),
				col("b_aric_zone_reservee").as("b_aric_zone_reservee"),

				callUDF("fromStringtoInteger", col("zone_operation").substr(195, 4)).as("ric_s2_long_ope"),
				trim(col("zone_operation").substr(199, 2)).as("ric_s3_code_article"),
				trim(col("zone_operation").substr(201, 3)).as("ric_s4_code_ope"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(204, 1)).as("ric_s5_type_id_do"),
				trim(col("zone_operation").substr(205, 7)).as("ric_s6_id_etblt_do"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(212, 1)).as("ric_s7_type_id_dest"),
				trim(col("zone_operation").substr(213, 7)).as("ric_s8_id_etblt_dest"),
				trim(col("zone_operation").substr(220, 5)).as("ric_s9_critere_rout_secondaire"),
				trim(col("zone_operation").substr(225, 4)).as("ric_s10_code_devise"),
				callUDF("fromStingToDouble", col("zone_operation").substr(229, 16),
						col("zone_operation").substr(225, 4)).as("ric_s11_mnt_compense"),
				callUDF("fromString6toDate", col("zone_operation").substr(245, 6)).as("ric_s12_date_reglement_demande"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(251, 1)).as("ric_s13_ind_modif_ddr"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(252, 1)).as("ric_s14_code_commission"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(253, 6))
						.as("ric_s15_commission_interbancaire"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(259, 1))
						.as("ric_s16_zone_reservee_declaration"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(260, 2)).as("ric_s17_code_anomalie"),
				trim(col("zone_operation").substr(262, 11)).as("ric_s18_zone_reservee"),
			    trim(col("zone_operation").substr(273, 4)).as("ric_code_motif"),
				trim(col("zone_operation").substr(277, 24)).as("ric_ref_ope"),
				trim(col("zone_operation").substr(301, 1)).as("ric_indice_delai"),
				trim(col("zone_operation").substr(302, 1)).as("ric_ind_restit_physque"),
				trim(col("zone_operation").substr(303, 1)).as("ric_indic_certif_non_pmt"),
				trim(col("zone_operation").substr(304, 1)).as("ric_nature_interdiction"),
				callUDF("fromString8toDate", col("zone_operation").substr(305, 8)).as("ric_date_interdiction"),
				callUDF("fromString8toDate", col("zone_operation").substr(313, 8)).as("ric_date_presentation"),
				trim(col("zone_operation").substr(321, 7)).as("ric_num_cheque"),
				trim(col("zone_operation").substr(328, 24)).as("ric_nom_tireur"),
				trim(col("zone_operation").substr(352, 24)).as("ric_lib_abre_domicil"),
				trim(col("zone_operation").substr(376, 11)).as("ric_num_cpte_tireur"),
				trim(col("zone_operation").substr(387, 90)).as("ric_coord_expediteur"),
				trim(col("zone_operation").substr(477, 30)).as("ric_zone_usage_etblmt"),
				trim(col("zone_operation").substr(507, 70)).as("ric_zone_reservee"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(579, 4)).as("oi_s2_long_ope"),
		        trim(col("zone_operation").substr(583, 2)).as("oi_s3_code_article"),
				trim(col("zone_operation").substr(585, 3)).as("oi_s4_code_ope"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(588, 1)).as("oi_s5_type_id_do"),
				trim(col("zone_operation").substr(589, 7)).as("oi_s6_id_etblt_do"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(596, 1)).as("oi_s7_type_id_dest"),
				trim(col("zone_operation").substr(597, 7)).as("oi_s8_id_etblt_dest"),
				trim(col("zone_operation").substr(604, 5)).as("oi_s9_critere_rout_secondaire"),
				trim(col("zone_operation").substr(609, 4)).as("oi_s10_code_devise"),
				callUDF("fromStingToDouble", col("zone_operation").substr(613, 16),
						col("zone_operation").substr(609, 4)).as("oi_s11_mnt_compense"),
				callUDF("fromString6toDate", col("zone_operation").substr(629, 6)).as("oi_s12_date_reglement_demande"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(635, 1)).as("oi_s13_ind_modif_ddr"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(636, 1)).as("oi_s14_code_commission"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(637, 6))
						.as("oi_s15_commission_interbancaire"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(643, 1))
						.as("oi_s16_zone_reservee_declaration"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(644, 2)).as("oi_s17_code_anomalie"),
				trim(col("zone_operation").substr(646, 11)).as("oi_s18_zone_reservee"),
				trim(col("zone_operation").substr(657, 4)).as("oi_b_ic_sous_code_ope"),
				trim(col("zone_operation").substr(661, 24)).as("oi_b_ic_ref_ope"),
				trim(col("zone_operation").substr(685, 50)).as("oi_b_ic_zone_banquier_remettant"),
				trim(col("zone_operation").substr(735, 7)).as("oi_b_ic_num_cheque_cmc7_4"),
				trim(col("zone_operation").substr(742, 12)).as("oi_b_ic_zone_interbancaire_cmc7_3"),
				trim(col("zone_operation").substr(754, 12)).as("oi_b_ic_zone_interieure_cmc7_2"),
				trim(col("zone_operation").substr(766, 1)).as("oi_b_ic_ind_balance_paiement"),
				trim(col("zone_operation").substr(767, 30)).as("oi_b_ic_zone_usage_etblmt"),
				trim(col("zone_operation").substr(797, 1)).as("oi_b_ic_indice_circulation"),
			    trim(col("zone_operation").substr(798, 1)).as("oi_b_ic_ind_cepc_concerne"),
				trim(col("zone_operation").substr(799, 34)).as("oi_b_ic_zone_reservee_ic"),
				col("date_insert").as("date_insert"), 
				col("date_ope").as("date_ope"))
				.withColumn("id_traitement",lit(idtrt));

	}

	/**
	 * Apply transformations to the source data Sort columns before insertion in
	 * target table
	 * 
	 * @param data
	 * @return DataFrame
	 */
	public Dataset<Row> prepareMinosRaricData(Dataset<Row> data) {

		return data.select(col("id_operation").as("id_ope_connexe"), col("id_ope_initiale").as("id_ope_initiale"),
				col("rio").as("rio"), col("ref_operation").as("ref_operation"),
				col("code_operation").as("code_operation"), col("id_type_operation").as("id_type_operation"),
				col("code_famille_operation").as("code_famille_operation"), col("type_operation").as("type_operation"),
				col("sens_echange").as("sens_echange"), col("systeme_echange").as("systeme_echange"),
				col("date_echange").as("date_echange"), col("date_reglement").as("date_reglement"),
				col("date_traitement_aval_recu").as("date_traitement_aval_recu"),
				col("delai_reglement_ope").as("delai_reglement_ope"), col("date_pec_amont").as("date_pec_amont"),
				col("num_remise").as("num_remise"), col("num_remise_tech").as("num_remise_tech"),
				col("mnt_compense_sit").as("mnt_compense_sit"),
				col("date_presentation_remise").as("date_presentation_remise"),
				col("code_client_conventionne").as("code_client_conventionne"), col("id_client").as("id_client"),
				col("code_grp_remettant").as("code_grp_remettant"), col("lib_grp_remettant").as("lib_grp_remettant"),
				col("id_compte_do").as("id_compte_do"), col("bic_do").as("bic_do"), col("iban_do").as("iban_do"),
				col("code_pays_do").as("code_pays_do"), col("cle_iban_do").as("cle_iban_do"),
				col("code_banque_do").as("code_banque_do"), col("code_guichet_do").as("code_guichet_do"),
				col("num_cpte_do").as("num_cpte_do"), col("cle_rib_do").as("cle_rib_do"),
				col("id_compte_dest").as("id_compte_dest"), col("bic_dest").as("bic_dest"),
				col("iban_dest").as("iban_dest"), col("code_pays_dest").as("code_pays_dest"),
				col("cle_iban_dest").as("cle_iban_dest"), col("code_banque_dest").as("code_banque_dest"),
				col("code_guichet_dest").as("code_guichet_dest"), col("num_cpte_dest").as("num_cpte_dest"),
				col("cle_rib_dest").as("cle_rib_dest"), col("etblt_concerne").as("etblt_concerne"),
				col("num_partition").as("num_partition"), col("code_flux_arch").as("code_flux_arch"),
				col("ind_connexe").as("ind_connexe"), col("zone_operation").as("zone_operation"),
				col("date_comptable_evolmpm").as("date_comptable_evolmpm"),
				col("flag_debrayage_embargo").as("flag_debrayage_embargo"), col("xtimts").as("xtimts"),
				col("s2_long_ope").as("s2_long_ope"), col("s3_code_article").as("s3_code_article"),
				col("s4_code_ope").as("s4_code_ope"), col("s5_type_id_do").as("s5_type_id_do"),
				col("s6_id_etblt_do").as("s6_id_etblt_do"), col("s7_type_id_dest").as("s7_type_id_dest"),
				col("s8_id_etblt_dest").as("s8_id_etblt_dest"),
				col("s9_critere_rout_secondaire").as("s9_critere_rout_secondaire"),
				col("s10_code_devise").as("s10_code_devise"), col("s11_mnt_compense").as("s11_mnt_compense"),
				col("s12_date_reglement_demande").as("s12_date_reglement_demande"),
				col("s13_ind_modif_ddr").as("s13_ind_modif_ddr"), col("s14_code_commission").as("s14_code_commission"),
				col("s15_commission_interbancaire").as("s15_commission_interbancaire"),
				col("s16_zone_reservee_declaration").as("s16_zone_reservee_declaration"),
				col("s17_code_anomalie").as("s17_code_anomalie"), col("s18_zone_reservee").as("s18_zone_reservee"),

				col("b_raric_code_motif").as("b_raric_code_motif"), col("b_raric_ref_ope").as("b_raric_ref_ope"),
				col("b_raric_zone_usage_etblt").as("b_raric_zone_usage_etblt"),
				col("b_raric_zone_reservee").as("b_raric_zone_reservee"),

				callUDF("fromStringtoInteger", col("zone_operation").substr(195, 4)).as("aric_s2_long_ope"),
				trim(col("zone_operation").substr(199, 2)).as("aric_s3_code_article"),
				trim(col("zone_operation").substr(201, 3)).as("aric_s4_code_ope"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(204, 1)).as("aric_s5_type_id_do"),
				trim(col("zone_operation").substr(205, 7)).as("aric_s6_id_etblt_do"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(212, 1)).as("aric_s7_type_id_dest"),
				trim(col("zone_operation").substr(213, 7)).as("aric_s8_id_etblt_dest"),
				trim(col("zone_operation").substr(220, 5)).as("aric_s9_critere_rout_secondaire"),
				trim(col("zone_operation").substr(225, 4)).as("aric_s10_code_devise"),
				callUDF("fromStingToDouble", col("zone_operation").substr(229, 16),
						col("zone_operation").substr(225, 4)).as("aric_s11_mnt_compense"),
				callUDF("fromString6toDate", col("zone_operation").substr(245, 6))
						.as("aric_s12_date_reglement_demande"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(251, 1)).as("aric_s13_ind_modif_ddr"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(252, 1)).as("aric_s14_code_commission"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(253, 6))
						.as("aric_s15_commission_interbancaire"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(259, 1))
						.as("aric_s16_zone_reservee_declaration"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(260, 2)).as("aric_s17_code_anomalie"),
				trim(col("zone_operation").substr(262, 11)).as("aric_s18_zone_reservee"),
				trim(col("zone_operation").substr(273, 4)).as("aric_code_motif"),
				trim(col("zone_operation").substr(277, 24)).as("aric_ref_ope"),
				trim(col("zone_operation").substr(301, 30)).as("aric_zone_usage_etblt"),
				trim(col("zone_operation").substr(331, 54)).as("aric_zone_reservee"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(387, 4)).as("ric_s2_long_ope"),
				trim(col("zone_operation").substr(391, 2)).as("ric_s3_code_article"),
				trim(col("zone_operation").substr(393, 3)).as("ric_s4_code_ope"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(396, 1)).as("ric_s5_type_id_do"),
				trim(col("zone_operation").substr(397, 7)).as("ric_s6_id_etblt_do"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(404, 1)).as("ric_s7_type_id_dest"),
				trim(col("zone_operation").substr(405, 7)).as("ric_s8_id_etblt_dest"),
				trim(col("zone_operation").substr(412, 5)).as("ric_s9_critere_rout_secondaire"),
				trim(col("zone_operation").substr(417, 4)).as("ric_s10_code_devise"),
				callUDF("fromStingToDouble", col("zone_operation").substr(421, 16),	col("zone_operation").substr(417, 4)).as("ric_s11_mnt_compense"),
				callUDF("fromString6toDate", col("zone_operation").substr(437, 6)).as("ric_s12_date_reglement_demande"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(443, 1)).as("ric_s13_ind_modif_ddr"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(444, 1)).as("ric_s14_code_commission"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(445, 6))
						.as("ric_s15_commission_interbancaire"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(451, 1))
						.as("ric_s16_zone_reservee_declaration"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(452, 2)).as("ric_s17_code_anomalie"),
				trim(col("zone_operation").substr(454, 11)).as("ric_s18_zone_reservee"),
				trim(col("zone_operation").substr(465, 4)).as("ric_code_motif"),
				trim(col("zone_operation").substr(469, 24)).as("ric_ref_ope"),
				trim(col("zone_operation").substr(493, 1)).as("ric_indice_delai"),
				trim(col("zone_operation").substr(494, 1)).as("ric_ind_restit_physque"),
				trim(col("zone_operation").substr(495, 1)).as("ric_indic_certif_non_pmt"),
				trim(col("zone_operation").substr(496, 1)).as("ric_nature_interdiction"),
				callUDF("fromString8toDate", col("zone_operation").substr(497, 8)).as("ric_date_interdiction"),
				callUDF("fromString8toDate", col("zone_operation").substr(505, 8)).as("ric_date_presentation"),
				trim(col("zone_operation").substr(513, 7)).as("ric_num_cheque"),
				trim(col("zone_operation").substr(520, 24)).as("ric_nom_tireur"),
				trim(col("zone_operation").substr(544, 24)).as("ric_lib_abre_domicil"),
				trim(col("zone_operation").substr(568, 11)).as("ric_num_cpte_tireur"),
				trim(col("zone_operation").substr(579, 90)).as("ric_coord_expediteur"),
				trim(col("zone_operation").substr(669, 30)).as("ric_zone_usage_etblmt"),
				trim(col("zone_operation").substr(699, 70)).as("ric_zone_reservee"),

				callUDF("fromStringtoInteger", col("zone_operation").substr(771, 4)).as("oi_s2_long_ope"),
				trim(col("zone_operation").substr(775, 2)).as("oi_s3_code_article"),
				trim(col("zone_operation").substr(777, 3)).as("oi_s4_code_ope"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(780, 1)).as("oi_s5_type_id_do"),
				trim(col("zone_operation").substr(781, 7)).as("oi_s6_id_etblt_do"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(788, 1)).as("oi_s7_type_id_dest"),
				trim(col("zone_operation").substr(789, 7)).as("oi_s8_id_etblt_dest"),
				trim(col("zone_operation").substr(796, 5)).as("oi_s9_critere_rout_secondaire"),
				trim(col("zone_operation").substr(801, 4)).as("oi_s10_code_devise"),
				callUDF("fromStingToDouble", col("zone_operation").substr(805, 16),
				         col("zone_operation").substr(801, 4)).as("oi_s11_mnt_compense"),
				callUDF("fromString6toDate", col("zone_operation").substr(821, 6)).as("oi_s12_date_reglement_demande"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(827, 1)).as("oi_s13_ind_modif_ddr"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(828, 1)).as("oi_s14_code_commission"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(829, 6))
						.as("oi_s15_commission_interbancaire"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(835, 1))
						.as("oi_s16_zone_reservee_declaration"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(836, 2)).as("oi_s17_code_anomalie"),
				trim(col("zone_operation").substr(838, 11)).as("oi_s18_zone_reservee"),
				trim(col("zone_operation").substr(849, 4)).as("oi_b_ic_sous_code_ope"),
				trim(col("zone_operation").substr(853, 24)).as("oi_b_ic_ref_ope"),
				trim(col("zone_operation").substr(877, 50)).as("oi_b_ic_zone_banquier_remettant"),
				trim(col("zone_operation").substr(927, 7)).as("oi_b_ic_num_cheque_cmc7_4"),
				trim(col("zone_operation").substr(934, 12)).as("oi_b_ic_zone_interbancaire_cmc7_3"),
				trim(col("zone_operation").substr(946, 12)).as("oi_b_ic_zone_interieure_cmc7_2"),
				trim(col("zone_operation").substr(958, 1)).as("oi_b_ic_ind_balance_paiement"),
				trim(col("zone_operation").substr(959, 30)).as("oi_b_ic_zone_usage_etblmt"),
				trim(col("zone_operation").substr(989, 1)).as("oi_b_ic_indice_circulation"),
				trim(col("zone_operation").substr(990, 1)).as("oi_b_ic_ind_cepc_concerne"),
				trim(col("zone_operation").substr(991, 34)).as("oi_b_ic_zone_reservee_ic"),
				col("date_insert").as("date_insert"), 
				col("date_ope").as("date_ope"))
				.withColumn("id_traitement",lit(idtrt));

	}

	/**
	 * Apply transformations to the source data Sort columns before insertion in
	 * target table
	 * 
	 * @param data
	 * @return DataFrame
	 */
	public Dataset<Row> prepareMinosDtcData(Dataset<Row> data) {

		return data.select(col("id_operation").as("id_ope_connexe"), col("id_ope_initiale").as("id_ope_initiale"),
				col("rio").as("rio"), col("ref_operation").as("ref_operation"),
				col("code_operation").as("code_operation"), col("id_type_operation").as("id_type_operation"),
				col("code_famille_operation").as("code_famille_operation"), col("type_operation").as("type_operation"),
				col("sens_echange").as("sens_echange"), col("systeme_echange").as("systeme_echange"),
				col("date_echange").as("date_echange"), col("date_reglement").as("date_reglement"),
				col("date_traitement_aval_recu").as("date_traitement_aval_recu"),
				col("delai_reglement_ope").as("delai_reglement_ope"), col("date_pec_amont").as("date_pec_amont"),
				col("num_remise").as("num_remise"), col("num_remise_tech").as("num_remise_tech"),
				col("mnt_compense_sit").as("mnt_compense_sit"),
				col("date_presentation_remise").as("date_presentation_remise"),
				col("code_client_conventionne").as("code_client_conventionne"), col("id_client").as("id_client"),
				col("code_grp_remettant").as("code_grp_remettant"), col("lib_grp_remettant").as("lib_grp_remettant"),
				col("id_compte_do").as("id_compte_do"), col("bic_do").as("bic_do"), col("iban_do").as("iban_do"),
				col("code_pays_do").as("code_pays_do"), col("cle_iban_do").as("cle_iban_do"),
				col("code_banque_do").as("code_banque_do"), col("code_guichet_do").as("code_guichet_do"),
				col("num_cpte_do").as("num_cpte_do"), col("cle_rib_do").as("cle_rib_do"),
				col("id_compte_dest").as("id_compte_dest"), col("bic_dest").as("bic_dest"),
				col("iban_dest").as("iban_dest"), col("code_pays_dest").as("code_pays_dest"),
				col("cle_iban_dest").as("cle_iban_dest"), col("code_banque_dest").as("code_banque_dest"),
				col("code_guichet_dest").as("code_guichet_dest"), col("num_cpte_dest").as("num_cpte_dest"),
				col("cle_rib_dest").as("cle_rib_dest"), col("etblt_concerne").as("etblt_concerne"),
				col("num_partition").as("num_partition"), col("code_flux_arch").as("code_flux_arch"),
				col("ind_connexe").as("ind_connexe"), col("zone_operation").as("zone_operation"),
				col("date_comptable_evolmpm").as("date_comptable_evolmpm"),
				col("flag_debrayage_embargo").as("flag_debrayage_embargo"), col("xtimts").as("xtimts"),
				col("s2_long_ope").as("s2_long_ope"), col("s3_code_article").as("s3_code_article"),
				col("s4_code_ope").as("s4_code_ope"), col("s5_type_id_do").as("s5_type_id_do"),
				col("s6_id_etblt_do").as("s6_id_etblt_do"), col("s7_type_id_dest").as("s7_type_id_dest"),
				col("s8_id_etblt_dest").as("s8_id_etblt_dest"),
				col("s9_critere_rout_secondaire").as("s9_critere_rout_secondaire"),
				col("s10_code_devise").as("s10_code_devise"), col("s11_mnt_compense").as("s11_mnt_compense"),
				col("s12_date_reglement_demande").as("s12_date_reglement_demande"),
				col("s13_ind_modif_ddr").as("s13_ind_modif_ddr"), col("s14_code_commission").as("s14_code_commission"),
				col("s15_commission_interbancaire").as("s15_commission_interbancaire"),
				col("s16_zone_reservee_declaration").as("s16_zone_reservee_declaration"),
				col("s17_code_anomalie").as("s17_code_anomalie"), col("s18_zone_reservee").as("s18_zone_reservee"),

				col("b_dtc_nature_demande").as("b_dtc_nature_demande"), col("b_dtc_ref_ope").as("b_dtc_ref_ope"),
				col("b_dtc_coord_exp").as("b_dtc_coord_exp"), col("b_dtc_zone_etablt").as("b_dtc_zone_etablt"),
				col("b_dtc_ident_emetteur").as("b_dtc_ident_emetteur"),
				col("b_dtc_zone_reservee").as("b_dtc_zone_reservee"),

				callUDF("fromStringtoInteger", col("zone_operation").substr(387, 4)).as("oi_s2_long_ope"),
				trim(col("zone_operation").substr(391, 2)).as("oi_s3_code_article"),
						trim(col("zone_operation").substr(393, 3)).as("oi_s4_code_ope"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(396, 1)).as("oi_s5_type_id_do"),
				trim(col("zone_operation").substr(397, 7)).as("oi_s6_id_etblt_do"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(404, 1)).as("oi_s7_type_id_dest"),
				trim(col("zone_operation").substr(405, 7)).as("oi_s8_id_etblt_dest"),
				trim(col("zone_operation").substr(412, 5)).as("oi_s9_critere_rout_secondaire"),
						trim(col("zone_operation").substr(417, 4)).as("oi_s10_code_devise"),
				callUDF("fromStingToDouble", col("zone_operation").substr(421, 16),
						col("zone_operation").substr(417, 4)).as("oi_s11_mnt_compense"),
				callUDF("fromString6toDate", col("zone_operation").substr(437, 6)).as("oi_s12_date_reglement_demande"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(443, 1)).as("oi_s13_ind_modif_ddr"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(444, 1)).as("oi_s14_code_commission"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(445, 6))
						.as("oi_s15_commission_interbancaire"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(451, 1))
						.as("oi_s16_zone_reservee_declaration"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(452, 2)).as("oi_s17_code_anomalie"),
				trim(col("zone_operation").substr(454, 11)).as("oi_s18_zone_reservee"),
						trim(col("zone_operation").substr(465, 4)).as("oi_b_ic_sous_code_ope"),
				trim(col("zone_operation").substr(469, 24)).as("oi_b_ic_ref_ope"),
						trim(col("zone_operation").substr(493, 50)).as("oi_b_ic_zone_banquier_remettant"),
				trim(col("zone_operation").substr(543, 7)).as("oi_b_ic_num_cheque_cmc7_4"),
						trim(col("zone_operation").substr(550, 12)).as("oi_b_ic_zone_interbancaire_cmc7_3"),
				trim(col("zone_operation").substr(562, 12)).as("oi_b_ic_zone_interieure_cmc7_2"),
						trim(col("zone_operation").substr(574, 1)).as("oi_b_ic_ind_balance_paiement"),
				trim(col("zone_operation").substr(575, 30)).as("oi_b_ic_zone_usage_etblmt"),
						trim(col("zone_operation").substr(605, 1)).as("oi_b_ic_indice_circulation"),
				trim(col("zone_operation").substr(606, 1)).as("oi_b_ic_ind_cepc_concerne"),
						trim(col("zone_operation").substr(607, 34)).as("oi_b_ic_zone_reservee_ic"),
				col("date_insert").as("date_insert"), 
				col("date_ope").as("date_ope"))
				.withColumn("id_traitement",lit(idtrt));

	}

	/**
	 * Apply transformations to the source data Sort columns before insertion in
	 * target table
	 * 
	 * @param data
	 * @return DataFrame
	 */
	public Dataset<Row> prepareMinosOdrData(Dataset<Row> data) {

		return data.select(col("id_operation").as("id_ope_connexe"), col("id_ope_initiale").as("id_ope_initiale"),
				col("rio").as("rio"), col("ref_operation").as("ref_operation"),
				col("code_operation").as("code_operation"), col("id_type_operation").as("id_type_operation"),
				col("code_famille_operation").as("code_famille_operation"), col("type_operation").as("type_operation"),
				col("sens_echange").as("sens_echange"), col("systeme_echange").as("systeme_echange"),
				col("date_echange").as("date_echange"), col("date_reglement").as("date_reglement"),
				col("date_traitement_aval_recu").as("date_traitement_aval_recu"),
				col("delai_reglement_ope").as("delai_reglement_ope"), col("date_pec_amont").as("date_pec_amont"),
				col("num_remise").as("num_remise"), col("num_remise_tech").as("num_remise_tech"),
				col("mnt_compense_sit").as("mnt_compense_sit"),
				col("date_presentation_remise").as("date_presentation_remise"),
				col("code_client_conventionne").as("code_client_conventionne"), col("id_client").as("id_client"),
				col("code_grp_remettant").as("code_grp_remettant"), col("lib_grp_remettant").as("lib_grp_remettant"),
				col("id_compte_do").as("id_compte_do"), col("bic_do").as("bic_do"), col("iban_do").as("iban_do"),
				col("code_pays_do").as("code_pays_do"), col("cle_iban_do").as("cle_iban_do"),
				col("code_banque_do").as("code_banque_do"), col("code_guichet_do").as("code_guichet_do"),
				col("num_cpte_do").as("num_cpte_do"), col("cle_rib_do").as("cle_rib_do"),
				col("id_compte_dest").as("id_compte_dest"), col("bic_dest").as("bic_dest"),
				col("iban_dest").as("iban_dest"), col("code_pays_dest").as("code_pays_dest"),
				col("cle_iban_dest").as("cle_iban_dest"), col("code_banque_dest").as("code_banque_dest"),
				col("code_guichet_dest").as("code_guichet_dest"), col("num_cpte_dest").as("num_cpte_dest"),
				col("cle_rib_dest").as("cle_rib_dest"), col("etblt_concerne").as("etblt_concerne"),
				col("num_partition").as("num_partition"), col("code_flux_arch").as("code_flux_arch"),
				col("ind_connexe").as("ind_connexe"), col("zone_operation").as("zone_operation"),
				col("date_comptable_evolmpm").as("date_comptable_evolmpm"),
				col("flag_debrayage_embargo").as("flag_debrayage_embargo"), col("xtimts").as("xtimts"),
				col("s2_long_ope").as("s2_long_ope"), col("s3_code_article").as("s3_code_article"),
				col("s4_code_ope").as("s4_code_ope"), col("s5_type_id_do").as("s5_type_id_do"),
				col("s6_id_etblt_do").as("s6_id_etblt_do"), col("s7_type_id_dest").as("s7_type_id_dest"),
				col("s8_id_etblt_dest").as("s8_id_etblt_dest"),
				col("s9_critere_rout_secondaire").as("s9_critere_rout_secondaire"),
				col("s10_code_devise").as("s10_code_devise"), col("s11_mnt_compense").as("s11_mnt_compense"),
				col("s12_date_reglement_demande").as("s12_date_reglement_demande"),
				col("s13_ind_modif_ddr").as("s13_ind_modif_ddr"), col("s14_code_commission").as("s14_code_commission"),
				col("s15_commission_interbancaire").as("s15_commission_interbancaire"),
				col("s16_zone_reservee_declaration").as("s16_zone_reservee_declaration"),
				col("s17_code_anomalie").as("s17_code_anomalie"), col("s18_zone_reservee").as("s18_zone_reservee"),

				col("b_odr_nature_ope").as("b_odr_nature_ope"), col("b_odr_ref_ope").as("b_odr_ref_ope"),
				col("b_odr_motif").as("b_odr_motif"), col("b_odr_coord_expediteur").as("b_odr_coord_expediteur"),
				col("b_odr_zone_usage_etblmt").as("b_odr_zone_usage_etblmt"),
				col("b_odr_zone_lib_contact").as("b_odr_zone_lib_contact"),
				col("b_odr_date_reglement").as("b_odr_date_reglement"),
				col("b_odr_zone_reservee").as("b_odr_zone_reservee"),

				callUDF("fromStringtoInteger", col("zone_operation").substr(387, 4)).as("oi_s2_long_ope"),
				trim(col("zone_operation").substr(391, 2)).as("oi_s3_code_article"),
						trim(col("zone_operation").substr(393, 3)).as("oi_s4_code_ope"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(396, 1)).as("oi_s5_type_id_do"),
				trim(col("zone_operation").substr(397, 7)).as("oi_s6_id_etblt_do"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(404, 1)).as("oi_s7_type_id_dest"),
				trim(col("zone_operation").substr(405, 7)).as("oi_s8_id_etblt_dest"),
						trim(col("zone_operation").substr(412, 5)).as("oi_s9_critere_rout_secondaire"),
				trim(col("zone_operation").substr(417, 4)).as("oi_s10_code_devise"),
				callUDF("fromStingToDouble", col("zone_operation").substr(421, 16),
						col("zone_operation").substr(417, 4)).as("oi_s11_mnt_compense"),
				callUDF("fromString6toDate", col("zone_operation").substr(437, 6)).as("oi_s12_date_reglement_demande"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(443, 1)).as("oi_s13_ind_modif_ddr"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(444, 1)).as("oi_s14_code_commission"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(445, 6))
						.as("oi_s15_commission_interbancaire"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(451, 1))
						.as("oi_s16_zone_reservee_declaration"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(452, 2)).as("oi_s17_code_anomalie"),
				trim(col("zone_operation").substr(454, 11)).as("oi_s18_zone_reservee"),
				trim(col("zone_operation").substr(465, 4)).as("oi_b_ic_sous_code_ope"),
				trim(col("zone_operation").substr(469, 24)).as("oi_b_ic_ref_ope"),
				trim(col("zone_operation").substr(493, 50)).as("oi_b_ic_zone_banquier_remettant"),
				trim(col("zone_operation").substr(543, 7)).as("oi_b_ic_num_cheque_cmc7_4"),
				trim(col("zone_operation").substr(550, 12)).as("oi_b_ic_zone_interbancaire_cmc7_3"),
				trim(col("zone_operation").substr(562, 12)).as("oi_b_ic_zone_interieure_cmc7_2"),
				trim(col("zone_operation").substr(574, 1)).as("oi_b_ic_ind_balance_paiement"),
				trim(col("zone_operation").substr(575, 30)).as("oi_b_ic_zone_usage_etblmt"),
				trim(col("zone_operation").substr(605, 1)).as("oi_b_ic_indice_circulation"),
				trim(col("zone_operation").substr(606, 1)).as("oi_b_ic_ind_cepc_concerne"),
				trim(col("zone_operation").substr(607, 34)).as("oi_b_ic_zone_reservee_ic"),
				col("date_insert").as("date_insert"), 
				col("date_ope").as("date_ope"))
				.withColumn("id_traitement",lit(idtrt));

	}

	/**
	 * Apply transformations to the source data Sort columns before insertion in
	 * target table
	 * 
	 * @param data
	 * @return DataFrame
	 */
	public Dataset<Row> prepareMinosOcrData(Dataset<Row> data) {

		return data.select(col("id_operation").as("id_ope_connexe"), col("id_ope_initiale").as("id_ope_initiale"),
				col("rio").as("rio"), col("ref_operation").as("ref_operation"),
				col("code_operation").as("code_operation"), col("id_type_operation").as("id_type_operation"),
				col("code_famille_operation").as("code_famille_operation"), col("type_operation").as("type_operation"),
				col("sens_echange").as("sens_echange"), col("systeme_echange").as("systeme_echange"),
				col("date_echange").as("date_echange"), col("date_reglement").as("date_reglement"),
				col("date_traitement_aval_recu").as("date_traitement_aval_recu"),
				col("delai_reglement_ope").as("delai_reglement_ope"), col("date_pec_amont").as("date_pec_amont"),
				col("num_remise").as("num_remise"), col("num_remise_tech").as("num_remise_tech"),
				col("mnt_compense_sit").as("mnt_compense_sit"),
				col("date_presentation_remise").as("date_presentation_remise"),
				col("code_client_conventionne").as("code_client_conventionne"), col("id_client").as("id_client"),
				col("code_grp_remettant").as("code_grp_remettant"), col("lib_grp_remettant").as("lib_grp_remettant"),
				col("id_compte_do").as("id_compte_do"), col("bic_do").as("bic_do"), col("iban_do").as("iban_do"),
				col("code_pays_do").as("code_pays_do"), col("cle_iban_do").as("cle_iban_do"),
				col("code_banque_do").as("code_banque_do"), col("code_guichet_do").as("code_guichet_do"),
				col("num_cpte_do").as("num_cpte_do"), col("cle_rib_do").as("cle_rib_do"),
				col("id_compte_dest").as("id_compte_dest"), col("bic_dest").as("bic_dest"),
				col("iban_dest").as("iban_dest"), col("code_pays_dest").as("code_pays_dest"),
				col("cle_iban_dest").as("cle_iban_dest"), col("code_banque_dest").as("code_banque_dest"),
				col("code_guichet_dest").as("code_guichet_dest"), col("num_cpte_dest").as("num_cpte_dest"),
				col("cle_rib_dest").as("cle_rib_dest"), col("etblt_concerne").as("etblt_concerne"),
				col("num_partition").as("num_partition"), col("code_flux_arch").as("code_flux_arch"),
				col("ind_connexe").as("ind_connexe"), col("zone_operation").as("zone_operation"),
				col("date_comptable_evolmpm").as("date_comptable_evolmpm"),
				col("flag_debrayage_embargo").as("flag_debrayage_embargo"), col("xtimts").as("xtimts"),
				col("s2_long_ope").as("s2_long_ope"), col("s3_code_article").as("s3_code_article"),
				col("s4_code_ope").as("s4_code_ope"), col("s5_type_id_do").as("s5_type_id_do"),
				col("s6_id_etblt_do").as("s6_id_etblt_do"), col("s7_type_id_dest").as("s7_type_id_dest"),
				col("s8_id_etblt_dest").as("s8_id_etblt_dest"),
				col("s9_critere_rout_secondaire").as("s9_critere_rout_secondaire"),
				col("s10_code_devise").as("s10_code_devise"), col("s11_mnt_compense").as("s11_mnt_compense"),
				col("s12_date_reglement_demande").as("s12_date_reglement_demande"),
				col("s13_ind_modif_ddr").as("s13_ind_modif_ddr"), col("s14_code_commission").as("s14_code_commission"),
				col("s15_commission_interbancaire").as("s15_commission_interbancaire"),
				col("s16_zone_reservee_declaration").as("s16_zone_reservee_declaration"),
				col("s17_code_anomalie").as("s17_code_anomalie"), col("s18_zone_reservee").as("s18_zone_reservee"),

				col("b_ocr_nature_ope").as("b_ocr_nature_ope"), col("b_ocr_ref_ope").as("b_ocr_ref_ope"),
				col("b_ocr_motif").as("b_ocr_motif"), col("b_ocr_coord_expediteur").as("b_ocr_coord_expediteur"),
				col("b_ocr_zone_usage_etblmt").as("b_ocr_zone_usage_etblmt"),
				col("b_ocr_zone_lib_contact").as("b_ocr_zone_lib_contact"),
				col("b_ocr_date_reglement").as("b_ocr_date_reglement"),
				col("b_ocr_zone_reservee").as("b_ocr_zone_reservee"),

				callUDF("fromStringtoInteger", col("zone_operation").substr(387, 4)).as("oi_s2_long_ope"),
				trim(col("zone_operation").substr(391, 2)).as("oi_s3_code_article"),
						trim(col("zone_operation").substr(393, 3)).as("oi_s4_code_ope"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(396, 1)).as("oi_s5_type_id_do"),
				trim(col("zone_operation").substr(397, 7)).as("oi_s6_id_etblt_do"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(404, 1)).as("oi_s7_type_id_dest"),
				trim(col("zone_operation").substr(405, 7)).as("oi_s8_id_etblt_dest"),
						trim(col("zone_operation").substr(412, 5)).as("oi_s9_critere_rout_secondaire"),
				trim(col("zone_operation").substr(417, 4)).as("oi_s10_code_devise"),
				callUDF("fromStingToDouble", col("zone_operation").substr(421, 16),
						col("zone_operation").substr(417, 4)).as("oi_s11_mnt_compense"),
				callUDF("fromString6toDate", col("zone_operation").substr(437, 6)).as("oi_s12_date_reglement_demande"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(443, 1)).as("oi_s13_ind_modif_ddr"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(444, 1)).as("oi_s14_code_commission"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(445, 6))
						.as("oi_s15_commission_interbancaire"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(451, 1))
						.as("oi_s16_zone_reservee_declaration"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(452, 2)).as("oi_s17_code_anomalie"),
				trim(col("zone_operation").substr(454, 11)).as("oi_s18_zone_reservee"),
						trim(col("zone_operation").substr(465, 4)).as("oi_b_ic_sous_code_ope"),
				trim(col("zone_operation").substr(469, 24)).as("oi_b_ic_ref_ope"),
						trim(col("zone_operation").substr(493, 50)).as("oi_b_ic_zone_banquier_remettant"),
				trim(col("zone_operation").substr(543, 7)).as("oi_b_ic_num_cheque_cmc7_4"),
						trim(col("zone_operation").substr(550, 12)).as("oi_b_ic_zone_interbancaire_cmc7_3"),
				trim(col("zone_operation").substr(562, 12)).as("oi_b_ic_zone_interieure_cmc7_2"),
						trim(col("zone_operation").substr(574, 1)).as("oi_b_ic_ind_balance_paiement"),
				trim(col("zone_operation").substr(575, 30)).as("oi_b_ic_zone_usage_etblmt"),
						trim(col("zone_operation").substr(605, 1)).as("oi_b_ic_indice_circulation"),
				trim(col("zone_operation").substr(606, 1)).as("oi_b_ic_ind_cepc_concerne"),
						trim(col("zone_operation").substr(607, 34)).as("oi_b_ic_zone_reservee_ic"),
				col("date_insert").as("date_insert"), 
				col("date_ope").as("date_ope"))
				.withColumn("id_traitement",lit(idtrt));

	}

	/**
	 * Apply transformations to the source data Sort columns before insertion in
	 * target table
	 * 
	 * @param data
	 * @return DataFrame
	 */
	public Dataset<Row> prepareMinosOncData(Dataset<Row> data) {

		return data.select(col("id_operation").as("id_ope_connexe"), col("id_ope_initiale").as("id_ope_initiale"),
				col("rio").as("rio"), col("ref_operation").as("ref_operation"),
				col("code_operation").as("code_operation"), col("id_type_operation").as("id_type_operation"),
				col("code_famille_operation").as("code_famille_operation"), col("type_operation").as("type_operation"),
				col("sens_echange").as("sens_echange"), col("systeme_echange").as("systeme_echange"),
				col("date_echange").as("date_echange"), col("date_reglement").as("date_reglement"),
				col("date_traitement_aval_recu").as("date_traitement_aval_recu"),
				col("delai_reglement_ope").as("delai_reglement_ope"), col("date_pec_amont").as("date_pec_amont"),
				col("num_remise").as("num_remise"), col("num_remise_tech").as("num_remise_tech"),
				col("mnt_compense_sit").as("mnt_compense_sit"),
				col("date_presentation_remise").as("date_presentation_remise"),
				col("code_client_conventionne").as("code_client_conventionne"), col("id_client").as("id_client"),
				col("code_grp_remettant").as("code_grp_remettant"), col("lib_grp_remettant").as("lib_grp_remettant"),
				col("id_compte_do").as("id_compte_do"), col("bic_do").as("bic_do"), col("iban_do").as("iban_do"),
				col("code_pays_do").as("code_pays_do"), col("cle_iban_do").as("cle_iban_do"),
				col("code_banque_do").as("code_banque_do"), col("code_guichet_do").as("code_guichet_do"),
				col("num_cpte_do").as("num_cpte_do"), col("cle_rib_do").as("cle_rib_do"),
				col("id_compte_dest").as("id_compte_dest"), col("bic_dest").as("bic_dest"),
				col("iban_dest").as("iban_dest"), col("code_pays_dest").as("code_pays_dest"),
				col("cle_iban_dest").as("cle_iban_dest"), col("code_banque_dest").as("code_banque_dest"),
				col("code_guichet_dest").as("code_guichet_dest"), col("num_cpte_dest").as("num_cpte_dest"),
				col("cle_rib_dest").as("cle_rib_dest"), col("etblt_concerne").as("etblt_concerne"),
				col("num_partition").as("num_partition"), col("code_flux_arch").as("code_flux_arch"),
				col("ind_connexe").as("ind_connexe"), col("zone_operation").as("zone_operation"),
				col("date_comptable_evolmpm").as("date_comptable_evolmpm"),
				col("flag_debrayage_embargo").as("flag_debrayage_embargo"), col("xtimts").as("xtimts"),
				col("s2_long_ope").as("s2_long_ope"), col("s3_code_article").as("s3_code_article"),
				col("s4_code_ope").as("s4_code_ope"), col("s5_type_id_do").as("s5_type_id_do"),
				col("s6_id_etblt_do").as("s6_id_etblt_do"), col("s7_type_id_dest").as("s7_type_id_dest"),
				col("s8_id_etblt_dest").as("s8_id_etblt_dest"),
				col("s9_critere_rout_secondaire").as("s9_critere_rout_secondaire"),
				col("s10_code_devise").as("s10_code_devise"), col("s11_mnt_compense").as("s11_mnt_compense"),
				col("s12_date_reglement_demande").as("s12_date_reglement_demande"),
				col("s13_ind_modif_ddr").as("s13_ind_modif_ddr"), col("s14_code_commission").as("s14_code_commission"),
				col("s15_commission_interbancaire").as("s15_commission_interbancaire"),
				col("s16_zone_reservee_declaration").as("s16_zone_reservee_declaration"),
				col("s17_code_anomalie").as("s17_code_anomalie"), col("s18_zone_reservee").as("s18_zone_reservee"),

				col("b_onc_nature_ope").as("b_onc_nature_ope"), col("b_onc_ref_ope").as("b_onc_ref_ope"),
				col("b_onc_coord_exp").as("b_onc_coord_exp"), col("b_onc_zone_etblt").as("b_onc_zone_etblt"),
				col("b_onc_zone_libelle").as("b_onc_zone_libelle"), col("b_onc_cat_onc").as("b_onc_cat_onc"),
				col("b_onc_zone_reservee").as("b_onc_zone_reservee"),

				callUDF("fromStringtoInteger", col("zone_operation").substr(387, 4)).as("oi_s2_long_ope"),
				trim(col("zone_operation").substr(391, 2)).as("oi_s3_code_article"),
						trim(col("zone_operation").substr(393, 3)).as("oi_s4_code_ope"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(396, 1)).as("oi_s5_type_id_do"),
				trim(col("zone_operation").substr(397, 7)).as("oi_s6_id_etblt_do"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(404, 1)).as("oi_s7_type_id_dest"),
				trim(col("zone_operation").substr(405, 7)).as("oi_s8_id_etblt_dest"),
						trim(col("zone_operation").substr(412, 5)).as("oi_s9_critere_rout_secondaire"),
								trim(col("zone_operation").substr(417, 4)).as("oi_s10_code_devise"),
				callUDF("fromStingToDouble", col("zone_operation").substr(421, 16),
						col("zone_operation").substr(417, 4)).as("oi_s11_mnt_compense"),
				callUDF("fromString6toDate", col("zone_operation").substr(437, 6)).as("oi_s12_date_reglement_demande"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(443, 1)).as("oi_s13_ind_modif_ddr"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(444, 1)).as("oi_s14_code_commission"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(445, 6))
						.as("oi_s15_commission_interbancaire"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(451, 1))
						.as("oi_s16_zone_reservee_declaration"),
				callUDF("fromStringtoInteger", col("zone_operation").substr(452, 2)).as("oi_s17_code_anomalie"),
				trim(col("zone_operation").substr(454, 11)).as("oi_s18_zone_reservee"),
						trim(col("zone_operation").substr(465, 4)).as("oi_b_ic_sous_code_ope"),
				trim(col("zone_operation").substr(469, 24)).as("oi_b_ic_ref_ope"),
						trim(col("zone_operation").substr(493, 50)).as("oi_b_ic_zone_banquier_remettant"),
				trim(col("zone_operation").substr(543, 7)).as("oi_b_ic_num_cheque_cmc7_4"),
						trim(col("zone_operation").substr(550, 12)).as("oi_b_ic_zone_interbancaire_cmc7_3"),
				trim(col("zone_operation").substr(562, 12)).as("oi_b_ic_zone_interieure_cmc7_2"),
						trim(col("zone_operation").substr(574, 1)).as("oi_b_ic_ind_balance_paiement"),
				trim(col("zone_operation").substr(575, 30)).as("oi_b_ic_zone_usage_etblmt"),
						trim(col("zone_operation").substr(605, 1)).as("oi_b_ic_indice_circulation"),
				trim(col("zone_operation").substr(606, 1)).as("oi_b_ic_ind_cepc_concerne"),
						trim(col("zone_operation").substr(607, 34)).as("oi_b_ic_zone_reservee_ic"),
				col("date_insert").as("date_insert"), 
				col("date_ope").as("date_ope"))
				.withColumn("id_traitement",lit(idtrt));

	}

	/**
	 * Write DataFrame as orc file in the HDFS path of the target table Add
	 * partition to target table.
	 * 
	 * @param data
	 */
									public void writeMinosData(Dataset<Row> data, String hdfsTablePath, String tableName) {

		data.write().partitionBy("id_traitement").format("orc").mode("append").save(hdfsTablePath);
		String alterTableStmt = "ALTER TABLE " + DecoupageMinosConstant.HIVE_WRK_LAYER + "." + tableName
				+ " ADD IF NOT EXISTS PARTITION (id_traitement='" + idtrt + "') location '" + hdfsTablePath
				+ "/id_traitement=" + idtrt + "'";
		System.out.println("INFO: " + alterTableStmt);
		sqlContext.sql(alterTableStmt);

	}

}
