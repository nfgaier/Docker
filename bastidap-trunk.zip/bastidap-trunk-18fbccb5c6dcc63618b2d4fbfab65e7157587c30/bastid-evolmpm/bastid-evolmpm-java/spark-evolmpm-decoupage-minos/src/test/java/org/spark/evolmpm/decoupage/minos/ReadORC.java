package org.spark.evolmpm.decoupage.minos;

import java.io.Serializable;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.expressions.Window;

import static org.apache.spark.sql.functions.col;
import static org.apache.spark.sql.functions.lit;
import static org.apache.spark.sql.functions.row_number;
import static org.apache.spark.sql.functions.concat;


public class ReadORC implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8334639462162846890L;
	private SparkSession sparkSession;
	
	/**
	 *  Constructor
	 */
	public ReadORC (SparkSession sparkSession) {
		this.sparkSession = sparkSession;
		
	}
	
	/** 
	 * function for getting orc data in a dataframe
	 */
	public Dataset<Row> getOrcData () {
      	
      	return sparkSession.read()
      			         .format("orc")
      			         //.load("C:\\\\work\\\\bastid\\\\evolmpm\\\\jiras\\\\ORCData\\\\th70\\\\id_traitement=20180118133040\\\\000000_0");	
      			         .load("src/test/resources/part-00005.orc","src/test/resources/part-00014.orc","src/test/resources/part-00026.orc","src/test/resources/part-00036.orc","src/test/resources/part-00036.snappy.orc","src/test/resources/part-00043.orc",
      			        		"src/test/resources/part-00056.orc","src/test/resources/part-00061.orc","src/test/resources/part-00096.orc","src/test/resources/part-00155.orc","src/test/resources/part-00180.orc","src/test/resources/part-00189.orc");
	}
	
	
	public Dataset<Row> getRefData () {
      	
		Dataset<Row> table = sparkSession.read()
      			         .format("orc")
      			         //.load("C:\\\\work\\\\bastid\\\\evolmpm\\\\jiras\\\\ORCData\\\\th70\\\\id_traitement=20180118133040\\\\000000_0");	
      			         .load("src/test/resources/000000_0");

		table.printSchema();
      	 return table.select(
      			
         		col("_col0").as("annee_calendrier"),
         		col("_col1").as("code_type_client_2c"),
         		col("_col2").as("code_type_client_4c"),
         		col("_col3").as("libelle_type_client"),
         		col("_col4").as("montant_limite"),
         		col("_col5").as("date_debut"),
         		col("_col6").as("date_fin"),
         		col("_col7").as("date_representation")

         		);
	}
	
	
//    public Dataset<Row> getMinosDataFromCSV() {	    	
//    	
//    	return sparkSession.read().format("csv")
//                .option("header", "true")
//                .option("delimiter", ";")
//                .csv("src/test/resources/part-00036.snappy.orc")
//                ;
//    }

    public Dataset<Row> getSepaData(Dataset<Row> table) {
        
        return table.select(concat(row_number().over(Window.orderBy(col("rfopi"))), col("rfopi")).as("id_operation"),        		
        		col("rfopi").cast("string").as("rfopi"),
        		col("tyopec").cast("string").as("tyopec"),
        		col("seopec").cast("string").as("seopec"),
        		col("ddops2").cast("Date").as("ddops2"),
        		col("mtopa2").cast("Double").as("mtopa2"),
        		col("coops").cast("string").as("coops"),
        		col("cofamo").cast("string").as("cofamo"),
        		col("nuprm").cast("string").as("nuprm"),
        		col("coclc").cast("string").as("coclc"),
        		col("idees4").cast("string").as("idees4"),
        		col("idiba1").cast("string").as("idiba1"),
        		col("iddss2").cast("string").as("iddss2"),
        		col("idiba2").cast("string").as("idiba2"),
        		col("e8rme").cast("Date").as("e8rme"),
        		col("ddpre").cast("Date").as("ddpre"),
        		col("hepre").cast("string").as("hepre"),
        		col("nurms1").cast("string").as("nurms1"),
        		col("ddpre1").cast("Date").as("ddpre1"),
        		col("hepre1").cast("string").as("hepre1"),
        		col("e8trav").cast("Date").as("e8trav"),
        		col("idefe").cast("string").as("idefe"),
        		col("xtimts").cast("Timestamp").as("xtimts"),
        		col("cocll").cast("string").as("cocll"),
        		col("rfopsc").cast("string").as("rfopsc"),
        		col("codoar").cast("string").as("codoar"),
        		col("inopr").cast("string").as("inopr"),
        		col("nopart").cast("string").as("nopart"),
        		col("xpart1").cast("string").as("xpart1"),
        		col("xpartt").cast("string").as("xpartt"),
        		col("rfopso").cast("string").as("rfopso"),
        		col("rfeeso").cast("string").as("rfeeso"),
        		col("idopso").cast("string").as("idopso"),
        		col("dtjco").cast("Date").as("dtjco"),
                col("debemb").cast("string").as("debemb"),
                lit("TM").cast("string").as("type_enregistrement"),
                lit("id_type_ope").as("id_type_ope"),
                lit("2018-03-12").cast("date").alias("date_insert"), 
                lit("20180312171400").cast("date").alias("id_traitement")
          		
        		);
        		    		
           		
    }

 	
}
