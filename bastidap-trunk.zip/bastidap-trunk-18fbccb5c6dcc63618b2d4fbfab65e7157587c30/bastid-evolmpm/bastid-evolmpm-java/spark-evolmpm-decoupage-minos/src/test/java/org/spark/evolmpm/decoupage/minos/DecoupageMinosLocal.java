package org.spark.evolmpm.decoupage.minos;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.spark.evolmpm.decoupage.minos.constant.DecoupageMinosConstant;
import static org.apache.spark.sql.functions.col;
import org.spark.evolmpm.decoupage.minos.data.WriteData;
/** gestion des LOGs */
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Level;




public class DecoupageMinosLocal {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Logger.getLogger("org").setLevel(Level.ERROR);
		
		 /** Init configuration and contexts */		
      	final SparkSession session = SparkSession.builder()
      				.appName("DecoupageMinos")
      				.master("local[*]")       			
      				.getOrCreate();      
         	
      	ReadORC orcReader = new ReadORC(session);
      	Dataset<Row> operationsMo = orcReader.getOrcData();
//      	operationsMo.show();
//      	operationsMo.printSchema();
       	
     	
    	Dataset<Row>  refTableDS = orcReader.getRefData(); 
    	     
          System.out.println("INFO:" + DecoupageMinosMain.getTime() +"refTableDS : " + refTableDS.count());
     
      	
      	
      	WriteData processor = new WriteData(session, "00000");

     	    List<String> listeCodeOpeMinos = new ArrayList<>(Arrays.asList("160")) ;
      
   
            for (String codeOpe : listeCodeOpeMinos)
                 {
                      System.out.println(codeOpe);
                      Dataset<Row> minosDecoupePrepDF =null ; 
                 
                      switch (codeOpe) {
                      case DecoupageMinosConstant.CODE_OPE_IC:

                    	  Dataset<Row> icDecoupePrep =  processor.prepareMinosIcData(operationsMo);
                          minosDecoupePrepDF = processor.joinIcRef(icDecoupePrep, refTableDS);
                          System.out.println("INFO:" + DecoupageMinosMain.getTime() + "minosDecoupePrepDF : " + minosDecoupePrepDF.count());
                          minosDecoupePrepDF.printSchema();;
                          Dataset<Row> icDecoupePrep2 = minosDecoupePrepDF.filter(col("b_ic_zone_banquier_remettant").isNotNull());
                          System.out.println(icDecoupePrep2.count());
                          icDecoupePrep2.show();
                          break ;                  
                                          
//                      case DecoupageMinosConstant.CODE_OPE_RIC:
//                    	  Dataset<Row>  minosTableDF = reader.getMinosConnexData("393", "469", 24,"ic");
//                    	  Dataset<Row> ricDecoupePrep =  writer.prepareMinosRicData(minosTableDF);
//                    	  //join the ref_param_repim table and select columns in the correct order
//                          minosDecoupePrepDF = writer.joinRicRef(ricDecoupePrep, refTableDS);
//                          System.out.println("INFO:" + DecoupageMinosMain.getTime() + "minosDecoupePrepDF : " + minosDecoupePrepDF.count());
//                    	  break;
                  }       
      	
      
  


	}
	}
	
}
