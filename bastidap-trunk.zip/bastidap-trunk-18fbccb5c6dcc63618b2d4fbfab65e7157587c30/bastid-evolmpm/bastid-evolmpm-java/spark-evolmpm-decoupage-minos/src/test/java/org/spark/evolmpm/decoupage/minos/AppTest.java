package org.spark.evolmpm.decoupage.minos;

//import org.apache.spark.SparkConf;
//import org.apache.spark.api.java.JavaSparkContext;
//
//import org.apache.spark.sql.Dataset;
//import org.apache.spark.sql.Row;
//import org.apache.spark.sql.SparkSession;
//
//import org.spark.evolmpm.decoupage.minos.data.ReadData;
//import org.spark.evolmpm.decoupage.minos.data.WriteData;


import junit.framework.TestCase;


/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{

    /**
     * Rigourous Test :-)
     */
    public void testApp()
    {
    	
//    	String idtrt = "20171120120000";
//    	String codeOpe = "160";
////        SparkConf conf = new SparkConf().setMaster("local").setAppName("LoadMainTest");
////        JavaSparkContext sc = new JavaSparkContext(conf);
//    	final SparkSession session = SparkSession.builder().master("local")
//				.appName("TestDecoupageMinos")
//				.config("spark.sql.hive.convertMetastoreOrc", "false")
//				 .config("hive.metastore.uris", "thrift://lxdv716a.unix-int.intra-int.bdf-int.local:9083?tez.queue.name=gabidev;tez.am.resource.memory=512")
//				.enableHiveSupport()
//				.getOrCreate()
//				;
//           //  sqlContext.setConf("hive.metastore.uris", "thrift://lxdv0126pv.unix-int.intra-int.bdf-int.local:9083");
//
////        sc.setLogLevel("WARN");
//        session.sql("show databases").show();
//       //sqlContext.table("default.test_minos").show();
//        
//        
//        
//        ReadData reader = new ReadData(session,idtrt, codeOpe);
//        
//        WriteData writer = new WriteData(session,idtrt);
//        
//        Dataset<Row> minosTableDF = reader.getMinosData();
//        
//                
//        minosTableDF.printSchema();
//        
//        Dataset<Row> minosTablePrepDF = writer.prepareMinosIcData(minosTableDF);
//        minosTablePrepDF.printSchema();
//        minosTablePrepDF.show();
//             
//        System.out.println("INFO: " + minosTablePrepDF.count());
//        
//        
//        assertTrue( true );
    }
}
