#!/usr/bin/env bash
###############################################################################
# Description :     Simulation de l'ordonnancement de la cha�ne de traitement Embargo
# Usage :           Pas de param�tre
#                   Les variables do_* (yes/no) permettent d'activer ou non chaque module
# Author :          LCO
# Updated :         12/10/2017
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec            #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  


REP_CONF="$EMB_TRT_CONF_PATH"
READ_BATCH_PARAM "${REP_CONF}/${PARAM_BATCH}" "APPLI" "VAR_APPLI"
READ_BATCH_PARAM "${REP_CONF}/${PARAM_BATCH}" "PHASE" "VAR_PHASE"

# D�finition du mode : $MODE_ALIM_INTERVAL (dev et rec)
#                   ou $MODE_ALIM_LIST_DATE (dev et rec)
#                   ou $MODE_ALIM_QUOTI (tout env)
MODE="$MODE_ALIM_INTERVAL"

# Param�tres pour le mode $MODE_ALIM_INTERVAL
# Pour l'acquisition d'une seule date_ope, INTERVAL_DEBUT = INTERVAL_FIN = date_ope
INTERVAL_DEBUT="2019-01-01"
INTERVAL_FIN="2019-01-02"

# Param�tres pour le mode $MODE_ALIM_LIST_DATE (� s�parer par des espaces)
LIST_DATE="2019-01-01 2019-01-05 2019-01-10"


# le premier niveau de param�trage (do_action, etc.) active ou d�sactive le traitement entier
# le deuxi�me niveau de param�trage (do_upd_ko_action, etc.) permet de d�sactiver des �l�ments du traitement

do_action="yes"
    do_upd_ko_action="yes"
    do_init_action="yes"
    do_construct_cat_action="yes"
    do_lecture_statut_dep_action="yes"
    do_load_action="yes"
    do_copy_work_to_opt_action="yes"
    do_valid_action="yes"

do_alerte="yes"
    do_upd_ko_alerte="yes"
    do_init_alerte="yes"
    do_construct_cat_alerte="yes"
    do_lecture_statut_dep_alerte="yes"
    do_load_alerte="yes"
    do_copy_work_to_opt_alerte="yes"
    do_valid_alerte="yes"

do_hit="yes"
    do_upd_ko_hit="yes"
    do_init_hit="yes"
    do_construct_cat_hit="yes"
    do_lecture_statut_dep_hit="yes"
    do_load_hit="yes"
    do_copy_work_to_opt_hit="yes"
    do_valid_hit="yes"

do_raw_to_opt="yes"
    do_upd_ko_raw_to_opt="yes"
    do_init_raw_to_opt="yes"
    do_construct_cat_raw_to_opt="yes"
    do_lecture_statut_dep_raw_to_opt="yes"
    do_load_raw_to_opt="yes"
    do_valid_raw_to_opt="yes"
    
#######################################
# Description:  S�rie de fonctions appelant les shells avec les bons param�tres
# Arguments:    Pas d'argument
# Returns:      
#######################################

UPD_KO () {

    LOG_INFO "Mise � jour des statuts En cours � KO pour $1"
    $REPBDF/common/suivi/shell/upd_ko.sh "${REP_CONF}" "$1"
}

INIT_STATUT () {

    LOG_INFO "Initialisation du chargement de $1"
    $REPBDF/common/suivi/shell/init_statut.sh "${REP_CONF}" "$1"
}

CONSTRUCT_DATE_TRT () {

    LOG_INFO "Construction du catalogue pour le traitement $1"
    $REPBDF/common/suivi/shell/constr_date_trt.sh "${REP_CONF}" "$1"
}

CONSTR_INTERVAL_DATE () {

    LOG_INFO "Alimentation du catalogue en mode ${MODE} pour $1"
    $REPBDF/common/suivi/shell/constr_interval_date.sh "${REP_CONF}" "$1" "${INTERVAL_DEBUT}" "${INTERVAL_FIN}"
}

CONSTR_LIST_DATE () {

    LOG_INFO "Alimentation du catalogue en mode ${MODE} pour $1"
    $REPBDF/common/suivi/shell/constr_list_date.sh "${REP_CONF}" "$1" "${LIST_DATE}"
}

LECTEUR_STATUT () {

    LOG_INFO "V�rification des statuts Acquisition pour d�clenchement du Traitement de $1"
    $REPBDF/common/suivi/shell/lecteur_statut.sh "${REP_CONF}" "$1"
}

LOAD_ACTION () {

    LOG_INFO "Chargement des tables du Traitement ACTION"
    $REPBDF/embargo/traitement/load/shell/load_actions.sh
}

LOAD_ALERTE () {

    LOG_INFO "Chargement des tables du Traitement ALERTE"
    $REPBDF/embargo/traitement/load/shell/load_alerte.sh
}

LOAD_HIT () {

    LOG_INFO "Chargement des tables du Traitement HIT"
    $REPBDF/embargo/traitement/load/shell/load_hits.sh
}

LOAD_RAW_TO_OPT () {

    LOG_INFO "Copie des tables sans traitement de la Raw vers l'Optimized"
    $REPBDF/embargo/traitement/load/shell/copy_raw_to_optimized_layer.sh
}

COPY_WORK_TO_OPT () {

    LOG_START_FUNC "${FUNCNAME[0]}"
    
    local nom_traitement="$1"
    local hql_path="${REPBDF}/embargo/traitement/load/hql/"
    local script_name
    case $nom_traitement in
        "ACTION") script_name="copy_action_to_optimized_layer.hql" ;;
        "ALERTE") script_name="copy_alerte_to_optimized_layer.hql" ;;
        "HIT") script_name="copy_hits_to_optimized_layer.hql" ;;
    esac
    
    GET_ID_TRT "$VAR_APPLI" "$VAR_PHASE" "$nom_traitement" "RESULTAT"
    local id_traitement="$RESULTAT"
    
    LOG_INFO "Copie de work � optimized pour le traitement $nom_traitement :"
    LOG_INFO "hive --hiveconf tez.queue.name=${EXP_QUEUE} --hiveconf id_traitement=${id_traitement} -f ${hql_path}${script_name}"
    hive --hiveconf tez.queue.name=${EXP_QUEUE} --hiveconf id_traitement=${id_traitement} -f ${hql_path}${script_name}
    LOG_INFO "Ex�cution OK"
}

VALID () {

    LOG_INFO "Validation du chargement de $1"
    $REPBDF/common/suivi/shell/valid.sh "${REP_CONF}" "$1"
}


#######################################
# Description:  Fonction principale, appel�e dans le corps du script
# Arguments:    Pas d'argument
# Returns:      
#######################################
main () {

  START
  SETUP
    
    if [[ ( $MODE == "$MODE_ALIM_INTERVAL" || $MODE == "$MODE_ALIM_LIST_DATE" ) && ( $ENVAPPLI == 'INT' || $ENVAPPLI == 'PRD' ) ]]
    then
        LOG_ERROR "Mode ${MODE}  non autoris� en INT ou PROD"
        exit $__FAILURE
    fi
    
    case $MODE in
        "${MODE_ALIM_QUOTI}") CONSTR_DATE_OPE='CONSTRUCT_DATE_TRT' ;;
        "${MODE_ALIM_INTERVAL}") CONSTR_DATE_OPE='CONSTR_INTERVAL_DATE' ;;
        "${MODE_ALIM_LIST_DATE}") CONSTR_DATE_OPE='CONSTR_LIST_DATE' ;;
    esac
    
    
    # ***********************************************************************************************************
    if [[ ${do_action} == "yes" ]]
    then
        # Update � KO des En cours
        if [[ ${do_upd_ko_action} == "yes" ]] ; then UPD_KO "ACTION"; fi
        
        # Insertion du statut EN COURS
        if [[ ${do_init_action} == "yes" ]] ; then INIT_STATUT "ACTION"; fi
        
        # Construction du catalogue
        if [[ ${do_construct_cat_action} == "yes" ]] ; then eval $CONSTR_DATE_OPE "ACTION"; fi
        
        # Lecture des statuts d'acquisition des d�pendances de la table ACTION
        if [[ ${do_lecture_statut_dep_action} == "yes" ]] ; then LECTEUR_STATUT "ACTION"; fi
        
        # Chargement de la table ACTION
        if [[ ${do_load_action} == "yes" ]] ; then LOAD_ACTION; fi
        
        # Copie de la table ACTION dans l'optimized
        if [[ ${do_copy_work_to_opt_action} == "yes" ]] ; then COPY_WORK_TO_OPT "ACTION"; fi
        
        # Validation du chargement dans les tables Statut et Catalogue Traitement pour le chargement de la table ACTION
        if [[ ${do_valid_action} == "yes" ]] ; then VALID "ACTION"; fi
    fi
    # ***********************************************************************************************************
    
    
    # ***********************************************************************************************************
    if [[ ${do_alerte} == "yes" ]]
    then
        # Update � KO des En cours
        if [[ ${do_upd_ko_alerte} == "yes" ]] ; then UPD_KO "ALERTE"; fi
        
        # Insertion du statut EN COURS
        if [[ ${do_init_alerte} == "yes" ]] ; then INIT_STATUT "ALERTE"; fi
        
        # Construction du catalogue
        if [[ ${do_construct_cat_alerte} == "yes" ]] ; then eval $CONSTR_DATE_OPE "ALERTE"; fi
        
        # Lecture des statuts d'acquisition des d�pendances de la table ALERTE
        if [[ ${do_lecture_statut_dep_alerte} == "yes" ]] ; then LECTEUR_STATUT "ALERTE"; fi
        
        # Chargement de la table ALERTE
        if [[ ${do_load_alerte} == "yes" ]] ; then LOAD_ALERTE; fi
        
        # Copie de la table ALERTE dans l'optimized
        if [[ ${do_copy_work_to_opt_alerte} == "yes" ]] ; then COPY_WORK_TO_OPT "ALERTE"; fi
        
        # Validation du chargement dans les tables Statut et Catalogue Traitement pour le chargement de la table ALERTE
        if [[ ${do_valid_alerte} == "yes" ]] ; then VALID "ALERTE"; fi
    fi
    # ***********************************************************************************************************
    
    
    # ***********************************************************************************************************
    if [[ ${do_hit} == "yes" ]]
    then
        # Update � KO des En cours
        if [[ ${do_upd_ko_hit} == "yes" ]] ; then UPD_KO "HIT"; fi
        
        # Insertion du statut EN COURS
        if [[ ${do_init_hit} == "yes" ]] ; then INIT_STATUT "HIT"; fi
        
        # Construction du catalogue
        if [[ ${do_construct_cat_hit} == "yes" ]] ; then eval $CONSTR_DATE_OPE "HIT"; fi
        
        # Lecture des statuts d'acquisition des d�pendances de la table HIT
        if [[ ${do_lecture_statut_dep_hit} == "yes" ]] ; then LECTEUR_STATUT "HIT"; fi
        
        # Chargement de la table HIT
        if [[ ${do_load_hit} == "yes" ]] ; then LOAD_HIT; fi
        
        # Copie de la table HIT dans l'optimized
        if [[ ${do_copy_work_to_opt_hit} == "yes" ]] ; then COPY_WORK_TO_OPT "HIT"; fi
        
        # Validation du chargement dans les tables Statut et Catalogue Traitement pour le chargement de la table HIT
        if [[ ${do_valid_hit} == "yes" ]] ; then VALID "HIT"; fi
    fi
    # ***********************************************************************************************************


    # ***********************************************************************************************************
    if [[ ${do_raw_to_opt} == "yes" ]]
    then
        # Update � KO des En cours
        if [[ ${do_upd_ko_raw_to_opt} == "yes" ]] ; then UPD_KO "COPIE_RAW_OPT"; fi
        
        # Insertion du statut EN COURS
        if [[ ${do_init_raw_to_opt} == "yes" ]] ; then INIT_STATUT "COPIE_RAW_OPT"; fi
        
        # Construction du catalogue
        if [[ ${do_construct_cat_raw_to_opt} == "yes" ]] ; then eval $CONSTR_DATE_OPE "COPIE_RAW_OPT"; fi
        
        # Lecture des statuts d'acquisition des d�pendances de la table HIT
        if [[ ${do_lecture_statut_dep_raw_to_opt} == "yes" ]] ; then LECTEUR_STATUT "COPIE_RAW_OPT"; fi
        
        # Chargement de la table HIT
        if [[ ${do_load_raw_to_opt} == "yes" ]] ; then LOAD_RAW_TO_OPT; fi
                
        # Validation du chargement dans les tables Statut et Catalogue Traitement pour la copie Raw vers Optimized
        if [[ ${do_valid_raw_to_opt} == "yes" ]] ; then VALID "COPIE_RAW_OPT"; fi
    fi
    # ***********************************************************************************************************
    
  END
  exit ${__SUCCESS}
  
}

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
