#!/usr/bin/env bash
###############################################################################
# Description :     Valide le chargement d'un bloc de traitement indépendant
# Usage : 
# Parameters :      $1 Nom du bloc de traitement indépendant à valider
# Author :          LCO
# Updated :         16/10/2017
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

if [[ -z ${WORKFLOW_ENV+x} ]]; then 
  WORKFLOW_ENV="OOZIE"; export WORKFLOW_ENV
fi

case "${WORKFLOW_ENV}" in 
  OOZIE) 
    if [[ $# != 5 ]] ; then
		echo "Ce traitement attend trois parametres : <ROOT> <NOM_TRAITEMENT> <APPLI_TRAITEMENT> <QUEUE> <SCRIPT_COPY_HQL>"
		exit ${__FAILURE}
	fi
	
	ROOT="$1"
	NOM_TRAITEMENT="$2"
	APPLI_TRAITEMENT="$3"
	EXP_QUEUE="$4"
    SCRIPT_HQL_NAME="$5"
	
	EMB_APPLI_NAME="${APPLI_TRAITEMENT^^}"
	LOGDIR="${ROOT}/log/${APPLI_TRAITEMENT}"; export LOGDIR    #log folder exported for use in .fonction_*_spec
	HQL_PATH="${ROOT}/${APPLI_TRAITEMENT}/traitement/load/hql/"
	FIC_TMP="id_${NOM_TRAITEMENT}.tmp"
	
	#load and apply specific oozie function
	hadoop fs -get "${ROOT}/common/.fonction_bastid_oozie"
	. .fonction_bastid_oozie 
    init_oozie_env "${ROOT}" "${APPLI_TRAITEMENT}" "${LOGDIR}"
	hadoop fs -get "${ROOT}/${APPLI_TRAITEMENT}/traitement/conf/${FIC_TMP}"
	;;
  *)
	. $APPLI_HOME/appli/connexion/.fonction_bastid_spec        #source .fonction_*_spec 
	
	HQL_PATH="${REPBDF}/embargo/traitement/load/hql/"
    SCRIPT_HQL_NAME="copy_raw_to_optimized_layer.hql"
    NOM_TRAITEMENT='COPIE_RAW_OPT'
    FIC_TMP="${EMB_TRT_CONF_PATH}/id_${NOM_TRAITEMENT}.tmp"
	
	LOGDIR="${LST}"; export LOGDIR                             #log folder exported for use in .fonction_*_spec 
	;;
esac

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

#######################################
# Description: Lecture des ID_TRAITEMENT de la phase d'acquisition à recopier dans l'optimized layer
# Arguments: 
# Returns: 
#######################################
get_id_acq(){
	
    LOG_INFO "============================================================================"
    LOG_INFO "Lecture des ID_TRAITEMENT de la phase acquisition à charger dans l'optimized"
    LOG_INFO "============================================================================"
    LOG_INFO ""
    
    if [[ ! -f $FIC_TMP ]] ; then  
        LOG_ERROR "File $FIC_TMP not found."
        exit ${__FAILURE}
    else 
        LOG_INFO "File $FIC_TMP found" 
        LOG_INFO "Reading $FIC_TMP ..."
    fi
    
    LOG_INFO ""
    GET_CSV_FIELD_BY_INDEX "$FIC_TMP" "," "FMF_USERS" "2" "ID_ACQ_FMF_USERS"
    LOG_INFO ""
    LOG_INFO ""
    GET_CSV_FIELD_BY_INDEX "$FIC_TMP" "," "FMF_USER_PROFILE" "2" "ID_ACQ_FMF_USER_PROFILE"
    LOG_INFO ""
    LOG_INFO ""
    GET_CSV_FIELD_BY_INDEX "$FIC_TMP" "," "FMF_PROFILES" "2" "ID_ACQ_FMF_PROFILES"
    LOG_INFO ""
    LOG_INFO ""
    GET_CSV_FIELD_BY_INDEX "$FIC_TMP" "," "FMF_USER_UNIT" "2" "ID_ACQ_FMF_USER_UNIT"
    LOG_INFO ""
    LOG_INFO ""
    GET_CSV_FIELD_BY_INDEX "$FIC_TMP" "," "FMF_UNITS" "2" "ID_ACQ_FMF_UNITS"
    LOG_INFO ""
    LOG_INFO ""
    GET_CSV_FIELD_BY_INDEX "$FIC_TMP" "," "FMF_PROFILE_RIGHT" "2" "ID_ACQ_FMF_PROFILE_RIGHT"
    LOG_INFO ""
    LOG_INFO ""
    GET_CSV_FIELD_BY_INDEX "$FIC_TMP" "," "FMF_RIGHTS" "2" "ID_ACQ_FMF_RIGHTS"
    LOG_INFO ""
    LOG_INFO ""
    GET_CSV_FIELD_BY_INDEX "$FIC_TMP" "," "FMF_PROFILE_STATE" "2" "ID_ACQ_FMF_PROFILE_STATE"
    LOG_INFO ""
    LOG_INFO ""
    GET_CSV_FIELD_BY_INDEX "$FIC_TMP" "," "FOF_STATES" "2" "ID_ACQ_FOF_STATES"
    LOG_INFO ""
    LOG_INFO ""
    GET_CSV_FIELD_BY_INDEX "$FIC_TMP" "," "PROFILE_TRANSITIONS" "2" "ID_ACQ_PROFILE_TRANSITIONS"
    LOG_INFO ""
    LOG_INFO ""
    GET_CSV_FIELD_BY_INDEX "$FIC_TMP" "," "FOF_TRANSITIONS" "2" "ID_ACQ_FOF_TRANSITIONS"
    LOG_INFO ""
    

    if [[ -z ${ID_ACQ_FMF_USERS} \
        || -z ${ID_ACQ_FMF_USER_PROFILE} \
        || -z ${ID_ACQ_FMF_PROFILES} \
        || -z ${ID_ACQ_FMF_USER_UNIT} \
        || -z ${ID_ACQ_FMF_UNITS} \
        || -z ${ID_ACQ_FMF_PROFILE_RIGHT} \
        || -z ${ID_ACQ_FMF_RIGHTS} \
        || -z ${ID_ACQ_FMF_PROFILE_STATE} \
        || -z ${ID_ACQ_FOF_STATES} \
        || -z ${ID_ACQ_PROFILE_TRANSITIONS} \
        || -z ${ID_ACQ_FOF_TRANSITIONS} \
        ]]
    then  
        LOG_ERROR "Un des ID_TRAITEMENT de l'acquisition n'a pas été trouvé dans ${FIC_TMP}."
        exit ${__FAILURE}
    fi
  
}

#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
run() {
	
	REQ="  --hiveconf tez.queue.name=${EXP_QUEUE}"
    REQ+=" --hiveconf id_acq_fmf_users=${ID_ACQ_FMF_USERS}"
    REQ+=" --hiveconf id_acq_fmf_user_profile=${ID_ACQ_FMF_USER_PROFILE}"
    REQ+=" --hiveconf id_acq_fmf_profiles=${ID_ACQ_FMF_PROFILES}"
    REQ+=" --hiveconf id_acq_fmf_user_unit=${ID_ACQ_FMF_USER_UNIT}"
    REQ+=" --hiveconf id_acq_fmf_units=${ID_ACQ_FMF_UNITS}"
    REQ+=" --hiveconf id_acq_fmf_profile_right=${ID_ACQ_FMF_PROFILE_RIGHT}"
    REQ+=" --hiveconf id_acq_fmf_rights=${ID_ACQ_FMF_RIGHTS}"
    REQ+=" --hiveconf id_acq_fmf_profile_state=${ID_ACQ_FMF_PROFILE_STATE}"
    REQ+=" --hiveconf id_acq_fof_states=${ID_ACQ_FOF_STATES}"
    REQ+=" --hiveconf id_acq_profile_transitions=${ID_ACQ_PROFILE_TRANSITIONS}"
    REQ+=" --hiveconf id_acq_fof_transitions=${ID_ACQ_FOF_TRANSITIONS}"
    REQ+=" --hiveconf id_traitement=${ID_TRAITEMENT}"
    REQ+=" -f ${HQL_PATH}${SCRIPT_HQL_NAME}"

	if [[ "${WORKFLOW_ENV}" == "OOZIE" ]] ; then 
	  LOG_INFO "Copy RAW to OPTIMIZED : hive --hiveconf mapreduce.job.credentials.binary=${HADOOP_TOKEN_FILE_LOCATION} --hiveconf tez.credentials.path=${HADOOP_TOKEN_FILE_LOCATION} ${REQ}"
      hive  --hiveconf mapreduce.job.credentials.binary="${HADOOP_TOKEN_FILE_LOCATION}" \
            --hiveconf tez.credentials.path="${HADOOP_TOKEN_FILE_LOCATION}" \
			${REQ}
    else
	
	  LOG_INFO "Copy RAW to OPTIMIZED : hive ${REQ}"
      hive  ${REQ}
    fi
	
	LOG_INFO "Exécution OK"
}

#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  START
  SETUP
  
  GET_ID_TRT "$EMB_APPLI_NAME" "$PHASE_TRAITEMENT" "$NOM_TRAITEMENT" 'ID_TRAITEMENT'
  get_id_acq
  
  run
    
  END  
  exit ${__SUCCESS}
  
}

if [[ "${WORKFLOW_ENV}" == "OOZIE" ]] ; then 
  main "$@"
else
  main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
fi
