#!/usr/bin/env bash
###############################################################################
# Description : 
# Usage : 
# Author : 
# Updated : 
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

if [[ -z ${WORKFLOW_ENV+x} ]]; then 
  WORKFLOW_ENV="OOZIE"; export WORKFLOW_ENV
fi

case "${WORKFLOW_ENV}" in 
  OOZIE) 
    if [[ $# != 2 ]] ; then
		echo "Ce traitement attend deux parametres : <ROOT> <APPLI_TRAITEMENT>"
		exit ${__FAILURE}
	fi
	
	ROOT="$1"
	APPLI_TRAITEMENT="$2"
	LOGDIR="${ROOT}/log/${APPLI_TRAITEMENT}"; export LOGDIR    #log folder exported for use in .fonction_*_spec
	
	#load and apply specific oozie function
	hadoop fs -get "${ROOT}/common/.fonction_bastid_oozie"
	. .fonction_bastid_oozie 
    init_oozie_env "${ROOT}" "${APPLI_TRAITEMENT}" "${LOGDIR}"
	
	hadoop fs -get "${ROOT}/${APPLI_TRAITEMENT}/traitement/conf/id_HIT.tmp"
	;;
  *)
	. $APPLI_HOME/appli/connexion/.fonction_bastid_spec        #source .fonction_*_spec 

	LOGDIR="${LST}"; export LOGDIR                             #log folder exported for use in .fonction_*_spec 
	;;
esac

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

#######################################
# Description: setup function setting variables
# Arguments: 
# Returns: 0 for success, 1 for failure
#######################################
prepare() {
  if [[ "${WORKFLOW_ENV}" != "OOZIE" ]]; then 
    jar_dir="${REPBDF}/embargo/traitement/jar/"
    config_dir="${REPBDF}/embargo/config/"
    jar_name="spark-embgo-hits.jar"
    hql_path="${REPBDF}/embargo/traitement/load/hql/"
    script_copy="copy_hits_to_optimized_layer.hql"
	GET_ID_TRT "$EMB_APPLI_NAME" "$PHASE_TRAITEMENT" "HIT" 'ID_TRT'
  else
    GET_ID_TRT "${APPLI_TRAITEMENT^^}" "$PHASE_TRAITEMENT" "HIT" 'ID_TRT'
  fi
  
  LOG_INFO "ID TRAITEMENT pour le chargement de la table HITS : $ID_TRT"
}

#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
run() {

  LOG_START_FUNC "${FUNCNAME[0]}"
  
  if [[ "${WORKFLOW_ENV}" != "OOZIE" ]] ; then
    LOG_INFO "INFO: Running  spark-submit \
              --class fr.bdf.spark.embgo.hits.main.LoadHitsMain \
              --master yarn  \
              --queue ${TRT_QUEUE} \
              --driver-memory 4g \
              --executor-memory 2g \
              --num-executors 3 \
              --keytab ${KERBEROS_KEYTAB} \
              --principal ${KERBEROS_PRINCIPAL} \
              ${jar_dir}${jar_name} \
              ${config_dir}hadoop-local.xml \
              ${EMB_TRT_CONF_PATH}/id_HIT.tmp \
              ${ID_TRT} "
    else
	  LOG_INFO "INFO: Running  spark-submit \
			  --class fr.bdf.spark.embgo.hits.main.LoadHitsMain \
			  --master yarn  \
			  --deploy-mode cluster \
			  --queue ${QUEUE_NAME} \
			  --keytab ${KEY_TAB} \
			  --principal ${PRINCIPAL} \
			  --files ${HIVE_CONF}, id_HIT.tmp \
			  ${JAR_DIR}/${JAR_NAME} \
			  ${CONF_PATH}/hadoop-local.xml \
			  id_HIT.tmp \
			  ${ID_TRT} "
	fi

  # On pousse l'evenement Debut de chargement dans la table de suivi
  LOG_INFO "Start Event logging into ${TOT}"
  INSERT_LOG_DEB_TRT "${ID_TRT}" "Debut de traitement HIT"
  
  # On quitte le mode Exit on Error pour pouvoir capter le code retour du spark-submit
  set +o errexit
  
  if [[ "${WORKFLOW_ENV}" != "OOZIE" ]] ; then  
    spark-submit --class fr.bdf.spark.embgo.hits.main.LoadHitsMain \
              --master yarn  \
              --queue "${TRT_QUEUE}" \
              --driver-memory 4g \
              --executor-memory 2g \
              --num-executors 3 \
			  --keytab "${KERBEROS_KEYTAB}" \
              --principal "${KERBEROS_PRINCIPAL}" \
              "${jar_dir}${jar_name}" \
              "${config_dir}hadoop-local.xml" \
              "${EMB_TRT_CONF_PATH}/id_HIT.tmp" \
              "${ID_TRT}" 
  else
    spark-submit --class "${MAIN_CLASS}" \
			  --master yarn \
			  --deploy-mode cluster \
			  --queue "${QUEUE_NAME}" \
			  --keytab "${KEY_TAB}" \
			  --principal "${PRINCIPAL}" \
			  --files "${HIVE_CONF}","id_HIT.tmp" \
			  "${JAR_DIR}/${JAR_NAME}" \
			  "${CONF_PATH}/hadoop-local.xml" \
			  "id_HIT.tmp" \
			  "${ID_TRT}" 
  fi
                 
  if [ $? -eq $__SUCCESS ]
  then
    STATUT_TRT="Succes"
  else
    STATUT_TRT="Echec"
  fi
  
  # On retablit le mode Exit on Error
  set -o errexit

  # On pousse l'evenement Fin de chargement dans la table de suivi
  LOG_INFO "End Event logging into ${TOT}"
  INSERT_LOG_FIN_TRT "${ID_TRT}" "Fin de traitement HIT" "${STATUT_TRT}"

}

#######################################
# Description: 
# Arguments: none
# Returns: 0 for success, 1 for failure
#######################################
copy_to_optimized_layer() {
	hive -hiveconf tez.queue.name=${EXP_QUEUE} -hiveconf id_traitement=${ID_TRT} -f ${hql_path}${script_copy}
}

#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  START
  
  SETUP
  
  LOG_INFO "INFO: Executing spark-embgo-hits"
  start=$(date +%s.%N)  
  
  prepare
  
  run
  
  if [[ $STATUT_TRT == "Echec" ]]
  then
    exit $__FAILURE
  fi
  
  if [[ "${WORKFLOW_ENV}" != "OOZIE" ]]; then
    copy_to_optimized_layer
  fi
  
  end=$(date +%s.%N)
  LOG_INFO "INFO: Waited for : "$(echo "$end - $start" | bc)" sec"
  
  END
  
  exit ${__SUCCESS}
  
}

if [[ "${WORKFLOW_ENV}" == "OOZIE" ]] ; then 
  main "$@"
else
  main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
fi