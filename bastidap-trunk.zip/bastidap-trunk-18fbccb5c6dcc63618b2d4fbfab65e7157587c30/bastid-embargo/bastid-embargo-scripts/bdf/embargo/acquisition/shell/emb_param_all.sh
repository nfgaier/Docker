#!/usr/bin/env bash
set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction                        #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

readonly __PARAMFILE="${__DIR}/${__BASE}_param.csv"            #permanent configuration file containing the scripts to execute 
readonly __TMP_PROCFILE=${__BASE}"_lst_prc_pid.tmp"            #temporary configuration file associating a script with its PID 
readonly __KO_PARAMFILE=${__BASE}"_param_KO.tmp"               #configuration file containing the KO scripts to re-execute 
readonly __TMP_KO_PARAMFILE=${__BASE}"_param_TMP_KO.tmp"       #temporary configuration file containing the KO scripts to execute
readonly __TMP_FOLDER="."                                      #folder for tmp files       
readonly __DUMMY_INIT=99999
readonly __SEPARATOR=","

__FAILED=0                                                     #failed scritps counter
__GROUPS_ARRAY=()                                              #global array used to store the groups ID 
__NB_TRIES=3                                                   #number of re-tries 
__TMP_PARAMFILE=${__PARAMFILE}                                 #variable used to pass the configuration file to a function

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

if [[ $# != 2 ]] ; then
    echo "Ce traitement attend deux parametres : <REP_CONF> <NOM_TRAITEMENT>"
    exit ${__FAILURE}
fi

REP_CONF="$1"
NOM_TRAITEMENT="$2"


main () {

    LOG_INFO "Lecture des parametres dans ${REP_CONF}${PARAM_BATCH}"
    READ_BATCH_PARAM "${REP_CONF}/${PARAM_BATCH}" "APPLI" "VAR_APPLI"
    READ_BATCH_PARAM "${REP_CONF}/${PARAM_BATCH}" "PHASE" "VAR_PHASE"

    GET_ID_TRT "$EMB_APPLI_NAME" "$VAR_PHASE" "$NOM_TRAITEMENT" "ID_TRAITEMENT"
    
    
    LOG_INFO ""
    LOG_INFO "Chargement de PARAM_ALERTE_MOTIF"
    "${__DIR}"/emb_load_param.sh "$ID_TRAITEMENT" "PARAM_ALERTE_MOTIF"

    LOG_INFO "Chargement de PARAM_ALERTE_IND"
    "${__DIR}"/emb_load_param.sh "$ID_TRAITEMENT" "PARAM_ALERTE_IND"

    LOG_INFO "Chargement de PARAM_ALERTE_ETAT"
    "${__DIR}"/emb_load_param.sh "$ID_TRAITEMENT" "PARAM_ALERTE_ETAT"

    LOG_INFO "Chargement de PARAM_ALERTE_BO"
    "${__DIR}"/emb_load_param.sh "$ID_TRAITEMENT" "PARAM_ALERTE_BO"

    LOG_INFO "Chargement de PARAM_ALERTE_NIVEAU"
    "${__DIR}"/emb_load_param.sh "$ID_TRAITEMENT" "PARAM_ALERTE_NIVEAU"

    LOG_INFO "Chargement de PARAM_ACTION_NIVEAU"
    "${__DIR}"/emb_load_param.sh "$ID_TRAITEMENT" "PARAM_ACTION_NIVEAU"

    LOG_INFO "Chargement de PARAM_ACTION_IND"
    "${__DIR}"/emb_load_param.sh "$ID_TRAITEMENT" "PARAM_ACTION_IND"

    LOG_INFO "Chargement de PARAM_ACTION_BO"
    "${__DIR}"/emb_load_param.sh "$ID_TRAITEMENT" "PARAM_ACTION_BO"

    LOG_INFO "Chargement de REF_USER_STATUT"
    "${__DIR}"/emb_load_param.sh "$ID_TRAITEMENT" "REF_USER_STATUT"

    LOG_INFO "Chargement de REF_PROFIL_STATUT"
    "${__DIR}"/emb_load_param.sh "$ID_TRAITEMENT" "REF_PROFIL_STATUT"

}

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
