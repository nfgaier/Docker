#!/usr/bin/env bash
###############################################################################
# Description :
# - Load csv ref_param files into TEXT tables and then ORC tables
#
# Usage : 
# Author : L.COQUET
# Updated : 01/09/2017
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction                        #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

CSV_PATH="${REP_BDF}/embargo/acquisition/ref_param/csv"
HQL_PATH="${REP_BDF}/embargo/acquisition/hql"

#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
check_file() {

  local filename="${1}"

  if [[ ! -f ${CSV_PATH}/${filename}".csv" ]] ; then  
    LOG_ERROR "File ${CSV_PATH}/${filename}.csv not found."
    exit ${__FAILURE} 
  else
    LOG_INFO "Source file ${CSV_PATH}/${filename}.csv found."
  fi
}


#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  if [[ "$#" -ne 2 ]]; then
    LOG_ERROR "${FUNCNAME[0]} : Usage : emb_load_param.sh <id traitement> <target table name>"
    exit ${__FAILURE} 
  else 
    local id_traitement=${1}
    local table_name=${2}
    local table_name_temp=${table_name}_temp
    LOG_ERROR "${FUNCNAME[0]} : Loading  file ${table_name}.csv in table $table_name"
  fi 

    START
    
    SETUP
    
    check_file "${table_name}"
    
    # Recuperation du nombre de lignes du CSV
    local nb_lignes_csv=$(wc -l < "${CSV_PATH}/${table_name}.csv")
    LOG_INFO "NB LIGNES CSV = ${nb_lignes_csv}"
    
    PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -e -c " \
        insert into $TOT (id_job, type_suivi, projet, application, phase, nom_traitement, nom_table, type_table, nb_lignes, type_log, log) \
        values ('$id_traitement', '$TYPE_SUIVI_LOG', '$PROJET', '$EMB_APPLI_NAME', '$PHASE_ACQUISITION', '$(basename "${BASH_SOURCE[0]}")', \
                '$table_name', 'FULL', '$nb_lignes_csv', 'COUNT SIO', 'Nombre de ligne dans le fichier source pour cette acquisition')"
    
    # chargement du contenu du CSV dans la table de parametrage
    LOG_INFO "Chargement de $table_name"
    hive --hiveconf tez.queue.name=${TRT_QUEUE} -f "${HQL_PATH}/$table_name.hql" \
          -hiveconf id_traitement=${id_traitement}  \
          -hiveconf csv_file_path=${CSV_PATH}
    
    LOG_INFO "Suppression fichier ${CSV_PATH}/${table_name}.csv"
    rm -f ${CSV_PATH}/${table_name}.csv
    
    
    # Recuperation du nombre de lignes dans la table de parametrage
    local nb_lignes_hive=$(hive --hiveconf tez.queue.name=${TRT_QUEUE} -S -e "SELECT count(*) from embarg_landing_acq.${table_name}_temp")
    LOG_INFO "NB LIGNES HIVE = ${nb_lignes_hive}"
    
    PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -e -c " \
        insert into $TOT (id_job, type_suivi, projet, application, phase, nom_traitement, nom_table, type_table, nb_lignes, type_log, log) \
        values ('$id_traitement', '$TYPE_SUIVI_LOG', '$PROJET', '$EMB_APPLI_NAME', '$PHASE_ACQUISITION', '$(basename "${BASH_SOURCE[0]}")', \
                '$table_name', 'FULL', '$nb_lignes_hive', 'COUNT BASTID Landing Layer', 'Nombre de ligne côté BASTID Landing Layer pour cette acquisition')"
    
    if [[ $nb_lignes_csv == $nb_lignes_hive ]]; then 
       REQ="  update $TOT"
       REQ+=" set status = '${ST_OK}'"
       REQ+=" where"
       REQ+="     type_suivi = '${TYPE_SUIVI_SUIVI}'"
       REQ+="     and niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}'"
       REQ+="     and projet = '${PROJET}'"
       REQ+="     and application = '${EMB_APPLI_NAME}'"
       REQ+="     and phase = '${PHASE_ACQUISITION}'"
       REQ+="     and nom_table = '${table_name}'"
       REQ+="     and status = '${ST_ENCOURS}'"
       PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" -e "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"
    else   
       REQ="  update $TOT"
       REQ+=" set status = '${ST_ERROR}'"
       REQ+=" where"
       REQ+="     type_suivi = '${TYPE_SUIVI_SUIVI}'"
       REQ+="     and niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}'"
       REQ+="     and projet = '${PROJET}'"
       REQ+="     and application = '${EMB_APPLI_NAME}'"
       REQ+="     and phase = '${PHASE_ACQUISITION}'"
       REQ+="     and nom_table = '${table_name}'"
       REQ+="     and status = '${ST_ENCOURS}'"
       PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" -e "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"
       exit ${__FAILURE}
    fi
    
    
    END
    exit ${__SUCCESS}
  
}

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
