#!/usr/bin/env bash
###############################################################################
# Description :
# Usage : 
# Author : 
# Updated : 
###############################################################################

#set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec                        #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

do_copy() {

  LOG_INFO "HDFS copy ..."

  #SIO
  LOG_INFO "fmf_profile_right"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fmf_profile_right/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fmf_profile_right/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fmf_profile_right/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fmf_profile_state"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fmf_profile_state/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fmf_profile_state/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fmf_profile_state/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fmf_profiles"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fmf_profiles/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fmf_profiles/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fmf_profiles/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fmf_rights"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fmf_rights/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fmf_rights/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fmf_rights/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fmf_units"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fmf_units/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fmf_units/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fmf_units/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fmf_user_profile"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fmf_user_profile/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fmf_user_profile/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fmf_user_profile/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fmf_user_unit"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fmf_user_unit/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fmf_user_unit/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fmf_user_unit/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fmf_users"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fmf_users/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fmf_users/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fmf_users/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fof_hist_files"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fof_hist_files/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fof_hist_files/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fof_hist_files/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fof_states"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fof_states/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fof_states/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fof_states/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fof_transitions"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fof_transitions/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fof_transitions/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fof_transitions/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fofa_hist_action"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fofa_hist_action/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fofa_hist_action/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fofa_hist_action/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fofa_hist_message"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fofa_hist_message/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fofa_hist_message/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fofa_hist_message/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "profile_transitions"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/profile_transitions/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/profile_transitions/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/profile_transitions/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fofa_hist_intervention"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fofa_hist_intervention/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fofa_hist_intervention/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fofa_hist_intervention/id_traitement=${ID_TRAITEMENT}
  
  LOG_INFO "MSCK REPAIR TABLE"
  hive -hiveconf tez.queue.name=${TRT_QUEUE}  -e "MSCK REPAIR TABLE embargo_raw_layer.fmf_profile_right;
                                                  MSCK REPAIR TABLE embargo_raw_layer.fmf_profile_state;
                                                  MSCK REPAIR TABLE embargo_raw_layer.fmf_profiles;
                                                  MSCK REPAIR TABLE embargo_raw_layer.fmf_rights;
                                                  MSCK REPAIR TABLE embargo_raw_layer.fmf_units;
                                                  MSCK REPAIR TABLE embargo_raw_layer.fmf_user_profile;
                                                  MSCK REPAIR TABLE embargo_raw_layer.fmf_user_unit;    
                                                  MSCK REPAIR TABLE embargo_raw_layer.fmf_users;
                                                  MSCK REPAIR TABLE embargo_raw_layer.fof_hist_files;
                                                  MSCK REPAIR TABLE embargo_raw_layer.fof_states;    
                                                  MSCK REPAIR TABLE embargo_raw_layer.fof_transitions;    
                                                  MSCK REPAIR TABLE embargo_raw_layer.fofa_hist_action;    
                                                  MSCK REPAIR TABLE embargo_raw_layer.fofa_hist_message;
                                                  MSCK REPAIR TABLE embargo_raw_layer.profile_transitions;  
                                                  MSCK REPAIR TABLE embargo_raw_layer.fofa_hist_intervention;"
}                                                  


main () {
  
  if [[ "$#" -ne 2 ]]; then
    LOG_ERROR "${FUNCNAME[0]} : Usage : copy_land_row.sh <id_traitement> <env(DEV,REC)>"
    exit ${__FAILURE} 
  else 
    ID_TRAITEMENT="${1}" 
    local temp="${2}"
    if [[ ${temp} != "DEV" && ${temp} != "REC" ]]; then
      LOG_ERROR "${FUNCNAME[0]} : Usage : second parameter must be either DEV or REC"
      exit ${__FAILURE} 
    else
      if [[ ${temp} != "DEV" ]]; then
         S_ENV="s_embarg" 
      else    
         S_ENV="s_dembarg" 
      fi   
    fi  
    LOG_INFO "ID_TRAITEMENT=$ID_TRAITEMENT"    
    LOG_INFO "S_ENV=$S_ENV"    
  fi 
  
  START
  
  SETUP

  do_copy
  
    REQ="update $TOT"                                     
    REQ+=" set status = '${ST_OK}'"
    REQ+=" where"                                             
    REQ+="     type_suivi = '${TYPE_SUIVI_SUIVI}'"            
    REQ+="     and niveau_suivi = '${NIVEAU_SUIVI_STATUT}'"
    REQ+="     and id_job = '${ID_TRAITEMENT}'"            
    REQ+="     and status = '${ST_DISPO_COPIE_LAND_ROW}'"            
    REQ+=" ;"                                                 
    PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" -e "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"
  
  LOG_INFO "Copy OK, STATUT of ID_TRAITEMENT ${ID_TRAITEMENT} updated"
  
  END
  
  exit ${__SUCCESS}

}                                                
                                                
main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1

