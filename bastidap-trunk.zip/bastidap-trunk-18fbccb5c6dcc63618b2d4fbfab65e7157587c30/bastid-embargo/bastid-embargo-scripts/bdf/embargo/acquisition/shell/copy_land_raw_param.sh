#!/usr/bin/env bash
###############################################################################
# Description :
# Usage : 
# Author : 
# Updated : 
###############################################################################

#set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec                        #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

if [[ "$#" -ne 1 ]]; then
    LOG_ERROR "Usage : ${__FILE} <id_traitement>"
    exit ${__FAILURE} 
fi

ID_TRAITEMENT="$1"

do_copy() {

  LOG_INFO "HDFS copy ..."
  #PARAMS
  LOG_INFO "param_action_bo"
  hdfs dfs -mkdir -p "${EMB_SRC_HDFS_RWL}"param_action_bo/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f "${EMB_SRC_HDFS_LDL}"param_action_bo/id_traitement=${ID_TRAITEMENT}/* "${EMB_SRC_HDFS_RWL}"param_action_bo/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "param_alerte_motif"
  hdfs dfs -mkdir -p "${EMB_SRC_HDFS_RWL}"param_alerte_motif/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f "${EMB_SRC_HDFS_LDL}"param_alerte_motif/id_traitement=${ID_TRAITEMENT}/* "${EMB_SRC_HDFS_RWL}"param_alerte_motif/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "param_alerte_ind"
  hdfs dfs -mkdir -p "${EMB_SRC_HDFS_RWL}"param_alerte_ind/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f "${EMB_SRC_HDFS_LDL}"param_alerte_ind/id_traitement=${ID_TRAITEMENT}/* "${EMB_SRC_HDFS_RWL}"param_alerte_ind/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "param_alerte_etat"
  hdfs dfs -mkdir -p "${EMB_SRC_HDFS_RWL}"param_alerte_etat/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f "${EMB_SRC_HDFS_LDL}"param_alerte_etat/id_traitement=${ID_TRAITEMENT}/* "${EMB_SRC_HDFS_RWL}"param_alerte_etat/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "param_alerte_bo"
  hdfs dfs -mkdir -p "${EMB_SRC_HDFS_RWL}"param_alerte_bo/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f "${EMB_SRC_HDFS_LDL}"param_alerte_bo/id_traitement=${ID_TRAITEMENT}/* "${EMB_SRC_HDFS_RWL}"param_alerte_bo/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "param_alerte_niveau"
  hdfs dfs -mkdir -p "${EMB_SRC_HDFS_RWL}"param_alerte_niveau/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f "${EMB_SRC_HDFS_LDL}"param_alerte_niveau/id_traitement=${ID_TRAITEMENT}/* "${EMB_SRC_HDFS_RWL}"param_alerte_niveau/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "param_action_niveau"
  hdfs dfs -mkdir -p "${EMB_SRC_HDFS_RWL}"param_action_niveau/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f "${EMB_SRC_HDFS_LDL}"param_action_niveau/id_traitement=${ID_TRAITEMENT}/* "${EMB_SRC_HDFS_RWL}"param_action_niveau/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "param_action_ind"
  hdfs dfs -mkdir -p "${EMB_SRC_HDFS_RWL}"param_action_ind/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f "${EMB_SRC_HDFS_LDL}"param_action_ind/id_traitement=${ID_TRAITEMENT}/* "${EMB_SRC_HDFS_RWL}"param_action_ind/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "ref_user_statut"
  hdfs dfs -mkdir -p "${EMB_SRC_HDFS_RWL}"ref_user_statut/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f "${EMB_SRC_HDFS_LDL}"ref_user_statut/id_traitement=${ID_TRAITEMENT}/* "${EMB_SRC_HDFS_RWL}"ref_user_statut/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "ref_profil_statut"
  hdfs dfs -mkdir -p "${EMB_SRC_HDFS_RWL}"ref_profil_statut/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f "${EMB_SRC_HDFS_LDL}"ref_profil_statut/id_traitement=${ID_TRAITEMENT}/* "${EMB_SRC_HDFS_RWL}"ref_profil_statut/id_traitement=${ID_TRAITEMENT}

  
  LOG_INFO "MSCK REPAIR TABLE"
  hive -hiveconf tez.queue.name=${TRT_QUEUE}  -e "MSCK REPAIR TABLE embargo_raw_layer.ref_profil_statut;
                                                  MSCK REPAIR TABLE embargo_raw_layer.param_action_bo;
                                                  MSCK REPAIR TABLE embargo_raw_layer.ref_user_statut;
                                                  MSCK REPAIR TABLE embargo_raw_layer.param_action_ind;
                                                  MSCK REPAIR TABLE embargo_raw_layer.param_alerte_niveau;
                                                  MSCK REPAIR TABLE embargo_raw_layer.param_alerte_bo;
                                                  MSCK REPAIR TABLE embargo_raw_layer.param_alerte_ind;
                                                  MSCK REPAIR TABLE embargo_raw_layer.param_alerte_motif;
                                                  MSCK REPAIR TABLE embargo_raw_layer.param_alerte_etat;
                                                  MSCK REPAIR TABLE embargo_raw_layer.param_action_niveau;"
}                                                  


main () {
  
    START
    SETUP

    LOG_INFO "ID_TRAITEMENT=$ID_TRAITEMENT"
    
    do_copy
  
    REQ="update $TOT"                                     
    REQ+=" set status = '${ST_OK}'"
    REQ+=" where"                                             
    REQ+="     type_suivi = '${TYPE_SUIVI_SUIVI}'"            
    REQ+="     and niveau_suivi = '${NIVEAU_SUIVI_STATUT}'"
    REQ+="     and id_job = '${ID_TRAITEMENT}'"            
    REQ+="     and status = '${ST_DISPO_COPIE_LAND_ROW}'"            
    REQ+=" ;"                                                 
    PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" -e "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"
    
    LOG_INFO "Copy OK, STATUT of ID_TRAITEMENT ${ID_TRAITEMENT} updated"
    
    END
    exit ${__SUCCESS}

}                                                
                                                
main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1

