#!/usr/bin/env bash
###############################################################################
# Description :
# - Control REF_PARAM file name
# - if ok, move to SAS, else move to a KO archive folder
#
# Usage : 
# Author : L.COQUET
# Updated : 29/08/2017
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.param
. $APPLI_HOME/appli/connexion/.fonction                        #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

NASDIR="$APPLI_HOME/appli/bdf/nifi/nas_ref_param"
SASDIR="$APPLI_HOME/appli/bdf/nifi/sas"
REFPARAMNAME='SESAM_BASTID_EMBARGO_REF_PARAM.xlsx'
ARCHIVEKO="$APPLI_HOME/appli/bdf/nifi/archive/ko"


#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  START
  
  SETUP
  
    # Control name of the file found in nas directory
    NASFILE=$(ls $NASDIR)
    LOG_INFO "Contrôle du nom de fichier présent dans le NAS"
    
    if [ $NASFILE != $REFPARAMNAME ]
    then
        mv $NASDIR/$NASFILE $ARCHIVEKO/${NASFILE}_${__TIMESTAMP}
        LOG_ERROR "Le nom du fichier, $NASFILE, n'est pas celui attendu : $REFPARAMNAME"
        LOG_INFO "Fichier ${NASFILE}_${__TIMESTAMP} archivé dans $ARCHIVEKO"
        exit ${__FAILURE}
    else
        LOG_INFO "Nom de fichier OK"
    fi
  
  END
  
  exit ${__SUCCESS}
  
}

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
