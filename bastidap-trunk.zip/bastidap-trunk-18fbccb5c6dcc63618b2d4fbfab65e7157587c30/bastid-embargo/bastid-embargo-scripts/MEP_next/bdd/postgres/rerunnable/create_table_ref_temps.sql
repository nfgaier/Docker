--------------------------------------------------------
--  DDL for Table ref_temps on Postgres
--------------------------------------------------------

\echo 'DDL table ref_temps'

DROP TABLE IF EXISTS ref_temps;
CREATE TABLE ref_temps
(
    id_date                 int      ,
    date_jour               date     ,
    jour_semaine            integer  ,
    jour_mois               integer  ,
    jour_annee              integer  ,
    jour_lib                text     ,
    annee                   integer  ,
    annee_mois              integer  ,
    semaine_num             integer  ,
    semaine_lib             text     ,
    semaine_debut           text     ,
    semaine_fin             text     ,
    week_end                text     ,
    mois_num                integer  ,
    mois_lib                text     ,
    mois_debut              text     ,
    mois_fin                text     ,
    trimestre_num           integer  ,
    trimestre_lib           text     ,
    trimestre_debut         text     ,
    trimestre_fin           text     ,
    semestre_num            integer  ,
    semestre_lib            text     ,
    semestre_debut          text     ,
    semestre_fin            text     ,
    jour_ferie              text
);
