#!/bin/ksh
################################################################################
# DATE                  : 05/12/2017
# Procedure             : deploiement_postgres.sh
#
# Fonction : lancer les scripts BDD PostGreSQL pour la prochaine MEP
# 
################################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
#set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

#----------------------------------------------------------------------------------------------------------------------------------
#  MISE EN PLACE DES VARIABLES D'ENVIRONNEMENT
#----------------------------------------------------------------------------------------------------------------------------------
. $APPLI_HOME/appli/connexion/.param
. $APPLI_HOME/appli/connexion/.fonction

export DATE=`date +%Y%m%d_%H%M%S`
export JOUR=`date +%Y%m%d`
NOM_SCRIPT=`basename $0`
DIR_SCRIPT=`dirname $0`

JOURNAL=journal ; export JOURNAL
LOGFILE=${NOM_SCRIPT}.lst.${JOUR} ; export LOGFILE

# Initialisation de variable de fin d'execution
typeset -R6 PID=$$
FIN=0 ; export FIN

#-----------------------------------------------------------------------------
#  FONCTIONS LOCALES
#-----------------------------------------------------------------------------

#-----------------------------------------------------------------------------
#  DEBUT DE LA PROCEDURE
#-----------------------------------------------------------------------------

{
DEBUT

REPLIV=$DIR_SCRIPT

LOG "-------------------------------------------------------------------------"
LOG "  Lancement de init_and_update_risque_pays.sql"
LOG "-------------------------------------------------------------------------"
psql -e -f "$REPLIV/create_table_ref_temps.sql"

LOG "-------------------------------------------------------------------------"
LOG "  Lancement de init_and_update_risque_pays.sql"
LOG "-------------------------------------------------------------------------"
psql -e -f "$REPLIV/init_ref_temps.sql"



FIN
} >>$LST/$LOGFILE 2>&1
