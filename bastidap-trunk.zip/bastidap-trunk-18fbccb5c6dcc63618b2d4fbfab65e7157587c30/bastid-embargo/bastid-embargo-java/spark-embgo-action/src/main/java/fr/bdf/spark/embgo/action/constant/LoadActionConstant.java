package fr.bdf.spark.embgo.action.constant;

import java.io.IOException;
import java.io.Serializable;

import fr.bdf.embgo.common.EmbgoCommonResource;

public class LoadActionConstant extends EmbgoCommonResource implements
		Serializable {

	private static final long serialVersionUID = -8682954110998364443L;

	// prefix used for the dynamic properties set in the processor
	public static final String CONDITION_PREFIX = "condition_";
	// suffix used for the condition field name property set in the processor
	public static final String CONDITION_FIELD_SUFFIX = "_field_name";
	// suffix used for the condition type property set in the processor
	public static final String CONDITION_TYPE_SUFFIX = "_type";
	// date used as default start date
	public static final String MIN_DATE = "1900-01-01";
	// date used as default end date
	public static final String MAX_DATE = "2900-01-01";
	// value used in the condition properties when testing an equality
	public static final String CONDITION_EQUAL = "EQUAL";
	// value used in the condition properties when testing a presence with a
	// wild card %
	public static final String CONDITION_LIKE = "LIKE";
	// null value
	public static final String NULL = "NULL";

	// hive tables
	public static final String TABLE_ACTION = "action";
	public static final String TMP_TABLE = "action_tmp";
	public static final String TMP_TABLE_NIVEAU_DECISION = "action_tmp_niveau_decision";
	public static final String TMP_TABLE_BO_AND_IND = "action_tmp_bo_and_ind";
	public static final String TMP_TABLE_TIME_TRT_ONE = "action_tmp_time_trt_one";
	public static final String FOFA_HIST_ACT = "FOFA_HIST_ACTION";
	public static final String FOF_HIST_FILES = "FOF_HIST_FILES";
	public static final String FMF_USERS = "FMF_USERS";

	public static final String PARAM_ACT_BO = "param_action_bo";
	public static final String PARAM_ACT_IND = "param_action_ind";
	public static final String PARAM_ACT_NIV = "param_action_niveau";

	public LoadActionConstant() throws IOException {
		super();
	}

}
