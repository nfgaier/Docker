/**
 * 
 */
package fr.bdf.spark.embgo.action.util;

import java.io.Serializable;
import java.util.Properties;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import fr.bdf.spark.embgo.action.functions.GetTuple2ElementSortBy;
import fr.bdf.spark.embgo.action.functions.ParseParamMapper;

import scala.Tuple2;

public class ParseParam implements Serializable {


    private static final long serialVersionUID = -5403704140415607436L;

    private java.util.Properties paramCols;
    private Dataset<Row> paramTable;
    /**
     * @return the paramCols
     */
    public java.util.Properties getParamCols() {
        return paramCols;
    }
    /**
     * @param paramCols la valeur de paramCols à attribuer.
     */
    public void setParamCols(java.util.Properties paramCols) {
        this.paramCols = paramCols;
    }
    /**
     * @return the paramTable
     */
    public Dataset<Row> getParamTable() {
        return paramTable;
    }
    /**
     * @param paramTable la valeur de paramTable à attribuer.
     */
    public void setParamTable(Dataset<Row> paramTable) {
        this.paramTable = paramTable;
    }
    /**
     * @param paramCols
     * @param paramTable
     */
    public ParseParam(Properties paramCols, Dataset<Row> paramTable) {
        super();
        this.paramCols = paramCols;
        this.paramTable = paramTable;
    }

    /**
     * Generates a case when statement based on a DataFrame containing the data from a parameter table and a Properties object describing the parameter table
     * @return a case when statement
     */
    public String getCaseWhenStmt() {
        
        //transform the DF to a RDD and apply the parse method in ParseParamMapper
        //the tuple <Integer, String> is used to sort the "when" clauses by the order defined in the parameter table 
        //the Integer is the rang, the String is the when clause 
        JavaRDD<Tuple2<Integer, String>> refAlerteBoRDDWhen = paramTable.toJSON().toJavaRDD().map(new ParseParamMapper(paramCols));
        //sort the RDD by the first element of the tuple
        JavaRDD<Tuple2<Integer, String>> refAlerteBoRDDWhenSorted = refAlerteBoRDDWhen.sortBy(new GetTuple2ElementSortBy(), true, 1);
        
        StringBuilder strBuilder = new StringBuilder("CASE ");
        //concatenate the when clauses (in the correct order) to get the complete CASE WHEN statement
        for (Tuple2<Integer, String> whenStr : refAlerteBoRDDWhenSorted.collect()) {
            strBuilder.append(whenStr._2().toString());
        }
        
        strBuilder.append("END AS " + paramCols.getProperty("targetFieldName"));
        
        String caseWhenBOStr = strBuilder.toString();
        
        return caseWhenBOStr;
        
    }
    
}
