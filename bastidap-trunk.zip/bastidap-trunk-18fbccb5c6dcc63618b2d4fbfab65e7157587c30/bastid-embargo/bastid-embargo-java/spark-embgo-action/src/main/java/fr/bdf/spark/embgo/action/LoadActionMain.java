package fr.bdf.spark.embgo.action;

import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.fs.Path;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import fr.bdf.bastid.util.bean.LineAcqFile;
import fr.bdf.bastid.util.filereader.AcqFileReader;
import fr.bdf.spark.embgo.action.constant.LoadActionConstant;
import fr.bdf.spark.embgo.action.data.GetParamData;
import fr.bdf.spark.embgo.action.data.ManageActionData;
import fr.bdf.spark.embgo.action.util.ParseParam;

public class LoadActionMain implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5626918089048992794L;

	public static String getTime() {
		return "[" + new SimpleDateFormat("HH:mm:ss").format(new Date())
				+ "] - ";
	}

	public static void main(String[] args) {

		if (args.length != 3) {
			System.out
					.println("INFO:"
							+ LoadActionMain.getTime()
							+ " Missing arguments. Usage: "
							+ new java.io.File(LoadActionMain.class
									.getProtectionDomain().getCodeSource()
									.getLocation().getPath()).getName()
							+ " <configuration file>"
							+ " <path to id acquisition file>"
							+ " <id traitement>");
			System.exit(0);
		}

		String pathToConfigFile = args[0];
		String acqFilePath = args[1];
		String idTrt = args[2];

		/** Init configuration and contexts */
		final SparkSession session = SparkSession.builder().appName("LoadAction")
				.config("spark.sql.warehouse.dir", "/apps/hive/warehouse")
				.config("spark.sql.hive.convertMetastoreOrc", "false")
				.config("hive.fetch.task.conversion", "none")
				.enableHiveSupport().getOrCreate();
		
		session.sparkContext().hadoopConfiguration().addResource(new Path(pathToConfigFile));
		
		LoadActionConstant loadActionConstant = null;
		try {
			loadActionConstant = new LoadActionConstant();
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}

		Logger.getRootLogger().setLevel(Level.WARN);

		AcqFileReader afr = new AcqFileReader(acqFilePath);

		Map<String, List<LineAcqFile>> mapAcqFileLines = getMapAcqFileLines(afr);

		String idAcqParamNiv = afr.getIdAcqParamOrFull(mapAcqFileLines,
				LoadActionConstant.PARAM_ACT_NIV.toUpperCase());
		String idAcqParamBo = afr.getIdAcqParamOrFull(mapAcqFileLines,
				LoadActionConstant.PARAM_ACT_BO.toUpperCase());
		String idAcqParamInd = afr.getIdAcqParamOrFull(mapAcqFileLines,
				LoadActionConstant.PARAM_ACT_IND.toUpperCase());
		
		String idAcqFmfUsers = afr.getIdAcqParamOrFull(mapAcqFileLines,
				LoadActionConstant.FMF_USERS.toUpperCase());

		if (!validAcqParamOrFull(idAcqParamNiv, idAcqParamBo, idAcqParamInd, idAcqFmfUsers)) {
			Logger.getRootLogger().error(
					"At least one of the param acquisition ids is missing");
			System.exit(0);
		}

		List<LineAcqFile> listIdAcqHistAction = mapAcqFileLines
				.get(LoadActionConstant.FOFA_HIST_ACT);
		List<LineAcqFile> listIdAcqHistFiles = mapAcqFileLines
				.get(LoadActionConstant.FOF_HIST_FILES);

		if (!validAcqDelta(listIdAcqHistAction, listIdAcqHistFiles)) {
			Logger.getRootLogger().error(
					"At least one of the delta acquisition ids is missing");
			System.exit(0);
		}

		// INIT Get Param Data
		GetParamData paramData = new GetParamData(session, loadActionConstant);

		/**
		 * STEP 1 : Build CASE WHEN statement for PARAM_ACTION_NIVEAU &
		 * PARAM_ACTION_BO & PARAM_ACTION_IND tables
		 */
		Dataset<Row> paramActNiveauDF = paramData
				.getParamActionNiveauData(idAcqParamNiv, loadActionConstant.getRawLayerHiveBase());
		Dataset<Row> paramActBoDF = paramData
				.getParamActionBoData(idAcqParamBo, loadActionConstant.getRawLayerHiveBase());
		Dataset<Row> paramActIndDF = paramData
				.getParamActionIndData(idAcqParamInd, loadActionConstant.getRawLayerHiveBase());

		// Logs
		System.out.println("INFO:" + getTime() + "paramActNiveauDF count : "
				+ paramActNiveauDF.count());
		System.out.println("INFO:" + getTime() + "paramActBoDF count : "
				+ paramActBoDF.count());
		System.out.println("INFO:" + getTime() + "paramActIndDF count : "
				+ paramActIndDF.count());

		// niveau_decision
		java.util.Properties paramCols = new java.util.Properties();
		paramCols.clear();
		paramCols.setProperty("compDateFieldName", "date_decision");
		paramCols.setProperty("startDateFieldName", "date_decision_deb");
		paramCols.setProperty("endDateFieldName", "date_decision_fin");
		paramCols.setProperty("resultFieldName", "niveau_decision");
		paramCols.setProperty("targetFieldName", "niveau_decision");
		paramCols.setProperty("nbCondidions", "1");
		paramCols.setProperty("condition_1_field_name", "type_decision");
		paramCols.setProperty("condition_1_type", "EQUAL");

		ParseParam paramNiveauDecision = new ParseParam(paramCols,
				paramActNiveauDF);
		String caseWhenNiveauDecisionStr = paramNiveauDecision
				.getCaseWhenStmt();
		// System.out.println("INFO:" + getTime() +
		// "caseWhenNiveauDecisionStr :" + caseWhenNiveauDecisionStr);
		// back office
		paramCols.clear();
		paramCols.setProperty("compDateFieldName", "date_decision");
		paramCols.setProperty("startDateFieldName", "date_decision_deb");
		paramCols.setProperty("endDateFieldName", "date_decision_fin");
		paramCols.setProperty("resultFieldName", "back_office");
		paramCols.setProperty("targetFieldName", "back_office");

		paramCols.setProperty("nbCondidions", "2");
		paramCols.setProperty("condition_1_field_name", "niveau_decision");
		paramCols.setProperty("condition_1_type", "EQUAL");
		paramCols.setProperty("condition_2_field_name", "type_decision");
		paramCols.setProperty("condition_2_type", "LIKE");

		ParseParam paramBO = new ParseParam(paramCols, paramActBoDF);
		String caseWhenBOStr = paramBO.getCaseWhenStmt();
		// System.out.println("INFO:" + getTime() + "caseWhenBOStr :" +
		// caseWhenBOStr);

		// ind
		paramCols.clear();
		paramCols.setProperty("compDateFieldName", "date_decision");
		paramCols.setProperty("startDateFieldName", "date_decision_deb");
		paramCols.setProperty("endDateFieldName", "date_decision_fin");
		paramCols.setProperty("resultFieldName", "ind_decision");
		paramCols.setProperty("targetFieldName", "ind_decision");

		paramCols.setProperty("nbCondidions", "2");
		paramCols.setProperty("condition_1_field_name", "type_decision");
		paramCols.setProperty("condition_1_type", "EQUAL");
		paramCols.setProperty("condition_2_field_name", "commentaire_action");
		paramCols.setProperty("condition_2_type", "EQUAL");

		ParseParam paramIND = new ParseParam(paramCols, paramActIndDF);
		String caseWhenINDStr = paramIND.getCaseWhenStmt();
		// System.out.println("INFO:" + getTime() + "caseWhenINDStr :" +
		// caseWhenINDStr);

		/** Initialize Bean for queries with case when statements */
		ManageActionData manageActionHelper = new ManageActionData(session,
				caseWhenNiveauDecisionStr, caseWhenBOStr, caseWhenINDStr);

		/**
		 * STEP 2 : Build ACTION dataframe (combination FOFA_HIST_ACTION +
		 * FOF_HIST_FILES) And SAVE it as tmp table
		 */
		Dataset<Row> actionDF = paramData.getBasicActionTable(
				listIdAcqHistAction, listIdAcqHistFiles, idAcqFmfUsers).persist();
		// actionDF.show();
		actionDF.createOrReplaceTempView(LoadActionConstant.TMP_TABLE);
		// sqlContext.sql("DROP TABLE IF EXISTS "+
		// LoadActionConstant.TMP_TABLE);
		// actionDF.write().mode("overwrite").saveAsTable(LoadActionConstant.TMP_TABLE);
		// actionDF.printSchema();
		// Logs
		System.out.println("INFO:" + getTime() + "actionDF count : "
				+ actionDF.count());

		/**
		 * STEP 3 : Request Action dataFrame to add niveau_decision And
		 * registrer as TMP Table
		 */
		Dataset<Row> actionNiveauDecision = manageActionHelper
				.generateActionNiveauDecision(LoadActionConstant.TMP_TABLE)
				.persist();
		actionNiveauDecision
				.createOrReplaceTempView(LoadActionConstant.TMP_TABLE_NIVEAU_DECISION);
		// sqlContext.sql("DROP TABLE IF EXISTS "+
		// LoadActionConstant.TMP_TABLE_NIVEAU_DECISION);
		// actionNiveauDecision.write().mode("overwrite").saveAsTable(LoadActionConstant.TMP_TABLE_NIVEAU_DECISION);
		// actionNiveauDecision.printSchema();

		// Logs
		System.out.println("INFO:" + getTime()
				+ "actionNiveauDecision count : "
				+ actionNiveauDecision.count());
		// clean tmp table and Old Dataframe
		// TODO : ReplacedropTemp Table
		// sqlContext.dropTempTable(LoadActionConstant.TMP_TABLE);
//		actionDF.unpersist();

		/**
		 * STEP 3 : Request actionNiveauDecisionDF to get back_office and ind
		 * fields
		 */
		Dataset<Row> actionBoAndIndDF = manageActionHelper
				.generateActionBoAndIndData(
						LoadActionConstant.TMP_TABLE_NIVEAU_DECISION).persist();
		actionBoAndIndDF
				.createOrReplaceTempView(LoadActionConstant.TMP_TABLE_BO_AND_IND);
		// sqlContext.sql("DROP TABLE IF EXISTS "+
		// LoadActionConstant.TMP_TABLE_BO_AND_IND);
		// actionBoAndIndDF.write().mode("overwrite").saveAsTable(LoadActionConstant.TMP_TABLE_BO_AND_IND);
		// actionBoAndIndDF.printSchema();
		// Logs
		System.out.println("INFO:" + getTime() + "actionBoAndIndDF count : "
				+ actionBoAndIndDF.count());
		// clean tmp table and Old Dataframe
		// TODO : ReplacedropTemp Table
		// sqlContext.dropTempTable(LoadActionConstant.TMP_TABLE_NIVEAU_DECISION);
//		actionNiveauDecision.unpersist();

		/** STEP 4 : Request complete action DF to get trt time */
		Dataset<Row> actionTimeTrtOneDF = manageActionHelper
				.generateActionTimeTrt(LoadActionConstant.TMP_TABLE_BO_AND_IND)
				.persist();
		actionTimeTrtOneDF
				.createOrReplaceTempView(LoadActionConstant.TMP_TABLE_TIME_TRT_ONE);
		// sqlContext.sql("DROP TABLE IF EXISTS "+
		// LoadActionConstant.TMP_TABLE_TIME_TRT_ONE);
		// actionTimeTrtOneDF.write().mode("overwrite").saveAsTable(LoadActionConstant.TMP_TABLE_TIME_TRT_ONE);
		// actionTimeTrtOneDF.printSchema();
		// Logs
		System.out.println("INFO:" + getTime() + "actionTimeTrtOneDF count : "
				+ actionTimeTrtOneDF.count());

		/**
		 * STEP 5 : Request actionBoAndIndDF and actionTimeTrtOneDF to build
		 * actionFinal table
		 */
		Dataset<Row> actionFinalDF = manageActionHelper.generateActionFinal(
				idTrt, LoadActionConstant.TMP_TABLE_BO_AND_IND,
				LoadActionConstant.TMP_TABLE_TIME_TRT_ONE);
		
		// Logs
		System.out.println("INFO:" + getTime() + "actionFinalDF count : "
				+ actionFinalDF.count());

		// clear old DataFrames and tmp tables
		// TODO : ReplacedropTemp Table
		// sqlContext.dropTempTable(LoadActionConstant.TMP_TABLE_BO_AND_IND);
		// sqlContext.dropTempTable(LoadActionConstant.TMP_TABLE_TIME_TRT_ONE);
//		actionBoAndIndDF.unpersist();
//		actionTimeTrtOneDF.unpersist();

		/** STEP 6 : Save alerte Final datas */
		manageActionHelper.writeAlerteData(loadActionConstant.getWorkLayerPath(), loadActionConstant.getWorkLayerHiveBase(), actionFinalDF, idTrt);
		
		/** Close sc */
		session.close();
	}

	/**
	 * Method that gets the acquisition ids needed for the treatment.
	 * 
	 * @param afr
	 *            the acquisition file reader
	 * @return the map that contains the acquisition ids needed for the
	 *         treatment
	 */
	private static Map<String, List<LineAcqFile>> getMapAcqFileLines(
			AcqFileReader afr) {
		Map<String, List<LineAcqFile>> mapAcqFileLines = null;
		try {
			mapAcqFileLines = afr.getAcqFileLines();
		} catch (IOException e) {
			Logger.getRootLogger().error(
					"An error occured when reading the file", e);
			System.exit(0);
		}

		if (mapAcqFileLines == null || mapAcqFileLines.isEmpty()) {
			Logger.getRootLogger().error(
					"The acquisition id map is null or empty");
			System.exit(0);
		}
		return mapAcqFileLines;
	}

	/**
	 * Method that verifies if the acquisition ids for param or full tables are valid
	 * 
	 * @param idAcqParamNiv
	 *            the acquisition id for PARAM_ACTION_NIVEAU
	 * @param idAcqParamBo
	 *            the acquisition id for PARAM_ACTION_BO
	 * @param idAcqParamInd
	 *            the acquisition id for PARAM_ACTION_IND
	 * @param idAcqFmfUsers
	 *            the acquisition id for FMF_USERS
	 * @return true if all the acquisition ids are valid, false if not
	 */
	private static boolean validAcqParamOrFull(String idAcqParamNiv,
			String idAcqParamBo, String idAcqParamInd, String idAcqFmfUsers) {
		return idAcqParamNiv != null && !"".equals(idAcqParamNiv)
				&& idAcqParamBo != null && !"".equals(idAcqParamBo)
				&& idAcqParamInd != null && !"".equals(idAcqParamInd)
				&& idAcqFmfUsers != null && !"".equals(idAcqFmfUsers);
	}

	/**
	 * Method that verifies if the acquisition ids for delta tables are valid
	 * 
	 * @param listIdAcqHistAction
	 *            the list of acquisition ids for FOFA_HIST_ACTION
	 * @param listIdAcqHistFiles
	 *            the list of acquisition ids for FOFA_HIST_FILES
	 * @return true if all the acquisition ids are valid, false if not
	 */
	private static boolean validAcqDelta(List<LineAcqFile> listIdAcqHistAction,
			List<LineAcqFile> listIdAcqHistFiles) {
		return listIdAcqHistAction != null && !listIdAcqHistAction.isEmpty()
				&& listIdAcqHistFiles != null && !listIdAcqHistFiles.isEmpty();
	}

}
