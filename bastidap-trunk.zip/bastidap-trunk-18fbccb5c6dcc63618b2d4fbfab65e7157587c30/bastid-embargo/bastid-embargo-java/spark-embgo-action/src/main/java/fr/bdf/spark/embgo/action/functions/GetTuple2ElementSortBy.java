/**
 * 
 */
package fr.bdf.spark.embgo.action.functions;

import java.io.Serializable;

import org.apache.spark.api.java.function.Function;

import scala.Tuple2;

/**
 * Used in a sortBy function. The goal is to extract the element used for the sort.
 * Here the element is the _1 of the Tuple2    
 */
public class GetTuple2ElementSortBy implements Function<Tuple2<Integer, String>, Object>, Serializable {

    private static final long serialVersionUID = 7411550303152820574L;

    @Override
    public Object call(Tuple2<Integer, String> v1) throws Exception {
        //"emit" the first element as it will be used by the sort function
        return v1._1();
    }

}
