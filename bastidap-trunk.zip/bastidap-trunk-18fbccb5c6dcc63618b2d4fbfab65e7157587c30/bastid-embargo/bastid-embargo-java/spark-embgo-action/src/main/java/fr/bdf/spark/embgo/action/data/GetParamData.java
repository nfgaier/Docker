/**
 * 
 */
package fr.bdf.spark.embgo.action.data;

import java.io.Serializable;
import java.util.List;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import fr.bdf.bastid.util.bean.LineAcqFile;
import fr.bdf.spark.embgo.action.constant.LoadActionConstant;


public class GetParamData implements Serializable {

    private static final long serialVersionUID = -6984146894018261739L;

    private SparkSession session;
	private LoadActionConstant loadActionConstant;

    /**
     * @param sqlContext
     */
    public GetParamData(SparkSession session, LoadActionConstant loadActionConstant) {
        super();
        this.session = session;
        this.loadActionConstant = loadActionConstant;
    }
    
    /** BASTID CONFIG */
    
    /** 
     * Method to get combination between fofa_hist_action and fofa_hist_files of the day
     * @param listIdAcqHistAction the list of id_acquisition / date_ope for FOFA_HIST_ACTION
     * @param listIdAcqHistFiles the list of id_acquisition / date_ope for FOFA_HIST_FILES
     * @param idAcqFmfUsers the id_acquisition for FMF_USERS
     * @return df , DataFrame
     * */
    public Dataset<Row> getBasicActionTable(List<LineAcqFile> listIdAcqHistAction, List<LineAcqFile> listIdAcqHistFiles, String idAcqFmfUsers) {
    	return session.sql("SELECT    t1.T_SYSTEM_ID AS id_action, " +
                        			 "t1.T_SYSTEM_ID AS ID_ALERTE, " +
                        			 "from_unixtime(unix_timestamp(t1.T_DECISION_DATE, 'yyyy-MM-dd hh:mm:ss')) AS DATE_DECISION," +
                        			 "t1.T_OPERATOR_DESC AS MATRICULE_UTILISATEUR, " +
                        			 "t3.t_id AS id_utilisateur, " +
                        			 "t1.T_DECISION_TYPE AS TYPE_DECISION," +
                         			 "t1.T_COMMENTS AS COMMENTAIRE_ACTION," +
                        			 "t2.FILE_NAME AS NOM_PJ, " +
                        			 "t2.content AS CONTENU_PJ, " +
                        			 "t2.CONTENT_SIZE AS TAILLE_CONTENU_PJ," +
                        			 "t2.COMMENTS AS COMMENTAIRE_PJ, " +
                        			 "t2.DEC_ID AS ID_DECISION," +
                        			 "'' AS back_office," +
                        			 "'' AS NIVEAU_DECISION," +
                        			 "'' as temps_trait," +
                        			 "'' as temps_trait_jhm," +
                        			 "'' AS IND_DECISION," +
                        			 "t1.date_ope as date_ope," +
                        			 "t1.date_insert as date_insert " +
                			"FROM " + loadActionConstant.getRawLayerHiveBase() + ".FOFA_HIST_ACTION t1 " +
                			"LEFT JOIN " + loadActionConstant.getRawLayerHiveBase() + ".FOF_HIST_FILES t2 ON (t1.T_SYSTEM_ID=t2.id "
                			                                            + "AND t1.T_DECISION_DATE=t2.DEC_DATE) " +
                			 "LEFT JOIN " + loadActionConstant.getRawLayerHiveBase() + ".FMF_USERS t3 ON (t1.T_OPERATOR_DESC = t3.t_login and t3.id_traitement='"+idAcqFmfUsers+"') " +
                			this.getWhereClause(listIdAcqHistAction, listIdAcqHistFiles));
    }
    
    
    /**
     * Method that constructs the where part of the request
     * @param listIdAcqHistAction the list of id_acquisition / date_ope for FOFA_HIST_ACTION
     * @param listIdAcqHistFiles the list of id_acquisition / date_ope for FOFA_HIST_FILES
     * @return the where part of the request
     */
    private String getWhereClause(List<LineAcqFile> listIdAcqHistAction, List<LineAcqFile> listIdAcqHistFiles) {
		StringBuilder sb = new StringBuilder("WHERE");
		for (LineAcqFile lineHistAction : listIdAcqHistAction) {
			for (LineAcqFile lineHistFile : listIdAcqHistFiles) {
				if (lineHistAction.getJourFonc() != null && lineHistAction.getJourFonc().equals(lineHistFile.getJourFonc())) {
					sb.append(" (t1.date_ope = '").append(lineHistAction.getJourFonc())
					.append("' AND t1.id_traitement = '").append(lineHistAction.getIdAcq())
					.append("' AND ((t2.date_ope = '").append(lineHistFile.getJourFonc())
					.append("' AND t2.id_traitement = '").append(lineHistFile.getIdAcq()).append("') OR t2.id IS NULL)) OR");
				}
			}
		}
		
		return sb.substring(0, sb.length() - 3);
	}

	public Dataset<Row> getParamActionNiveauData (String idTraitement, String hiveBaseName) {
		return session.sql("select  ordre,"
                                    + "date_decision_deb,"
                                    + "date_decision_fin,"
                                    + "type_decision,"
                                    + "niveau_decision,"
                                    + "id_traitement"
                           + " from " + hiveBaseName + "." + LoadActionConstant.PARAM_ACT_NIV 
                           + " where id_traitement = '"+idTraitement+"' order by ordre"); 
    }
    

	public Dataset<Row> getParamActionBoData (String idTraitement, String hiveBaseName) { 
	    return session.sql("select  ordre,"
	                                + "date_decision_deb,"
	                                + "date_decision_fin,"
	                                + "niveau_decision,"
	                                + "type_decision,"
	                                + "back_office,"
	                                + "id_traitement"
	                       + " from " + hiveBaseName + "." + LoadActionConstant.PARAM_ACT_BO 
	                       + " where id_traitement = '"+idTraitement+"' order by ordre"); 
	}

	public Dataset<Row> getParamActionIndData (String idTraitement, String hiveBaseName) { 
	    return session.sql("select  ordre,"
	                                + "date_decision_deb,"
	                                + "date_decision_fin,"
	                                + "type_decision,"
	                                + "commentaire_action,"
	                                + "ind_decision,"
	                                + "id_traitement"
	                       + " from " + hiveBaseName + "." + LoadActionConstant.PARAM_ACT_IND 
	                       + " where id_traitement = '"+idTraitement+"' order by ordre"); 
	}
	    
    
}
