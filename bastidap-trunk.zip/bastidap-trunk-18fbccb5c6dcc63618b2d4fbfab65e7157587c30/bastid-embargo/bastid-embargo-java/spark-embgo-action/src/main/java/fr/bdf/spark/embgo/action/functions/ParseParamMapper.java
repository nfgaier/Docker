/**
 * 
 */
package fr.bdf.spark.embgo.action.functions;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.Serializable;
import java.util.Properties;

import org.apache.spark.api.java.function.Function;
import fr.bdf.spark.embgo.action.constant.LoadActionConstant;

import scala.Tuple2;


public class ParseParamMapper implements Function<String, Tuple2<Integer, String>>, Serializable {


    private static final long serialVersionUID = 7085468820871812762L;

    private Properties paramCols;
    private Boolean hasDateCondition = true;

    /**
     * @param p
     */
    public ParseParamMapper(Properties p) {
        super();
        this.paramCols = p;
    }

    /**
     * @return the paramCols
     */
    public Properties getParamCols() {
        return paramCols;
    }

    /**
     * @param paramCols la valeur de paramCols à attribuer.
     */
    public void setParamCols(Properties paramCols) {
        this.paramCols = paramCols;
    }

    @Override
    public Tuple2<Integer, String> call(String v1) throws Exception {

        //used to construct the CASE WHEN statement
        StringBuilder strBuilder = new StringBuilder("");

        strBuilder.append(" WHEN ");

        JsonParser parser = new JsonParser();
        
        JsonObject paramObj = parser.parse(v1).getAsJsonObject();
        Integer ordre = Integer.parseInt(paramObj.get("ordre").toString());
        final String compDateFieldName = getParamCols().getProperty("compDateFieldName") ;
        final String startDateFieldName = getParamCols().getProperty("startDateFieldName") ;
        final String endDateFieldName = getParamCols().getProperty("endDateFieldName") ;
        final String resultFieldName = getParamCols().getProperty("resultFieldName") ;
        //final String targetFieldName = getParamCols().getProperty("targetFieldName") ;
        final Integer nbCondidions = Integer.parseInt(getParamCols().getProperty("nbCondidions")) ;
        
        //if there is no date filed to compare to, then skip the test based on the start and end dates
        if (hasDateCondition) {
            // if a date is empty then use the default dates from ParseParamConstant  
            String startDate = paramObj.get(startDateFieldName)==null ?  LoadActionConstant.MIN_DATE : paramObj.get(startDateFieldName).getAsString();
            String endDate = paramObj.get(endDateFieldName)==null ? LoadActionConstant.MAX_DATE : paramObj.get(endDateFieldName).getAsString(); 
            // construct an expression like : to_date('1900-01-01') <= date_decision_finale  and to_date('2016-07-06') > date_decision_finale     
            strBuilder.append("to_date('")
            .append(startDate)
            .append("') <= ")
            .append(compDateFieldName)
            .append(" and to_date('")
            .append(endDate)
            .append("') >= ")
            .append(compDateFieldName)
            ;
        }

        //get the name of the filed containing the value if the conditions are met
        String result = paramObj.get(resultFieldName).getAsString(); 
        // loop through the list of conditions    
        for (int i=1; i<=nbCondidions;i++) {
            //get the filed name
            String condFieldName = getParamCols().getProperty(LoadActionConstant.CONDITION_PREFIX+i+LoadActionConstant.CONDITION_FIELD_SUFFIX); 
            String condValue = null;
            try { 
                //get the value
                condValue = paramObj.get(condFieldName).getAsString();
            }catch (Exception e) {
                throw e;
            }

            //if the value of the condition is null or an empty string the ignore the condition and not include it in the CASE WHEN statement 
            if ( condValue!=null && !condValue.trim().equals("")) {

                if (hasDateCondition && i==1 || i != 1) {
                    strBuilder.append(" and ");
                }

                //if the value of the condition is the string NULL append the test IS NULL
                if (LoadActionConstant.NULL.equalsIgnoreCase(condValue)) {
                    strBuilder.append(condFieldName)
                    .append(" IS ")
                    .append(LoadActionConstant.NULL);
                } else {
                    //get the condition type (EQUAL or LIKE)
                    String condType =  getParamCols().getProperty(LoadActionConstant.CONDITION_PREFIX+i+LoadActionConstant.CONDITION_TYPE_SUFFIX); 
                    //append the appropriate test depending on the condition type
                    if (condType.equals(LoadActionConstant.CONDITION_EQUAL)) {
                        strBuilder.append(condFieldName)
                        .append(" = ")
                        .append("'"+condValue+"'");
                    }
                    else if (condType.equals(LoadActionConstant.CONDITION_LIKE)) {
                        strBuilder.append(condFieldName)
                        .append(" LIKE ")
                        .append("'"+condValue+"'");
                    }
                    else {
                        //TODO Should not happen, raise exception
                        System.out.println("Should not happen, raise exception");
                    }
                }
            }
        }

        //append the result value
        strBuilder.append(" then '" + result + "' " );

        return new Tuple2<Integer, String>(ordre,strBuilder.toString());
    }

}
