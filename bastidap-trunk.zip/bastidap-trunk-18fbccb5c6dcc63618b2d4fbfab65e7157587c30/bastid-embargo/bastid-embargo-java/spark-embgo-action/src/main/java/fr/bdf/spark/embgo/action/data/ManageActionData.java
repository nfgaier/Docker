package fr.bdf.spark.embgo.action.data;

import java.io.Serializable;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import fr.bdf.spark.embgo.action.constant.LoadActionConstant;

public class ManageActionData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3503941338879801828L;
	
	private SparkSession session;
	
	private String caseWhenNiveauDecisionStr;
    private String caseWhenBOStr;

	private String caseWhenINDStr;

    /**
     * @param sqlContext
     * @param caseWhenMOTStr : string containing the case when statement for the refMotif field
     * @param caseWhenETATStr : string containing the case when statement for the refEtat field
     * @param caseWhenBOStr : string containing the case when statement for the refBackOffice field
     * @param caseWhenINDStr : string containing the case when statement for the refInd field
     */
    public ManageActionData(SparkSession session, String caseWhenNiveauDecisionStr, String caseWhenBOStr, String caseWhenINDStr) {
        super();
        this.session = session;
        this.caseWhenNiveauDecisionStr = caseWhenNiveauDecisionStr;
        this.caseWhenBOStr = caseWhenBOStr;
        this.caseWhenINDStr = caseWhenINDStr;
    }


    public SparkSession getSession() {
		return session;
	}




	public void setSession(SparkSession session) {
		this.session = session;
	}
     
    /**
     * Executes a hive a prepared query with the case when statements injected and returns a DataFrame 
     * @param idTraitement
     * @return DataFrame
     */
    public Dataset<Row> generateActionNiveauDecision (String tmpTable) {

        String query = "select  id_action, " +
                        		"id_alerte, " +
                        		"date_decision, " +
                        		"matricule_utilisateur, " +
                        		"id_utilisateur, " +
                        		"type_decision, " +
                        		"ind_decision, " +
                        		this.caseWhenNiveauDecisionStr +", " +
                        		"back_office, " +
                        		"commentaire_action, " +
                        		"nom_pj, " +
                        		"contenu_pj, " +
                        		"taille_contenu_pj, " +
                        		"commentaire_pj, " +
                        		"id_decision, " +
                        		"temps_trait, " +
                        		"temps_trait_jhm, " +
                        		"date_ope, " +
                        		"date_insert " +
                      "from "+ tmpTable;

        //System.out.println("generateActionNiveauDecision query: " + query);
        return session.sql(query);
    }
    
    /**
     * Executes a hive a prepared query with the case when statements injected and returns a DataFrame 
     * @param idTraitement
     * @return DataFrame
     */
    public Dataset<Row> generateActionBoAndIndData (String tmpTable) {

        String query = "select  id_action," +
                        		"id_alerte," +
                        		"date_decision," +
                        		"matricule_utilisateur," +
                        		"id_utilisateur," +
                        		"type_decision," +
                        		this.caseWhenINDStr + "," +
                        		"niveau_decision," +
                        		this.caseWhenBOStr + "," +
                        		"commentaire_action," +
                        		"nom_pj," +
                        		"contenu_pj," +
                        		"taille_contenu_pj," +
                        		"commentaire_pj," +
                        		"id_decision," +
                        		"temps_trait," +
                        		"temps_trait_jhm, " +
                        		"date_ope, " +
                        		"date_insert " +
                        "from "+ tmpTable;

        //System.out.println("generateActionBoAndIndData query: " + query);
        return session.sql(query);
    }

    
    /**
     * Executes a hive a prepared query with the case when statements injected and returns a DataFrame 
     * @param idTraitement
     * @return DataFrame
     */
    public Dataset<Row> generateActionTimeTrt(String tmpTable) {
        String query = 
        		"SELECT act.id_action, act.id_alerte, act.date_decision,  "
        		     + "act.niveau_decision, act.ind_decision, act.type_decision, " +
        		       "CASE WHEN ACT.NIVEAU_DECISION != \"N0\" AND ACT.DATE_DECISION == first_value(act.date_decision) " +
        		           "OVER (PARTITION BY act.id_alerte, act.niveau_decision ORDER BY act.DATE_DECISION DESC) THEN first_value(act.date_decision) " +
        		           "OVER (PARTITION BY act.id_alerte, act.niveau_decision ORDER BY act.DATE_DECISION DESC) END AS NEWER, " +  
        		       "CASE WHEN ACT.NIVEAU_DECISION = \"N0\" AND ACT.DATE_DECISION == first_value(act.date_decision) " +
        		           "OVER (PARTITION BY act.id_alerte, act.niveau_decision ORDER BY act.DATE_DECISION ASC) THEN first_value(act.date_decision) " +
        		          "OVER (PARTITION BY act.id_alerte, act.niveau_decision ORDER BY act.DATE_DECISION ASC) END AS OLDER_NO " +
        		"FROM "+ tmpTable + " act "
        	  + "WHERE (TYPE_DECISION IS NOT NULL) "
        	  + "ORDER BY ID_ALERTE, DATE_DECISION, NIVEAU_DECISION" ;

        //System.out.println("generateActionTimeTrt query: " + query);
        return session.sql(query);
    }
    
    /**
     * @param idTraitement
     * @return DataFrame
     */
    public Dataset<Row> generateActionFinal(String idTraitement, String tmpTableBoAndInd, String tmpTableTimeTrt) {
    	String query = 
        		"SELECT  concat(" + idTraitement + ", row_number() over(order by t0.ID_ALERTE)) as ID_ACTION, " +
        				"t0.ID_ALERTE, t0.DATE_DECISION, t0.MATRICULE_UTILISATEUR, t0.ID_UTILISATEUR, " +
        		        "t0.TYPE_DECISION, t0.IND_DECISION, t0.NIVEAU_DECISION, t0.BACK_OFFICE, t0.COMMENTAIRE_ACTION, " +
        		        "t0.NOM_PJ, t0.CONTENU_PJ AS CONTENU_PJ, t0.TAILLE_CONTENU_PJ, t0.COMMENTAIRE_PJ, t0.ID_DECISION, " + 
        		         "t1.TEMPS_TRAIT, t1.TEMPS_TRAIT_JHM, t0.DATE_OPE, t0.DATE_INSERT, '" + idTraitement + "' as id_traitement " +
        	    "FROM " + tmpTableBoAndInd + " t0 " +
        	    "LEFT JOIN ( SELECT id_action, id_alerte, date_decision,  "
        	                     + "niveau_decision, ind_decision, type_decision, "
        	                     + "CASE WHEN IND_DECISION = \"FIN\" AND LAG(NIVEAU_DECISION,1) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC) <= NIVEAU_DECISION THEN CONCAT(CAST(INT((unix_timestamp(LAG(DATE_DECISION,0) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC))-unix_timestamp(LAG(DATE_DECISION,1) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC)))/86400) AS STRING), ':', " +
        	                                                                                                                                                 "CAST(INT(((unix_timestamp(LAG(DATE_DECISION,0) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC))-unix_timestamp(LAG(DATE_DECISION,1) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC)))%86400)/3600) AS STRING), ':', " + 
        	                                                                                                                                                 "CAST(INT((((unix_timestamp(LAG(DATE_DECISION,0) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC))-unix_timestamp(LAG(DATE_DECISION,1) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC)))%86400)%3600)/60)AS STRING), ':', " +
        	                                                                                                                                                 "CAST(INT(((((unix_timestamp(LAG(DATE_DECISION,0) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC))-unix_timestamp(LAG(DATE_DECISION,1) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC)))%86400)%1440)%60)) AS STRING))  " +                         
        	                            "WHEN IND_DECISION = \"FIN\" AND LAG(NIVEAU_DECISION,1) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC) >  NIVEAU_DECISION THEN \"\" " +            
        	                            "ELSE CONCAT(CAST(INT((unix_timestamp(LAG(DATE_DECISION,0) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC))-unix_timestamp(LAG(DATE_DECISION,1) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC)))/86400) AS STRING), ':', " +
        	                                        "CAST(INT(((unix_timestamp(LAG(DATE_DECISION,0) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC))-unix_timestamp(LAG(DATE_DECISION,1) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC)))%86400)/3600) AS STRING), ':', " +
        	                                        "CAST(INT((((unix_timestamp(LAG(DATE_DECISION,0) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC))-unix_timestamp(LAG(DATE_DECISION,1) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC)))%86400)%3600)/60)AS STRING), ':', " +
        	                                        "CAST(INT(((((unix_timestamp(LAG(DATE_DECISION,0) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC))-unix_timestamp(LAG(DATE_DECISION,1) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC)))%86400)%1440)%60)) AS STRING)) " +
        	                            "END AS TEMPS_TRAIT_JHM, " +              
        	                        "unix_timestamp(LAG(DATE_DECISION, 0) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC)) - unix_timestamp(LAG(DATE_DECISION, 1) OVER (PARTITION BY ID_ALERTE ORDER BY DATE_DECISION ASC)) AS TEMPS_TRAIT " +
        	                "FROM " + tmpTableTimeTrt + 
        	               " WHERE (NEWER IS NOT NULL OR OLDER_NO IS NOT NULL) AND TYPE_DECISION IS NOT NULL " +
        	               " ORDER BY ID_ALERTE, DATE_DECISION, NIVEAU_DECISION ) t1 " +       
        	    "ON t0.ID_ALERTE=t1.ID_ALERTE AND t0.DATE_DECISION=t1.DATE_DECISION AND t0.NIVEAU_DECISION=t1.NIVEAU_DECISION " +
        	    "ORDER BY ID_ALERTE, DATE_DECISION, NIVEAU_DECISION";

        System.out.println("generateActionFinal query: " + query);
        return session.sql(query);
    }
    
    /**
     * Writes DataFrame to path and creates a partition in the target table 
     * @param path : 
     * @param data
     * @param idTraitement
     */
    public void writeAlerteData(String path,String hiveBaseName, Dataset<Row> data, String idTraitement){

        //write to path 
        data.write().partitionBy("id_traitement").format("orc").mode("append").save(path + LoadActionConstant.TABLE_ACTION);
        //add partition
        String alterTable = "ALTER TABLE " + hiveBaseName + "." + LoadActionConstant.TABLE_ACTION + 
                " ADD IF NOT EXISTS PARTITION (id_traitement='"+ idTraitement +"') location '"+path+LoadActionConstant.TABLE_ACTION+"/id_traitement="+ idTraitement +"'" ;
        session.sql(alterTable);

        System.out.println("Alter table : " + alterTable);

    }

}
