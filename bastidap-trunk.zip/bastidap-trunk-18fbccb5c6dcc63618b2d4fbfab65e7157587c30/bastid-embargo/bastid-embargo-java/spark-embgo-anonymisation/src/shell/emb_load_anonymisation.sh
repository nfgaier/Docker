#!/usr/bin/env bash
###############################################################################
# Description :
# Usage :    
# Author : Umanis for BDF
# Updated : 06/10/2017
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug


. $APPLI_HOME/appli/connexion/.fonction                        #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  


ENVIRONMENT=$1
TABLE_NAME=$2

#######################################
# Description: setup function setting variables
# Arguments: 
# Returns: 0 for success, 1 for failure
#######################################
prepare () {

  jar_dir="${REPBDF}/embargo/traitement/jar/"
  config_dir="${REPBDF}/embargo/config/"
  script_name="spark-embgo-anonymisation-1.0.0-SNAPSHOT.jar"
  idAcq=$(cat "${EMB_TMP_FOLDER}/id_traitement_acq.tmp")
  
  if [[ -z ${idAcq} ]] ; then  
    LOG_ERROR "idAcq variable not set."
    exit 1
  else
    LOG_INFO "idAcq = ${idAcq}"
  fi 
}

#######################################
# Description: 
# Arguments: none
# Returns: 0 for success, 1 for failure
#######################################
run() {
  
  echo "INFO: ${__BASE} : ${FUNCNAME[0]} : Running  "
  spark-submit --class org.fr.bdf.spark.embgo.anonymisation.LoadAnonymisationMain \
               --master yarn  \
               --queue ${TRT_QUEUE} \
               --driver-memory 4g \
               "${jar_dir}${script_name}" \
               ${ENVIRONMENT} \
               ${TABLE_NAME} \
               ${idAcq}
                                                                                            
}  

#######################################
# Description: Main function
# Arguments: -
# Returns: 
#######################################
main () {

  START

  SETUP
  
  LOG_INFO "${FUNCNAME[0]} : EMB : Load aletes" 
  
  prepare
  
  run
  
  END
 
  exit ${__SUCCESS}
 
}

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1