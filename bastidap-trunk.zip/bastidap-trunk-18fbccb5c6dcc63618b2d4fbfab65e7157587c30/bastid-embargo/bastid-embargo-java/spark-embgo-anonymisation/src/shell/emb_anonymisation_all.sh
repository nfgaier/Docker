#!/usr/bin/env bash
set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction                        #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

readonly __PARAMFILE="${__DIR}/${__BASE}_param.csv"            #permanent configuration file containing the scripts to execute 
readonly __TMP_PROCFILE=${__BASE}"_lst_prc_pid.tmp"            #temporary configuration file associating a script with its PID 
readonly __KO_PARAMFILE=${__BASE}"_param_KO.tmp"               #configuration file containing the KO scripts to re-execute 
readonly __TMP_KO_PARAMFILE=${__BASE}"_param_TMP_KO.tmp"       #temporary configuration file containing the KO scripts to execute
readonly __TMP_FOLDER="."                                      #folder for tmp files       
readonly __DUMMY_INIT=99999
readonly __SEPARATOR=","

__FAILED=0                                                     #failed scritps counter
__GROUPS_ARRAY=()                                              #global array used to store the groups ID 
__NB_TRIES=3                                                   #number of re-tries 
__TMP_PARAMFILE=${__PARAMFILE}                                 #variable used to pass the configuration file to a function

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

main () {

./emb_load_anonymisation.sh REC fmf_users
./emb_load_anonymisation.sh REC fofa_hist_action
./emb_load_anonymisation.sh REC fofa_hist_intervention
./emb_load_anonymisation.sh REC fofa_hist_message
./emb_load_anonymisation.sh REC fof_hist_files
./emb_load_anonymisation.sh REC param_alerte_motif
./copy_land_row_unanonymized_tables.sh REC
./emb_verif_anonymisation.sh

exit ${__SUCCESS}

}

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
