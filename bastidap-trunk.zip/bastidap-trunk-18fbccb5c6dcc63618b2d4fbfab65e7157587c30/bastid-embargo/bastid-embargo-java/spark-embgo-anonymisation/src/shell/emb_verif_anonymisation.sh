#!/usr/bin/env bash
set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction                        #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

readonly __PARAMFILE="${__DIR}/${__BASE}_param.csv"            #permanent configuration file containing the scripts to execute 
readonly __TMP_PROCFILE=${__BASE}"_lst_prc_pid.tmp"            #temporary configuration file associating a script with its PID 
readonly __KO_PARAMFILE=${__BASE}"_param_KO.tmp"               #configuration file containing the KO scripts to re-execute 
readonly __TMP_KO_PARAMFILE=${__BASE}"_param_TMP_KO.tmp"       #temporary configuration file containing the KO scripts to execute
readonly __TMP_FOLDER="."                                      #folder for tmp files       
readonly __DUMMY_INIT=99999
readonly __SEPARATOR=","

__FAILED=0                                                     #failed scritps counter
__GROUPS_ARRAY=()                                              #global array used to store the groups ID 
__NB_TRIES=3                                                   #number of re-tries 
__TMP_PARAMFILE=${__PARAMFILE}                                 #variable used to pass the configuration file to a function

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

#######################################
# Description: setup function setting variables
# Arguments: 
# Returns: 0 for success, 1 for failure
#######################################
prepare () {

  ID_TRAITEMENT=$(cat "${EMB_TMP_FOLDER}/id_traitement_acq.tmp")
  
  if [[ -z ${ID_TRAITEMENT} ]] ; then  
    LOG_ERROR "idAcq variable not set."
    exit 1
  else
    LOG_INFO "ID_TRAITEMENT = ${ID_TRAITEMENT}"
  fi 
}

#######################################
# Description: checking function for number of lines landing_layer vs raw_layer
# Arguments: 
# Returns: 0 for success, 1 for failure
#######################################
check_anonymisation () {

#INITIALISATION tables to check
tables_tab=(fmf_users fof_hist_files fofa_hist_action fofa_hist_intervention fofa_hist_message param_alerte_motif)

for i in "${!tables_tab[@]}"; do 

	LOG_INFO "Check Table : ${tables_tab[$i]}"
	NB_LINE_LANDING=$(hive --hiveconf tez.queue.name=$TRT_QUEUE -S -e "SELECT count(*) from ${EMB_HIVEDB_LDL}.${tables_tab[$i]} WHERE id_traitement='${ID_TRAITEMENT}'")
	NB_LINE_RAW=$(hive --hiveconf tez.queue.name=$TRT_QUEUE -S -e "SELECT count(*) from ${EMB_HIVEDB_RWL}.${tables_tab[$i]} WHERE id_traitement='${ID_TRAITEMENT}'")

	if [ $NB_LINE_LANDING = $NB_LINE_RAW ]
    then 
		LOG_INFO "Table : ${tables_tab[$i]} OK , nb lines Landing : ${NB_LINE_LANDING} , nb line raw : ${NB_LINE_LANDING}"
    else   
		LOG_ERROR "Table : ${tables_tab[$i]} KO , nb lines Landing : ${NB_LINE_LANDING} , nb line raw : ${NB_LINE_LANDING}"
    fi 

done
}


#######################################
# Description: main
# Arguments: 
# Returns: 0 for success, 1 for failure
#######################################
main () {

	prepare
	
	check_anonymisation

	exit ${__SUCCESS}
}

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
