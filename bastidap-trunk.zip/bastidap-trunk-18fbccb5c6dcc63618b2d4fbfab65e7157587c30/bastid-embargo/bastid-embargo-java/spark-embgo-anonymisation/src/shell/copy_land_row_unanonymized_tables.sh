#!/usr/bin/env bash
###############################################################################
# Description :
# Usage : 
# Author : 
# Updated : 
###############################################################################

#set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec                        #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

do_copy() {

  LOG_INFO "HDFS copy ..."
  #PARAMS
  LOG_INFO "param_action_bo"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/param_action_bo/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/param_action_bo/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/param_action_bo/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "param_alerte_ind"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/param_alerte_ind/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/param_alerte_ind/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/param_alerte_ind/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "param_alerte_etat"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/param_alerte_etat/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/param_alerte_etat/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/param_alerte_etat/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "param_alerte_bo"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/param_alerte_bo/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/param_alerte_bo/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/param_alerte_bo/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "param_alerte_niveau"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/param_alerte_niveau/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/param_alerte_niveau/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/param_alerte_niveau/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "param_action_niveau"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/param_action_niveau/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/param_action_niveau/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/param_action_niveau/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "param_action_ind"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/param_action_ind/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/param_action_ind/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/param_action_ind/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "ref_user_statut"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/ref_user_statut/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/ref_user_statut/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/ref_user_statut/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "ref_profil_statut"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/ref_profil_statut/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/ref_profil_statut/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/ref_profil_statut/id_traitement=${ID_TRAITEMENT}

  #SIO
  LOG_INFO "fmf_profile_right"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fmf_profile_right/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fmf_profile_right/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fmf_profile_right/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fmf_profile_state"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fmf_profile_state/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fmf_profile_state/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fmf_profile_state/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fmf_profiles"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fmf_profiles/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fmf_profiles/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fmf_profiles/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fmf_rights"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fmf_rights/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fmf_rights/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fmf_rights/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fmf_units"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fmf_units/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fmf_units/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fmf_units/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fmf_user_profile"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fmf_user_profile/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fmf_user_profile/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fmf_user_profile/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fmf_user_unit"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fmf_user_unit/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fmf_user_unit/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fmf_user_unit/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fof_states"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fof_states/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fof_states/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fof_states/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "fof_transitions"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/fof_transitions/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/fof_transitions/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/fof_transitions/id_traitement=${ID_TRAITEMENT}
  LOG_INFO "profile_transitions"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/profile_transitions/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/profile_transitions/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/profile_transitions/id_traitement=${ID_TRAITEMENT}
  
  LOG_INFO "MSCK REPAIR TABLE"
  hive -hiveconf tez.queue.name=${TRT_QUEUE}  -e "MSCK REPAIR TABLE embargo_raw_layer.ref_profil_statut;
                                                  MSCK REPAIR TABLE embargo_raw_layer.param_action_bo;
                                                  MSCK REPAIR TABLE embargo_raw_layer.ref_user_statut;
                                                  MSCK REPAIR TABLE embargo_raw_layer.param_action_ind;
                                                  MSCK REPAIR TABLE embargo_raw_layer.param_alerte_niveau;
                                                  MSCK REPAIR TABLE embargo_raw_layer.param_alerte_bo;
                                                  MSCK REPAIR TABLE embargo_raw_layer.param_alerte_ind;
                                                  MSCK REPAIR TABLE embargo_raw_layer.param_alerte_motif;
                                                  MSCK REPAIR TABLE embargo_raw_layer.param_alerte_etat;
                                                  MSCK REPAIR TABLE embargo_raw_layer.param_action_niveau;
                                                  MSCK REPAIR TABLE embargo_raw_layer.fmf_profile_right;
                                                  MSCK REPAIR TABLE embargo_raw_layer.fmf_profile_state;
                                                  MSCK REPAIR TABLE embargo_raw_layer.fmf_profiles;
                                                  MSCK REPAIR TABLE embargo_raw_layer.fmf_rights;
                                                  MSCK REPAIR TABLE embargo_raw_layer.fmf_units;
                                                  MSCK REPAIR TABLE embargo_raw_layer.fmf_user_profile;
                                                  MSCK REPAIR TABLE embargo_raw_layer.fmf_user_unit;    
                                                  MSCK REPAIR TABLE embargo_raw_layer.fof_states;    
                                                  MSCK REPAIR TABLE embargo_raw_layer.fof_transitions;    
                                                  MSCK REPAIR TABLE embargo_raw_layer.profile_transitions;"
}                                                  


main () {
  
  if [[ "$#" -ne 1 ]]; then
    LOG_ERROR "${FUNCNAME[0]} : Usage : copy_land_row_unanonymized_tables.sh <env(DEV,REC)>"
    exit ${__FAILURE} 
  else 
    ID_TRAITEMENT=$(cat "${EMB_TMP_FOLDER}/id_traitement_acq.tmp")
    if [[ -z ${ID_TRAITEMENT} ]] ; then  
    	LOG_ERROR "ID_TRAITEMENT variable not set."
    	exit 1
  	else
    	LOG_INFO "ID_TRAITEMENT = ${ID_TRAITEMENT}"
  	fi  
    local temp="${1}"
    if [[ ${temp} != "DEV" && ${temp} != "REC" ]]; then
      LOG_ERROR "${FUNCNAME[0]} : Usage : second parameter must be either DEV or REC"
      exit ${__FAILURE} 
    else
      if [[ ${temp} != "DEV" ]]; then
         S_ENV="s_embarg" 
      else    
         S_ENV="s_dembarg" 
      fi   
    fi  
    LOG_INFO "ID_TRAITEMENT=$ID_TRAITEMENT"    
    LOG_INFO "S_ENV=$S_ENV"    
  fi 
  
  START
  
  SETUP

  do_copy
  
  END
  
  exit ${__SUCCESS}

}                                                
                                                
main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1

