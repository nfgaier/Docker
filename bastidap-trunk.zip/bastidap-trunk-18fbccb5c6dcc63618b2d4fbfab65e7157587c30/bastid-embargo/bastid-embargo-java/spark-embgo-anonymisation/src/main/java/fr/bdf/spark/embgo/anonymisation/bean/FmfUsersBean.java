package fr.bdf.spark.embgo.anonymisation.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;


public class FmfUsersBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4720623338880010852L;
	
	private BigDecimal t_id;
	private BigDecimal business_unit_id;
	private String t_lockcomment;
	private BigDecimal t_out_of_office;
	private String t_public_holidays;
	private String t_working_hours;
	private String t_days_off;
	private BigDecimal t_password_initial;
	private BigDecimal t_status;
	private String t_last_remote_host;
	private String t_last_login_date;
	private String t_user_last_update;
	private String t_password_last_update;
	private String t_creation_date;
	private String t_password;
	private String t_email;
	private String t_description;
	private String t_login;
	private BigDecimal t_login_failures;
	private Date date_ope;
	private Date date_insert;
	private String id_traitement;
	
	public FmfUsersBean() {
		
	}

	public FmfUsersBean(BigDecimal t_id, BigDecimal business_unit_id, String t_lockcomment, BigDecimal t_out_of_office,
			String t_public_holidays, String t_working_hours, String t_days_off, BigDecimal t_password_initial,
			BigDecimal t_status, String t_last_remote_host, String t_last_login_date, String t_user_last_update,
			String t_password_last_update, String t_creation_date, String t_password, String t_email,
			String t_description, String t_login, BigDecimal t_login_failures, Date date_ope, Date date_insert,
			String id_traitement) {
		super();
		this.t_id = t_id;
		this.business_unit_id = business_unit_id;
		this.t_lockcomment = t_lockcomment;
		this.t_out_of_office = t_out_of_office;
		this.t_public_holidays = t_public_holidays;
		this.t_working_hours = t_working_hours;
		this.t_days_off = t_days_off;
		this.t_password_initial = t_password_initial;
		this.t_status = t_status;
		this.t_last_remote_host = t_last_remote_host;
		this.t_last_login_date = t_last_login_date;
		this.t_user_last_update = t_user_last_update;
		this.t_password_last_update = t_password_last_update;
		this.t_creation_date = t_creation_date;
		this.t_password = t_password;
		this.t_email = t_email;
		this.t_description = t_description;
		this.t_login = t_login;
		this.t_login_failures = t_login_failures;
		this.date_ope = date_ope;
		this.date_insert = date_insert;
		this.id_traitement = id_traitement;
	}





	public BigDecimal getT_id() {
		return t_id;
	}


	public void setT_id(BigDecimal t_id) {
		this.t_id = t_id;
	}


	public BigDecimal getBusiness_unit_id() {
		return business_unit_id;
	}


	public void setBusiness_unit_id(BigDecimal business_unit_id) {
		this.business_unit_id = business_unit_id;
	}


	public String getT_lockcomment() {
		return t_lockcomment;
	}


	public void setT_lockcomment(String t_lockcomment) {
		this.t_lockcomment = t_lockcomment;
	}


	public BigDecimal getT_out_of_office() {
		return t_out_of_office;
	}


	public void setT_out_of_office(BigDecimal t_out_of_office) {
		this.t_out_of_office = t_out_of_office;
	}


	public String getT_public_holidays() {
		return t_public_holidays;
	}


	public void setT_public_holidays(String t_public_holidays) {
		this.t_public_holidays = t_public_holidays;
	}


	public String getT_working_hours() {
		return t_working_hours;
	}


	public void setT_working_hours(String t_working_hours) {
		this.t_working_hours = t_working_hours;
	}


	public String getT_days_off() {
		return t_days_off;
	}


	public void setT_days_off(String t_days_off) {
		this.t_days_off = t_days_off;
	}


	public BigDecimal getT_password_initial() {
		return t_password_initial;
	}


	public void setT_password_initial(BigDecimal t_password_initial) {
		this.t_password_initial = t_password_initial;
	}


	public BigDecimal getT_status() {
		return t_status;
	}


	public void setT_status(BigDecimal t_status) {
		this.t_status = t_status;
	}


	public String getT_last_remote_host() {
		return t_last_remote_host;
	}


	public void setT_last_remote_host(String t_last_remote_host) {
		this.t_last_remote_host = t_last_remote_host;
	}


	public String getT_last_login_date() {
		return t_last_login_date;
	}


	public void setT_last_login_date(String t_last_login_date) {
		this.t_last_login_date = t_last_login_date;
	}


	public String getT_user_last_update() {
		return t_user_last_update;
	}


	public void setT_user_last_update(String t_user_last_update) {
		this.t_user_last_update = t_user_last_update;
	}


	public String getT_password_last_update() {
		return t_password_last_update;
	}


	public void setT_password_last_update(String t_password_last_update) {
		this.t_password_last_update = t_password_last_update;
	}


	public String getT_creation_date() {
		return t_creation_date;
	}


	public void setT_creation_date(String t_creation_date) {
		this.t_creation_date = t_creation_date;
	}


	public String getT_password() {
		return t_password;
	}


	public void setT_password(String t_password) {
		this.t_password = t_password;
	}


	public String getT_email() {
		return t_email;
	}


	public void setT_email(String t_email) {
		this.t_email = t_email;
	}


	public String getT_description() {
		return t_description;
	}


	public void setT_description(String t_description) {
		this.t_description = t_description;
	}


	public String getT_login() {
		return t_login;
	}


	public void setT_login(String t_login) {
		this.t_login = t_login;
	}


	public BigDecimal getT_login_failures() {
		return t_login_failures;
	}


	public void setT_login_failures(BigDecimal t_login_failures) {
		this.t_login_failures = t_login_failures;
	}


	public Date getDate_ope() {
		return date_ope;
	}


	public void setDate_ope(Date date_ope) {
		this.date_ope = date_ope;
	}


	public String getId_traitement() {
		return id_traitement;
	}


	public void setId_traitement(String id_traitement) {
		this.id_traitement = id_traitement;
	}


	public Date getDate_insert() {
		return date_insert;
	}


	public void setDate_insert(Date date_insert) {
		this.date_insert = date_insert;
	}
	
	
	

}
