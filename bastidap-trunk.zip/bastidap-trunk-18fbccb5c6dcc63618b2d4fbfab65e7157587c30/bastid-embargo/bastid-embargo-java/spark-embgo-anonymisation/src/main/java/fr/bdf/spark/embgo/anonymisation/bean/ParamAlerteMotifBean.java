package fr.bdf.spark.embgo.anonymisation.bean;

import java.io.Serializable;
import java.sql.Date;

public class ParamAlerteMotifBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2132099302771664209L;
	
	private int ordre;
	private Date date_decision_deb;
	private Date date_decision_fin;
	private String decision_finale;
	private String motif_decision;
	private Date date_insert;
	private String id_traitement;
	
	
	public ParamAlerteMotifBean() {
		super();
	}




	public ParamAlerteMotifBean(int ordre, Date date_decision_deb, Date date_decision_fin, String decision_finale,
			String motif_decision, Date date_insert, String id_traitement) {
		super();
		this.ordre = ordre;
		this.date_decision_deb = date_decision_deb;
		this.date_decision_fin = date_decision_fin;
		this.decision_finale = decision_finale;
		this.motif_decision = motif_decision;
		this.date_insert = date_insert;
		this.id_traitement = id_traitement;
	}




	public int getOrdre() {
		return ordre;
	}


	public void setOrdre(int ordre) {
		this.ordre = ordre;
	}


	public Date getDate_decision_deb() {
		return date_decision_deb;
	}


	public void setDate_decision_deb(Date date_decision_deb) {
		this.date_decision_deb = date_decision_deb;
	}


	public Date getDate_decision_fin() {
		return date_decision_fin;
	}


	public void setDate_decision_fin(Date date_decision_fin) {
		this.date_decision_fin = date_decision_fin;
	}


	public String getDecision_finale() {
		return decision_finale;
	}


	public void setDecision_finale(String decision_finale) {
		this.decision_finale = decision_finale;
	}


	public String getMotif_decision() {
		return motif_decision;
	}


	public void setMotif_decision(String motif_decision) {
		this.motif_decision = motif_decision;
	}


	public String getId_traitement() {
		return id_traitement;
	}


	public void setId_traitement(String id_traitement) {
		this.id_traitement = id_traitement;
	}


	public Date getDate_insert() {
		return date_insert;
	}


	public void setDate_insert(Date date_insert) {
		this.date_insert = date_insert;
	}

	
	
	
}
