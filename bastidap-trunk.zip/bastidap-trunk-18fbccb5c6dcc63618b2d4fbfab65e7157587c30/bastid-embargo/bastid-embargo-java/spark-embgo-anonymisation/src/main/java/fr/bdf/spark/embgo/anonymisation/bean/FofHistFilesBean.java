package fr.bdf.spark.embgo.anonymisation.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;

public class FofHistFilesBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3508678223152867240L;

	private String id;
	private String dec_date;
	private BigDecimal dec_id;
	private String operator;
	private String comments;
	private BigDecimal content_size;
	private byte[] content;
	private String file_name;
	private Date date_ope;
	private Date date_insert;
	private String id_traitement;
	
	
	public FofHistFilesBean() {
		super();
	}



	public FofHistFilesBean(String id, String dec_date, BigDecimal dec_id, String operator, String comments,
			BigDecimal content_size, byte[] content, String file_name, Date date_ope, Date date_insert,
			String id_traitement) {
		super();
		this.id = id;
		this.dec_date = dec_date;
		this.dec_id = dec_id;
		this.operator = operator;
		this.comments = comments;
		this.content_size = content_size;
		this.content = content;
		this.file_name = file_name;
		this.date_ope = date_ope;
		this.date_insert = date_insert;
		this.id_traitement = id_traitement;
	}



	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getDec_date() {
		return dec_date;
	}


	public void setDec_date(String dec_date) {
		this.dec_date = dec_date;
	}


	public BigDecimal getDec_id() {
		return dec_id;
	}


	public void setDec_id(BigDecimal dec_id) {
		this.dec_id = dec_id;
	}


	public String getOperator() {
		return operator;
	}


	public void setOperator(String operator) {
		this.operator = operator;
	}


	public String getComments() {
		return comments;
	}


	public void setComments(String comments) {
		this.comments = comments;
	}


	public BigDecimal getContent_size() {
		return content_size;
	}


	public void setContent_size(BigDecimal content_size) {
		this.content_size = content_size;
	}


	public byte[] getContent() {
		return content;
	}


	public void setContent(byte[] content) {
		this.content = content;
	}


	public String getFile_name() {
		return file_name;
	}


	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}


	public Date getDate_ope() {
		return date_ope;
	}


	public void setDate_ope(Date date_ope) {
		this.date_ope = date_ope;
	}


	public String getId_traitement() {
		return id_traitement;
	}


	public void setId_traitement(String id_traitement) {
		this.id_traitement = id_traitement;
	}



	public Date getDate_insert() {
		return date_insert;
	}



	public void setDate_insert(Date date_insert) {
		this.date_insert = date_insert;
	}
}
