package fr.bdf.spark.embgo.anonymisation.factory;

import java.io.Serializable;

import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Row;
import fr.bdf.spark.embgo.anonymisation.bean.ParamAlerteMotifBean;
import fr.bdf.spark.embgo.anonymisation.util.AnonymizerUtil;

public class ParamAlerteMotifFactory extends AbstractFactory implements Function<Row, ParamAlerteMotifBean>, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2751482134381631244L;

	@Override
	public ParamAlerteMotifBean call(Row data) throws Exception {
		final ParamAlerteMotifBean bean = new ParamAlerteMotifBean();
		final AnonymizerUtil anonymizer = new AnonymizerUtil();
		
		bean.setOrdre(getInteger(data.getAs("ordre")));
		bean.setDate_decision_deb(getDateSql(data.getAs("date_decision_deb")));	
		bean.setDate_decision_fin(getDateSql(data.getAs("date_decision_fin")));
		bean.setDecision_finale(getString(data.getAs("decision_finale")));
		bean.setMotif_decision(anonymizer.anonymizeString(getString(data.getAs("motif_decision"))));
		bean.setDate_insert(getDateSql(data.getAs("date_insert")));
		bean.setId_traitement(getString(data.getAs("id_traitement")));
		return bean;
	}
	
}

