package fr.bdf.spark.embgo.anonymisation.constant;

import java.io.IOException;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import fr.bdf.embgo.common.EmbgoCommonResource;

public class AnonymisationConstant extends EmbgoCommonResource implements
		Serializable {

	private static final long serialVersionUID = 4574633708829117378L;

	/** TABLES */
	// table list
	public static final List<String> TABLE_TO_ANONYMIZE = Arrays.asList(
			"fofa_hist_message", "fofa_hist_intervention", "fofa_hist_action",
			"fof_hist_files", "fmf_users", "param_alerte_motif");
	public static final String TABLE_FOFA_HIST_MESSAGE = "fofa_hist_message";
	public static final String TABLE_FOFA_HIST_INTERVENTION = "fofa_hist_intervention";
	public static final String TABLE_FOFA_HIST_ACTION = "fofa_hist_action";
	public static final String TABLE_FOF_HIST_FILES = "fof_hist_files";
	public static final String TABLE_FMF_USERS = "fmf_users";
	public static final String TABLE_PARAM_ALERTE_MOTIF = "param_alerte_motif";

	/** Constant for PACS003 */
	public static final String TYPE_PACS003 = "PACS.003";

	/** Constant for PACS008 */
	public static final String TYPE_PACS008 = "PACS.008";

	public AnonymisationConstant() throws IOException {
		super();
	}
}
