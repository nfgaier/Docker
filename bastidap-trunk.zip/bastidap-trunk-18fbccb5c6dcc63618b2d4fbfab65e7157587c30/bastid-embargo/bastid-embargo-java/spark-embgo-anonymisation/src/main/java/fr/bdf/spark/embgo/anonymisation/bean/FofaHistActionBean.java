package fr.bdf.spark.embgo.anonymisation.bean;

import java.io.Serializable;
import java.sql.Date;

public class FofaHistActionBean implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6748126963536460580L;
	
	private String t_system_id;
	private String t_comments;
	private String t_operator_desc;
	private String t_decision_type;
	private String t_decision_date;
	private Date date_ope;
	private Date date_insert;
	private String id_traitement;
	
	
	public FofaHistActionBean() {
		super();
	}

	public FofaHistActionBean(String t_system_id, String t_comments, String t_operator_desc, String t_decision_type,
			String t_decision_date, Date date_ope, Date date_insert, String id_traitement) {
		super();
		this.t_system_id = t_system_id;
		this.t_comments = t_comments;
		this.t_operator_desc = t_operator_desc;
		this.t_decision_type = t_decision_type;
		this.t_decision_date = t_decision_date;
		this.date_ope = date_ope;
		this.date_insert = date_insert;
		this.id_traitement = id_traitement;
	}

	public String getT_system_id() {
		return t_system_id;
	}

	public void setT_system_id(String t_system_id) {
		this.t_system_id = t_system_id;
	}

	public String getT_comments() {
		return t_comments;
	}

	public void setT_comments(String t_comments) {
		this.t_comments = t_comments;
	}

	public String getT_operator_desc() {
		return t_operator_desc;
	}

	public void setT_operator_desc(String t_operator_desc) {
		this.t_operator_desc = t_operator_desc;
	}

	public String getT_decision_type() {
		return t_decision_type;
	}

	public void setT_decision_type(String t_decision_type) {
		this.t_decision_type = t_decision_type;
	}

	public String getT_decision_date() {
		return t_decision_date;
	}

	public void setT_decision_date(String t_decision_date) {
		this.t_decision_date = t_decision_date;
	}

	public String getId_traitement() {
		return id_traitement;
	}

	public void setId_traitement(String id_traitement) {
		this.id_traitement = id_traitement;
	}

	public Date getDate_ope() {
		return date_ope;
	}

	public void setDate_ope(Date date_ope) {
		this.date_ope = date_ope;
	}

	public Date getDate_insert() {
		return date_insert;
	}

	public void setDate_insert(Date date_insert) {
		this.date_insert = date_insert;
	}
}
