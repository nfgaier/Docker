package fr.bdf.spark.embgo.anonymisation.data;

import java.io.Serializable;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class PutData implements Serializable {

	private static final long serialVersionUID = -2787490678942479642L;

	private SparkSession sparkSession;

	/**
	 * @param sqlContext
	 */
	public PutData(SparkSession sparkSession) {
		super();
		this.sparkSession = sparkSession;
	}

	public SparkSession getSparkSession() {
		return sparkSession;
	}

	public void setSparkSession(SparkSession sparkSession) {
		this.sparkSession = sparkSession;
	}

	/**
	 * Writes DataFrame to path and creates a partition in the target table
	 * 
	 * @param layerPath
	 *            :
	 * @param data
	 * @param idTraitement
	 */
	public void writeData(String layerPath, String hiveBaseName,
			String tableName, Dataset<Row> data, String idTraitement) {

		// LOGS FOR TESTING
		System.out.println("Id_traitement before writing : " + idTraitement);
		System.out.println("Path to write " + layerPath + tableName);
		// System.out.println("Data to write : ");
		// data.show();

		// write to path
		data.write().partitionBy("id_traitement").format("orc").mode("append")
				.save(layerPath + tableName);
		// add partition
		String alterTable = "ALTER TABLE " + hiveBaseName + "." + tableName
				+ " ADD IF NOT EXISTS PARTITION (id_traitement='"
				+ idTraitement + "') location '" + layerPath + tableName
				+ "/id_traitement=" + idTraitement + "'";
		sparkSession.sql(alterTable);

		System.out.println("Alter table : " + alterTable);

	}

}
