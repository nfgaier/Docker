package fr.bdf.spark.embgo.anonymisation.factory;

import java.io.Serializable;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Row;
import fr.bdf.spark.embgo.anonymisation.bean.FmfUsersBean;
import fr.bdf.spark.embgo.anonymisation.util.AnonymizerUtil;

public class FmfUsersFactory extends AbstractFactory implements Function<Row, FmfUsersBean>, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3698903849130400173L;

    
	
	@Override
	public FmfUsersBean call(Row data) throws Exception {
		final AnonymizerUtil anonymizer = new AnonymizerUtil();
		final FmfUsersBean bean = new FmfUsersBean();
		
		bean.setT_id(anonymizer.anonymizeBigDecimal());
		
		bean.setBusiness_unit_id(getBigDecimal(data.getAs("business_unit_id"), 0));
		bean.setT_lockcomment(getString(data.getAs("t_lockcomment")));
		bean.setT_out_of_office(getBigDecimal(data.getAs("t_out_of_office"), 0));
		bean.setT_public_holidays(getString(data.getAs("t_public_holidays")));
		bean.setT_working_hours(getString(data.getAs("t_working_hours")));
		bean.setT_days_off(getString(data.getAs("t_days_off")));
		bean.setT_password_initial(getBigDecimal(data.getAs("t_password_initial"), 0));
		bean.setT_status(getBigDecimal(data.getAs("t_status"), 0));
		bean.setT_last_remote_host(anonymizer.anonymizeString(getString(data.getAs("t_last_remote_host"))));
		bean.setT_last_login_date(getString(data.getAs("t_last_login_date")));
		bean.setT_user_last_update(getString(data.getAs("t_user_last_update")));
		bean.setT_password_last_update(getString(data.getAs("t_password_last_update")));
		bean.setT_creation_date(anonymizer.anonymizeString(getString(data.getAs("t_creation_date"))));
		bean.setT_password(anonymizer.anonymizeString(getString(data.getAs("t_password"))));
		bean.setT_email(anonymizer.anonymizeString(getString(data.getAs("t_email"))));
		bean.setT_description(anonymizer.anonymizeString(getString(data.getAs("t_description"))));
		bean.setT_login(anonymizer.anonymizeString(getString(data.getAs("t_login"))));
		bean.setT_login_failures(getBigDecimal(data.getAs("t_login_failures"), 0));
		
		bean.setDate_ope(getDateSql(data.getAs("date_ope")));
		bean.setDate_insert(getDateSql(data.getAs("date_insert")));
		
		bean.setId_traitement(getString(data.getAs("id_traitement")));

		return bean;
	}

}