package fr.bdf.spark.embgo.anonymisation.factory;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Row;
import fr.bdf.spark.embgo.anonymisation.bean.FofaHistMessageBean;
import fr.bdf.spark.embgo.anonymisation.constant.AnonymisationConstant;
import fr.bdf.spark.embgo.anonymisation.util.AnonymizerUtil;

public class FofaHistMessageFactory extends AbstractFactory implements Function<Row, FofaHistMessageBean>, Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -3898823239656733697L;

    @Override
    public FofaHistMessageBean call(Row data) throws Exception {
    	final AnonymizerUtil anonymizer = new AnonymizerUtil();
        final FofaHistMessageBean fhmBean = new FofaHistMessageBean();
        
        fhmBean.setT_system_id(getString(data.getAs("t_system_id")));
        fhmBean.setBusiness_unit_id(getBigDecimal(data.getAs("business_unit_id"), 0));
        fhmBean.setSaausrgrp(getString(data.getAs("saausrgrp")));
        fhmBean.setT_normamount(getBigDecimal(data.getAs("t_normamount"), 0));
        fhmBean.setT_app_deadline(getTimestamp(data.getAs("t_app_deadline")));
        fhmBean.setT_app_priority(getBigDecimal(data.getAs("t_app_priority"), 0));
        fhmBean.setT_alignment(getString(data.getAs("t_alignment")));
        fhmBean.setT_confidentiality(getBigDecimal(data.getAs("t_confidentiality"), 0));
        fhmBean.setT_priority(getBigDecimal(data.getAs("t_priority"), 0));
        fhmBean.setT_type(getString(data.getAs("t_type")));
        fhmBean.setT_transaction(getString(data.getAs("t_transaction")));
        fhmBean.setT_toappli(getString(data.getAs("t_toappli")));
        fhmBean.setT_sender(anonymizer.anonymizeString(getString(data.getAs("t_sender"))));
        fhmBean.setT_related_ref(getString(data.getAs("t_related_ref")));
        fhmBean.setT_receiver(anonymizer.anonymizeString(getString(data.getAs("t_receiver"))));
        fhmBean.setT_pairing_id(getString(data.getAs("t_pairing_id")));
        fhmBean.setT_nonblocking(getBigDecimal(data.getAs("t_nonblocking"), 0));
        fhmBean.setT_nature(getString(data.getAs("t_nature")));
        fhmBean.setT_message_id(getString(data.getAs("t_message_id")));
        fhmBean.setT_i_o(getString(data.getAs("t_i_o")));
        fhmBean.setT_gateway(getString(data.getAs("t_gateway")));
        fhmBean.setT_fromappli(getString(data.getAs("t_fromappli")));
        fhmBean.setT_filtered(getString(data.getAs("t_filtered")));
        fhmBean.setT_entity(getString(data.getAs("t_entity")));
        fhmBean.setT_lastoperator(anonymizer.anonymizeString(getString(data.getAs("t_lastoperator"))));
        fhmBean.setT_decision_type(getString(data.getAs("t_decision_type")));
        fhmBean.setT_date_value(getString(data.getAs("t_date_value")));
        fhmBean.setT_currency(getString(data.getAs("t_currency")));
        fhmBean.setT_created(getString(data.getAs("t_created")));
        fhmBean.setT_copy_service(getString(data.getAs("t_copy_service")));
        fhmBean.setT_completed(getString(data.getAs("t_completed")));
        fhmBean.setT_bunit(getString(data.getAs("t_bunit")));
        fhmBean.setT_blocking(getBigDecimal(data.getAs("t_blocking"), 0));
        fhmBean.setT_amount_float(getFloat(data.getAs("t_amount_float")));
        fhmBean.setT_amount(getString(data.getAs("t_amount")));
        fhmBean.setDate_ope(getDateSql(data.getAs("date_ope")));
        fhmBean.setDate_insert(getDateSql(data.getAs("date_insert")));
        fhmBean.setId_traitement(getString(data.getAs("id_traitement")));
        
        if(StringUtils.isNotBlank(fhmBean.getT_type()) && 
        		(AnonymisationConstant.TYPE_PACS003.equals(fhmBean.getT_type()) || AnonymisationConstant.TYPE_PACS008.equals(fhmBean.getT_type()))) {
        	// Security to avoid XML message from embargo recette
        	if(StringUtils.isNotBlank(fhmBean.getT_message()) && !fhmBean.getT_message().contains("<MsgId>")) {
        		fhmBean.setT_message(anonymizer.parseAndAnonymizeSEPA(getString(data.getAs("t_message"))));
        	}
        	
        } else {
        	fhmBean.setT_message(anonymizer.parseAndAnonymizeSWIFT(getString(data.getAs("t_message"))));
        }
        
        return fhmBean;
    }

}
