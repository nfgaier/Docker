package fr.bdf.spark.embgo.anonymisation.factory;

import java.io.Serializable;

import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Row;
import fr.bdf.spark.embgo.anonymisation.bean.FofaHistInterventionBean;
import fr.bdf.spark.embgo.anonymisation.util.AnonymizerUtil;

public class FofaHistInterventionFactory extends AbstractFactory implements Function<Row, FofaHistInterventionBean>, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3898718979896512692L;

	
	@Override
	public FofaHistInterventionBean call(Row data) throws Exception {
		final AnonymizerUtil anonymizer = new AnonymizerUtil();
		final FofaHistInterventionBean bean = new FofaHistInterventionBean();
		
		bean.setT_system_id(getString(data.getAs("t_system_id")));
		bean.setT_intervention(anonymizer.parseAndAnonymizeTIntervention(getString(data.getAs("t_intervention"))));
		bean.setDate_ope(getDateSql(data.getAs("date_ope")));
		bean.setDate_insert(getDateSql(data.getAs("date_insert")));
		bean.setId_traitement(getString(data.getAs("id_traitement")));
		
		return bean;
	}

}