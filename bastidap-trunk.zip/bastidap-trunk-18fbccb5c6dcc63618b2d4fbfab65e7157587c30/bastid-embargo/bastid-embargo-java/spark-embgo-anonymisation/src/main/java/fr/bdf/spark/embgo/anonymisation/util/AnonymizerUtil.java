package fr.bdf.spark.embgo.anonymisation.util;

import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

public class AnonymizerUtil implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4686347856521225862L;

	/**
	 * Method to get a random BigDecimal for anonymisation.
	 * 
	 */
	public BigDecimal anonymizeBigDecimal() {
		Random rand = new Random();
		Integer random = rand.nextInt();
		if (random < 0) {
			random *= -1;
		}
		
		BigInteger randBigInt = BigInteger.valueOf(random.intValue());
		return new BigDecimal(randBigInt, 0);
	}

	
	
	public String anonymizeString(String strInput) throws NoSuchAlgorithmException {
		if (StringUtils.isNotBlank(strInput)) {
			MessageDigest digest = MessageDigest.getInstance("MD5");
			digest.update(strInput.getBytes());
			byte[] datas = digest.digest();

			StringBuffer buffer = new StringBuffer();
			for (int i = 0; i < datas.length; i++) {
				buffer.append(Integer.toString((datas[i] & 0xff) + 0x100, 16).substring(1));
			}
			return buffer.toString();
		}
		return strInput;
	}
	
	public String parseAndAnonymizeSEPA(String strInput) throws Exception {
		if (StringUtils.isNotBlank(strInput)) {
			final List<String> regexList = Arrays.asList(
					"(?<=\\[A_INDRAG       \\])(.*?)[^\\r\\n\\[]+", // 7 spaces
					"(?<=\\[A_INGRAG       \\])(.*?)[^\\r\\n\\[]+",
					"(?<=\\[A_INDRAGAC     \\])(.*?)[^\\r\\n\\[]+",
					"(?<=\\[A_INGRAGAC     \\])(.*?)[^\\r\\n\\[]+",
					"(?<=\\[A_THRGRAG      \\])(.*?)[^\\r\\n\\[]+",
					"(?<=\\[A_THRGRAGAC    \\])(.*?)[^\\r\\n\\[]+",
					"(?s)(?<=\\[B_CDTR         \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?s)(?<=\\[B_DBTR         \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_CDTRAC       \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_DBTRAC       \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_CDTRAG       \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_DBTRAG       \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_CDTRAGAC     \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_DBTRAGAC     \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_INTAG1       \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_INTAGAC1     \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_INTAG1AC     \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?s)(?<=\\[B_RELREMIT     \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?s)(?<=\\[B_REMITINF     \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_INSTCDAG     \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_RGLRPTG      \\])(.*?)(?=[\\r\\n|\\n]\\[)"
			);
			final String result = anonymizeFromRegexList(regexList, strInput);
			return result;
		}
		return strInput;
	}
	
	public String parseAndAnonymizeSWIFT(String strInput) throws IOException, NoSuchAlgorithmException {
		if (StringUtils.isNotBlank(strInput)) {
			final List<String> lines = Arrays.asList(strInput.split("\\r\\n|\\n"));
			final List<String> newLines = new ArrayList<String>();
			for (String line : lines) {
				if(!(line.startsWith(":SND:") || line.startsWith(":RCV:") || line.startsWith(":20:") || line.startsWith(":23B:") 
								|| line.startsWith(":32A:") || line.startsWith(":33B:") || line.startsWith(":36:") || line.startsWith(":71A:")
								|| line.startsWith(":71B:") || line.startsWith(":71F:") || line.startsWith(":71G:"))) {
					if(line.startsWith(":")) {
						int substringLastIndex = 0;
						if(line.length() > 4) {
							if(":".equals(String.valueOf(line.charAt(3)))) {
								substringLastIndex = 4;
							} else {
								substringLastIndex = 5;
							}
						}
						newLines.add(line.substring(0, substringLastIndex) + anonymizeString(line.substring(substringLastIndex)));
						
					} else if(line.startsWith("1/") || line.startsWith("2/") || line.startsWith("3/")) {
						newLines.add(line.substring(0, 2) + anonymizeString(line.substring(2)));
					} else {
						newLines.add(anonymizeString(line));
					}
				} else { 
					newLines.add(line);
				}
			}
			return StringUtils.join(newLines, "\n");
		}
		return strInput;
	}
	
	public String parseAndAnonymizeTIntervention(String strInput) throws IOException, NoSuchAlgorithmException {
		if (StringUtils.isNotBlank(strInput)) {
			final List<String> regexList = Arrays.asList(
					"(?<=MATCHINGTEXT:)(.*?)[^\\r\\n]+",
					"(?<=NAME:)(.*?)[^\\r\\n]+",
					"(?<=ADDRESS:)(.*?)[^\\r\\n]+",
					"(?<=CITY:)(.*?)[^\\r\\n]+",
					"(?<=COUNTRY:)(.*?)[^\\r\\n]+",
					"(?<=STATE:)(.*?)[^\\r\\n]+",
					"(?s)(?<=ORIGIN:[\\s*][\\r\\n|\\n+])(.*?)(?=[\\r\\n|\n]DESIGNATION:)",
					"(?s)(?<=PASSPORT:[\\s*][\\r\\n|\\n+])(.*?)(?=[\\r\\n|\n]BIC CODES:)",
					"(?s)(?<=BIC CODES:[\\s*][\\r\\n|\\n+])(.*?)(?=[\\r\\n|\n]NATID:)",
					"(?s)(?<=NATID:[\\s*][\\r\\n|\\n+])(.*?)(?=[\\r\\n|\n]PLACE OF BIRTH:)",
					"(?s)(?<=PLACE OF BIRTH:[\\s*][\\r\\n|\\n+])(.*?)(?=[\\r\\n|\n]DATE OF BIRTH:)",
					"(?s)(?<=DATE OF BIRTH:[\\s*][\\r\\n|\\n+])(.*?)(?=[\\r\\n|\n]NATIONALITY:)",
					"(?s)(?<=NATIONALITY:[\\s*][\\r\\n|\\n+])(.*?)(?=[\\r\\n|\n]ADDITIONAL INFOS:)",
					"(?s)(?<=ADDITIONAL INFOS:[\\s*][\\r\\n|\\n+])(.*?)(?=[\\r\\n|\n]FML TYPE:)",
					"(?s)(?<=Synonyms:)(.*?)(?=[\\r\\n|\\n][A-Z]*:)"
			);
			final String result = anonymizeFromRegexList(regexList, strInput);
			return result;
		}
		return strInput;
	}

	
	public String anonymizeFromRegexList(List<String> regexList, String strInput) throws NoSuchAlgorithmException {
		String regex = StringUtils.join(regexList, "|");
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(strInput);

		StringBuffer result = new StringBuffer();
		String text = new String();
		try {
			while (matcher.find()) {
				text = anonymizeString(matcher.group());
				matcher.appendReplacement(result, text);
			}
		} catch (Exception e) {
			System.out.println("Error occured with regex : " + regex +", text : "+text+"\n And matcher :"+matcher.group());
		}
 		matcher.appendTail(result);
		return result.toString();
	}

}
