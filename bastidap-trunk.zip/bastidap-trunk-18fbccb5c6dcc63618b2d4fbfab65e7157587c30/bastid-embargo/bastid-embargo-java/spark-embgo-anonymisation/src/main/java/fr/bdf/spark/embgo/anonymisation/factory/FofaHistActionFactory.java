package fr.bdf.spark.embgo.anonymisation.factory;

import java.io.Serializable;

import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Row;
import fr.bdf.spark.embgo.anonymisation.bean.FofaHistActionBean;
import fr.bdf.spark.embgo.anonymisation.util.AnonymizerUtil;

public class FofaHistActionFactory extends AbstractFactory implements Function<Row, FofaHistActionBean>, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5648396405176074793L;
	
	

	@Override
	public FofaHistActionBean call(Row data) throws Exception {
		final FofaHistActionBean bean = new FofaHistActionBean();
		final AnonymizerUtil anonymizer = new AnonymizerUtil();
		
		bean.setT_system_id(getString(data.getAs("t_system_id")));
		bean.setT_comments(anonymizer.anonymizeString(getString(data.getAs("t_comments"))));
		bean.setT_operator_desc(anonymizer.anonymizeString(getString(data.getAs("t_operator_desc"))));
		bean.setT_decision_type(getString(data.getAs("t_decision_type")));
		bean.setT_decision_date(getString(data.getAs("t_decision_date")));
		bean.setDate_ope(getDateSql(data.getAs("date_ope")));
		bean.setDate_insert(getDateSql(data.getAs("date_insert")));
		bean.setId_traitement(getString(data.getAs("id_traitement")));
		
		return bean;
	}

}
