package fr.bdf.spark.embgo.anonymisation.bean;

import java.io.Serializable;
import java.sql.Date;

public class FofaHistInterventionBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6731600150346333954L;
	
	
	private String t_system_id;
	private String t_intervention;
	private java.sql.Date date_ope;
	private java.sql.Date date_insert;
	private String id_traitement;
	
	public FofaHistInterventionBean() {
		super();
	}



	public FofaHistInterventionBean(String t_system_id, String t_intervention, Date date_ope, Date date_insert,
			String id_traitement) {
		super();
		this.t_system_id = t_system_id;
		this.t_intervention = t_intervention;
		this.date_ope = date_ope;
		this.date_insert = date_insert;
		this.id_traitement = id_traitement;
	}



	public String getT_system_id() {
		return t_system_id;
	}

	public void setT_system_id(String t_system_id) {
		this.t_system_id = t_system_id;
	}

	public String getT_intervention() {
		return t_intervention;
	}

	public void setT_intervention(String t_intervention) {
		this.t_intervention = t_intervention;
	}

	public java.sql.Date getDate_ope() {
		return date_ope;
	}

	public void setDate_ope(java.sql.Date date_ope) {
		this.date_ope = date_ope;
	}

	public String getId_traitement() {
		return id_traitement;
	}

	public void setId_traitement(String id_traitement) {
		this.id_traitement = id_traitement;
	}

	public java.sql.Date getDate_insert() {
		return date_insert;
	}

	public void setDate_insert(java.sql.Date date_insert) {
		this.date_insert = date_insert;
	}
	
	
	

}
