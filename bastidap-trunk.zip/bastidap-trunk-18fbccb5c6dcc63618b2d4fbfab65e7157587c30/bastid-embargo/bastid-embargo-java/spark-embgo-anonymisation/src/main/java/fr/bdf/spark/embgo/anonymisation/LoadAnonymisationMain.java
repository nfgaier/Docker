package fr.bdf.spark.embgo.anonymisation;

import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import fr.bdf.spark.embgo.anonymisation.bean.FmfUsersBean;
import fr.bdf.spark.embgo.anonymisation.bean.FofHistFilesBean;
import fr.bdf.spark.embgo.anonymisation.bean.FofaHistActionBean;
import fr.bdf.spark.embgo.anonymisation.bean.FofaHistInterventionBean;
import fr.bdf.spark.embgo.anonymisation.bean.FofaHistMessageBean;
import fr.bdf.spark.embgo.anonymisation.bean.ParamAlerteMotifBean;
import fr.bdf.spark.embgo.anonymisation.constant.AnonymisationConstant;
import fr.bdf.spark.embgo.anonymisation.data.GetData;
import fr.bdf.spark.embgo.anonymisation.data.PutData;
import fr.bdf.spark.embgo.anonymisation.factory.FmfUsersFactory;
import fr.bdf.spark.embgo.anonymisation.factory.FofHistFilesFactory;
import fr.bdf.spark.embgo.anonymisation.factory.FofaHistActionFactory;
import fr.bdf.spark.embgo.anonymisation.factory.FofaHistInterventionFactory;
import fr.bdf.spark.embgo.anonymisation.factory.FofaHistMessageFactory;
import fr.bdf.spark.embgo.anonymisation.factory.ParamAlerteMotifFactory;

public class LoadAnonymisationMain implements Serializable {

	private static final long serialVersionUID = -1168012702104516656L;

	public static String getTime() {
		return "[" + new SimpleDateFormat("HH:mm:ss").format(new Date())
				+ "] - ";
	}

	public static void main(String[] args) {

		/** Control parameters */
		// control number of parameters
		if (args.length != 2) {
			System.out.println("INFO:"
					+ LoadAnonymisationMain.getTime()
					+ " Wrong arguments. Usage: "
					+ new java.io.File(LoadAnonymisationMain.class
							.getProtectionDomain().getCodeSource()
							.getLocation().getPath()).getName()
					+ " <environment> <table> <idTraitement>");
			System.exit(0);
		}

		// Control parameter 1, table name
		if (!AnonymisationConstant.TABLE_TO_ANONYMIZE.contains(args[1]
				.toLowerCase())) {
			System.out.println("INFO:" + LoadAnonymisationMain.getTime()
					+ " Wrong table name , table must be in : ");
			System.out.println(StringUtils.join(
					AnonymisationConstant.TABLE_TO_ANONYMIZE, ", "));
			System.exit(0);
		}

		// Initialize parameters and DF
		String tableName = args[0].toLowerCase();
		String idTraitement = args[1];

		SparkSession sparkSession = SparkSession.builder()
				.config(new SparkConf())
				.config("spark.sql.warehouse.dir", "/apps/hive/warehouse")
				.config("spark.sql.hive.convertMetastoreOrc", "false")// https://issues.apache.org/jira/browse/SPARK-12998
				.enableHiveSupport().getOrCreate();

		AnonymisationConstant anonymisationConstant = null;
		try {
			anonymisationConstant = new AnonymisationConstant();
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}

		// Build Dataframes for each table type
		// Anonymize fields in factories
		Dataset<Row> dfToAnonymized = null;
		JavaRDD<?> rdd = null;
		Dataset<Row> dfAnonym = null;
		Dataset<Row> orderedDfAnonym = null;
		GetData getData = new GetData(sparkSession,
				anonymisationConstant.getLandingLayerHiveBase());

		switch (tableName) {
		case AnonymisationConstant.TABLE_FOFA_HIST_MESSAGE:
			dfToAnonymized = getData.getFOFAHistMessageData(idTraitement)
					.persist();
			rdd = dfToAnonymized.toJavaRDD().map(new FofaHistMessageFactory());
			dfAnonym = sparkSession.createDataFrame(rdd,
					FofaHistMessageBean.class);
			orderedDfAnonym = getData
					.getOrderedDfAnonymFofaHistMessage(dfAnonym);
			break;
		case AnonymisationConstant.TABLE_FOFA_HIST_INTERVENTION:
			dfToAnonymized = getData.getFOFAHistInterventionData(idTraitement)
					.persist();
			rdd = dfToAnonymized.toJavaRDD().map(
					new FofaHistInterventionFactory());
			dfAnonym = sparkSession.createDataFrame(rdd,
					FofaHistInterventionBean.class);
			orderedDfAnonym = getData
					.getOrderedDfAnonymFofaHistIntervention(dfAnonym);
			break;
		case AnonymisationConstant.TABLE_FOFA_HIST_ACTION:
			dfToAnonymized = getData.getFOFAHistActionData(idTraitement)
					.persist();
			rdd = dfToAnonymized.toJavaRDD().map(new FofaHistActionFactory());
			dfAnonym = sparkSession.createDataFrame(rdd,
					FofaHistActionBean.class);
			orderedDfAnonym = getData
					.getOrderedDfAnonymFofaHistAction(dfAnonym);
			break;
		case AnonymisationConstant.TABLE_FOF_HIST_FILES:
			dfToAnonymized = getData.getFOFHistFilesData(idTraitement)
					.persist();
			rdd = dfToAnonymized.toJavaRDD().map(new FofHistFilesFactory());
			dfAnonym = sparkSession
					.createDataFrame(rdd, FofHistFilesBean.class);
			orderedDfAnonym = getData.getOrderedDfAnonymFOFHistFiles(dfAnonym);
			break;
		case AnonymisationConstant.TABLE_FMF_USERS:
			dfToAnonymized = getData.getFMFUsersData(idTraitement).persist();
			rdd = dfToAnonymized.toJavaRDD().map(new FmfUsersFactory());
			dfAnonym = sparkSession.createDataFrame(rdd, FmfUsersBean.class);
			orderedDfAnonym = getData.getOrderedDfAnonymFmfUsers(dfAnonym);
			break;
		case AnonymisationConstant.TABLE_PARAM_ALERTE_MOTIF:
			dfToAnonymized = getData.getParamAlerteMotifData(idTraitement)
					.persist();
			rdd = dfToAnonymized.toJavaRDD().map(new ParamAlerteMotifFactory());
			dfAnonym = sparkSession.createDataFrame(rdd,
					ParamAlerteMotifBean.class);
			orderedDfAnonym = getData
					.getOrderedDfAnonymParamAlerteMotif(dfAnonym);
			// TODO implement generic method for all other tables
		default:
			break;
		}

		// save anonymized datas
		PutData putDataHelper = new PutData(sparkSession);
		putDataHelper.writeData(anonymisationConstant.getRawLayerPath(),
				anonymisationConstant.getRawLayerHiveBase(), tableName,
				orderedDfAnonym, idTraitement);

		sparkSession.close();

	}
}
