package fr.bdf.spark.embgo.anonymisation;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

/**
 * Classe de tests pour vérifier la faisabilité : - De modification d'une chaine
 * de caractère en utilisant les Matcher (Hits et SEPA) - De modification d'un
 * message SWIFT via l'API prowideSoftware
 * 
 */
public class AnonymisationTest {

	/**
	 * @throws NoSuchAlgorithmException  
	 * 
	 * */
	public static void main(String[] args) {
		AnonymisationTest test = new AnonymisationTest();
		try {
			test.parseAndAnonymizeSEPA();
			//test.parseAndAnonymizeHits();
			//test.parseAndAnonymizeSWIFT();
			
//			String testStr = "New test";
//			MessageDigest digest = MessageDigest.getInstance("MD5");
//			digest.update(testStr.getBytes());
//			byte[] datas = digest.digest();
//			
//			StringBuffer buffer = new StringBuffer();
//			for(int i=0; i < datas.length; i++) {
//				buffer.append(Integer.toString((datas[i] & 0xff) + 0x100, 16).substring(1));
//			}
//			System.out.println("Hashing result : "+ buffer.toString());
			
		//	System.out.println("UUID :" + UUID.randomUUID().toString());
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		


	}

	public void parseAndAnonymizeSEPA() throws Exception {
		InputStream input = getClass().getClassLoader().getResourceAsStream("sepa-example-pacs008-text.txt");
		String strInput = IOUtils.toString(input, Charset.forName("UTF-8"));
		if (StringUtils.isNotBlank(strInput)) {

			final List<String> regexList = Arrays.asList(			
					"(?<=\\[A_INDRAG       \\])(.*?)[^\\r\\n\\[]+", // 7 spaces
					"(?<=\\[A_INGRAG       \\])(.*?)[^\\r\\n\\[]+",
					"(?<=\\[A_INDRAGAC     \\])(.*?)[^\\r\\n\\[]+",
					"(?<=\\[A_INGRAGAC     \\])(.*?)[^\\r\\n\\[]+",
					"(?<=\\[A_THRGRAG      \\])(.*?)[^\\r\\n\\[]+",
					"(?<=\\[A_THRGRAGAC    \\])(.*?)[^\\r\\n\\[]+",
					"(?s)(?<=\\[B_CDTR         \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?s)(?<=\\[B_DBTR         \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_CDTRAC       \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_DBTRAC       \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_CDTRAG       \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_DBTRAG       \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_CDTRAGAC     \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_DBTRAGAC     \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_INTAG1       \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_INTAGAC1     \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_INTAG1AC     \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?s)(?<=\\[B_RELREMIT     \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?s)(?<=\\[B_REMITINF     \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_INSTCDAG     \\])(.*?)(?=[\\r\\n|\\n]\\[)",
					"(?<=\\[B_RGLRPTG      \\])(.*?)(?=[\\r\\n|\\n]\\[)"
					
//					"(?s)\\[B_DBTR\\s*\\](.*)\\[B_DBTRAC\\s*\\]"		
//					"(?s)(?<=\\[B_CDTR         \\])(.*?)(?=[\\r\\n|\\n]\\[B_CDTRAC)",
//					"(?s)(?<=\\[B_DBTR         \\])(.*?)(?=[\\r\\n|\\n]\\[B_DBTRAC)",
			);
			strInput = anonymizeFromRegexListHash(regexList, strInput);
		}
		System.out.println("Anonymized SEPA : \n"+strInput);

	}

	public void parseAndAnonymizeSWIFT() throws IOException {
		InputStream input = getClass().getClassLoader().getResourceAsStream("swift-example.txt");
		String strInput = IOUtils.toString(input, Charset.forName("UTF-8"));
		if (StringUtils.isNotBlank(strInput)) {
//			final List<String> regexList = Arrays.asList(
//					"(?<=20[A-Z]?:)[^:23]+"
//			);
//			anonymizeFromRegexList(regexList, strInput);
//			strInput = strInput.replaceAll("(?<=:[0-9][0-9][A-Z]?:)[^:[0-9][0-9][A-Z]?:]|"
//					+ "(?<=:[A-Z][A-Z][A-Z]:)[^:[0-9][0-9][A-Z]?:]", "X");
//			System.out.println("StrInput output : "+strInput);
			final List<String> lines = Arrays.asList(strInput.split("\\r\\n|\\n"));
			final List<String> newLines = new ArrayList<String>();
			for (String line : lines) {
				if(!(line.startsWith(":SND") || line.startsWith(":RCV") || line.startsWith(":20") || line.startsWith(":23") 
								|| line.startsWith(":32") || line.startsWith(":33") || line.startsWith(":36") || line.startsWith(":71"))) {
					if(line.lastIndexOf(":") > 0) {
						newLines.add(line.substring(0, line.lastIndexOf(":")) + 
								line.substring(line.lastIndexOf(":")).replaceAll("[A-Z]", "X").replaceAll("[a-z]", "x").replaceAll("[0-9]", "n"));
					} else {
						newLines.add(line.replaceAll("[A-Z]", "X").replaceAll("[a-z]", "x").replaceAll("[0-9]", "n"));
					}
				} else { 
					newLines.add(line);
				}
			}
			
			final String strOuput = StringUtils.join(newLines, "\n");
		
			System.out.println("StrOutput : "+strOuput);
		}
	}

	public void parseAndAnonymizeHits() throws IOException {
		InputStream input = getClass().getClassLoader().getResourceAsStream("hit-example.txt");
		String strInput = IOUtils.toString(input, Charset.forName("UTF-8"));
		if (StringUtils.isNotBlank(strInput)) {
			final List<String> regexList = Arrays.asList(
					"(?<=MATCHINGTEXT:)(.*?)[^\\r\\n]+",
					"(?<=NAME:)(.*?)[^\\r\\n]+",
					"(?<=ADDRESS:)(.*?)[^\\r\\n]+",
					"(?<=CITY:)(.*?)[^\\r\\n]+",
					"(?<=COUNTRY:)(.*?)[^\\r\\n]+",
					"(?<=STATE:)(.*?)[^\\r\\n]+",
					"(?s)(?<=ORIGIN:[\\s*][\\r\\n|\\n+])(.*?)(?=[\\r\\n|\n]DESIGNATION:)",
					"(?s)(?<=PASSPORT:[\\s*][\\r\\n|\\n+])(.*?)(?=[\\r\\n|\n]BIC CODES:)",
					"(?s)(?<=BIC CODES:[\\s*][\\r\\n|\\n+])(.*?)(?=[\\r\\n|\n]NATID:)",
					"(?s)(?<=NATID:[\\s*][\\r\\n|\\n+])(.*?)(?=[\\r\\n|\n]PLACE OF BIRTH:)",
					"(?s)(?<=PLACE OF BIRTH:[\\s*][\\r\\n|\\n+])(.*?)(?=[\\r\\n|\n]DATE OF BIRTH:)",
					"(?s)(?<=DATE OF BIRTH:[\\s*][\\r\\n|\\n+])(.*?)(?=[\\r\\n|\n]NATIONALITY:)",
					"(?s)(?<=NATIONALITY:[\\s*][\\r\\n|\\n+])(.*?)(?=[\\r\\n|\n]ADDITIONAL INFOS:)",
					"(?s)(?<=ADDITIONAL INFOS:[\\s*][\\r\\n|\\n+])(.*?)(?=[\\r\\n|\n]FML TYPE:)",
					"(?s)(?<=Synonyms:)(.*?)(?=[\\r\\n|\\n][A-Z]*:)"
				
					
//					"(?<=MATCHINGTEXT:)[^\\n]+",
//					"(?<=NAME:)[^\\n]+",
//					"(?<=ADDRESS:)[^\\n]+",
//					"(?<=CITY:)[^\\n]+",
//					"(?<=COUNTRY:)[^\\n]+",
//					"(?<=STATE:)[^\\n]+",
//					"(?s)(?<=ORIGIN:)(.*?)(?=DESIGNATION:)",
//					"(?s)(?<=PASSPORT:)(.*?)(?=BIC CODES:)",
//					"(?s)(?<=BIC CODES:)(.*?)(?=NATID:)",
//					"(?s)(?<=NATID:)(.*?)(?=PLACE OF BIRTH:)",
//					"(?s)(?<=PLACE OF BIRTH:)(.*?)(?=DATE OF BIRTH:)",
//					"(?s)(?<=DATE OF BIRTH:)(.*?)(?=NATIONALITY:)",
//					"(?s)(?<=NATIONALITY:)(.*?)(?=ADDITIONAL INFOS:)",
//					"(?s)(?<=ADDITIONAL INFOS:)(.*?)(?=FML TYPE:)",
//					"(?s)(?<=Synonyms:)(.*?)(?=[A-Z]*:)"
					
					
//					"(?<=MATCHINGTEXT:)[^\\r\\n]+",
//					"(?<=NAME:)[^\\r\\n]+",
//					"(?<=Synonyms:)[^\\r\\nADDRESS:]+",
//					"(?<=ADDRESS:)[^\\r\\n]+",
//					"(?<=Synonyms:)[^\\r\\nCITY:]+",
//					"(?<=CITY:)[^\\r\\n]+",
//					"(?<=Synonyms:)[^\\r\\nCOUNTRY:]+",
//					"(?<=COUNTRY:)[^\\r\\n]+",
//					"(?<=Synonyms:)[^\\r\\nSTATE:]+",
//					"(?<=STATE:)[^\\r\\n]+",
//					"(?<=Synonyms:)[^\\r\\nORIGIN:]+",
//					"(?s)(?<=ORIGIN:)(.*?)(?=DESIGNATION:)",
//					"(?s)(?<=PASSPORT:)(.*?)(?=BIC CODES:)",
//					"(?s)(?<=BIC CODES:)(.*?)(?=NATID:)",
//					"(?s)(?<=NATID:)(.*?)(?=PLACE OF BIRTH:)",
//					"(?s)(?<=PLACE OF BIRTH:)(.*?)(?=DATE OF BIRTH:)",
//					"(?s)(?<=DATE OF BIRTH:)(.*?)(?=NATIONALITY:)",
//					"(?s)(?<=NATIONALITY:)(.*?)(?=ADDITIONAL INFOS:)",
//					"(?s)(?<=ADDITIONAL INFOS:)(.*?)(?=FML TYPE:)"			
					
//					"(?<=COUNTRY:)(.*)(?=STATE:)"
//					"(?si)(?:COUNTRY:.*Synonyms:).*(?:STATE:)"
//					Pattern.quote("Synonyms:") + "(.*?)" + Pattern.quote("STATE:"),
			);
			// Easy regex
			strInput = anonymizeFromRegexList(regexList, strInput);
			
			// Synonyms replace
			//strInput = anonymizeSynonymsFields(strInput);
			
			// Result
			System.out.println("RESULT : "+strInput);
		}
	}


	public String anonymizeFromRegexList(List<String> regexList, String strInput) {
		if(CollectionUtils.isNotEmpty(regexList)) {
			String regex = StringUtils.join(regexList, "|");
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(strInput);
	
			//matcher.find();
			// String text = matcher.group().replaceAll("[A-Z]", "X").replaceAll("[a-z]", "x").replaceAll("[0-9]", "n");
			
			StringBuffer result = new StringBuffer();
			String text = new String();
			while (matcher.find()) {
				text = matcher.group().replaceAll("[A-Z]", "X").replaceAll("[a-z]", "x").replaceAll("[0-9]", "n");
				matcher.appendReplacement(result, text);
			}
			matcher.appendTail(result);
			return result.toString();
		}
		return strInput;
		
	}
	
	public String anonymizeFromRegexListHash(List<String> regexList, String strInput) throws NoSuchAlgorithmException {
		String regex = StringUtils.join(regexList, "|");
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(strInput);

		StringBuffer result = new StringBuffer();
		String text = new String();
		try {
			while (matcher.find()) {
				text = anonymizeString(matcher.group());
				matcher.appendReplacement(result, text);
			}
		} catch (Exception e) {
			System.out.println("Error occured with regex : " + regex +", text : "+text+"\n And matcher :"+matcher.group());
		}
 		matcher.appendTail(result);
		return result.toString();
	}
	
	public String anonymizeString(String strInput) throws NoSuchAlgorithmException {
		if (StringUtils.isNotBlank(strInput)) {
			MessageDigest digest = MessageDigest.getInstance("MD5");
			digest.update(strInput.getBytes());
			byte[] datas = digest.digest();

			StringBuffer buffer = new StringBuffer();
			for (int i = 0; i < datas.length; i++) {
				buffer.append(Integer.toString((datas[i] & 0xff) + 0x100, 16).substring(1));
			}
			return buffer.toString();
		}
		return strInput;
	}
	
}
