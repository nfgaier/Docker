package fr.bdf.spark.embgo.anonymisation.data;

import static org.apache.spark.sql.functions.col;

import java.io.Serializable;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import fr.bdf.spark.embgo.anonymisation.constant.AnonymisationConstant;

public class GetData implements Serializable {

	private static final long serialVersionUID = -2123020491283549029L;

	private SparkSession sparkSession;

	private String sourceBase;

	/**
	 * @param sqlContext
	 */
	public GetData(SparkSession sparkSession, String sourceBase) {
		super();
		this.sparkSession = sparkSession;
		this.sourceBase = sourceBase;
	}

	public String getSourceBase() {
		return sourceBase;
	}

	public void setSourceBase(String sourceBase) {
		this.sourceBase = sourceBase;
	}

	public SparkSession getSparkSession() {
		return sparkSession;
	}

	public void setSparkSession(SparkSession sparkSession) {
		this.sparkSession = sparkSession;
	}

	/** Get data from fofa_hist_message */
	public Dataset<Row> getFOFAHistMessageData(String idTraitement) {
		return sparkSession
				.sql("select t_system_id,"
						+ "business_unit_id,"
						+ "saausrgrp,"
						+ "t_normamount,"
						+ "concat(regexp_replace(cast(t_app_deadline as string),'-','/'),' 00:00:00') t_app_deadline,"
						+ "t_app_priority,"
						+ "t_alignment,"
						+ "t_confidentiality,"
						+ "t_priority,"
						+ "t_type,"
						+ "t_transaction,"
						+ "t_toappli,"
						+ "t_sender,"
						+ "t_related_ref,"
						+ "t_receiver,"
						+ "t_pairing_id,"
						+ "t_nonblocking,"
						+ "t_nature,"
						+ "t_message_id,"
						+ "t_message,"
						+ "t_i_o,"
						+ "t_gateway,"
						+ "t_fromappli,"
						+ "t_filtered,"
						+ "t_entity,"
						+ "t_lastoperator,"
						+ "t_decision_type,"
						+ "case when LENGTH(t_date_value)=10 then CONCAT(t_date_value,' 00:00:00') else t_date_value end t_date_value,"
						+ "t_currency," + "t_created," + "t_copy_service,"
						+ "t_completed," + "t_bunit," + "t_blocking,"
						+ "t_amount_float," + "t_amount," + "date_ope," + "date_insert,"
						+ "id_traitement" + " from " + sourceBase + "."
						+ AnonymisationConstant.TABLE_FOFA_HIST_MESSAGE
						+ " where id_traitement='" + idTraitement + "'");
	}

	public Dataset<Row> getOrderedDfAnonymFofaHistMessage(Dataset<Row> dfAnonym) {
		Dataset<Row> orderedDF = dfAnonym.select(col("t_system_id"),
				col("business_unit_id"), col("saausrgrp"), col("t_normamount"),
				col("t_app_deadline"), col("t_app_priority"),
				col("t_alignment"), col("t_confidentiality"),
				col("t_priority"), col("t_type"), col("t_transaction"),
				col("t_toappli"), col("t_sender"), col("t_related_ref"),
				col("t_receiver"), col("t_pairing_id"), col("t_nonblocking"),
				col("t_nature"), col("t_message_id"), col("t_message"),
				col("t_i_o"), col("t_gateway"), col("t_fromappli"),
				col("t_filtered"), col("t_entity"), col("t_lastoperator"),
				col("t_decision_type"), col("t_date_value"), col("t_currency"),
				col("t_created"), col("t_copy_service"), col("t_completed"),
				col("t_bunit"), col("t_blocking"), col("t_amount_float"),
				col("t_amount"), col("date_ope"), col("date_insert"), col("id_traitement"));
		return orderedDF;
	}

	/** Get data from fofa_hist_intervention */
	public Dataset<Row> getFOFAHistInterventionData(String idTraitement) {
		// return sqlContext.sql(" select t_system_id, " +
		// "t_intervention, " +
		// "date_ope, " +
		// "id_traitement " +
		// "FROM "+AnonymisationConstant.HIVE_LANDING_LAYER + "." +
		// AnonymisationConstant.TABLE_FMF_USERS +
		// " WHERE id_traitement ='" + idTraitement +"'");

		return sparkSession
				.table(sourceBase + "."
						+ AnonymisationConstant.TABLE_FOFA_HIST_INTERVENTION)
				.where(col("id_traitement").equalTo(idTraitement)).persist();
	}

	public Dataset<Row> getOrderedDfAnonymFofaHistIntervention(
			Dataset<Row> dfAnonym) {
		Dataset<Row> orderedDF = dfAnonym.select(col("t_system_id"),
				col("t_intervention"), col("date_ope"), col("date_insert"), col("id_traitement"));
		return orderedDF;
	}

	/** Get data from fofa_hist_action */
	public Dataset<Row> getFOFAHistActionData(String idTraitement) {
		return sparkSession.sql(" select t_system_id, " + "t_comments, "
				+ "t_operator_desc, " + "t_decision_type, "
				+ "t_decision_date, " + "date_ope, " + "date_insert, " + "id_traitement "
				+ "FROM " + sourceBase + "."
				+ AnonymisationConstant.TABLE_FOFA_HIST_ACTION
				+ " WHERE id_traitement ='" + idTraitement + "'");
	}

	public Dataset<Row> getOrderedDfAnonymFofaHistAction(Dataset<Row> dfAnonym) {
		Dataset<Row> orderedDF = dfAnonym.select(col("t_system_id"),
				col("t_comments"), col("t_operator_desc"),
				col("t_decision_type"), col("t_decision_date"),
				col("date_ope"), col("date_insert"), col("id_traitement"));
		return orderedDF;
	}

	/** Get data from fof_hist_files */
	public Dataset<Row> getFOFHistFilesData(String idTraitement) {
		return sparkSession
				.table(sourceBase + "."
						+ AnonymisationConstant.TABLE_FOF_HIST_FILES)
				.where(col("id_traitement").equalTo(idTraitement)).persist();
	}

	public Dataset<Row> getOrderedDfAnonymFOFHistFiles(Dataset<Row> dfAnonym) {
		Dataset<Row> orderedDF = dfAnonym.select(col("id"), col("dec_date"),
				col("dec_id"), col("operator"), col("comments"),
				col("content_size"), col("content"), col("file_name"),
				col("date_ope"), col("date_insert"), col("id_traitement"));
		return orderedDF;
	}

	public Dataset<Row> getFMFUsersData(String idTraitement) {
		return sparkSession.sql(" select t_id ," + "business_unit_id ,"
				+ "t_lockcomment ," + "t_out_of_office ,"
				+ "t_public_holidays ," + "t_working_hours ," + "t_days_off ,"
				+ "t_password_initial ," + "t_status ,"
				+ "t_last_remote_host ," + "t_last_login_date ,"
				+ "t_user_last_update ," + "t_password_last_update ,"
				+ "t_creation_date ," + "t_password ," + "t_email ,"
				+ "t_description ," + "t_login ," + "t_login_failures ,"
				+ "date_ope ," + "date_insert ," + "id_traitement " + "FROM " + sourceBase + "."
				+ AnonymisationConstant.TABLE_FMF_USERS
				+ " WHERE id_traitement ='" + idTraitement + "'");
	}

	public Dataset<Row> getOrderedDfAnonymFmfUsers(Dataset<Row> dfAnonym) {
		/** Order Hits Dataset<Row> */
		Dataset<Row> orderedDF = dfAnonym.select(col("t_id"),
				col("business_unit_id"), col("t_lockcomment"),
				col("t_out_of_office"), col("t_public_holidays"),
				col("t_working_hours"), col("t_days_off"),
				col("t_password_initial"), col("t_status"),
				col("t_last_remote_host"), col("t_last_login_date"),
				col("t_user_last_update"), col("t_password_last_update"),
				col("t_creation_date"), col("t_password"), col("t_email"),
				col("t_description"), col("t_login"), col("t_login_failures"),
				col("date_ope"), col("date_insert"), col("id_traitement"));
		return orderedDF;
	}

	/** Get data from fof_hist_files */
	public Dataset<Row> getParamAlerteMotifData(String idTraitement) {
		return sparkSession
				.table(sourceBase + "."
						+ AnonymisationConstant.TABLE_PARAM_ALERTE_MOTIF)
				.where(col("id_traitement").equalTo(idTraitement)).persist();
	}

	public Dataset<Row> getOrderedDfAnonymParamAlerteMotif(Dataset<Row> dfAnonym) {
		/** Order Dataset<Row> */
		Dataset<Row> orderedDF = dfAnonym.select(col("ordre"),
				col("date_decision_deb"), col("date_decision_fin"),
				col("decision_finale"), col("motif_decision"), col("date_insert"),
				col("id_traitement"));
		return orderedDF;
	}
}
