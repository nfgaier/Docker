/**
 * 
 */
package fr.bdf.spark.embgo.anonymisation.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.sql.Date;

/**
 * @author i2108fv
 *
 */
public class FofaHistMessageBean implements Serializable {
    

    
    /**
	 * 
	 */
	private static final long serialVersionUID = -9085524770852765556L;
	
	private String t_system_id;
    private BigDecimal business_unit_id;
    private String saausrgrp;
    private BigDecimal t_normamount;
    private java.sql.Timestamp t_app_deadline;
    private BigDecimal t_app_priority;
    private String t_alignment;
    private BigDecimal t_confidentiality;
    private BigDecimal t_priority;
    private String t_type;
    private String t_transaction;
    private String t_toappli;
    private String t_sender;
    private String t_related_ref;
    private String t_receiver;
    private String t_pairing_id;
    private BigDecimal t_nonblocking;
    private String t_nature;
    private String t_message_id;
    private String t_message;
    private String t_i_o;
    private String t_gateway;
    private String t_fromappli;
    private String t_filtered;
    private String t_entity;
    private String t_lastoperator;
    private String t_decision_type;
    private String t_date_value;
    private String t_currency;
    private String t_created;
    private String t_copy_service;
    private String t_completed;
    private String t_bunit;
    private BigDecimal t_blocking;
    private Float t_amount_float;
    private String t_amount;
	private Date date_ope;
	private Date date_insert;
	private String id_traitement;
	
	public FofaHistMessageBean() {
		super();
	}


	public FofaHistMessageBean(String t_system_id, BigDecimal business_unit_id, String saausrgrp,
			BigDecimal t_normamount, Timestamp t_app_deadline, BigDecimal t_app_priority, String t_alignment,
			BigDecimal t_confidentiality, BigDecimal t_priority, String t_type, String t_transaction, String t_toappli,
			String t_sender, String t_related_ref, String t_receiver, String t_pairing_id, BigDecimal t_nonblocking,
			String t_nature, String t_message_id, String t_message, String t_i_o, String t_gateway, String t_fromappli,
			String t_filtered, String t_entity, String t_lastoperator, String t_decision_type, String t_date_value,
			String t_currency, String t_created, String t_copy_service, String t_completed, String t_bunit,
			BigDecimal t_blocking, Float t_amount_float, String t_amount, Date date_ope, Date date_insert,
			String id_traitement) {
		super();
		this.t_system_id = t_system_id;
		this.business_unit_id = business_unit_id;
		this.saausrgrp = saausrgrp;
		this.t_normamount = t_normamount;
		this.t_app_deadline = t_app_deadline;
		this.t_app_priority = t_app_priority;
		this.t_alignment = t_alignment;
		this.t_confidentiality = t_confidentiality;
		this.t_priority = t_priority;
		this.t_type = t_type;
		this.t_transaction = t_transaction;
		this.t_toappli = t_toappli;
		this.t_sender = t_sender;
		this.t_related_ref = t_related_ref;
		this.t_receiver = t_receiver;
		this.t_pairing_id = t_pairing_id;
		this.t_nonblocking = t_nonblocking;
		this.t_nature = t_nature;
		this.t_message_id = t_message_id;
		this.t_message = t_message;
		this.t_i_o = t_i_o;
		this.t_gateway = t_gateway;
		this.t_fromappli = t_fromappli;
		this.t_filtered = t_filtered;
		this.t_entity = t_entity;
		this.t_lastoperator = t_lastoperator;
		this.t_decision_type = t_decision_type;
		this.t_date_value = t_date_value;
		this.t_currency = t_currency;
		this.t_created = t_created;
		this.t_copy_service = t_copy_service;
		this.t_completed = t_completed;
		this.t_bunit = t_bunit;
		this.t_blocking = t_blocking;
		this.t_amount_float = t_amount_float;
		this.t_amount = t_amount;
		this.date_ope = date_ope;
		this.date_insert = date_insert;
		this.id_traitement = id_traitement;
	}


	public String getT_system_id() {
		return t_system_id;
	}

	public void setT_system_id(String t_system_id) {
		this.t_system_id = t_system_id;
	}

	public BigDecimal getBusiness_unit_id() {
		return business_unit_id;
	}

	public void setBusiness_unit_id(BigDecimal business_unit_id) {
		this.business_unit_id = business_unit_id;
	}

	public String getSaausrgrp() {
		return saausrgrp;
	}

	public void setSaausrgrp(String saausrgrp) {
		this.saausrgrp = saausrgrp;
	}

	public BigDecimal getT_normamount() {
		return t_normamount;
	}

	public void setT_normamount(BigDecimal t_normamount) {
		this.t_normamount = t_normamount;
	}

	public java.sql.Timestamp getT_app_deadline() {
		return t_app_deadline;
	}

	public void setT_app_deadline(java.sql.Timestamp t_app_deadline) {
		this.t_app_deadline = t_app_deadline;
	}

	public BigDecimal getT_app_priority() {
		return t_app_priority;
	}

	public void setT_app_priority(BigDecimal t_app_priority) {
		this.t_app_priority = t_app_priority;
	}

	public String getT_alignment() {
		return t_alignment;
	}

	public void setT_alignment(String t_alignment) {
		this.t_alignment = t_alignment;
	}

	public BigDecimal getT_confidentiality() {
		return t_confidentiality;
	}

	public void setT_confidentiality(BigDecimal t_confidentiality) {
		this.t_confidentiality = t_confidentiality;
	}

	public BigDecimal getT_priority() {
		return t_priority;
	}

	public void setT_priority(BigDecimal t_priority) {
		this.t_priority = t_priority;
	}

	public String getT_type() {
		return t_type;
	}

	public void setT_type(String t_type) {
		this.t_type = t_type;
	}

	public String getT_transaction() {
		return t_transaction;
	}

	public void setT_transaction(String t_transaction) {
		this.t_transaction = t_transaction;
	}

	public String getT_toappli() {
		return t_toappli;
	}

	public void setT_toappli(String t_toappli) {
		this.t_toappli = t_toappli;
	}

	public String getT_sender() {
		return t_sender;
	}

	public void setT_sender(String t_sender) {
		this.t_sender = t_sender;
	}

	public String getT_related_ref() {
		return t_related_ref;
	}

	public void setT_related_ref(String t_related_ref) {
		this.t_related_ref = t_related_ref;
	}

	public String getT_receiver() {
		return t_receiver;
	}

	public void setT_receiver(String t_receiver) {
		this.t_receiver = t_receiver;
	}

	public String getT_pairing_id() {
		return t_pairing_id;
	}

	public void setT_pairing_id(String t_pairing_id) {
		this.t_pairing_id = t_pairing_id;
	}

	public BigDecimal getT_nonblocking() {
		return t_nonblocking;
	}

	public void setT_nonblocking(BigDecimal t_nonblocking) {
		this.t_nonblocking = t_nonblocking;
	}

	public String getT_nature() {
		return t_nature;
	}

	public void setT_nature(String t_nature) {
		this.t_nature = t_nature;
	}

	public String getT_message_id() {
		return t_message_id;
	}

	public void setT_message_id(String t_message_id) {
		this.t_message_id = t_message_id;
	}

	public String getT_message() {
		return t_message;
	}

	public void setT_message(String t_message) {
		this.t_message = t_message;
	}

	public String getT_i_o() {
		return t_i_o;
	}

	public void setT_i_o(String t_i_o) {
		this.t_i_o = t_i_o;
	}

	public String getT_gateway() {
		return t_gateway;
	}

	public void setT_gateway(String t_gateway) {
		this.t_gateway = t_gateway;
	}

	public String getT_fromappli() {
		return t_fromappli;
	}

	public void setT_fromappli(String t_fromappli) {
		this.t_fromappli = t_fromappli;
	}

	public String getT_filtered() {
		return t_filtered;
	}

	public void setT_filtered(String t_filtered) {
		this.t_filtered = t_filtered;
	}

	public String getT_entity() {
		return t_entity;
	}

	public void setT_entity(String t_entity) {
		this.t_entity = t_entity;
	}

	public String getT_lastoperator() {
		return t_lastoperator;
	}

	public void setT_lastoperator(String t_lastoperator) {
		this.t_lastoperator = t_lastoperator;
	}

	public String getT_decision_type() {
		return t_decision_type;
	}

	public void setT_decision_type(String t_decision_type) {
		this.t_decision_type = t_decision_type;
	}

	public String getT_date_value() {
		return t_date_value;
	}

	public void setT_date_value(String t_date_value) {
		this.t_date_value = t_date_value;
	}

	public String getT_currency() {
		return t_currency;
	}

	public void setT_currency(String t_currency) {
		this.t_currency = t_currency;
	}

	public String getT_created() {
		return t_created;
	}

	public void setT_created(String t_created) {
		this.t_created = t_created;
	}

	public String getT_copy_service() {
		return t_copy_service;
	}

	public void setT_copy_service(String t_copy_service) {
		this.t_copy_service = t_copy_service;
	}

	public String getT_completed() {
		return t_completed;
	}

	public void setT_completed(String t_completed) {
		this.t_completed = t_completed;
	}

	public String getT_bunit() {
		return t_bunit;
	}

	public void setT_bunit(String t_bunit) {
		this.t_bunit = t_bunit;
	}

	public BigDecimal getT_blocking() {
		return t_blocking;
	}

	public void setT_blocking(BigDecimal t_blocking) {
		this.t_blocking = t_blocking;
	}

	public Float getT_amount_float() {
		return t_amount_float;
	}

	public void setT_amount_float(Float t_amount_float) {
		this.t_amount_float = t_amount_float;
	}

	public String getT_amount() {
		return t_amount;
	}

	public void setT_amount(String t_amount) {
		this.t_amount = t_amount;
	}

	public Date getDate_ope() {
		return date_ope;
	}

	public void setDate_ope(Date date_ope) {
		this.date_ope = date_ope;
	}

	public String getId_traitement() {
		return id_traitement;
	}

	public void setId_traitement(String id_traitement) {
		this.id_traitement = id_traitement;
	}


	public Date getDate_insert() {
		return date_insert;
	}


	public void setDate_insert(Date date_insert) {
		this.date_insert = date_insert;
	}
	
	


}
