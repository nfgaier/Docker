package fr.bdf.spark.embgo.anonymisation.factory;

import java.io.Serializable;

import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Row;
import fr.bdf.spark.embgo.anonymisation.bean.FofHistFilesBean;

public class FofHistFilesFactory  extends AbstractFactory implements Function<Row, FofHistFilesBean>, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2933472377292278685L;

	@Override
	public FofHistFilesBean call(Row data) throws Exception {
		
		final FofHistFilesBean bean = new FofHistFilesBean();
		
		bean.setId(getString(data.getAs("id")));
		bean.setDec_date(getString(data.getAs("dec_date")));
		bean.setDec_id(getBigDecimal(data.getAs("dec_id"), 0));
		bean.setOperator(getString(data.getAs("operator")));
		bean.setComments(getString(data.getAs("comments")));
		bean.setContent_size(getBigDecimal(data.getAs("content_size"), 0));
		bean.setContent(null);
		bean.setFile_name(getString(data.getAs("file_name")));
		bean.setDate_ope(getDateSql(data.getAs("date_ope")));
		bean.setDate_insert(getDateSql(data.getAs("date_insert")));
		bean.setId_traitement(getString(data.getAs("id_traitement")));
	
		return bean;
	}
	
}