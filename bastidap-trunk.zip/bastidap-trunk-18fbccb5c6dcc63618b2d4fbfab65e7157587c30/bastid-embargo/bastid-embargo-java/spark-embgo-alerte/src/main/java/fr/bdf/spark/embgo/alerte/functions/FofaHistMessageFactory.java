/**
 * 
 */
package fr.bdf.spark.embgo.alerte.functions;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Row;

import fr.bdf.spark.embgo.alerte.beans.FofaHistMessageBean;

public class FofaHistMessageFactory implements
		Function<Row, FofaHistMessageBean>, Serializable {

	/**
     * 
     */
	private static final long serialVersionUID = -3898823239656733697L;

	private String getString(Object obj) {
		if (obj == null) {
			return null;
		} else {
			return obj.toString();
		}
	}

	private Integer getInteger(Object obj) {
		if (obj == null) {
			return null;
		} else {
			return Integer.parseInt(obj.toString());
		}
	}

	private Double getDouble(Object obj) {
		if (obj == null) {
			return null;
		} else {
			return Double.parseDouble(obj.toString());
		}
	}

	private Float getFloat(Object obj) {
		if (obj == null) {
			return null;
		} else {
			return Float.parseFloat(obj.toString());
		}
	}

	private Date getDateTime(Object obj) {
		if (obj == null) {
			return null;
		} else {
			try {
//				return new SimpleDateFormat("yyyy/dd/MM HH:mm:ss").parse(obj.toString());
				return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(obj.toString());
			} catch (ParseException e) {
				e.printStackTrace();
				return null;
			}
		}
	}

	protected java.sql.Date getDateSql(Object obj) {
		if (obj == null) {
			return null;
		} else {
			try {
				java.sql.Date dateSql = null;
				final java.util.Date dateUtil = new SimpleDateFormat("yyyy-MM-dd").parse(obj.toString());
				if (dateUtil != null) {
					dateSql = new java.sql.Date(dateUtil.getTime());
				}
				return dateSql;
			} catch (ParseException e) {
				e.printStackTrace();
				return null;
			}
		}
	}

	@Override
	public FofaHistMessageBean call(Row v1) throws Exception {

		FofaHistMessageBean fhmBean = new FofaHistMessageBean();

		fhmBean.setT_system_id(getString(v1.getAs("t_system_id")));
		fhmBean.setBusiness_unit_id(getDouble(v1.getAs("business_unit_id")));
		fhmBean.setSaausrgrp(getString(v1.getAs("saausrgrp")));
		fhmBean.setT_normamount(getDouble(v1.getAs("t_normamount")));
		fhmBean.setT_app_deadline(getDateTime(v1.getAs("t_app_deadline")));
		fhmBean.setT_app_priority(getDouble(v1.getAs("t_app_priority")));
		fhmBean.setT_alignment(getString(v1.getAs("t_alignment")));
		fhmBean.setT_confidentiality(getDouble(v1.getAs("t_confidentiality")));
		fhmBean.setT_priority(getDouble(v1.getAs("t_priority")));
		fhmBean.setT_type(getString(v1.getAs("t_type")));
		fhmBean.setT_transaction(getString(v1.getAs("t_transaction")));
		fhmBean.setT_toappli(getString(v1.getAs("t_toappli")));
		fhmBean.setT_sender(getString(v1.getAs("t_sender")));
		fhmBean.setT_related_ref(getString(v1.getAs("t_related_ref")));
		fhmBean.setT_receiver(getString(v1.getAs("t_receiver")));
		fhmBean.setT_pairing_id(getString(v1.getAs("t_pairing_id")));
		fhmBean.setT_nonblocking(getDouble(v1.getAs("t_nonblocking")));
		fhmBean.setT_nature(getString(v1.getAs("t_nature")));
		fhmBean.setT_message_id(getString(v1.getAs("t_message_id")));
		fhmBean.setT_message(getString(v1.getAs("t_message")));
		fhmBean.setT_message_upd(getString(v1.getAs("t_message_upd")));
		fhmBean.setT_i_o(getString(v1.getAs("t_i_o")));
		fhmBean.setT_gateway(getString(v1.getAs("t_gateway")));
		fhmBean.setT_fromappli(getString(v1.getAs("t_fromappli")));
		fhmBean.setT_filtered(getString(v1.getAs("t_filtered")));
		fhmBean.setT_entity(getString(v1.getAs("t_entity")));
		fhmBean.setT_lastoperator(getString(v1.getAs("t_lastoperator")));
		fhmBean.setT_decision_type(getString(v1.getAs("t_decision_type")));
		fhmBean.setT_date_value(getString(v1.getAs("t_date_value")));
		fhmBean.setT_currency(getString(v1.getAs("t_currency")));
		fhmBean.setT_created(getString(v1.getAs("t_created")));
		fhmBean.setT_copy_service(getString(v1.getAs("t_copy_service")));
		fhmBean.setT_completed(getString(v1.getAs("t_completed")));
		fhmBean.setT_bunit(getString(v1.getAs("t_bunit")));
		fhmBean.setT_blocking(getDouble(v1.getAs("t_blocking")));
		fhmBean.setT_amount_float(getFloat(v1.getAs("t_amount_float")));
		fhmBean.setT_amount(getString(v1.getAs("t_amount")));
		fhmBean.setNiveau_decision(getString(v1.getAs("niveau_decision")));
		fhmBean.setInd_swift_sepa(getString(v1.getAs("ind_swift_sepa")));
		fhmBean.setDate_ope(getDateSql(v1.getAs("date_ope")));
		fhmBean.setDate_insert(getDateSql(v1.getAs("date_insert")));
		return fhmBean;
	}

}
