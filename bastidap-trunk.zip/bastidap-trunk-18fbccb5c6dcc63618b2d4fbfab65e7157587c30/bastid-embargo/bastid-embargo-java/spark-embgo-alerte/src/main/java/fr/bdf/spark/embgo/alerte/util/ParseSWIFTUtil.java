/**
 * 
 */
package fr.bdf.spark.embgo.alerte.util;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;



public class ParseSWIFTUtil implements Serializable{
    
    private static final long serialVersionUID = 460189531306322530L;
    
    private String _SWIFTDatePattern = "\\d{2}\\d{2}\\d{2}";
    private String _SWIFTDateFormat = "yyMMdd";
    private String _sourceTsFormat = "yyyy/MM/dd HH:mm:ss";
    private String _sourceDateFormat = "yyyy/MM/dd";
    
    /**
     * Converts a time stamp string to java.sql.Timestamp with the format yyyy/MM/dd HH:mm:ss
     * @param String yyyy/MM/dd HH:mm:ss
     * @return java.sql.Timestamp
     */
    public java.sql.Timestamp tsFromString(String date) {
        try {
            if( date==null || date.trim().equals("")) { 
                return null;
            }
            SimpleDateFormat format = new SimpleDateFormat(_sourceTsFormat);
            format.setLenient(Boolean.FALSE);
            return new java.sql.Timestamp(format.parse(date).getTime());
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Converts a time stamp string to java.sql.Timestamp with the format yyyy/MM/dd
     * @param String yyyy/MM/dd
     * @return java.sql.Timestamp
     */
    public java.sql.Timestamp dateFromString(String date) {
        try {
            if( date==null || date.trim().equals("")) { 
                return null;
            }
            SimpleDateFormat format = new SimpleDateFormat(_sourceDateFormat);
            format.setLenient(Boolean.FALSE);
            return new java.sql.Timestamp(format.parse(date).getTime());
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }    
    
    /**
     * Converts String to BigDecimal. Return null if convertion to BigDecimal fails
     * @param tag
     * @return BigDecimal
     */
    public BigDecimal parseBigDecimalTag (String tag) {
        
        try{
            if( tag==null || tag.trim().equals("")) { 
                return null;
            }
            return BigDecimal.valueOf(Double.parseDouble(tag));
        }
        catch (Exception e) {
            System.out.println("WARN : Parsing SWIFT : parseBigDecimalTag method error : " + " String to parse = " + tag );
            System.out.println("WARN : Parsing SWIFT : parseBigDecimalTag method error : " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
     
    /**
     * Returns empty string if parameter String is null or have only spaces/tabs
     * @param tag
     * @return String
     */
    public String getTag(String tag) {
        
        if( tag==null || tag.trim().equals("")) { 
            return "";
        }
        return tag; 
    }
    
    /**
     * Returns empty string if substring fails
     * @param tag
     * @param start
     * @param end
     * @return string
     */
    public String subStr(String tag, int start, int end) {
        try {
            if( tag==null || tag.trim().equals("")) { 
                return "";
            }
            return tag.substring(start, end);
        }
        catch (Exception e) {
            System.out.println("WARN : Parsing SWIFT : subStr method error : " + " String = " + tag + " start = " + start + " end = " + end);
            System.out.println("WARN : Parsing SWIFT : subStr method error : " + e.getMessage());
            e.printStackTrace();
            return "";
        }
    }
    
    
    /**
     * Returns true if string passed as parameter matches the date pattern, false if not
     * @param date
     * @return Boolean
     */
    public Boolean testDateFormat (String date) {
        return  date.matches(_SWIFTDatePattern);
    }
    
    /**
     * Extract BIC
     * @param tag
     * @return
     */
    public String getBicFromTag(String tag) {
        //split tag using new line
        String[] strLst = getTag(tag).split("\\r\\n|\\r|\\n");
        String tmp = strLst[0];
        
        // return the first line if it doesn't start with /
        if (tmp.length() > 0 && !subStr(tmp, 0, 1).equals("/")) {
            return subStr(tmp,0,tmp.length());
        }// if not return the second
        else if (strLst.length > 1){
            return strLst[1];
        }
        else {
            return "";
        }        
    }
    

    /**
     * Extract account number
     * @param tag
     * @return
     */
    public String getNumCptFromTag(String tag) {
        String tmp = getTag(tag).split("\\r\\n|\\r|\\n")[0]; 
        // return the first line if it starts with /
        if (tmp.length() > 0 && subStr(tmp, 0, 1).equals("/")) {
            return subStr(tmp,1,tmp.length());
        }
        else {
            return "";
        }
    }
    
    /**
     * Extract name from tag
     * @param tag
     * @return
     */
    public String getNomFromTag (String tag ){
        String[] strLst = getTag(tag).split("\\r\\n|\\r|\\n");
        String tmp = strLst[0];
        // return the first line if it start with /
        if (tmp.length() > 0 && ! subStr(tmp, 0, 1).equals("/")) {
            return tmp;
        }
        else if (strLst.length > 1) {
            return strLst[1];
        }
        else {
            return "";
        }        
    }
    /**
     * Extract adresse from tag
     * @param tag
     * @return
     */
    public String getAdresseFromTag(String tag) {
        String[] strLst = getTag(tag).split("\\r\\n|\\r|\\n");
        
        //if the first line doesn't start with / then take the data starting from the second line 
        if (strLst.length > 1 && strLst[0].length() > 0 && ! strLst[0].startsWith("/") ) {
            String tmp="";
            for(int i = 1; i< strLst.length; i++){
                tmp = tmp + " " + strLst[i];
            }
            return tmp.trim(); 
        }//if the first line starts with / then take the data starting from the third line
        else if (strLst.length > 2 && strLst[0].length() > 0 && strLst[0].startsWith("/") ) {
            String tmp="";
            for(int i = 2; i< strLst.length; i++){
                tmp = tmp + " " + strLst[i];
            }
            return tmp.trim(); 
        }            
        else {
            return "";
        }        

    }
    
    
    /**
     * Field ref_transaction from tag 20 
     * @param tag
     * @return
     */
    public String getRefTransaction(String tag) {
          return getTag(tag);
    }
    
    /**
     * Field code_operation from tag 23B
     * @param tag
     * @return
     */
    public String getCodeOperation(String tag) {
        return getTag(tag);
    }
   
    /**
     * Field date_valeur from tag 32A
     * @param tag
     * @return
     */
    public java.sql.Date getMsgDateValeur(String tag) {

        String tmp = subStr(getTag(tag),0,6); 
                
        if (tmp.equals("")) {
            return null;
        }
        else if (!testDateFormat(tmp)) {
            return null;
        }
        else {
            try {
                SimpleDateFormat formatter = new SimpleDateFormat(_SWIFTDateFormat);
                return  new java.sql.Date(formatter.parse(tmp).getTime());
            }
            catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
    }
    
    /**
     * Field devise_credit from tag 32A
     * @param tag
     * @return
     */
    public String getMsgDeviseCredit(String tag) { 
          return subStr(getTag(tag),6,9); 
    }
    /**
     * Field mnt_credit from tag 32A
     * @param tag
     * @return
     */
    public BigDecimal getMsgMntCredit(String tag) { 
        return parseBigDecimalTag(subStr(getTag(tag),9,getTag(tag).length()).replace(",", "."));
    }

    /**
     * Field devise_debit from tag 33
     * @param tag
     * @return
     */
    public String getMsgDeviseDebit(String tag) { 
        return subStr(getTag(tag),0,3);  
    }

    /**
     * Field mnt_debit from tag 33
     * @param tag
     * @return
     */
    public BigDecimal getMsgMntDebit(String tag) { 
        return parseBigDecimalTag(subStr(getTag(tag),3,getTag(tag).length()).replace(",", ".")); 
    }
    
    /**
     * Field taxu_change from tag 36
     * @param tag
     * @return
     */
    public BigDecimal getMsgTauxChange(String tag) { 
        return parseBigDecimalTag(getTag(tag).replace(",", ".")); 
    }

    /**
     * Field num_cpt_do from tag 50
     * @param tag
     * @return
     */
    public String getMsgNumCptDo(String tag) { 
        return getNumCptFromTag(tag);
    }
    
    /**
     * Field bic_do from tag 50
     * @param tag
     * @return
     */
    public String getMsgBicDo(String tag) { 
            return getBicFromTag(tag);
    }

    /**
     * Field nom_do from tag 50
     * @param tag
     * @return
     */
    public String getMsgNomDo(String tag) { 
        //TODO Check
        String[] strLst = getTag(tag).split("\\r\\n|\\r|\\n");

        String value;

        //50F : return the second line if it starts with 1/
        if (strLst.length > 1 && strLst[1].length() > 2 && strLst[1].startsWith("1/")) {
        	value = getOneOrMoreLines(strLst, "1/");
        }
        //50K : return the second line if it starts with /
        else if (strLst.length > 1 && strLst[1].length() > 0 && strLst[0].startsWith("/") ) {
            value = strLst[1];
        }
        //50H : return the first line if it doesn't start with /
        else if (strLst.length > 1 && strLst[1].length() > 0 && ! strLst[0].startsWith("/") ) {
            value = strLst[0];
        }
        //50L
        else {
            value = strLst[0];
        }

        return value;
    }
     
    /**
     * Method that gets all the lines from the table that starts with the prefix and returns them concatenated
     * @param strLst the table
     * @param prefix the prefix
     * @return the string with all the lines concatenated
     */
    private String getOneOrMoreLines(String[] strLst, String prefix) {
    	StringBuilder sb = new StringBuilder();
    	for (int i=0; i<strLst.length; i++) {
    		if (strLst[i].length() > 2 && strLst[i].startsWith(prefix)) {
    			sb.append(subStr(strLst[i], 2, strLst[i].length())).append(" ");
    		}
    	}
    	return sb.toString().trim();
	}

	/**
     * Field adresse_bo from tag 50
     * @param tag
     * @return
     */
    public String getMsgAdresseBo(String tag) { 
        //TODO Check        
        String[] strLst = getTag(tag).split("\\r\\n|\\r|\\n");
              
    
        // TODO : Generaliser ce if pour les cas ou il y a plusieurs lignes suffixes par 1/
//        if (strLst.length > 3 && 
//                strLst[2].length() > 2 && strLst[2].startsWith("2/") &&
//                strLst[3].length() > 2 && strLst[3].startsWith("3/")) {
//        	return subStr(strLst[2],2,strLst[2].length()) + " "+ subStr(strLst[3], 2,strLst[3].length());
//        }
        
       String value = StringUtils.EMPTY; 
       //50F
       // Check if the tag is not empty and if the number of lines of the tag is greater than 3
       // Also check if there is at least one line with a length greater than 2 and starting with 2/
       // Also check if there is at least one line with a length greater 2 and starting with 3/
        if(CollectionUtils.isNotEmpty(Arrays.asList(strLst)) && strLst.length > 3
        		&& Arrays.asList(strLst).stream().anyMatch(x -> x.length() > 2 && x.startsWith("2/"))
                && Arrays.asList(strLst).stream().anyMatch(x -> x.length() > 2 && x.startsWith("3/"))) {
        	
        	// Convert String[] to List<String>
        	//filter it on lines with a length greater than 2 and starting with 2/ or 3/
        	// transform each filtered line by suppressing the 2 first characters (2/ or 3/)
        	// Collect result as List<String>
        	// Join all the string in the list with space as result
        	value =  StringUtils.join(
        			Arrays.asList(strLst).stream()
                	.filter(x -> x.length() > 2 && (x.startsWith("2/") || x.startsWith("3/")))
                	.map(x -> subStr(x,2,x.length()))
                	.collect(Collectors.toList()), " ");
    	} 
        //50H & 50K
        else {
            value = getAdresseFromTag(tag);
        }
        return value;
    }
     
    
    /**
     * Field num_cpt_bq_do from tag 52
     * @param tag
     * @return
     */
    public String getMsgNumCptBqDo(String tag) {
        return getNumCptFromTag(tag);        
    }
     
    
    /**
     * Field bic_bq_do from tag 52   
     * @param tag
     * @return
     */
    public String getMsgBicBqDo(String tag) { 
        return getBicFromTag(tag);
    }

    /**
     * Field nom_bq_do from tag 52 
     * @param tag
     * @return
     */
    public String getMsgNomBqDo(String tag) { 
        return getNomFromTag(tag);
    }
     
    /**
     * Field adresse_bq_do from tag 52
     * @param tag
     * @return
     */
    public String getMsgAdresseBqDo(String tag) { 
        return getAdresseFromTag(tag);
    }
    
    /**
     * Field num_cpt_bq_em from tag 53 
     * @param tag
     * @return
     */
    public String getMsgNumCptBqEm(String tag) { 
        return getNumCptFromTag(tag);
    }

    /**
     * Field bic_bq_em from tag 53A 
     * @param tag
     * @return
     */
    public String getMsgBicBqEm(String tag) { 
        return getBicFromTag(tag); 
    }

    /**
     * Field nom_bq_em from tag 53D
     * @param tag
     * @return
     */
    public String getMsgNomBqEm(String tag) { 
        return getNomFromTag(tag);
    }
     
    /**
     * Field adresse_bq_em from tag 53D
     * @param tag
     * @return
     */
    public String getMsgAdresseBqEm(String tag) { 
        return getAdresseFromTag(tag); 
    }
     
    /**
     * Field num_cpt_bq_destfrom tag 54
     * @param tag
     * @return
     */
    public String getMsgNumCptBqDest(String tag) { 
           return getNumCptFromTag(tag);
    }
     
    /**
     * Field bic_bq_dest from tag 54D
     * @param tag
     * @return
     */
    public String getMsgBicBqDest(String tag) { 
      return getBicFromTag(tag);
    }

    /**
     * Field nom_bq_dest from tag 54D
     * @param tag 
     * @return
     */
    public String getMsgNomBqDest(String tag) { 
        return getNomFromTag(tag);
    }
     
    /**
     * Field adresse_bq_dest from tag 54D
     * @param tag
     * @return
     */
    public String getMsgAdresseBqDest(String tag) { 
        return getAdresseFromTag(tag);
    }
    
    
   /**
    * Field num_cpt_bq_int from tag 56
    * @param tag
    * @return
    */
   public String getMsgNumCptBqTie(String tag) { 
       return getNumCptFromTag(tag);
   }
    
    /**
     * Field bic_bq_tie from tag 55A
     * @param tag
     * @return
     */
    public String getMsgBicBqTie(String tag) { 
        return getBicFromTag(tag);
    }

    /**
     * Field nom_bq_tie from tag 55D
     * @param tag
     * @return
     */
    public String getMsgNomBqTie(String tag) { 
        return getNomFromTag(tag);
    }
    
    /**
     * Field adresse_bq_tie from tag 55D
     * @param tag
     * @return
     */
    public String getMsgAdresseBqTie(String tag) { 
        return getAdresseFromTag(tag);
    }
     
    /**
     * Field num_cpt_bq_int from tag 56
     * @param tag
     * @return
     */
    public String getMsgNumCptBqInt(String tag) { 
        return getNumCptFromTag(tag);
    }
     
    /**
     * Field bic_bq_int from tag 56A
     * @param tag
     * @return
     */
    public String getMsgBicBqInt(String tag) { 
        return getBicFromTag(tag); 
    }
    
    /**
     * Field nom_bq_int from tag 56D
     * @param tag
     * @return
     */
    public String getMsgNomBqInt(String tag) { 
        return getNomFromTag(tag);
    }
    
    /**
     * Field adresse_bq_int from tag 56D
     * @param tag
     * @return
     */
    public String getMsgAdresseBqInt(String tag) {
        return getAdresseFromTag(tag);
    }
     
    /**
     * Field num_cpt_bq_du_benef from tag 57
     * @param tag
     * @return
     */
    public String getMsgNumCptBqDuBenef(String tag) { 
        return getNumCptFromTag(tag);
    }
     
    /**
     * Field bic_bq_du_benef from tag 57A
     * @param tag
     * @return
     */
    public String getMsgBicBqDuBenef(String tag) { 
        return getBicFromTag(tag); 
    }

    /**
     * Field nom_bq_du_benef from tag 57D
     * @param tag
     * @return
     */
    public String getMsgNomBqDuBenef(String tag) { 
        return getNomFromTag(tag);
    }
     
    /**
     * Field adresse_bq_du_benef from tag 57D
     * @param tag
     * @return
     */
    public String getMsgAdresseBqDuBenef(String tag) { 
        return getAdresseFromTag(tag); 
    }
     
    /**
     * Field num_cpt_bq_benef from tag 58
     * @param tag
     * @return
     */
    public String getMsgNumCptBqBenef(String tag) { 
        return getNumCptFromTag(tag);
    }
     
    /**
     * Field bic_bq_benef from tag 58A
     * @param tag
     * @return
     */
    public String getMsgBicBqBenef(String tag) { 
         return getBicFromTag(tag);
    }

    /**
     * Field nom_bq_benef from tag 58D
     * @param tag
     * @return
     */
    public String getMsgNomBqBenef(String tag) { 
        return getNomFromTag(tag);
    }
    
    /**
     * Field adresse_bq_benef from tag 58D
     * @param tag
     * @return
     */
    public String getMsgAdresseBqBenef(String tag) { 
        return getAdresseFromTag(tag);
    }
    
    /**
     * Field num_cpt_benef from tag 59D
     * @param tag
     * @return
     */
    public String getMsgNumCptBenef(String tag) { 
        return getNumCptFromTag(tag);
    }
     
    /**
     * Field bic_benef from tag 59A
     * @param tag
     * @return
     */
    public String getMsgBicBenef(String tag) {
        return getBicFromTag(tag);
    }

    /**
     * Field nom_benef from tag 59
     * @param tagValue
     * @return
     */
    public String getMsgNomBenef(String tagValue, String tag ) { 
        //TODO Check
        String[] strLst = getTag(tagValue).split("\\r\\n|\\r|\\n");

        String value = "";

        //59F : return the second line if it starts with 1/
        if (tag.equals("59F"))
        {
        	value = getOneOrMoreLines(strLst, "1/");	
        }
        //59:/  return the second line if it starts with /
        else if (tag.equals("59")) {
        	if (strLst.length > 1 && strLst[1].length() > 0 && strLst[0].startsWith("/") ) {
        	value = strLst[1];
        
        }
        //59: return the first line if it doesn't start with /
        else if (strLst.length > 0 && strLst[0].length() > 0 && ! strLst[0].startsWith("/") ) {
        	value = strLst[0];
       
        		}
        }
        

        return value;
    }
     
    /**
     * Field adresse_benef from tag 59
     * @param tag
     * @return
     */
    public String getMsgAdresseBenef(String tag) { 
        //TODO Check        
        String[] strLst = getTag(tag).split("\\r\\n|\\r|\\n");
        StringBuilder address = new StringBuilder();
        
        //59F
//        if (strLst.length > 3 && 
//                strLst[2].length() > 2 && strLst[2].startsWith("2/") &&
//                strLst[3].length() > 2 && strLst[3].startsWith("3/")) {
//            return subStr(strLst[2],2,strLst[2].length()) + subStr(strLst[3],2,strLst[2].length());
//        }
        
        if(tag.contains("2/") || tag.contains("3/") ) {
	        for(int i = 0; i < strLst.length; i++) {
	        	if(strLst[i].startsWith("2/") || strLst[i].startsWith("3/")) {
	        		address.append(strLst[i].substring(2)).append(" ");
	        	}
	        }
	        return address.toString().trim();
        } else {
            return getAdresseFromTag(tag);
        }
    }
    
    /**
     * Field adresse_benef from tag 59 or 59F
     * @param tag
     * @return
     */
    public String getMsgAdresseBenef(String tag, String tagType) { 
    	   StringBuilder address = new StringBuilder();
    	if((tag!=null && ! tag.trim().equals("")) && (tagType!=null && ! tag.trim().equals(""))) {
    		
    		String[] strLst = getTag(tag).split("\\r\\n|\\r|\\n");
    		
    		switch (tagType) {
			case "59":
				address.append(getAdresseFromTag(tag));
				break;
			case "59F" : 
		        for(int i = 0; i < strLst.length; i++) {
		        	if(strLst[i].startsWith("2/") || strLst[i].startsWith("3/")) {
		        		address.append(strLst[i].substring(2)).append(" ");
		        	}
		        }
				break;
			default:
				break;
			}
    	}
    	
    	return address.toString();
    }
     
    /**
     * Field motif_paiement from tag 70
     * @param tag
     * @return
     */
    public String getMsgMotifPaiement(String tag) { 
        return getTag(tag).replaceAll("(\\r|\\n|\\r\\n)+", " ");
    }
     
    /**
     * Field message_banque from tag 72
     * @param tag
     * @return
     */
    public String getMsgMessageBq(String tag) { 
        return getTag(tag).replaceAll("(\\r|\\n|\\r\\n)+", " "); 
    }
     
    /**
     * Field commentaire from tag 79
     * @param tag
     * @return
     */
    public String getMsgCommentaire(String tag) {
        return getTag(tag).replaceAll("(\\r|\\n|\\r\\n)+", " "); 
    }
     
    /**
     * Field mode_paiement from tag 71A
     * @param tag
     * @return
     */
    public String getMsgModePaiementChg(String tag) {
        String[] strLst = getTag(tag).split("\\r\\n|\\r|\\n");
        String tmp = strLst[0];
        return tmp; 
    }
    
    /**
     * Field detail_charge from tag 71B
     * @param tag
     * @return
     */
    public String getMsgDetailCharge(String tag) { 
        return getTag(tag); 
    }
    
    /**
     * Field devise_ch_em from tag 71F
     * @param tag
     * @return
     */
    public String getMsgDeviseChgEm(String tag) { 
        return subStr(getTag(tag),0,3); 
    }
     
    /**
     * Field mnt_chg_em from tag 71F
     * @param tag
     * @return
     */
    public BigDecimal getMsgMntChgEm(String tag) { 
        return parseBigDecimalTag(subStr(getTag(tag),3,getTag(tag).length()).replace(",", ".")); 
    }

    /**
     * Field devise_ch_benef from tag 71G
     * @param tag
     * @return
     */
    public String getMsgDeviseChgBenef(String tag) { 
        return subStr(getTag(tag),0,3); 
    }
    /**
     * Field mnt_chg_benef from tag 71G
     * @param tag
     * @return
     */
    public BigDecimal getMsgMntChgBenef(String tag){ 
        return parseBigDecimalTag(subStr(getTag(tag),3,getTag(tag).length()).replace(",", ".")); 
    }

}
