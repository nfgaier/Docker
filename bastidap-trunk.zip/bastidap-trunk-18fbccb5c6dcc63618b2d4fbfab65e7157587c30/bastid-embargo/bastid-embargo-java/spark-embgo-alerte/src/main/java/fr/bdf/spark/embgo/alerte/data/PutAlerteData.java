/**
 * 
 */
package fr.bdf.spark.embgo.alerte.data;

import java.io.Serializable;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import fr.bdf.spark.embgo.alerte.constant.LoadAlerteConstant;

public class PutAlerteData implements Serializable {

	private static final long serialVersionUID = 4272287829460699050L;

	private SparkSession session;
	private String caseWhenMOTStr;
	private String caseWhenETATStr;
	private String caseWhenBOStr;
	private String caseWhenINDStr;
	private String tmpTable;

	/**
	 * @param sqlContext
	 * @param caseWhenMOTStr
	 *            : string containing the case when statement for the refMotif
	 *            field
	 * @param caseWhenETATStr
	 *            : string containing the case when statement for the refEtat
	 *            field
	 * @param caseWhenBOStr
	 *            : string containing the case when statement for the
	 *            refBackOffice field
	 * @param caseWhenINDStr
	 *            : string containing the case when statement for the refInd
	 *            field
	 */
	public PutAlerteData(SparkSession session, String caseWhenMOTStr,
			String caseWhenETATStr, String caseWhenBOStr,
			String caseWhenINDStr, String tmpTable) {
		super();
		this.session = session;
		this.caseWhenMOTStr = caseWhenMOTStr;
		this.caseWhenETATStr = caseWhenETATStr;
		this.caseWhenBOStr = caseWhenBOStr;
		this.caseWhenINDStr = caseWhenINDStr;
		this.tmpTable = tmpTable;
	}

	public SparkSession getSession() {
		return session;
	}

	public void setSession(SparkSession session) {
		this.session = session;
	}
	
	/**
	 * Executes a hive a prepared query with the case when statements injected
	 * and returns a DataFrame
	 * @param tmpTableFofaHistMsg
	 * @return DataFrame
	 */
	public Dataset<Row> generateFofaHistMsgWithInd(String tmpTableFofaHistMsg) {

		String caseWhen = this.caseWhenINDStr.replace("type_message", "t_type")
				.replace("date_decision_finale", "t_completed");

		String query = "select tmp.t_system_id,"
				+ "tmp.business_unit_id,"
				+ "tmp.saausrgrp,"
				+ "tmp.t_normamount,"
				+ "tmp.t_app_deadline,"
				+ "tmp.t_app_priority,"
				+ "tmp.t_alignment,"
				+ "tmp.t_confidentiality,"
				+ "tmp.t_priority,"
				+ "tmp.t_type,"
				+ "tmp.t_transaction,"
				+ "tmp.t_toappli,"
				+ "tmp.t_sender,"
				+ "tmp.t_related_ref,"
				+ "tmp.t_receiver,"
				+ "tmp.t_pairing_id,"
				+ "tmp.t_nonblocking,"
				+ "tmp.t_nature,"
				+ "tmp.t_message_id,"
				+ "tmp.t_message,"
				+ "tmp.t_message_upd,"
				+ "tmp.t_i_o,"
				+ "tmp.t_gateway,"
				+ "tmp.t_fromappli,"
				+ "tmp.t_filtered,"
				+ "tmp.t_entity,"
				+ "tmp.t_lastoperator,"
				+ "tmp.t_decision_type,"
				+ "tmp.t_date_value,"
				+ "tmp.t_currency,"
				+ "tmp.t_created,"
				+ "tmp.t_copy_service,"
				+ "tmp.t_completed,"
				+ "tmp.t_bunit,"
				+ "tmp.t_blocking,"
				+ "tmp.t_amount_float,"
				+ "tmp.t_amount,"
				+ "tmp.niveau_decision,"
				+ caseWhen
				+ ","
				+ "tmp.date_ope,"
				+ "tmp.date_insert "
				+ "from "
				+ tmpTableFofaHistMsg
				+ " tmp";

//		System.out.println("generateFofaHistMsgWithInd query: " + query);
		return session.sql(query);
	}

	/**
	 * Executes a hive a prepared query with the case when statements injected
	 * and returns a DataFrame
	 * 
	 * @param idTraitement
	 * @param idAcqFmfUsers the id acquisition for the table FMF_USERS
	 * @return DataFrame
	 */
	public Dataset<Row> generateAlerteData(String idTraitement, String idAcqFmfUsers) {

		String query = "select tmp.id_alerte," + "tmp.dernier_utilisateur,"
				+ "us.t_id," + "tmp.montant_transaction," + "tmp.blocking,"
				+ "tmp.bunit," + "tmp.date_decision_finale,"
				+ "tmp.copy_service," + "tmp.date_creation_transact,"
				+ "tmp.devise_transaction," + "tmp.date_valeur_transact,"
				+ "tmp.decision_finale," + "tmp.niveau_decision,"
				+ this.caseWhenMOTStr
				+ ","
				+ this.caseWhenETATStr
				+ ","
				+ "tmp.bo_gestion,"
				+ this.caseWhenBOStr
				+ ","
				+ "tmp.date_filtre,"
				+ "tmp.saa_origine,"
				+ "tmp.saa_destination,"
				+ "tmp.gateway,"
				+ "tmp.bic_bq_emet,"
				+ "tmp.bic_bq_dest,"
				+ "tmp.ref_related,"
				+ "tmp.ref_transaction,"
				+ "tmp.type_message,"
				+ "tmp.ind_swift_sepa,"
				+ "tmp.sens_flux_e_r,"
				+ "tmp.id_message,"
				+ "tmp.msg_ref_transaction,"
				+ "tmp.msg_code_operation,"
				+ "tmp.msg_date_valeur,"
				+ "tmp.msg_devise_credit,"
				+ "tmp.msg_mnt_credit,"
				+ "tmp.msg_devise_debit,"
				+ "tmp.msg_mnt_debit,"
				+ "tmp.msg_taux_change,"
				+ "tmp.msg_num_cpt_do,"
				+ "tmp.msg_bic_do,"
				+ "tmp.msg_nom_do,"
				+ "tmp.msg_adresse_do,"
				+ "tmp.msg_num_cpt_bq_do,"
				+ "tmp.msg_bic_bq_do,"
				+ "tmp.msg_nom_bq_do,"
				+ "tmp.msg_adresse_bq_do,"
				+ "tmp.msg_num_cpt_bq_em,"
				+ "tmp.msg_bic_bq_em,"
				+ "tmp.msg_nom_bq_em,"
				+ "tmp.msg_adresse_bq_em,"
				+ "tmp.msg_num_cpt_bq_dest,"
				+ "tmp.msg_bic_bq_dest,"
				+ "tmp.msg_nom_bq_dest,"
				+ "tmp.msg_adresse_bq_dest,"
				+ "tmp.msg_num_cpt_bq_tie,"
				+ "tmp.msg_bic_bq_tie,"
				+ "tmp.msg_nom_bq_tie,"
				+ "tmp.msg_adresse_bq_tie,"
				+ "tmp.msg_num_cpt_bq_int,"
				+ "tmp.msg_bic_bq_int,"
				+ "tmp.msg_nom_bq_int,"
				+ "tmp.msg_adresse_bq_int,"
				+ "tmp.msg_num_cpt_bq_du_benef,"
				+ "tmp.msg_bic_bq_du_benef,"
				+ "tmp.msg_nom_bq_du_benef,"
				+ "tmp.msg_adresse_bq_du_benef,"
				+ "tmp.msg_num_cpt_bq_benef,"
				+ "tmp.msg_bic_bq_benef,"
				+ "tmp.msg_nom_bq_benef,"
				+ "tmp.msg_adresse_bq_benef,"
				+ "tmp.msg_num_cpt_benef,"
				+ "tmp.msg_bic_benef,"
				+ "tmp.msg_nom_benef,"
				+ "tmp.msg_adresse_benef,"
				+ "tmp.msg_motif_paiement,"
				+ "tmp.msg_message_bq,"
				+ "tmp.msg_commentaire,"
				+ "tmp.msg_mode_paiement_chg,"
				+ "tmp.msg_detail_charge,"
				+ "tmp.msg_devise_chg_em,"
				+ "tmp.msg_mnt_chg_em,"
				+ "tmp.msg_devise_chg_benef,"
				+ "tmp.msg_mnt_chg_benef,"
				+ "tmp.message_clob,"
				+ "tmp.nature,"
				+ "tmp.nonblocking,"
				+ "tmp.id_pairing,"
				+ "tmp.priorite,"
				+ "tmp.confidentialite,"
				+ "tmp.alignement,"
				+ "tmp.app_priority,"
				+ "tmp.app_deadline,"
				+ "tmp.normamount,"
				+ "tmp.saausrgrp,"
				+ "tmp.id_business_unit, "
				+ "tmp.date_ope as date_ope,"
				+ "tmp.date_insert as date_insert,"
				+ "'"
				+ idTraitement
				+ "'"
				+ " as id_traitement "
				+ "from "
				+ tmpTable
				+ " tmp "
				+ "left join embargo_raw_layer.FMF_USERS us on (tmp.dernier_utilisateur = us.t_login and us.id_traitement = '"+idAcqFmfUsers+"')";

		// System.out.println("Result query: " + query);
		return session.sql(query);
	}

	/**
	 * Writes DataFrame to path and creates a partition in the target table
	 * 
	 * @param path
	 *            :
	 * @param data
	 * @param idTraitement
	 */
	public void writeAlerteData(String path, String workLayerHiveBase,
			Dataset<Row> data, String idTraitement) {

		// LOGS FOR TESTING
		System.out.println("Id_traitement before writing : " + idTraitement);
		System.out.println("Path to write " + path);
		// System.out.println("Data to write : ");
		// data.show();

		// write to path
		data.write().partitionBy("id_traitement").format("orc").mode("append")
				.save(path + LoadAlerteConstant.TABLE_ALERTE);
		// add partition
		String alterTable = "ALTER TABLE " + workLayerHiveBase + "."
				+ LoadAlerteConstant.TABLE_ALERTE
				+ " ADD IF NOT EXISTS PARTITION (id_traitement='"
				+ idTraitement + "') location '" + path
				+ LoadAlerteConstant.TABLE_ALERTE + "/id_traitement="
				+ idTraitement + "'";
		session.sql(alterTable);

		System.out.println("Alter table : " + alterTable);

	}
}
