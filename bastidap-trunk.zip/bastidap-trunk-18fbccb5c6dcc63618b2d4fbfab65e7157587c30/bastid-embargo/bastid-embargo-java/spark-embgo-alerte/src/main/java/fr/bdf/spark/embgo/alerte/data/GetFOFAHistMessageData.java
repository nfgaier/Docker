/**
 * 
 */
package fr.bdf.spark.embgo.alerte.data;

import java.io.Serializable;
import java.util.List;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import fr.bdf.bastid.util.bean.LineAcqFile;
import fr.bdf.spark.embgo.alerte.constant.LoadAlerteConstant;


public class GetFOFAHistMessageData implements Serializable {


    private static final long serialVersionUID = 3189184834287715461L;

    
    private SparkSession session;


    /**
     * @param sqlContext
     */
    public GetFOFAHistMessageData(SparkSession session) {
        super();
        this.setSession(session);
    }


  
    public SparkSession getSession() {
		return session;
	}





	public void setSession(SparkSession session) {
		this.session = session;
	}





	public Dataset<Row> getFOFAHistMessageData(List<LineAcqFile> listIdAcq, String rawLayerHiveBase) {
        
        return session.sql("select t_system_id," + 
                "cast (business_unit_id as double) business_unit_id," + 
                "saausrgrp," + 
                "cast (t_normamount as double) t_normamount," + 
                "concat(regexp_replace(cast(t_app_deadline as string),'-','/'),' 00:00:00') t_app_deadline," + 
                "cast (t_app_priority as double) t_app_priority," + 
                "t_alignment," + 
                "cast (t_confidentiality as double) t_confidentiality," + 
                "cast (t_priority as double) t_priority," + 
                "t_type," + 
                "t_transaction," + 
                "t_toappli," + 
                "t_sender," + 
                "t_related_ref," + 
                "t_receiver," + 
                "t_pairing_id," + 
                "cast (t_nonblocking as double) t_nonblocking," + 
                "t_nature," + 
                "t_message_id," + 
                "t_message," + 
                "concat(concat('{1:F01XXXXXXXXXXXX0101010101}{2:I101YOURBANKXJKLU3003}{4:\n' ,t_message),'\n-}') t_message_upd," + 
                "t_i_o," + 
                "t_gateway," + 
                "t_fromappli," + 
                "t_filtered," + 
                "t_entity," + 
                "t_lastoperator," + 
                "t_decision_type," + 
                "case when LENGTH(t_date_value)=10 then CONCAT(t_date_value,' 00:00:00') else t_date_value end t_date_value," + 
                "t_currency," + 
                "t_created," + 
                "t_copy_service," + 
                "t_completed," + 
                "t_bunit," + 
                "cast (t_blocking as double) t_blocking," + 
                "t_amount_float," + 
                "t_amount," +
                "date_ope," +
                "date_insert," +
                "id_traitement" +
           " from " + rawLayerHiveBase + "." +  LoadAlerteConstant.FOFA_HIST_MES + 
           this.getWhereClause(listIdAcq));
    }


	/**
	 * Method that constructs the where part of the request. 
	 * @param listIdAcq the list of id_acquisition / date_ope for FOFA_HIST_MESSAGE
	 * @return the where part of the request
	 */
	private String getWhereClause(List<LineAcqFile> listIdAcq) {
		StringBuilder sb = new StringBuilder(" WHERE");
		for (LineAcqFile lineAlerte : listIdAcq) {
			sb.append(" (date_ope = '").append(lineAlerte.getJourFonc())
			.append("' AND id_traitement = '").append(lineAlerte.getIdAcq()).append("') OR");
		}
		
		return sb.substring(0, sb.length() - 3);
	}
    
}
