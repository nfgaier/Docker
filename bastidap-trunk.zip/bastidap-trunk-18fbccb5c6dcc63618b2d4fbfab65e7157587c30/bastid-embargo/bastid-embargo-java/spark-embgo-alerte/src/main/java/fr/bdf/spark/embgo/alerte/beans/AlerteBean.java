/**
 * 
 */
package fr.bdf.spark.embgo.alerte.beans;

import java.io.Serializable;
import java.math.BigDecimal;


public class AlerteBean implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -1863445417011928930L;

    
    private String id_alerte;
    private String dernier_utilisateur;
    private BigDecimal id_utilisateur;
    private BigDecimal montant_transaction;
    private BigDecimal blocking;   
    private String bunit; 
    private java.sql.Timestamp date_decision_finale;
    private String copy_service;  
    private java.sql.Timestamp date_creation_transact;
    private String devise_transaction;
    private java.sql.Timestamp date_valeur_transact;
    private String decision_finale;
    private String niveau_decision;
    private String motif_decision;
    private String etat;
    private String bo_gestion;
    private String back_office;
    private java.sql.Timestamp date_filtre;
    private String saa_origine;
    private String saa_destination;
    private String gateway; 
    private String bic_bq_emet;
    private String bic_bq_dest;
    private String ref_related; 
    private String ref_transaction;
    private String type_message;
    private String ind_swift_sepa;
    private String sens_flux_e_r;
    private String id_message; 
    private String msg_ref_transaction;
    private String msg_code_operation;
    private java.sql.Date msg_date_valeur;
    private String msg_devise_credit;
    private BigDecimal msg_mnt_credit;
    private String msg_devise_debit;
    private BigDecimal msg_mnt_debit;
    private BigDecimal msg_taux_change;
    private String msg_num_cpt_do; 
    private String msg_bic_do;
    private String msg_nom_do; 
    private String msg_adresse_do; 
    private String msg_num_cpt_bq_do; 
    private String msg_bic_bq_do;
    private String msg_nom_bq_do; 
    private String msg_adresse_bq_do; 
    private String msg_num_cpt_bq_em; 
    private String msg_bic_bq_em;
    private String msg_nom_bq_em; 
    private String msg_adresse_bq_em; 
    private String msg_num_cpt_bq_dest; 
    private String msg_bic_bq_dest;
    private String msg_nom_bq_dest; 
    private String msg_adresse_bq_dest; 
    private String msg_num_cpt_bq_tie;
    private String msg_bic_bq_tie;
    private String msg_nom_bq_tie; 
    private String msg_adresse_bq_tie; 
    private String msg_num_cpt_bq_int; 
    private String msg_bic_bq_int;
    private String msg_nom_bq_int; 
    private String msg_adresse_bq_int; 
    private String msg_num_cpt_bq_du_benef; 
    private String msg_bic_bq_du_benef;
    private String msg_nom_bq_du_benef; 
    private String msg_adresse_bq_du_benef; 
    private String msg_num_cpt_bq_benef; 
    private String msg_bic_bq_benef;
    private String msg_nom_bq_benef; 
    private String msg_adresse_bq_benef; 
    private String msg_num_cpt_benef; 
    private String msg_bic_benef;
    private String msg_nom_benef; 
    private String msg_adresse_benef; 
    private String msg_motif_paiement; 
    private String msg_message_bq; 
    private String msg_commentaire; 
    private String msg_mode_paiement_chg; 
    private String msg_detail_charge; 
    private String msg_devise_chg_em; 
    private BigDecimal msg_mnt_chg_em;
    private String msg_devise_chg_benef; 
    private BigDecimal msg_mnt_chg_benef;
    private String message_clob;
    private String nature; 
    private BigDecimal nonblocking;   
    private String id_pairing; 
    private BigDecimal priorite;   
    private BigDecimal confidentialite;  
    private String alignement;  
    private BigDecimal app_priority;  
    private java.sql.Timestamp app_deadline;         
    private BigDecimal normamount;  
    private String saausrgrp; 
    private BigDecimal id_business_unit;
    private java.sql.Date date_ope;
    private java.sql.Date date_insert;
    
    /**
     * @return the id_alerte
     */
    public String getId_alerte() {
        return id_alerte;
    }
    /**
     * @param id_alerte la valeur de id_alerte à attribuer.
     */
    public void setId_alerte(String id_alerte) {
        this.id_alerte = id_alerte;
    }
    /**
     * @return the dernier_utilisateur
     */
    public String getDernier_utilisateur() {
        return dernier_utilisateur;
    }
    /**
     * @param dernier_utilisateur la valeur de dernier_utilisateur à attribuer.
     */
    public void setDernier_utilisateur(String dernier_utilisateur) {
        this.dernier_utilisateur = dernier_utilisateur;
    }
    /**
     * @return the id_utilisateur
     */
    public BigDecimal getId_utilisateur() {
        return id_utilisateur;
    }
    /**
     * @param id_utilisateur la valeur de id_utilisateur à attribuer.
     */
    public void setId_utilisateur(BigDecimal id_utilisateur) {
        this.id_utilisateur = id_utilisateur;
    }
    /**
     * @return the montant_transaction
     */
    public BigDecimal getMontant_transaction() {
        return montant_transaction;
    }
    /**
     * @param montant_transaction la valeur de montant_transaction à attribuer.
     */
    public void setMontant_transaction(BigDecimal montant_transaction) {
        this.montant_transaction = montant_transaction;
    }
    /**
     * @return the blocking
     */
    public BigDecimal getBlocking() {
        return blocking;
    }
    /**
     * @param blocking la valeur de blocking à attribuer.
     */
    public void setBlocking(BigDecimal blocking) {
        this.blocking = blocking;
    }
    /**
     * @return the bunit
     */
    public String getBunit() {
        return bunit;
    }
    /**
     * @param bunit la valeur de bunit à attribuer.
     */
    public void setBunit(String bunit) {
        this.bunit = bunit;
    }
    /**
     * @return the date_decision_finale
     */
    public java.sql.Timestamp getDate_decision_finale() {
        return date_decision_finale;
    }
    /**
     * @param date_decision_finale la valeur de date_decision_finale à attribuer.
     */
    public void setDate_decision_finale(java.sql.Timestamp date_decision_finale) {
        this.date_decision_finale = date_decision_finale;
    }
    /**
     * @return the copy_service
     */
    public String getCopy_service() {
        return copy_service;
    }
    /**
     * @param copy_service la valeur de copy_service à attribuer.
     */
    public void setCopy_service(String copy_service) {
        this.copy_service = copy_service;
    }
    /**
     * @return the date_creation_transact
     */
    public java.sql.Timestamp getDate_creation_transact() {
        return date_creation_transact;
    }
    /**
     * @param date_creation_transact la valeur de date_creation_transact à attribuer.
     */
    public void setDate_creation_transact(java.sql.Timestamp date_creation_transact) {
        this.date_creation_transact = date_creation_transact;
    }
    /**
     * @return the devise_transaction
     */
    public String getDevise_transaction() {
        return devise_transaction;
    }
    /**
     * @param devise_transaction la valeur de devise_transaction à attribuer.
     */
    public void setDevise_transaction(String devise_transaction) {
        this.devise_transaction = devise_transaction;
    }
    /**
     * @return the date_valeur_transact
     */
    public java.sql.Timestamp getDate_valeur_transact() {
        return date_valeur_transact;
    }
    /**
     * @param date_valeur_transact la valeur de date_valeur_transact à attribuer.
     */
    public void setDate_valeur_transact(java.sql.Timestamp date_valeur_transact) {
        this.date_valeur_transact = date_valeur_transact;
    }
    /**
     * @return the decision_finale
     */
    public String getDecision_finale() {
        return decision_finale;
    }
    /**
     * @param decision_finale la valeur de decision_finale à attribuer.
     */
    public void setDecision_finale(String decision_finale) {
        this.decision_finale = decision_finale;
    }
    /**
     * @return the niveau_decision
     */
    public String getNiveau_decision() {
        return niveau_decision;
    }
    /**
     * @param niveau_decision la valeur de niveau_decision à attribuer.
     */
    public void setNiveau_decision(String niveau_decision) {
        this.niveau_decision = niveau_decision;
    }
    /**
     * @return the motif_decision
     */
    public String getMotif_decision() {
        return motif_decision;
    }
    /**
     * @param motif_decision la valeur de motif_decision à attribuer.
     */
    public void setMotif_decision(String motif_decision) {
        this.motif_decision = motif_decision;
    }
    /**
     * @return the etat
     */
    public String getEtat() {
        return etat;
    }
    /**
     * @param etat la valeur de etat à attribuer.
     */
    public void setEtat(String etat) {
        this.etat = etat;
    }
    /**
     * @return the bo_gestion
     */
    public String getBo_gestion() {
        return bo_gestion;
    }
    /**
     * @param bo_gestion la valeur de bo_gestion à attribuer.
     */
    public void setBo_gestion(String bo_gestion) {
        this.bo_gestion = bo_gestion;
    }
    /**
     * @return the back_office
     */
    public String getBack_office() {
        return back_office;
    }
    /**
     * @param back_office la valeur de back_office à attribuer.
     */
    public void setBack_office(String back_office) {
        this.back_office = back_office;
    }
    /**
     * @return the date_filtre
     */
    public java.sql.Timestamp getDate_filtre() {
        return date_filtre;
    }
    /**
     * @param date_filtre la valeur de date_filtre à attribuer.
     */
    public void setDate_filtre(java.sql.Timestamp date_filtre) {
        this.date_filtre = date_filtre;
    }
    /**
     * @return the saa_origine
     */
    public String getSaa_origine() {
        return saa_origine;
    }
    /**
     * @param saa_origine la valeur de saa_origine à attribuer.
     */
    public void setSaa_origine(String saa_origine) {
        this.saa_origine = saa_origine;
    }
    /**
     * @return the saa_destination
     */
    public String getSaa_destination() {
        return saa_destination;
    }
    /**
     * @param saa_destination la valeur de saa_destination à attribuer.
     */
    public void setSaa_destination(String saa_destination) {
        this.saa_destination = saa_destination;
    }
    /**
     * @return the gateway
     */
    public String getGateway() {
        return gateway;
    }
    /**
     * @param gateway la valeur de gateway à attribuer.
     */
    public void setGateway(String gateway) {
        this.gateway = gateway;
    }
    /**
     * @return the bic_bq_emet
     */
    public String getBic_bq_emet() {
        return bic_bq_emet;
    }
    /**
     * @param bic_bq_emet la valeur de bic_bq_emet à attribuer.
     */
    public void setBic_bq_emet(String bic_bq_emet) {
        this.bic_bq_emet = bic_bq_emet;
    }
    /**
     * @return the bic_bq_dest
     */
    public String getBic_bq_dest() {
        return bic_bq_dest;
    }
    /**
     * @param bic_bq_dest la valeur de bic_bq_dest à attribuer.
     */
    public void setBic_bq_dest(String bic_bq_dest) {
        this.bic_bq_dest = bic_bq_dest;
    }
    /**
     * @return the ref_related
     */
    public String getRef_related() {
        return ref_related;
    }
    /**
     * @param ref_related la valeur de ref_related à attribuer.
     */
    public void setRef_related(String ref_related) {
        this.ref_related = ref_related;
    }
    /**
     * @return the ref_transaction
     */
    public String getRef_transaction() {
        return ref_transaction;
    }
    /**
     * @param ref_transaction la valeur de ref_transaction à attribuer.
     */
    public void setRef_transaction(String ref_transaction) {
        this.ref_transaction = ref_transaction;
    }
    /**
     * @return the type_message
     */
    public String getType_message() {
        return type_message;
    }
    /**
     * @param type_message la valeur de type_message à attribuer.
     */
    public void setType_message(String type_message) {
        this.type_message = type_message;
    }
    /**
     * @return the ind_swift_sepa
     */
    public String getInd_swift_sepa() {
        return ind_swift_sepa;
    }
    /**
     * @param ind_swift_sepa la valeur de ind_swift_sepa à attribuer.
     */
    public void setInd_swift_sepa(String ind_swift_sepa) {
        this.ind_swift_sepa = ind_swift_sepa;
    }
    /**
     * @return the sens_flux_e_r
     */
    public String getSens_flux_e_r() {
        return sens_flux_e_r;
    }
    /**
     * @param sens_flux_e_r la valeur de sens_flux_e_r à attribuer.
     */
    public void setSens_flux_e_r(String sens_flux_e_r) {
        this.sens_flux_e_r = sens_flux_e_r;
    }
    /**
     * @return the id_message
     */
    public String getId_message() {
        return id_message;
    }
    /**
     * @param id_message la valeur de id_message à attribuer.
     */
    public void setId_message(String id_message) {
        this.id_message = id_message;
    }
    /**
     * @return the msg_ref_transaction
     */
    public String getMsg_ref_transaction() {
        return msg_ref_transaction;
    }
    /**
     * @param msg_ref_transaction la valeur de msg_ref_transaction à attribuer.
     */
    public void setMsg_ref_transaction(String msg_ref_transaction) {
        this.msg_ref_transaction = msg_ref_transaction;
    }
    /**
     * @return the msg_code_operation
     */
    public String getMsg_code_operation() {
        return msg_code_operation;
    }
    /**
     * @param msg_code_operation la valeur de msg_code_operation à attribuer.
     */
    public void setMsg_code_operation(String msg_code_operation) {
        this.msg_code_operation = msg_code_operation;
    }
    /**
     * @return the msg_date_valeur
     */
    public java.sql.Date getMsg_date_valeur() {
        return msg_date_valeur;
    }
    /**
     * @param msg_date_valeur la valeur de msg_date_valeur à attribuer.
     */
    public void setMsg_date_valeur(java.sql.Date msg_date_valeur) {
        this.msg_date_valeur = msg_date_valeur;
    }
    /**
     * @return the msg_devise_credit
     */
    public String getMsg_devise_credit() {
        return msg_devise_credit;
    }
    /**
     * @param msg_devise_credit la valeur de msg_devise_credit à attribuer.
     */
    public void setMsg_devise_credit(String msg_devise_credit) {
        this.msg_devise_credit = msg_devise_credit;
    }
    /**
     * @return the msg_mnt_credit
     */
    public BigDecimal getMsg_mnt_credit() {
        return msg_mnt_credit;
    }
    /**
     * @param msg_mnt_credit la valeur de msg_mnt_credit à attribuer.
     */
    public void setMsg_mnt_credit(BigDecimal msg_mnt_credit) {
        this.msg_mnt_credit = msg_mnt_credit;
    }
    /**
     * @return the msg_devise_debit
     */
    public String getMsg_devise_debit() {
        return msg_devise_debit;
    }
    /**
     * @param msg_devise_debit la valeur de msg_devise_debit à attribuer.
     */
    public void setMsg_devise_debit(String msg_devise_debit) {
        this.msg_devise_debit = msg_devise_debit;
    }
    /**
     * @return the msg_mnt_debit
     */
    public BigDecimal getMsg_mnt_debit() {
        return msg_mnt_debit;
    }
    /**
     * @param msg_mnt_debit la valeur de msg_mnt_debit à attribuer.
     */
    public void setMsg_mnt_debit(BigDecimal msg_mnt_debit) {
        this.msg_mnt_debit = msg_mnt_debit;
    }
    /**
     * @return the msg_taux_change
     */
    public BigDecimal getMsg_taux_change() {
        return msg_taux_change;
    }
    /**
     * @param msg_taux_change la valeur de msg_taux_change à attribuer.
     */
    public void setMsg_taux_change(BigDecimal msg_taux_change) {
        this.msg_taux_change = msg_taux_change;
    }
    /**
     * @return the msg_num_cpt_do
     */
    public String getMsg_num_cpt_do() {
        return msg_num_cpt_do;
    }
    /**
     * @param msg_num_cpt_do la valeur de msg_num_cpt_do à attribuer.
     */
    public void setMsg_num_cpt_do(String msg_num_cpt_do) {
        this.msg_num_cpt_do = msg_num_cpt_do;
    }
    /**
     * @return the msg_bic_do
     */
    public String getMsg_bic_do() {
        return msg_bic_do;
    }
    /**
     * @param msg_bic_do la valeur de msg_bic_do à attribuer.
     */
    public void setMsg_bic_do(String msg_bic_do) {
        this.msg_bic_do = msg_bic_do;
    }
    /**
     * @return the msg_nom_do
     */
    public String getMsg_nom_do() {
        return msg_nom_do;
    }
    /**
     * @param msg_nom_do la valeur de msg_nom_do à attribuer.
     */
    public void setMsg_nom_do(String msg_nom_do) {
        this.msg_nom_do = msg_nom_do;
    }
    /**
     * @return the msg_adresse_bo
     */
    public String getMsg_adresse_do() {
        return msg_adresse_do;
    }
    /**
     * @param msg_adresse_bo la valeur de msg_adresse_bo à attribuer.
     */
    public void setMsg_adresse_do(String msg_adresse_do) {
        this.msg_adresse_do = msg_adresse_do;
    }
    /**
     * @return the msg_num_cpt_bq_do
     */
    public String getMsg_num_cpt_bq_do() {
        return msg_num_cpt_bq_do;
    }
    /**
     * @param msg_num_cpt_bq_do la valeur de msg_num_cpt_bq_do à attribuer.
     */
    public void setMsg_num_cpt_bq_do(String msg_num_cpt_bq_do) {
        this.msg_num_cpt_bq_do = msg_num_cpt_bq_do;
    }
    /**
     * @return the msg_bic_bq_do
     */
    public String getMsg_bic_bq_do() {
        return msg_bic_bq_do;
    }
    /**
     * @param msg_bic_bq_do la valeur de msg_bic_bq_do à attribuer.
     */
    public void setMsg_bic_bq_do(String msg_bic_bq_do) {
        this.msg_bic_bq_do = msg_bic_bq_do;
    }
    /**
     * @return the msg_nom_bq_do
     */
    public String getMsg_nom_bq_do() {
        return msg_nom_bq_do;
    }
    /**
     * @param msg_nom_bq_do la valeur de msg_nom_bq_do à attribuer.
     */
    public void setMsg_nom_bq_do(String msg_nom_bq_do) {
        this.msg_nom_bq_do = msg_nom_bq_do;
    }
    /**
     * @return the msg_adresse_bq_do
     */
    public String getMsg_adresse_bq_do() {
        return msg_adresse_bq_do;
    }
    /**
     * @param msg_adresse_bq_do la valeur de msg_adresse_bq_do à attribuer.
     */
    public void setMsg_adresse_bq_do(String msg_adresse_bq_do) {
        this.msg_adresse_bq_do = msg_adresse_bq_do;
    }
    /**
     * @return the msg_num_cpt_bq_em
     */
    public String getMsg_num_cpt_bq_em() {
        return msg_num_cpt_bq_em;
    }
    /**
     * @param msg_num_cpt_bq_em la valeur de msg_num_cpt_bq_em à attribuer.
     */
    public void setMsg_num_cpt_bq_em(String msg_num_cpt_bq_em) {
        this.msg_num_cpt_bq_em = msg_num_cpt_bq_em;
    }
    /**
     * @return the msg_bic_bq_em
     */
    public String getMsg_bic_bq_em() {
        return msg_bic_bq_em;
    }
    /**
     * @param msg_bic_bq_em la valeur de msg_bic_bq_em à attribuer.
     */
    public void setMsg_bic_bq_em(String msg_bic_bq_em) {
        this.msg_bic_bq_em = msg_bic_bq_em;
    }
    /**
     * @return the msg_nom_bq_em
     */
    public String getMsg_nom_bq_em() {
        return msg_nom_bq_em;
    }
    /**
     * @param msg_nom_bq_em la valeur de msg_nom_bq_em à attribuer.
     */
    public void setMsg_nom_bq_em(String msg_nom_bq_em) {
        this.msg_nom_bq_em = msg_nom_bq_em;
    }
    /**
     * @return the msg_adresse_bq_em
     */
    public String getMsg_adresse_bq_em() {
        return msg_adresse_bq_em;
    }
    /**
     * @param msg_adresse_bq_em la valeur de msg_adresse_bq_em à attribuer.
     */
    public void setMsg_adresse_bq_em(String msg_adresse_bq_em) {
        this.msg_adresse_bq_em = msg_adresse_bq_em;
    }
    /**
     * @return the msg_num_cpt_bq_dest
     */
    public String getMsg_num_cpt_bq_dest() {
        return msg_num_cpt_bq_dest;
    }
    /**
     * @param msg_num_cpt_bq_dest la valeur de msg_num_cpt_bq_dest à attribuer.
     */
    public void setMsg_num_cpt_bq_dest(String msg_num_cpt_bq_dest) {
        this.msg_num_cpt_bq_dest = msg_num_cpt_bq_dest;
    }
    /**
     * @return the msg_bic_bq_dest
     */
    public String getMsg_bic_bq_dest() {
        return msg_bic_bq_dest;
    }
    /**
     * @param msg_bic_bq_dest la valeur de msg_bic_bq_dest à attribuer.
     */
    public void setMsg_bic_bq_dest(String msg_bic_bq_dest) {
        this.msg_bic_bq_dest = msg_bic_bq_dest;
    }
    /**
     * @return the msg_nom_bq_dest
     */
    public String getMsg_nom_bq_dest() {
        return msg_nom_bq_dest;
    }
    /**
     * @param msg_nom_bq_dest la valeur de msg_nom_bq_dest à attribuer.
     */
    public void setMsg_nom_bq_dest(String msg_nom_bq_dest) {
        this.msg_nom_bq_dest = msg_nom_bq_dest;
    }
    /**
     * @return the msg_adresse_bq_dest
     */
    public String getMsg_adresse_bq_dest() {
        return msg_adresse_bq_dest;
    }
    /**
     * @param msg_adresse_bq_dest la valeur de msg_adresse_bq_dest à attribuer.
     */
    public void setMsg_adresse_bq_dest(String msg_adresse_bq_dest) {
        this.msg_adresse_bq_dest = msg_adresse_bq_dest;
    }
    
	/**
     * @return the msg_num_cpt_bq_tie
     */
    public String getMsg_num_cpt_bq_tie() {
		return msg_num_cpt_bq_tie;
	}
    
    /**
     * @param msg_num_cpt_bq_tie la valeur de msg_num_cpt_bq_tie à attribuer.
     */
	public void setMsg_num_cpt_bq_tie(String msg_num_cpt_bq_tie) {
		this.msg_num_cpt_bq_tie = msg_num_cpt_bq_tie;
	}
    
    /**
     * @return the msg_bic_bq_tie
     */
    public String getMsg_bic_bq_tie() {
        return msg_bic_bq_tie;
    }
    /**
     * @param msg_bic_bq_tie la valeur de msg_bic_bq_tie à attribuer.
     */
    public void setMsg_bic_bq_tie(String msg_bic_bq_tie) {
        this.msg_bic_bq_tie = msg_bic_bq_tie;
    }
    /**
     * @return the msg_nom_bq_tie
     */
    public String getMsg_nom_bq_tie() {
        return msg_nom_bq_tie;
    }
    /**
     * @param msg_nom_bq_tie la valeur de msg_nom_bq_tie à attribuer.
     */
    public void setMsg_nom_bq_tie(String msg_nom_bq_tie) {
        this.msg_nom_bq_tie = msg_nom_bq_tie;
    }
    /**
     * @return the msg_adresse_bq_tie
     */
    public String getMsg_adresse_bq_tie() {
        return msg_adresse_bq_tie;
    }
    /**
     * @param msg_adresse_bq_tie la valeur de msg_adresse_bq_tie à attribuer.
     */
    public void setMsg_adresse_bq_tie(String msg_adresse_bq_tie) {
        this.msg_adresse_bq_tie = msg_adresse_bq_tie;
    }
    /**
     * @return the msg_num_cpt_bq_int
     */
    public String getMsg_num_cpt_bq_int() {
        return msg_num_cpt_bq_int;
    }
    /**
     * @param msg_num_cpt_bq_int la valeur de msg_num_cpt_bq_int à attribuer.
     */
    public void setMsg_num_cpt_bq_int(String msg_num_cpt_bq_int) {
        this.msg_num_cpt_bq_int = msg_num_cpt_bq_int;
    }
    /**
     * @return the msg_bic_bq_int
     */
    public String getMsg_bic_bq_int() {
        return msg_bic_bq_int;
    }
    /**
     * @param msg_bic_bq_int la valeur de msg_bic_bq_int à attribuer.
     */
    public void setMsg_bic_bq_int(String msg_bic_bq_int) {
        this.msg_bic_bq_int = msg_bic_bq_int;
    }
    /**
     * @return the msg_nom_bq_int
     */
    public String getMsg_nom_bq_int() {
        return msg_nom_bq_int;
    }
    /**
     * @param msg_nom_bq_int la valeur de msg_nom_bq_int à attribuer.
     */
    public void setMsg_nom_bq_int(String msg_nom_bq_int) {
        this.msg_nom_bq_int = msg_nom_bq_int;
    }
    /**
     * @return the msg_adresse_bq_int
     */
    public String getMsg_adresse_bq_int() {
        return msg_adresse_bq_int;
    }
    /**
     * @param msg_adresse_bq_int la valeur de msg_adresse_bq_int à attribuer.
     */
    public void setMsg_adresse_bq_int(String msg_adresse_bq_int) {
        this.msg_adresse_bq_int = msg_adresse_bq_int;
    }
    /**
     * @return the msg_num_cpt_bq_du_benef
     */
    public String getMsg_num_cpt_bq_du_benef() {
        return msg_num_cpt_bq_du_benef;
    }
    /**
     * @param msg_num_cpt_bq_du_benef la valeur de msg_num_cpt_bq_du_benef à attribuer.
     */
    public void setMsg_num_cpt_bq_du_benef(String msg_num_cpt_bq_du_benef) {
        this.msg_num_cpt_bq_du_benef = msg_num_cpt_bq_du_benef;
    }
    /**
     * @return the msg_bic_bq_du_benef
     */
    public String getMsg_bic_bq_du_benef() {
        return msg_bic_bq_du_benef;
    }
    /**
     * @param msg_bic_bq_du_benef la valeur de msg_bic_bq_du_benef à attribuer.
     */
    public void setMsg_bic_bq_du_benef(String msg_bic_bq_du_benef) {
        this.msg_bic_bq_du_benef = msg_bic_bq_du_benef;
    }
    /**
     * @return the msg_nom_bq_du_benef
     */
    public String getMsg_nom_bq_du_benef() {
        return msg_nom_bq_du_benef;
    }
    /**
     * @param msg_nom_bq_du_benef la valeur de msg_nom_bq_du_benef à attribuer.
     */
    public void setMsg_nom_bq_du_benef(String msg_nom_bq_du_benef) {
        this.msg_nom_bq_du_benef = msg_nom_bq_du_benef;
    }
    /**
     * @return the msg_adresse_bq_du_benef
     */
    public String getMsg_adresse_bq_du_benef() {
        return msg_adresse_bq_du_benef;
    }
    /**
     * @param msg_adresse_bq_du_benef la valeur de msg_adresse_bq_du_benef à attribuer.
     */
    public void setMsg_adresse_bq_du_benef(String msg_adresse_bq_du_benef) {
        this.msg_adresse_bq_du_benef = msg_adresse_bq_du_benef;
    }
    /**
     * @return the msg_num_cpt_bq_benef
     */
    public String getMsg_num_cpt_bq_benef() {
        return msg_num_cpt_bq_benef;
    }
    /**
     * @param msg_num_cpt_bq_benef la valeur de msg_num_cpt_bq_benef à attribuer.
     */
    public void setMsg_num_cpt_bq_benef(String msg_num_cpt_bq_benef) {
        this.msg_num_cpt_bq_benef = msg_num_cpt_bq_benef;
    }
    /**
     * @return the msg_bic_bq_benef
     */
    public String getMsg_bic_bq_benef() {
        return msg_bic_bq_benef;
    }
    /**
     * @param msg_bic_bq_benef la valeur de msg_bic_bq_benef à attribuer.
     */
    public void setMsg_bic_bq_benef(String msg_bic_bq_benef) {
        this.msg_bic_bq_benef = msg_bic_bq_benef;
    }
    /**
     * @return the msg_nom_bq_benef
     */
    public String getMsg_nom_bq_benef() {
        return msg_nom_bq_benef;
    }
    /**
     * @param msg_nom_bq_benef la valeur de msg_nom_bq_benef à attribuer.
     */
    public void setMsg_nom_bq_benef(String msg_nom_bq_benef) {
        this.msg_nom_bq_benef = msg_nom_bq_benef;
    }
    /**
     * @return the msg_adresse_bq_benef
     */
    public String getMsg_adresse_bq_benef() {
        return msg_adresse_bq_benef;
    }
    /**
     * @param msg_adresse_bq_benef la valeur de msg_adresse_bq_benef à attribuer.
     */
    public void setMsg_adresse_bq_benef(String msg_adresse_bq_benef) {
        this.msg_adresse_bq_benef = msg_adresse_bq_benef;
    }
    /**
     * @return the msg_num_cpt_benef
     */
    public String getMsg_num_cpt_benef() {
        return msg_num_cpt_benef;
    }
    /**
     * @param msg_num_cpt_benef la valeur de msg_num_cpt_benef à attribuer.
     */
    public void setMsg_num_cpt_benef(String msg_num_cpt_benef) {
        this.msg_num_cpt_benef = msg_num_cpt_benef;
    }
    /**
     * @return the msg_bic_benef
     */
    public String getMsg_bic_benef() {
        return msg_bic_benef;
    }
    /**
     * @param msg_bic_benef la valeur de msg_bic_benef à attribuer.
     */
    public void setMsg_bic_benef(String msg_bic_benef) {
        this.msg_bic_benef = msg_bic_benef;
    }
    /**
     * @return the msg_nom_benef
     */
    public String getMsg_nom_benef() {
        return msg_nom_benef;
    }
    /**
     * @param msg_nom_benef la valeur de msg_nom_benef à attribuer.
     */
    public void setMsg_nom_benef(String msg_nom_benef) {
        this.msg_nom_benef = msg_nom_benef;
    }
    /**
     * @return the msg_adresse_benef
     */
    public String getMsg_adresse_benef() {
        return msg_adresse_benef;
    }
    /**
     * @param msg_adresse_benef la valeur de msg_adresse_benef à attribuer.
     */
    public void setMsg_adresse_benef(String msg_adresse_benef) {
        this.msg_adresse_benef = msg_adresse_benef;
    }
    /**
     * @return the msg_motif_paiement
     */
    public String getMsg_motif_paiement() {
        return msg_motif_paiement;
    }
    /**
     * @param msg_motif_paiement la valeur de msg_motif_paiement à attribuer.
     */
    public void setMsg_motif_paiement(String msg_motif_paiement) {
        this.msg_motif_paiement = msg_motif_paiement;
    }
    /**
     * @return the msg_message_bq
     */
    public String getMsg_message_bq() {
        return msg_message_bq;
    }
    /**
     * @param msg_message_bq la valeur de msg_message_bq à attribuer.
     */
    public void setMsg_message_bq(String msg_message_bq) {
        this.msg_message_bq = msg_message_bq;
    }
    /**
     * @return the msg_commentaire
     */
    public String getMsg_commentaire() {
        return msg_commentaire;
    }
    /**
     * @param msg_commentaire la valeur de msg_commentaire à attribuer.
     */
    public void setMsg_commentaire(String msg_commentaire) {
        this.msg_commentaire = msg_commentaire;
    }
    /**
     * @return the msg_mode_paiement_chg
     */
    public String getMsg_mode_paiement_chg() {
        return msg_mode_paiement_chg;
    }
    /**
     * @param msg_mode_paiement_chg la valeur de msg_mode_paiement_chg à attribuer.
     */
    public void setMsg_mode_paiement_chg(String msg_mode_paiement_chg) {
        this.msg_mode_paiement_chg = msg_mode_paiement_chg;
    }
    /**
     * @return the msg_detail_charge
     */
    public String getMsg_detail_charge() {
        return msg_detail_charge;
    }
    /**
     * @param msg_detail_charge la valeur de msg_detail_charge à attribuer.
     */
    public void setMsg_detail_charge(String msg_detail_charge) {
        this.msg_detail_charge = msg_detail_charge;
    }
    /**
     * @return the msg_devise_chg_em
     */
    public String getMsg_devise_chg_em() {
        return msg_devise_chg_em;
    }
    /**
     * @param msg_devise_chg_em la valeur de msg_devise_chg_em à attribuer.
     */
    public void setMsg_devise_chg_em(String msg_devise_chg_em) {
        this.msg_devise_chg_em = msg_devise_chg_em;
    }
    /**
     * @return the msg_mnt_chg_em
     */
    public BigDecimal getMsg_mnt_chg_em() {
        return msg_mnt_chg_em;
    }
    /**
     * @param msg_mnt_chg_em la valeur de msg_mnt_chg_em à attribuer.
     */
    public void setMsg_mnt_chg_em(BigDecimal msg_mnt_chg_em) {
        this.msg_mnt_chg_em = msg_mnt_chg_em;
    }
    /**
     * @return the msg_devise_chg_benef
     */
    public String getMsg_devise_chg_benef() {
        return msg_devise_chg_benef;
    }
    /**
     * @param msg_devise_chg_benef la valeur de msg_devise_chg_benef à attribuer.
     */
    public void setMsg_devise_chg_benef(String msg_devise_chg_benef) {
        this.msg_devise_chg_benef = msg_devise_chg_benef;
    }
    /**
     * @return the msg_mnt_chg_benef
     */
    public BigDecimal getMsg_mnt_chg_benef() {
        return msg_mnt_chg_benef;
    }
    /**
     * @param msg_mnt_chg_benef la valeur de msg_mnt_chg_benef à attribuer.
     */
    public void setMsg_mnt_chg_benef(BigDecimal msg_mnt_chg_benef) {
        this.msg_mnt_chg_benef = msg_mnt_chg_benef;
    }
    /**
     * @return the message_clob
     */
    public String getMessage_clob() {
        return message_clob;
    }
    /**
     * @param message_clob la valeur de message_clob à attribuer.
     */
    public void setMessage_clob(String message_clob) {
        this.message_clob = message_clob;
    }
    /**
     * @return the nature
     */
    public String getNature() {
        return nature;
    }
    /**
     * @param nature la valeur de nature à attribuer.
     */
    public void setNature(String nature) {
        this.nature = nature;
    }
    /**
     * @return the nonblocking
     */
    public BigDecimal getNonblocking() {
        return nonblocking;
    }
    /**
     * @param nonblocking la valeur de nonblocking à attribuer.
     */
    public void setNonblocking(BigDecimal nonblocking) {
        this.nonblocking = nonblocking;
    }
    /**
     * @return the id_pairing
     */
    public String getId_pairing() {
        return id_pairing;
    }
    /**
     * @param id_pairing la valeur de id_pairing à attribuer.
     */
    public void setId_pairing(String id_pairing) {
        this.id_pairing = id_pairing;
    }
    /**
     * @return the priorite
     */
    public BigDecimal getPriorite() {
        return priorite;
    }
    /**
     * @param priorite la valeur de priorite à attribuer.
     */
    public void setPriorite(BigDecimal priorite) {
        this.priorite = priorite;
    }
    /**
     * @return the confidentialite
     */
    public BigDecimal getConfidentialite() {
        return confidentialite;
    }
    /**
     * @param confidentialite la valeur de confidentialite à attribuer.
     */
    public void setConfidentialite(BigDecimal confidentialite) {
        this.confidentialite = confidentialite;
    }
    /**
     * @return the alignement
     */
    public String getAlignement() {
        return alignement;
    }
    /**
     * @param alignement la valeur de alignement à attribuer.
     */
    public void setAlignement(String alignement) {
        this.alignement = alignement;
    }
    /**
     * @return the app_priority
     */
    public BigDecimal getApp_priority() {
        return app_priority;
    }
    /**
     * @param app_priority la valeur de app_priority à attribuer.
     */
    public void setApp_priority(BigDecimal app_priority) {
        this.app_priority = app_priority;
    }
    /**
     * @return the app_deadline
     */
    public java.sql.Timestamp getApp_deadline() {
        return app_deadline;
    }
    /**
     * @param app_deadline la valeur de app_deadline à attribuer.
     */
    public void setApp_deadline(java.sql.Timestamp app_deadline) {
        this.app_deadline = app_deadline;
    }
    /**
     * @return the normamount
     */
    public BigDecimal getNormamount() {
        return normamount;
    }
    /**
     * @param normamount la valeur de normamount à attribuer.
     */
    public void setNormamount(BigDecimal normamount) {
        this.normamount = normamount;
    }
    /**
     * @return the saausrgrp
     */
    public String getSaausrgrp() {
        return saausrgrp;
    }
    /**
     * @param saausrgrp la valeur de saausrgrp à attribuer.
     */
    public void setSaausrgrp(String saausrgrp) {
        this.saausrgrp = saausrgrp;
    }
    /**
     * @return the id_business_unit
     */
    public BigDecimal getId_business_unit() {
        return id_business_unit;
    }
    /**
     * @param id_business_unit la valeur de id_business_unit à attribuer.
     */
    public void setId_business_unit(BigDecimal id_business_unit) {
        this.id_business_unit = id_business_unit;
    }
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Alerte [id_alerte="
                + id_alerte
                    + ", dernier_utilisateur="
                    + dernier_utilisateur
                    + ", id_utilisateur="
                    + id_utilisateur
                    + ", montant_transaction="
                    + montant_transaction
                    + ", blocking="
                    + blocking
                    + ", bunit="
                    + bunit
                    + ", date_decision_finale="
                    + date_decision_finale
                    + ", copy_service="
                    + copy_service
                    + ", date_creation_transact="
                    + date_creation_transact
                    + ", devise_transaction="
                    + devise_transaction
                    + ", date_valeur_transact="
                    + date_valeur_transact
                    + ", decision_finale="
                    + decision_finale
                    + ", niveau_decision="
                    + niveau_decision
                    + ", motif_decision="
                    + motif_decision
                    + ", etat="
                    + etat
                    + ", bo_gestion="
                    + bo_gestion
                    + ", back_office="
                    + back_office
                    + ", date_filtre="
                    + date_filtre
                    + ", saa_origine="
                    + saa_origine
                    + ", saa_destination="
                    + saa_destination
                    + ", gateway="
                    + gateway
                    + ", bic_bq_emet="
                    + bic_bq_emet
                    + ", bic_bq_dest="
                    + bic_bq_dest
                    + ", ref_related="
                    + ref_related
                    + ", ref_transaction="
                    + ref_transaction
                    + ", type_message="
                    + type_message
                    + ", ind_swift_sepa="
                    + ind_swift_sepa
                    + ", sens_flux_e_r="
                    + sens_flux_e_r
                    + ", id_message="
                    + id_message
                    + ", msg_ref_transaction="
                    + msg_ref_transaction
                    + ", msg_code_operation="
                    + msg_code_operation
                    + ", msg_date_valeur="
                    + msg_date_valeur
                    + ", msg_devise_credit="
                    + msg_devise_credit
                    + ", msg_mnt_credit="
                    + msg_mnt_credit
                    + ", msg_devise_debit="
                    + msg_devise_debit
                    + ", msg_mnt_debit="
                    + msg_mnt_debit
                    + ", msg_taux_change="
                    + msg_taux_change
                    + ", msg_num_cpt_do="
                    + msg_num_cpt_do
                    + ", msg_bic_do="
                    + msg_bic_do
                    + ", msg_nom_do="
                    + msg_nom_do
                    + ", msg_adresse_do="
                    + msg_adresse_do
                    + ", msg_num_cpt_bq_do="
                    + msg_num_cpt_bq_do
                    + ", msg_bic_bq_do="
                    + msg_bic_bq_do
                    + ", msg_nom_bq_do="
                    + msg_nom_bq_do
                    + ", msg_adresse_bq_do="
                    + msg_adresse_bq_do
                    + ", msg_num_cpt_bq_em="
                    + msg_num_cpt_bq_em
                    + ", msg_bic_bq_em="
                    + msg_bic_bq_em
                    + ", msg_nom_bq_em="
                    + msg_nom_bq_em
                    + ", msg_adresse_bq_em="
                    + msg_adresse_bq_em
                    + ", msg_num_cpt_bq_dest="
                    + msg_num_cpt_bq_dest
                    + ", msg_bic_bq_dest="
                    + msg_bic_bq_dest
                    + ", msg_nom_bq_dest="
                    + msg_nom_bq_dest
                    + ", msg_adresse_bq_dest="
                    + msg_adresse_bq_dest
                    + ", msg_bic_bq_tie="
                    + msg_bic_bq_tie
                    + ", msg_nom_bq_tie="
                    + msg_nom_bq_tie
                    + ", msg_adresse_bq_tie="
                    + msg_adresse_bq_tie
                    + ", msg_num_cpt_bq_int="
                    + msg_num_cpt_bq_int
                    + ", msg_bic_bq_int="
                    + msg_bic_bq_int
                    + ", msg_nom_bq_int="
                    + msg_nom_bq_int
                    + ", msg_adresse_bq_int="
                    + msg_adresse_bq_int
                    + ", msg_num_cpt_bq_du_benef="
                    + msg_num_cpt_bq_du_benef
                    + ", msg_bic_bq_du_benef="
                    + msg_bic_bq_du_benef
                    + ", msg_nom_bq_du_benef="
                    + msg_nom_bq_du_benef
                    + ", msg_adresse_bq_du_benef="
                    + msg_adresse_bq_du_benef
                    + ", msg_num_cpt_bq_benef="
                    + msg_num_cpt_bq_benef
                    + ", msg_bic_bq_benef="
                    + msg_bic_bq_benef
                    + ", msg_nom_bq_benef="
                    + msg_nom_bq_benef
                    + ", msg_adresse_bq_benef="
                    + msg_adresse_bq_benef
                    + ", msg_num_cpt_benef="
                    + msg_num_cpt_benef
                    + ", msg_bic_benef="
                    + msg_bic_benef
                    + ", msg_nom_benef="
                    + msg_nom_benef
                    + ", msg_adresse_benef="
                    + msg_adresse_benef
                    + ", msg_motif_paiement="
                    + msg_motif_paiement
                    + ", msg_message_bq="
                    + msg_message_bq
                    + ", msg_commentaire="
                    + msg_commentaire
                    + ", msg_mode_paiement_chg="
                    + msg_mode_paiement_chg
                    + ", msg_detail_charge="
                    + msg_detail_charge
                    + ", msg_devise_chg_em="
                    + msg_devise_chg_em
                    + ", msg_mnt_chg_em="
                    + msg_mnt_chg_em
                    + ", msg_devise_chg_benef="
                    + msg_devise_chg_benef
                    + ", msg_mnt_chg_benef="
                    + msg_mnt_chg_benef
                    + ", message_clob="
                    + message_clob
                    + ", nature="
                    + nature
                    + ", nonblocking="
                    + nonblocking
                    + ", id_pairing="
                    + id_pairing
                    + ", priorite="
                    + priorite
                    + ", confidentialite="
                    + confidentialite
                    + ", alignement="
                    + alignement
                    + ", app_priority="
                    + app_priority
                    + ", app_deadline="
                    + app_deadline
                    + ", normamount="
                    + normamount
                    + ", saausrgrp="
                    + saausrgrp
                    + ", id_business_unit="
                    + id_business_unit
                    + "]";
    }
    /**
     * @param id_alerte
     * @param dernier_utilisateur
     * @param id_utilisateur
     * @param montant_transaction
     * @param blocking
     * @param bunit
     * @param date_decision_finale
     * @param copy_service
     * @param date_creation_transact
     * @param devise_transaction
     * @param date_valeur_transact
     * @param decision_finale
     * @param niveau_decision
     * @param motif_decision
     * @param etat
     * @param bo_gestion
     * @param back_office
     * @param date_filtre
     * @param saa_origine
     * @param saa_destination
     * @param gateway
     * @param bic_bq_emet
     * @param bic_bq_dest
     * @param ref_related
     * @param ref_transaction
     * @param type_message
     * @param ind_swift_sepa
     * @param sens_flux_e_r
     * @param id_message
     * @param msg_ref_transaction
     * @param msg_code_operation
     * @param msg_date_valeur
     * @param msg_devise_credit
     * @param msg_mnt_credit
     * @param msg_devise_debit
     * @param msg_mnt_debit
     * @param msg_taux_change
     * @param msg_num_cpt_do
     * @param msg_bic_do
     * @param msg_nom_do
     * @param msg_adresse_bo
     * @param msg_num_cpt_bq_do
     * @param msg_bic_bq_do
     * @param msg_nom_bq_do
     * @param msg_adresse_bq_do
     * @param msg_num_cpt_bq_em
     * @param msg_bic_bq_em
     * @param msg_nom_bq_em
     * @param msg_adresse_bq_em
     * @param msg_num_cpt_bq_dest
     * @param msg_bic_bq_dest
     * @param msg_nom_bq_dest
     * @param msg_adresse_bq_dest
     * @param msg_bic_bq_tie
     * @param msg_nom_bq_tie
     * @param msg_adresse_bq_tie
     * @param msg_num_cpt_bq_int
     * @param msg_bic_bq_int
     * @param msg_nom_bq_int
     * @param msg_adresse_bq_int
     * @param msg_num_cpt_bq_du_benef
     * @param msg_bic_bq_du_benef
     * @param msg_nom_bq_du_benef
     * @param msg_adresse_bq_du_benef
     * @param msg_num_cpt_bq_benef
     * @param msg_bic_bq_benef
     * @param msg_nom_bq_benef
     * @param msg_adresse_bq_benef
     * @param msg_num_cpt_benef
     * @param msg_bic_benef
     * @param msg_nom_benef
     * @param msg_adresse_benef
     * @param msg_motif_paiement
     * @param msg_message_bq
     * @param msg_commentaire
     * @param msg_mode_paiement_chg
     * @param msg_detail_charge
     * @param msg_devise_chg_em
     * @param msg_mnt_chg_em
     * @param msg_devise_chg_benef
     * @param msg_mnt_chg_benef
     * @param message_clob
     * @param nature
     * @param nonblocking
     * @param id_pairing
     * @param priorite
     * @param confidentialite
     * @param alignement
     * @param app_priority
     * @param app_deadline
     * @param normamount
     * @param saausrgrp
     * @param id_business_unit
     */
    public AlerteBean(String id_alerte, String dernier_utilisateur,
            BigDecimal id_utilisateur, BigDecimal montant_transaction, BigDecimal blocking,
            String bunit, java.sql.Timestamp date_decision_finale, String copy_service,
            java.sql.Timestamp date_creation_transact, String devise_transaction,
            java.sql.Timestamp date_valeur_transact, String decision_finale,
            String niveau_decision, String motif_decision, String etat,
            String bo_gestion, String back_office, java.sql.Timestamp date_filtre,
            String saa_origine, String saa_destination, String gateway,
            String bic_bq_emet, String bic_bq_dest, String ref_related,
            String ref_transaction, String type_message, String ind_swift_sepa,
            String sens_flux_e_r, String id_message, String msg_ref_transaction,
            String msg_code_operation, java.sql.Date msg_date_valeur,
            String msg_devise_credit, BigDecimal msg_mnt_credit,
            String msg_devise_debit, BigDecimal msg_mnt_debit,
            BigDecimal msg_taux_change, String msg_num_cpt_do, String msg_bic_do,
            String msg_nom_do, String msg_adresse_do, String msg_num_cpt_bq_do,
            String msg_bic_bq_do, String msg_nom_bq_do,
            String msg_adresse_bq_do, String msg_num_cpt_bq_em,
            String msg_bic_bq_em, String msg_nom_bq_em,
            String msg_adresse_bq_em, String msg_num_cpt_bq_dest,
            String msg_bic_bq_dest, String msg_nom_bq_dest,
            String msg_adresse_bq_dest, String msg_bic_bq_tie,
            String msg_nom_bq_tie, String msg_adresse_bq_tie,
            String msg_num_cpt_bq_int, String msg_bic_bq_int,
            String msg_nom_bq_int, String msg_adresse_bq_int,
            String msg_num_cpt_bq_du_benef, String msg_bic_bq_du_benef,
            String msg_nom_bq_du_benef, String msg_adresse_bq_du_benef,
            String msg_num_cpt_bq_benef, String msg_bic_bq_benef,
            String msg_nom_bq_benef, String msg_adresse_bq_benef,
            String msg_num_cpt_benef, String msg_bic_benef,
            String msg_nom_benef, String msg_adresse_benef,
            String msg_motif_paiement, String msg_message_bq,
            String msg_commentaire, String msg_mode_paiement_chg,
            String msg_detail_charge, String msg_devise_chg_em,
            BigDecimal msg_mnt_chg_em, String msg_devise_chg_benef,
            BigDecimal msg_mnt_chg_benef, String message_clob, String nature,
            BigDecimal nonblocking, String id_pairing, BigDecimal priorite,
            BigDecimal confidentialite, String alignement, BigDecimal app_priority,
            java.sql.Timestamp app_deadline, BigDecimal normamount, String saausrgrp,
            BigDecimal id_business_unit) {
        super();
        this.id_alerte = id_alerte;
        this.dernier_utilisateur = dernier_utilisateur;
        this.id_utilisateur = id_utilisateur;
        this.montant_transaction = montant_transaction;
        this.blocking = blocking;
        this.bunit = bunit;
        this.date_decision_finale = date_decision_finale;
        this.copy_service = copy_service;
        this.date_creation_transact = date_creation_transact;
        this.devise_transaction = devise_transaction;
        this.date_valeur_transact = date_valeur_transact;
        this.decision_finale = decision_finale;
        this.niveau_decision = niveau_decision;
        this.motif_decision = motif_decision;
        this.etat = etat;
        this.bo_gestion = bo_gestion;
        this.back_office = back_office;
        this.date_filtre = date_filtre;
        this.saa_origine = saa_origine;
        this.saa_destination = saa_destination;
        this.gateway = gateway;
        this.bic_bq_emet = bic_bq_emet;
        this.bic_bq_dest = bic_bq_dest;
        this.ref_related = ref_related;
        this.ref_transaction = ref_transaction;
        this.type_message = type_message;
        this.ind_swift_sepa = ind_swift_sepa;
        this.sens_flux_e_r = sens_flux_e_r;
        this.id_message = id_message;
        this.msg_ref_transaction = msg_ref_transaction;
        this.msg_code_operation = msg_code_operation;
        this.msg_date_valeur = msg_date_valeur;
        this.msg_devise_credit = msg_devise_credit;
        this.msg_mnt_credit = msg_mnt_credit;
        this.msg_devise_debit = msg_devise_debit;
        this.msg_mnt_debit = msg_mnt_debit;
        this.msg_taux_change = msg_taux_change;
        this.msg_num_cpt_do = msg_num_cpt_do;
        this.msg_bic_do = msg_bic_do;
        this.msg_nom_do = msg_nom_do;
        this.msg_adresse_do = msg_adresse_do;
        this.msg_num_cpt_bq_do = msg_num_cpt_bq_do;
        this.msg_bic_bq_do = msg_bic_bq_do;
        this.msg_nom_bq_do = msg_nom_bq_do;
        this.msg_adresse_bq_do = msg_adresse_bq_do;
        this.msg_num_cpt_bq_em = msg_num_cpt_bq_em;
        this.msg_bic_bq_em = msg_bic_bq_em;
        this.msg_nom_bq_em = msg_nom_bq_em;
        this.msg_adresse_bq_em = msg_adresse_bq_em;
        this.msg_num_cpt_bq_dest = msg_num_cpt_bq_dest;
        this.msg_bic_bq_dest = msg_bic_bq_dest;
        this.msg_nom_bq_dest = msg_nom_bq_dest;
        this.msg_adresse_bq_dest = msg_adresse_bq_dest;
        this.msg_bic_bq_tie = msg_bic_bq_tie;
        this.msg_nom_bq_tie = msg_nom_bq_tie;
        this.msg_adresse_bq_tie = msg_adresse_bq_tie;
        this.msg_num_cpt_bq_int = msg_num_cpt_bq_int;
        this.msg_bic_bq_int = msg_bic_bq_int;
        this.msg_nom_bq_int = msg_nom_bq_int;
        this.msg_adresse_bq_int = msg_adresse_bq_int;
        this.msg_num_cpt_bq_du_benef = msg_num_cpt_bq_du_benef;
        this.msg_bic_bq_du_benef = msg_bic_bq_du_benef;
        this.msg_nom_bq_du_benef = msg_nom_bq_du_benef;
        this.msg_adresse_bq_du_benef = msg_adresse_bq_du_benef;
        this.msg_num_cpt_bq_benef = msg_num_cpt_bq_benef;
        this.msg_bic_bq_benef = msg_bic_bq_benef;
        this.msg_nom_bq_benef = msg_nom_bq_benef;
        this.msg_adresse_bq_benef = msg_adresse_bq_benef;
        this.msg_num_cpt_benef = msg_num_cpt_benef;
        this.msg_bic_benef = msg_bic_benef;
        this.msg_nom_benef = msg_nom_benef;
        this.msg_adresse_benef = msg_adresse_benef;
        this.msg_motif_paiement = msg_motif_paiement;
        this.msg_message_bq = msg_message_bq;
        this.msg_commentaire = msg_commentaire;
        this.msg_mode_paiement_chg = msg_mode_paiement_chg;
        this.msg_detail_charge = msg_detail_charge;
        this.msg_devise_chg_em = msg_devise_chg_em;
        this.msg_mnt_chg_em = msg_mnt_chg_em;
        this.msg_devise_chg_benef = msg_devise_chg_benef;
        this.msg_mnt_chg_benef = msg_mnt_chg_benef;
        this.message_clob = message_clob;
        this.nature = nature;
        this.nonblocking = nonblocking;
        this.id_pairing = id_pairing;
        this.priorite = priorite;
        this.confidentialite = confidentialite;
        this.alignement = alignement;
        this.app_priority = app_priority;
        this.app_deadline = app_deadline;
        this.normamount = normamount;
        this.saausrgrp = saausrgrp;
        this.id_business_unit = id_business_unit;
    }
    /**
     * 
     */
    public AlerteBean() {
        super();
    }
	public java.sql.Date getDate_ope() {
		return date_ope;
	}
	public void setDate_ope(java.sql.Date date_ope) {
		this.date_ope = date_ope;
	}
	public java.sql.Date getDate_insert() {
		return date_insert;
	}
	public void setDate_insert(java.sql.Date date_insert) {
		this.date_insert = date_insert;
	}
    
    
    
    
}
