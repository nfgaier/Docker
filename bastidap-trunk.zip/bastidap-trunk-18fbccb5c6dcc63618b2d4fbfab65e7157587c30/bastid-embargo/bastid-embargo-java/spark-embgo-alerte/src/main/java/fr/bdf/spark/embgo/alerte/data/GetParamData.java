/**
 * 
 */
package fr.bdf.spark.embgo.alerte.data;

import java.io.Serializable;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import fr.bdf.spark.embgo.alerte.constant.LoadAlerteConstant;

public class GetParamData implements Serializable {

	private static final long serialVersionUID = -6984146894018261739L;

	private SparkSession session;

	private String rawLayerHiveBase;

	/**
	 * @param sqlContext
	 */
	public GetParamData(SparkSession session, String rawLayerHiveBase) {
		super();
		this.session = session;
		this.rawLayerHiveBase = rawLayerHiveBase;
	}

	/*
	 * public DataFrame getRefAlerteBOData (String idTraitement) {
	 * //20171004112817
	 * 
	 * return sqlContext.sql("select  ordre," + "date_decision_deb," +
	 * "date_decision_fin," + "niveau_decision," + "decision_finale," +
	 * "bo_gestion," + "back_office," + "t_id_traitement" + " from " +
	 * rawLayerHiveBase + "." + LoadAlerteConstant.REF_ALT_BO +
	 * " where t_id_traitement = '"+idTraitement+"' order by ordre"); }
	 * 
	 * public DataFrame getRefAlerteEtatData (String idTraitement) {
	 * 
	 * return sqlContext.sql("select  ordre," + "date_decision_deb," +
	 * "date_decision_fin," + "decision_finale," + "etat," + "t_id_traitement" +
	 * " from " + rawLayerHiveBase + "." + LoadAlerteConstant.REF_ALT_ETAT +
	 * " where t_id_traitement = '"+idTraitement+"' order by ordre"); }
	 * 
	 * public DataFrame getRefAlerteIndData (String idTraitement) {
	 * 
	 * return sqlContext.sql("select  ordre," + "date_decision_deb," +
	 * "date_decision_fin," + "type_message," + "ind_swift_sepa," +
	 * "t_id_traitement" + " from " + rawLayerHiveBase + "." +
	 * LoadAlerteConstant.REF_ALT_IND +
	 * " where t_id_traitement = '"+idTraitement+"' order by ordre"); }
	 * 
	 * public DataFrame getRefAlerteMotifData (String idTraitement) {
	 * 
	 * return sqlContext.sql("select  ordre," + "date_decision_deb," +
	 * "date_decision_fin," + "decision_finale," + "motif_decision," +
	 * "t_id_traitement" + " from " + rawLayerHiveBase + "." +
	 * LoadAlerteConstant.REF_ALT_MOT +
	 * " where t_id_traitement = '"+idTraitement+"' order by ordre"); }
	 * 
	 * public DataFrame getRefAlerteNivData (String idTraitement) {
	 * 
	 * return sqlContext.sql("select date_decision_deb," + "date_decision_fin,"
	 * + "decision_finale," + "niveau_decision, " + "t_id_traitement " +
	 * " from " + rawLayerHiveBase + "." + LoadAlerteConstant.REF_ALT_NIV +
	 * " where t_id_traitement = '"+idTraitement+"' order by ordre"); }
	 */

	/** BASTID CONFIG */

	public Dataset<Row> getRefAlerteBOData(String idTraitement) { // 20171004112817

		return session.sql("select  ordre," + "date_decision_deb,"
				+ "date_decision_fin," + "niveau_decision,"
				+ "decision_finale," + "bo_gestion," + "back_office,"
				+ "id_traitement" + " from " + rawLayerHiveBase + "."
				+ LoadAlerteConstant.REF_ALT_BO + " where id_traitement = '"
				+ idTraitement + "' order by ordre");
	}

	public Dataset<Row> getRefAlerteEtatData(String idTraitement) {

		return session.sql("select  ordre," + "date_decision_deb,"
				+ "date_decision_fin," + "decision_finale," + "etat,"
				+ "id_traitement" + " from " + rawLayerHiveBase + "."
				+ LoadAlerteConstant.REF_ALT_ETAT + " where id_traitement = '"
				+ idTraitement + "' order by ordre");
	}

	public Dataset<Row> getRefAlerteIndData(String idTraitement) {

		return session.sql("select  ordre," + "date_decision_deb,"
				+ "date_decision_fin," + "type_message," + "ind_swift_sepa,"
				+ "id_traitement" + " from " + rawLayerHiveBase + "."
				+ LoadAlerteConstant.REF_ALT_IND + " where id_traitement = '"
				+ idTraitement + "' order by ordre");
	}

	public Dataset<Row> getRefAlerteMotifData(String idTraitement) {

		return session.sql("select  ordre," + "date_decision_deb,"
				+ "date_decision_fin," + "decision_finale," + "motif_decision,"
				+ "id_traitement" + " from " + rawLayerHiveBase + "."
				+ LoadAlerteConstant.REF_ALT_MOT + " where id_traitement = '"
				+ idTraitement + "' order by ordre");
	}

	public Dataset<Row> getRefAlerteNivData(String idTraitement) {

		return session.sql("select date_decision_deb," + "date_decision_fin,"
				+ "decision_finale," + "niveau_decision, " + "id_traitement "
				+ " from " + rawLayerHiveBase + "."
				+ LoadAlerteConstant.REF_ALT_NIV + " where id_traitement = '"
				+ idTraitement + "' order by ordre");
	}

}
