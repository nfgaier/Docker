package fr.bdf.spark.embgo.alerte.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

public class ParseSEPAUtil {
	
	/** 
	 * Constructeur.
	 * */
	public ParseSEPAUtil() {
		
	}

	/********
	 * Get Field B_PMTID
	 * @param strInput , SEPA msg input
	 * @return result , B_PMTID field extracted
	 * *********/
	public String getFieldBPMTID(String strInput) {
		if(StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_PMTID)[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);
				matcher.find();
				String result = matcher.group().replaceAll("[^A-Za-z0-9|^-]", StringUtils.EMPTY);

				if (StringUtils.isNotBlank(result)) {
					result = result.replaceAll("[^A-Za-z0-9|^-]", StringUtils.EMPTY);
				}
		
				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field B_PMTID" + e);
			}
		}
		return null;
	}

	/********
	 * Get Field B_SVCLVL
	 * @param strInput , SEPA msg input
	 * @return result , B_SVCLVL field extracted
	 * *********/
	public String getFieldBSVCLVL(String strInput) {
		if(StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_SVCLVL)[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);
		
				matcher.find();
				String result = matcher.group();
		
				if (StringUtils.isNotBlank(result)) {
					result = result.replaceAll("[^A-Za-z0-9|^-]", StringUtils.EMPTY);
				}
		
				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field B_SVCLVL" + e);
			}
		}
		return null;
	}

	/********
	 * Get Field B_STTLAMT
	 * @param strInput , SEPA msg input
	 * @return result , B_STTLAMT field extracted
	 * *********/
	public String getFieldBSTTLAMT(String strInput) {
		if(StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_STTLAMT     X\\])[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);
		
				matcher.find();
				String result = matcher.group();
		
				if (StringUtils.isNotBlank(result)) {
					result = result.replaceAll("[^A-Za-z0-9|^-|^.]", StringUtils.EMPTY);
				}
		
				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field B_STTLAMT" + e);
			}
		}
		return null;
	}

	/********
	 * Get Currency of Field B_STTLAMT
	 * @param strInput , Field B_STTLAMT 
	 * @return result , Currency of the B_STTLAMT field extracted
	 * *********/
	public String getCurrencyFieldBSTTLAMT(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "[A-Za-z]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);
				matcher.find();
				return matcher.group().trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field CurrencyFieldBSTTLAMT" + e);
			}
		}
		return null;
	}

	/********
	 * Get Amount of Field B_STTLAMT
	 * @param strInput , Field B_STTLAMT 
	 * @return result , Amount of the B_STTLAMT field extracted
	 * *********/
	public String getAmountFieldBSTTLAMT(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "[\\d|.]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);
				matcher.find();
				return matcher.group().trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field AmountFieldBSTTLAMT" + e);
			}
		}
		return null;
	}

	/********
	 * Get Amount of Field B_DBTRAG
	 * @param strInput , SEPA msg
	 * @return result , B_DBTRAG field extracted
	 * *********/
	public String getFieldBDBTRAG(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_DBTRAG )[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group();

				if (StringUtils.isNotBlank(result)) {
					result = result.replaceAll("[^A-Za-z0-9|^-|^.]", StringUtils.EMPTY);
				}

				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field
				// B_DBTRAG" + e);
			}
		}
		return null;
	}

	/********
	 * Get Amount of Field B_DBTRAGAC
	 * @param strInput , SEPA msg
	 * @return result , B_DBTRAGAC field extracted
	 * *********/
	public String getFieldBDBTRAGAC(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_DBTRAGAC)[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group();

				if (StringUtils.isNotBlank(result)) {
					result = result.replaceAll("[^A-Za-z0-9|^-|^.]", StringUtils.EMPTY);
				}

				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field
				// B_DBTRAGAC" + e);
			}
		}
		return null;
	}
	
	/********
	 * Get Amount of Field B_CDTRAG
	 * @param strInput , SEPA msg
	 * @return result , B_CDTRAG field extracted
	 * *********/
	public String getFieldBCDTRAG(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_CDTRAG )[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group();

				if (StringUtils.isNotBlank(result)) {
					result = result.replaceAll("[^A-Za-z0-9|^-|^.]", StringUtils.EMPTY);
				}

				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field
				// B_DBTRAG" + e);
			}
		}
		return null;
	}

	/********
	 * Get Amount of Field B_CDTRAGAC
	 * @param strInput , SEPA msg
	 * @return result , B_CDTRAGAC field extracted
	 * *********/
	public String getFieldBCDTRAGAC(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_CDTRAGAC)[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group();

				if (StringUtils.isNotBlank(result)) {
					result = result.replaceAll("[^A-Za-z0-9|^-|^.|^\\s]", StringUtils.EMPTY).trim();
				}

				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field
				// B_DBTRAGAC" + e);
			}
		}
		return null;
	}
	
	/********
	 * Get Amount of Field A_INDRAG
	 * @param strInput , SEPA msg
	 * @return result , A_INDRAG field extracted
	 * *********/
	public String getFieldAINDRAG(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[A_INDRAG )[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);
		
				matcher.find();
				String result = matcher.group();
		
				if (StringUtils.isNotBlank(result)) {
					result = result.replaceAll("[^A-Za-z0-9|^-|^.]", StringUtils.EMPTY);
				}
		
				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field A_INDRAG" + e);
			}
		}
		return null;
	}
	
	/********
	 * Get Field A_INDRAGAC
	 * @param strInput , SEPA msg
	 * @return result , A_INDRAGAC field extracted
	 * *********/
	public String getFieldAINDRAGAC(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[A_INDRAGAC)[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);
		
				matcher.find();
				String result = matcher.group();
		
				if (StringUtils.isNotBlank(result)) {
					result = result.replaceAll("[^A-Za-z0-9|^-|^.]", StringUtils.EMPTY);
				}
		
				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field A_INDRAGAC" + e);
			}
		}
		return null;
	}
	
	
	/********
	 * Get Field A_INGRAG
	 * @param strInput , SEPA msg
	 * @return result , A_INGRAG field extracted
	 * *********/
	public String getFieldAINGRAG(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[A_INGRAG )[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group();

				if (StringUtils.isNotBlank(result)) {
					result = result.replaceAll("[^A-Za-z0-9|^-|^.]", StringUtils.EMPTY);
				}

				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field
				// A_INGRAG" + e);
			}
		}
		return null;
	}

	/********
	 * Get Field A_INGRAGAC
	 * @param strInput , SEPA msg
	 * @return result , A_INGRAGAC field extracted
	 * *********/
	public String getFieldAINGRAGAC(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[A_INGRAGAC)[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group();

				if (StringUtils.isNotBlank(result)) {
					result = result.replaceAll("[^A-Za-z0-9|^-|^.]", StringUtils.EMPTY);
				}

				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field
				// A_INGRAG" + e);
			}
		}
		return null;
	}


	/********
	 * Get Field A_THRGRAG
	 * @param strInput , SEPA msg
	 * @return result , A_THRGRAG field extracted
	 * *********/
	public String getFieldATHRGRAG(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[A_THRGRAG )[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group();

				if (StringUtils.isNotBlank(result)) {
					result = result.replaceAll("[^A-Za-z0-9|^-|^.]", StringUtils.EMPTY);
				}

				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field A_THRGRAG" + e);
			}
		}
		return null;
	}
	
	/********
	 * Get Field A_THRGRAGAC
	 * @param strInput , SEPA msg
	 * @return result , A_THRGRAGAC field extracted
	 * *********/
	public String getFieldATHRGRAGAC(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[A_THRGRAGAC)[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group();

				if (StringUtils.isNotBlank(result)) {
					result = result.replaceAll("[^A-Za-z0-9|^-|^.]", StringUtils.EMPTY);
				}

				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field A_THRGRAG" + e);
			}
		}
		return null;
	}
	
	/********
	 * Get Field B_INTAG1
	 * @param strInput , SEPA msg
	 * @return result , B_INTAG1 field extracted
	 * *********/
	public String getFieldBINTAG1(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_INTAG1 )[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group();

				if (StringUtils.isNotBlank(result)) {
					result = result.replaceAll("[^A-Za-z0-9|^-|^.]", StringUtils.EMPTY);
				}

				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field B_INTAG1" + e);
			}
		}
		return null;
	}
	
	/********
	 * Get Field B_INTAG1AC
	 * @param strInput , SEPA msg
	 * @return result , B_INTAG1AC field extracted
	 * *********/
	public String getFieldBINTAG1AC(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_INTAG1AC)[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group();

				if (StringUtils.isNotBlank(result)) {
					result = result.replaceAll("[^A-Za-z0-9|^-|^.]", StringUtils.EMPTY);
				}

				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field B_INTAG1" + e);
			}
		}
		return null;
	}
	
	
	/********
	 * Get Field B_INTAGAC1
	 * @param strInput , SEPA msg
	 * @return result , B_INTAG1AC field extracted
	 * *********/
	public String getFieldBINTAGAC1(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_INTAGAC1)[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group();

				if (StringUtils.isNotBlank(result)) {
					result = result.replaceAll("[^A-Za-z0-9|^-|^.]", StringUtils.EMPTY);
				}

				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field B_INTAG1" + e);
			}
		}
		return null;
	}
	
	/********
	 * Get Field B_DBTRAC
	 * @param strInput , SEPA msg
	 * @return result , B_DBTRAC field extracted
	 * *********/
	public String getFieldBDBTRAC(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_DBTRAC)[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group();

				if (StringUtils.isNotBlank(result)) {
					result = result.substring(result.indexOf("]") + 1).trim();
				}

				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field
				// B_DBTRAC" + e);
			}
		}
		return null;
	}
	
	/********
	 * Get Field B_CDTRAC
	 * @param strInput , SEPA msg
	 * @return result , B_CDTRAC field extracted
	 * *********/
	public String getFieldBCDTRAC(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_CDTRAC)[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group();

				if (StringUtils.isNotBlank(result)) {
					result = result.substring(result.indexOf("]") + 1).trim();
				}

				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field
				// B_CDTRAC" + e);
			}
		}
		return null;
	}
	
	
	/********
	 * Get Field B_DBTR
	 * @param strInput , SEPA msg
	 * @return result , B_DBTR field extracted
	 * *********/
	public String getFieldBDBTR(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_DBTR )[^\\[]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group();

				if (StringUtils.isNotBlank(result)) {
					result = result.substring(result.indexOf("]") + 1).trim();
				}

				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field
				// B_DBTR" + e);
			}
		}
		return null;
	}

	/********
	 * Get Amount of Field B_DBTR
	 * @param strInput , SEPA msg
	 * @return result , B_DBTR field extracted
	 * *********/
	public String getFieldBDBTRName(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group().trim().replaceAll("\\r\\n|\\r|\\n", StringUtils.SPACE);
				return result == null ? StringUtils.EMPTY : result;
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field
				// BDBTRName" + e);
			}
		}

		return null;

	}

	public String getFieldBDBTRAddress(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				String result = strInput.substring(strInput.indexOf("\r\n") + 2).trim().replaceAll("\\r\\n|\\r|\\n", StringUtils.SPACE);
				return result == null ? StringUtils.EMPTY : result;
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field
				// BDBTRAddress" + e);
			}
		}

		return null;

	}
	
	/** */
	public String getFieldBCDTR(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
//				final String regex = "(?<=\\[B_CDTR)[^\\[B_CDTRAC]+";
				final String regex = "(?<=\\[B_CDTR )[^\\[]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group();

				if (StringUtils.isNotBlank(result)) {
					result = result.substring(result.indexOf("]") + 1).trim();
				}

				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field
				// B_CDTR" + e);
			}
		}
		return null;
	}

	public String getFieldBCDTRName(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group().trim().replaceAll("\\r\\n|\\r|\\n", StringUtils.SPACE);
				return result == null ? StringUtils.EMPTY : result;
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field
				// BDBTRName" + e);
			}
		}

		return null;

	}

	public String getFieldBCDTRAddress(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				String result = strInput.substring(strInput.indexOf("\r\n") + 2).trim().replaceAll("\\r\\n|\\r|\\n", StringUtils.SPACE);
				return result == null ? StringUtils.EMPTY : result;
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field
				// BDBTRAddress" + e);
			}
		}

		return null;

	}

	
	/*****************/
	public String getFieldBCHGINF(String strInput) {
		if(StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_CHGINF )[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);
		
				matcher.find();
				String result = matcher.group();
		
				if (StringUtils.isNotBlank(result)) {
					result = result.substring(result.indexOf("]") + 1).trim();
					result = result.replaceAll("[^A-Za-z0-9|^-]", StringUtils.EMPTY);
				}
		
				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field B_CHRGBR" + e);
			}
		}
		return null;
	}
	
	

	/****** Parser for PACS003 **/
	/** */
	public String getFieldBREMITINF(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_REMITINF)[^\\r\\n\\[]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group();

				if (StringUtils.isNotBlank(result)) {
					result = result.substring(result.indexOf("]") + 1).trim();
				}

				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field
				// B_REMITINF" + e);
			}
		}
		return null;
	}
	
	
	/*****************/
	public String getFieldBCHRGBR(String strInput) {
		if(StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_CHRGBR )[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);
		
				matcher.find();
				String result = matcher.group();
		
				if (StringUtils.isNotBlank(result)) {
					result = result.substring(result.indexOf("]") + 1).trim();
					result = result.replaceAll("[^A-Za-z0-9|^-]", StringUtils.EMPTY);
				}
		
				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field B_CHRGBR" + e);
			}
		}
		return null;
	}
	
	/****** Parser for PACS008 **/
	/** */
	public String getFieldBRELREMIT(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_RELREMIT)[^\\r\\n\\[]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group();

				if (StringUtils.isNotBlank(result)) {
					result = result.substring(result.indexOf("]") + 1).trim();
				}

				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field
				// RELREMIT" + e);
			}
		}
		return null;
	}


	/*****************/
	public String getFieldBCHGBR(String strInput) {
		if(StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_CHGBR )[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);
		
				matcher.find();
				String result = matcher.group();
		
				if (StringUtils.isNotBlank(result)) {
					result = result.substring(result.indexOf("]") + 1).trim();
					result = result.replaceAll("[^A-Za-z0-9|^-|^\\s]", StringUtils.EMPTY);
				}
		
				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field B_CHRGBR" + e);
			}
		}
		return null;
	}
	
	
	
	/********
	 * Get Field B_INTAG1
	 * @param strInput , SEPA msg
	 * @return result , B_INTAG1 field extracted
	 * *********/
	public String getFieldBRGLRPTG(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_RGLRPTG)[^\\r\\n]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group();

				if (StringUtils.isNotBlank(result)) {
					result = result.replaceAll("[^A-Za-z0-9|^-|^.]", StringUtils.EMPTY);
				}

				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field B_INTAG1" + e);
			}
		}
		return null;
	}

	
	/** */
	public String getFieldBINSTCDAG(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final String regex = "(?<=\\[B_INSTCDAG)[^\\r\\n\\[]+";
				final Pattern pattern = Pattern.compile(regex);
				final Matcher matcher = pattern.matcher(strInput);

				matcher.find();
				String result = matcher.group();

				if (StringUtils.isNotBlank(result)) {
					result = result.substring(result.indexOf("]") + 1).trim();
				}

				return result.trim();
			} catch (Exception e) {
				// getLogger().log(LogLevel.ERROR,"Error while getting field
				// B_REMITINF" + e);
			}
		}
		return null;
	}
	
}
