/**
 * 
 */
package fr.bdf.spark.embgo.alerte.beans;

import java.io.Serializable;
import java.util.Date;

/**
 * @author i2108fv
 *
 */
public class FofaHistMessageBean implements Serializable {
    
  
    private static final long serialVersionUID = 3070879572890812748L;
    
    private String t_system_id;
    private Double business_unit_id;
    private String saausrgrp;
    private Double t_normamount;
    private Date t_app_deadline;
    private Double t_app_priority;
    private String t_alignment;
    private Double t_confidentiality;
    private Double t_priority;
    private String t_type;
    private String t_transaction;
    private String t_toappli;
    private String t_sender;
    private String t_related_ref;
    private String t_receiver;
    private String t_pairing_id;
    private Double t_nonblocking;
    private String t_nature;
    private String t_message_id;
    private String t_message;
    private String t_message_upd;
    private String t_i_o;
    private String t_gateway;
    private String t_fromappli;
    private String t_filtered;
    private String t_entity;
    private String t_lastoperator;
    private String t_decision_type;
    private String t_date_value;
    private String t_currency;
    private String t_created;
    private String t_copy_service;
    private String t_completed;
    private String t_bunit;
    private Double t_blocking;
    private Float t_amount_float;
    private String t_amount;
    private String niveau_decision;
    private String ind_swift_sepa;
    private java.sql.Date date_ope;
    private java.sql.Date date_insert;
    
    /**
     * @return the t_system_id
     */
    public String getT_system_id() {
        return t_system_id;
    }
    /**
     * @param t_system_id la valeur de t_system_id à attribuer.
     */
    public void setT_system_id(String t_system_id) {
        this.t_system_id = t_system_id;
    }
    /**
     * @return the business_unit_id
     */
    public Double getBusiness_unit_id() {
        return business_unit_id;
    }
    /**
     * @param business_unit_id la valeur de business_unit_id à attribuer.
     */
    public void setBusiness_unit_id(Double business_unit_id) {
        this.business_unit_id = business_unit_id;
    }
    /**
     * @return the saausrgrp
     */
    public String getSaausrgrp() {
        return saausrgrp;
    }
    /**
     * @param saausrgrp la valeur de saausrgrp à attribuer.
     */
    public void setSaausrgrp(String saausrgrp) {
        this.saausrgrp = saausrgrp;
    }
    /**
     * @return the t_normamount
     */
    public Double getT_normamount() {
        return t_normamount;
    }
    /**
     * @param t_normamount la valeur de t_normamount à attribuer.
     */
    public void setT_normamount(Double t_normamount) {
        this.t_normamount = t_normamount;
    }
    /**
     * @return the t_app_deadline
     */
    public Date getT_app_deadline() {
        return t_app_deadline;
    }
    /**
     * @param t_app_deadline la valeur de t_app_deadline à attribuer.
     */
    public void setT_app_deadline(Date t_app_deadline) {
        this.t_app_deadline = t_app_deadline;
    }
    /**
     * @return the t_app_priority
     */
    public Double getT_app_priority() {
        return t_app_priority;
    }
    /**
     * @param t_app_priority la valeur de t_app_priority à attribuer.
     */
    public void setT_app_priority(Double t_app_priority) {
        this.t_app_priority = t_app_priority;
    }
    /**
     * @return the t_alignment
     */
    public String getT_alignment() {
        return t_alignment;
    }
    /**
     * @param t_alignment la valeur de t_alignment à attribuer.
     */
    public void setT_alignment(String t_alignment) {
        this.t_alignment = t_alignment;
    }
    /**
     * @return the t_confidentiality
     */
    public Double getT_confidentiality() {
        return t_confidentiality;
    }
    /**
     * @param t_confidentiality la valeur de t_confidentiality à attribuer.
     */
    public void setT_confidentiality(Double t_confidentiality) {
        this.t_confidentiality = t_confidentiality;
    }
    /**
     * @return the t_priority
     */
    public Double getT_priority() {
        return t_priority;
    }
    /**
     * @param t_priority la valeur de t_priority à attribuer.
     */
    public void setT_priority(Double t_priority) {
        this.t_priority = t_priority;
    }
    /**
     * @return the t_type
     */
    public String getT_type() {
        return t_type;
    }
    /**
     * @param t_type la valeur de t_type à attribuer.
     */
    public void setT_type(String t_type) {
        this.t_type = t_type;
    }
    /**
     * @return the t_transaction
     */
    public String getT_transaction() {
        return t_transaction;
    }
    /**
     * @param t_transaction la valeur de t_transaction à attribuer.
     */
    public void setT_transaction(String t_transaction) {
        this.t_transaction = t_transaction;
    }
    /**
     * @return the t_toappli
     */
    public String getT_toappli() {
        return t_toappli;
    }
    /**
     * @param t_toappli la valeur de t_toappli à attribuer.
     */
    public void setT_toappli(String t_toappli) {
        this.t_toappli = t_toappli;
    }
    /**
     * @return the t_sender
     */
    public String getT_sender() {
        return t_sender;
    }
    /**
     * @param t_sender la valeur de t_sender à attribuer.
     */
    public void setT_sender(String t_sender) {
        this.t_sender = t_sender;
    }
    /**
     * @return the t_related_ref
     */
    public String getT_related_ref() {
        return t_related_ref;
    }
    /**
     * @param t_related_ref la valeur de t_related_ref à attribuer.
     */
    public void setT_related_ref(String t_related_ref) {
        this.t_related_ref = t_related_ref;
    }
    /**
     * @return the t_receiver
     */
    public String getT_receiver() {
        return t_receiver;
    }
    /**
     * @param t_receiver la valeur de t_receiver à attribuer.
     */
    public void setT_receiver(String t_receiver) {
        this.t_receiver = t_receiver;
    }
    /**
     * @return the t_pairing_id
     */
    public String getT_pairing_id() {
        return t_pairing_id;
    }
    /**
     * @param t_pairing_id la valeur de t_pairing_id à attribuer.
     */
    public void setT_pairing_id(String t_pairing_id) {
        this.t_pairing_id = t_pairing_id;
    }
    /**
     * @return the t_nonblocking
     */
    public Double getT_nonblocking() {
        return t_nonblocking;
    }
    /**
     * @param t_nonblocking la valeur de t_nonblocking à attribuer.
     */
    public void setT_nonblocking(Double t_nonblocking) {
        this.t_nonblocking = t_nonblocking;
    }
    /**
     * @return the t_nature
     */
    public String getT_nature() {
        return t_nature;
    }
    /**
     * @param t_nature la valeur de t_nature à attribuer.
     */
    public void setT_nature(String t_nature) {
        this.t_nature = t_nature;
    }
    /**
     * @return the t_message_id
     */
    public String getT_message_id() {
        return t_message_id;
    }
    /**
     * @param t_message_id la valeur de t_message_id à attribuer.
     */
    public void setT_message_id(String t_message_id) {
        this.t_message_id = t_message_id;
    }
    /**
     * @return the t_message
     */
    public String getT_message() {
        return t_message.replaceAll("(\\r|\\n|\\r\\n)+", "{newline}"); 
    }
    
    /**
     * @return the t_message without replace
     */
    public String getT_message_no_replace() {
        return t_message; 
    }
    
    /**
     * @param t_message la valeur de t_message à attribuer.
     */
    public void setT_message(String t_message) {
        this.t_message = t_message;
    }
    /**
     * @return the t_message_upd
     */
    public String getT_message_upd() {
        return t_message_upd;
    }
    /**
     * @param t_message_upd la valeur de t_message_upd à attribuer.
     */
    public void setT_message_upd(String t_message_upd) {
        this.t_message_upd = t_message_upd;
    }
    /**
     * @return the t_i_o
     */
    public String getT_i_o() {
        return t_i_o;
    }
    /**
     * @param t_i_o la valeur de t_i_o à attribuer.
     */
    public void setT_i_o(String t_i_o) {
        this.t_i_o = t_i_o;
    }
    /**
     * @return the t_gateway
     */
    public String getT_gateway() {
        return t_gateway;
    }
    /**
     * @param t_gateway la valeur de t_gateway à attribuer.
     */
    public void setT_gateway(String t_gateway) {
        this.t_gateway = t_gateway;
    }
    /**
     * @return the t_fromappli
     */
    public String getT_fromappli() {
        return t_fromappli;
    }
    /**
     * @param t_fromappli la valeur de t_fromappli à attribuer.
     */
    public void setT_fromappli(String t_fromappli) {
        this.t_fromappli = t_fromappli;
    }
    /**
     * @return the t_filtered
     */
    public String getT_filtered() {
        return t_filtered;
    }
    /**
     * @param t_filtered la valeur de t_filtered à attribuer.
     */
    public void setT_filtered(String t_filtered) {
        this.t_filtered = t_filtered;
    }
    /**
     * @return the t_entity
     */
    public String getT_entity() {
        return t_entity;
    }
    /**
     * @param t_entity la valeur de t_entity à attribuer.
     */
    public void setT_entity(String t_entity) {
        this.t_entity = t_entity;
    }
    /**
     * @return the t_lastoperator
     */
    public String getT_lastoperator() {
        return t_lastoperator;
    }
    /**
     * @param t_lastoperator la valeur de t_lastoperator à attribuer.
     */
    public void setT_lastoperator(String t_lastoperator) {
        this.t_lastoperator = t_lastoperator;
    }
    /**
     * @return the t_decision_type
     */
    public String getT_decision_type() {
        return t_decision_type;
    }
    /**
     * @param t_decision_type la valeur de t_decision_type à attribuer.
     */
    public void setT_decision_type(String t_decision_type) {
        this.t_decision_type = t_decision_type;
    }
    /**
     * @return the t_date_value
     */
    public String getT_date_value() {
        return t_date_value;
    }
    /**
     * @param t_date_value la valeur de t_date_value à attribuer.
     */
    public void setT_date_value(String t_date_value) {
        this.t_date_value = t_date_value;
    }
    /**
     * @return the t_currency
     */
    public String getT_currency() {
        return t_currency;
    }
    /**
     * @param t_currency la valeur de t_currency à attribuer.
     */
    public void setT_currency(String t_currency) {
        this.t_currency = t_currency;
    }
    /**
     * @return the t_created
     */
    public String getT_created() {
        return t_created;
    }
    /**
     * @param t_created la valeur de t_created à attribuer.
     */
    public void setT_created(String t_created) {
        this.t_created = t_created;
    }
    /**
     * @return the t_copy_service
     */
    public String getT_copy_service() {
        return t_copy_service;
    }
    /**
     * @param t_copy_service la valeur de t_copy_service à attribuer.
     */
    public void setT_copy_service(String t_copy_service) {
        this.t_copy_service = t_copy_service;
    }
    /**
     * @return the t_completed
     */
    public String getT_completed() {
        return t_completed;
    }
    /**
     * @param t_completed la valeur de t_completed à attribuer.
     */
    public void setT_completed(String t_completed) {
        this.t_completed = t_completed;
    }
    /**
     * @return the t_bunit
     */
    public String getT_bunit() {
        return t_bunit;
    }
    /**
     * @param t_bunit la valeur de t_bunit à attribuer.
     */
    public void setT_bunit(String t_bunit) {
        this.t_bunit = t_bunit;
    }
    /**
     * @return the t_blocking
     */
    public Double getT_blocking() {
        return t_blocking;
    }
    /**
     * @param t_blocking la valeur de t_blocking à attribuer.
     */
    public void setT_blocking(Double t_blocking) {
        this.t_blocking = t_blocking;
    }
    /**
     * @return the t_amount_float
     */
    public Float getT_amount_float() {
        return t_amount_float;
    }
    /**
     * @param t_amount_float la valeur de t_amount_float à attribuer.
     */
    public void setT_amount_float(Float t_amount_float) {
        this.t_amount_float = t_amount_float;
    }
    /**
     * @return the t_amount
     */
    public String getT_amount() {
        return t_amount;
    }
    /**
     * @param t_amount la valeur de t_amount à attribuer.
     */
    public void setT_amount(String t_amount) {
        this.t_amount = t_amount;
    }
    /**
     * @return the niveau_decision
     */
    public String getNiveau_decision() {
        return niveau_decision;
    }
    /**
     * @param niveau_decision la valeur de niveau_decision à attribuer.
     */
    public void setNiveau_decision(String niveau_decision) {
        this.niveau_decision = niveau_decision;
    }
    /**
     * @return the ind_swift_sepa
     */
    public String getInd_swift_sepa() {
        return ind_swift_sepa;
    }
    /**
     * @param ind_swift_sepa la valeur de ind_swift_sepa à attribuer.
     */
    public void setInd_swift_sepa(String ind_swift_sepa) {
        this.ind_swift_sepa = ind_swift_sepa;
    }
    /**
     * @param t_system_id
     * @param business_unit_id
     * @param saausrgrp
     * @param t_normamount
     * @param t_app_deadline
     * @param t_app_priority
     * @param t_alignment
     * @param t_confidentiality
     * @param t_priority
     * @param t_type
     * @param t_transaction
     * @param t_toappli
     * @param t_sender
     * @param t_related_ref
     * @param t_receiver
     * @param t_pairing_id
     * @param t_nonblocking
     * @param t_nature
     * @param t_message_id
     * @param t_message
     * @param t_message_upd
     * @param t_i_o
     * @param t_gateway
     * @param t_fromappli
     * @param t_filtered
     * @param t_entity
     * @param t_lastoperator
     * @param t_decision_type
     * @param t_date_value
     * @param t_currency
     * @param t_created
     * @param t_copy_service
     * @param t_completed
     * @param t_bunit
     * @param t_blocking
     * @param t_amount_float
     * @param t_amount
     * @param niveau_decision
     * @param ind_swift_sepa
     */
    public FofaHistMessageBean(String t_system_id, Double business_unit_id,
            String saausrgrp, Double t_normamount, Date t_app_deadline,
            Double t_app_priority, String t_alignment, Double t_confidentiality,
            Double t_priority, String t_type, String t_transaction,
            String t_toappli, String t_sender, String t_related_ref,
            String t_receiver, String t_pairing_id, Double t_nonblocking,
            String t_nature, String t_message_id, String t_message,
            String t_message_upd, String t_i_o, String t_gateway,
            String t_fromappli, String t_filtered, String t_entity,
            String t_lastoperator, String t_decision_type, String t_date_value,
            String t_currency, String t_created, String t_copy_service,
            String t_completed, String t_bunit, Double t_blocking,
            Float t_amount_float, String t_amount, String niveau_decision, String ind_swift_sepa) {
        super();
        this.t_system_id = t_system_id;
        this.business_unit_id = business_unit_id;
        this.saausrgrp = saausrgrp;
        this.t_normamount = t_normamount;
        this.t_app_deadline = t_app_deadline;
        this.t_app_priority = t_app_priority;
        this.t_alignment = t_alignment;
        this.t_confidentiality = t_confidentiality;
        this.t_priority = t_priority;
        this.t_type = t_type;
        this.t_transaction = t_transaction;
        this.t_toappli = t_toappli;
        this.t_sender = t_sender;
        this.t_related_ref = t_related_ref;
        this.t_receiver = t_receiver;
        this.t_pairing_id = t_pairing_id;
        this.t_nonblocking = t_nonblocking;
        this.t_nature = t_nature;
        this.t_message_id = t_message_id;
        this.t_message = t_message;
        this.t_message_upd = t_message_upd;
        this.t_i_o = t_i_o;
        this.t_gateway = t_gateway;
        this.t_fromappli = t_fromappli;
        this.t_filtered = t_filtered;
        this.t_entity = t_entity;
        this.t_lastoperator = t_lastoperator;
        this.t_decision_type = t_decision_type;
        this.t_date_value = t_date_value;
        this.t_currency = t_currency;
        this.t_created = t_created;
        this.t_copy_service = t_copy_service;
        this.t_completed = t_completed;
        this.t_bunit = t_bunit;
        this.t_blocking = t_blocking;
        this.t_amount_float = t_amount_float;
        this.t_amount = t_amount;
        this.niveau_decision = niveau_decision;
        this.ind_swift_sepa = ind_swift_sepa;
    }
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Fofa_hist_message [t_system_id="
                + t_system_id
                    + ", business_unit_id="
                    + business_unit_id
                    + ", saausrgrp="
                    + saausrgrp
                    + ", t_normamount="
                    + t_normamount
                    + ", t_app_deadline="
                    + t_app_deadline
                    + ", t_app_priority="
                    + t_app_priority
                    + ", t_alignment="
                    + t_alignment
                    + ", t_confidentiality="
                    + t_confidentiality
                    + ", t_priority="
                    + t_priority
                    + ", t_type="
                    + t_type
                    + ", t_transaction="
                    + t_transaction
                    + ", t_toappli="
                    + t_toappli
                    + ", t_sender="
                    + t_sender
                    + ", t_related_ref="
                    + t_related_ref
                    + ", t_receiver="
                    + t_receiver
                    + ", t_pairing_id="
                    + t_pairing_id
                    + ", t_nonblocking="
                    + t_nonblocking
                    + ", t_nature="
                    + t_nature
                    + ", t_message_id="
                    + t_message_id
                    + ", t_message="
                    + t_message
                    + ", t_message_upd="
                    + t_message_upd
                    + ", t_i_o="
                    + t_i_o
                    + ", t_gateway="
                    + t_gateway
                    + ", t_fromappli="
                    + t_fromappli
                    + ", t_filtered="
                    + t_filtered
                    + ", t_entity="
                    + t_entity
                    + ", t_lastoperator="
                    + t_lastoperator
                    + ", t_decision_type="
                    + t_decision_type
                    + ", t_date_value="
                    + t_date_value
                    + ", t_currency="
                    + t_currency
                    + ", t_created="
                    + t_created
                    + ", t_copy_service="
                    + t_copy_service
                    + ", t_completed="
                    + t_completed
                    + ", t_bunit="
                    + t_bunit
                    + ", t_blocking="
                    + t_blocking
                    + ", t_amount_float="
                    + t_amount_float
                    + ", t_amount="
                    + t_amount
                    + ", niveau_decision="
                    + niveau_decision
                    + ", ind_swift_sepa="
                    + ind_swift_sepa
                    + "]";
    }
    /**
     * 
     */
    public FofaHistMessageBean() {
        super();
    }
	public java.sql.Date getDate_ope() {
		return date_ope;
	}
	public void setDate_ope(java.sql.Date date_ope) {
		this.date_ope = date_ope;
	}
	public java.sql.Date getDate_insert() {
		return date_insert;
	}
	public void setDate_insert(java.sql.Date date_insert) {
		this.date_insert = date_insert;
	}
    
    

}
