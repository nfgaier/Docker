package fr.bdf.spark.embgo.alerte;

import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.fs.Path;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import fr.bdf.bastid.util.bean.LineAcqFile;
import fr.bdf.bastid.util.filereader.AcqFileReader;
import fr.bdf.spark.embgo.alerte.beans.AlerteBean;
import fr.bdf.spark.embgo.alerte.beans.FofaHistMessageBean;
import fr.bdf.spark.embgo.alerte.constant.LoadAlerteConstant;
import fr.bdf.spark.embgo.alerte.data.GetFOFAHistMessageData;
import fr.bdf.spark.embgo.alerte.data.GetParamData;
import fr.bdf.spark.embgo.alerte.data.PutAlerteData;
import fr.bdf.spark.embgo.alerte.functions.AlertFactory;
import fr.bdf.spark.embgo.alerte.functions.FofaHistMessageFactory;
import fr.bdf.spark.embgo.alerte.util.ParseParam;

public class LoadAlerteMain implements Serializable {

	private static final long serialVersionUID = -6328814976488579625L;

	public static String getTime() {
		return "[" + new SimpleDateFormat("HH:mm:ss").format(new Date())
				+ "] - ";
	}

	public static void main(String[] args) {

		if (args.length != 3) {
			System.out
					.println("INFO:"
							+ LoadAlerteMain.getTime()
							+ " Missing arguments. Usage: "
							+ new java.io.File(LoadAlerteMain.class
									.getProtectionDomain().getCodeSource()
									.getLocation().getPath()).getName()
							+ " <configuration file>"
							+ " <path to id acquisition file>"
							+ " <timestamp_trt>");
			System.exit(0);
		}

		String pathToConfigFile = args[0];
		String acqFilePath = args[1];
		String idTrt = args[2];

		/** Init configuration and contexts */
		final SparkSession session = SparkSession.builder()
				.appName("LoadAlerte")
				.config("spark.sql.warehouse.dir", "/apps/hive/warehouse")
				.config("spark.sql.hive.convertMetastoreOrc", "false")
				.enableHiveSupport().getOrCreate();
		
		session.sparkContext().hadoopConfiguration().addResource(new Path(pathToConfigFile));

		LoadAlerteConstant loadAlerteConstant = null;
		try {
			loadAlerteConstant = new LoadAlerteConstant();
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}

		Logger.getRootLogger().setLevel(Level.WARN);
		// sqlContext.sql("show databases").show();

		AcqFileReader afr = new AcqFileReader(acqFilePath);

		Map<String, List<LineAcqFile>> mapAcqFileLines = getMapAcqFileLines(afr);

		String idAcqParamNiv = afr.getIdAcqParamOrFull(mapAcqFileLines,
				LoadAlerteConstant.REF_ALT_NIV.toUpperCase());
		String idAcqParamBo = afr.getIdAcqParamOrFull(mapAcqFileLines,
				LoadAlerteConstant.REF_ALT_BO.toUpperCase());
		String idAcqParamEtat = afr.getIdAcqParamOrFull(mapAcqFileLines,
				LoadAlerteConstant.REF_ALT_ETAT.toUpperCase());
		String idAcqParamInd = afr.getIdAcqParamOrFull(mapAcqFileLines,
				LoadAlerteConstant.REF_ALT_IND.toUpperCase());
		String idAcqParamMotif = afr.getIdAcqParamOrFull(mapAcqFileLines,
				LoadAlerteConstant.REF_ALT_MOT.toUpperCase());
		
		String idAcqFmfUsers = afr.getIdAcqParamOrFull(mapAcqFileLines,
				LoadAlerteConstant.FMF_USERS.toUpperCase());

		if (!validAcqParamOrFull(idAcqParamNiv, idAcqParamBo, idAcqParamEtat,
				idAcqParamInd, idAcqParamMotif, idAcqFmfUsers)) {
			Logger.getRootLogger().error(
					"At least one of the param acquisition ids is missing");
			System.exit(0);
		}

		List<LineAcqFile> listIdAcqHistMess = mapAcqFileLines
				.get(LoadAlerteConstant.FOFA_HIST_MES.toUpperCase());

		if (!validAcqDelta(listIdAcqHistMess)) {
			Logger.getRootLogger().error(
					"At least one of the delta acquisition ids is missing");
			System.exit(0);
		}

		// get data from the source table fofa_hist_message
		Dataset<Row> fofaHistMsgDF = new GetFOFAHistMessageData(session)
				.getFOFAHistMessageData(listIdAcqHistMess,
						loadAlerteConstant.getRawLayerHiveBase()).persist();
		System.out.println("INFO:" + getTime() + "fofaHistMsgDF count : "
				+ fofaHistMsgDF.count());

		// get data from the parameter tables
		GetParamData paramData = new GetParamData(session,
				loadAlerteConstant.getRawLayerHiveBase());

		// niveau decision table
		Dataset<Row> refAlerteNiv = paramData
				.getRefAlerteNivData(idAcqParamNiv).persist();

		// back office table
		Dataset<Row> refAlerteBo = paramData.getRefAlerteBOData(idAcqParamBo);

		// etat table
		Dataset<Row> refAlerteEtat = paramData
				.getRefAlerteEtatData(idAcqParamEtat);

		// ind table
		Dataset<Row> refAlerteInd = paramData
				.getRefAlerteIndData(idAcqParamInd);

		// motif table
		Dataset<Row> refAlerteMot = paramData
				.getRefAlerteMotifData(idAcqParamMotif);

		System.out.println("INFO:" + getTime() + "refAlerteNiv count : "
				+ refAlerteNiv.count());
		System.out.println("INFO:" + getTime() + "refAlerteBo count : "
				+ refAlerteBo.count());
		System.out.println("INFO:" + getTime() + "refAlerteEtat count : "
				+ refAlerteEtat.count());
		System.out.println("INFO:" + getTime() + "refAlerteInd count : "
				+ refAlerteInd.count());
		System.out.println("INFO:" + getTime() + "refAlerteMot count : "
				+ refAlerteMot.count());

		// generate CASE WHEN foe each parameter table
		// set properties for each parameter table in order to pass them to the
		// ParseParam class
		java.util.Properties paramCols = new java.util.Properties();

		// back office
		paramCols.setProperty("compDateFieldName", "date_decision_finale");
		paramCols.setProperty("startDateFieldName", "date_decision_deb");
		paramCols.setProperty("endDateFieldName", "date_decision_fin");
		paramCols.setProperty("resultFieldName", "back_office");
		paramCols.setProperty("targetFieldName", "back_office");

		paramCols.setProperty("nbCondidions", "3");
		paramCols.setProperty("condition_1_field_name", "niveau_decision");
		paramCols.setProperty("condition_1_type", "EQUAL");
		paramCols.setProperty("condition_2_field_name", "decision_finale");
		paramCols.setProperty("condition_2_type", "LIKE");
		paramCols.setProperty("condition_3_field_name", "bo_gestion");
		paramCols.setProperty("condition_3_type", "EQUAL");

		ParseParam paramBO = new ParseParam(paramCols, refAlerteBo);
		String caseWhenBOStr = paramBO.getCaseWhenStmt();
		// System.out.println("caseWhenBOStr : " + caseWhenBOStr);

		// etat
		paramCols.clear();
		paramCols.setProperty("compDateFieldName", "date_decision_finale");
		paramCols.setProperty("startDateFieldName", "date_decision_deb");
		paramCols.setProperty("endDateFieldName", "date_decision_fin");
		paramCols.setProperty("resultFieldName", "etat");
		paramCols.setProperty("targetFieldName", "etat");

		paramCols.setProperty("nbCondidions", "1");
		paramCols.setProperty("condition_1_field_name", "decision_finale");
		paramCols.setProperty("condition_1_type", "EQUAL");

		ParseParam paramETAT = new ParseParam(paramCols, refAlerteEtat);
		String caseWhenETATStr = paramETAT.getCaseWhenStmt();
		// System.out.println("caseWhenETATStr : " + caseWhenETATStr);

		// ind
		paramCols.clear();
		paramCols.setProperty("compDateFieldName", "date_decision_finale");
		paramCols.setProperty("startDateFieldName", "date_decision_deb");
		paramCols.setProperty("endDateFieldName", "date_decision_fin");
		paramCols.setProperty("resultFieldName", "ind_swift_sepa");
		paramCols.setProperty("targetFieldName", "ind_swift_sepa");

		paramCols.setProperty("nbCondidions", "1");
		paramCols.setProperty("condition_1_field_name", "type_message");
		paramCols.setProperty("condition_1_type", "EQUAL");

		ParseParam paramIND = new ParseParam(paramCols, refAlerteInd);
		String caseWhenINDStr = paramIND.getCaseWhenStmt();
		// System.out.println("caseWhenINDStr : " + caseWhenINDStr);

		// motif_decision
		paramCols.clear();
		paramCols.setProperty("compDateFieldName", "date_decision_finale");
		paramCols.setProperty("startDateFieldName", "date_decision_deb");
		paramCols.setProperty("endDateFieldName", "date_decision_fin");
		paramCols.setProperty("resultFieldName", "motif_decision");
		paramCols.setProperty("targetFieldName", "motif_decision");

		paramCols.setProperty("nbCondidions", "1");
		paramCols.setProperty("condition_1_field_name", "decision_finale");
		paramCols.setProperty("condition_1_type", "EQUAL");

		ParseParam paramMOT = new ParseParam(paramCols, refAlerteMot);
		String caseWhenMOTStr = paramMOT.getCaseWhenStmt();
		// System.out.println("caseWhenMOTStr : " + caseWhenMOTStr);

		// join fofa_hist_message DF and niveau decision parameter DF in order
		// to get the niveau decision for each fofa_hist_message
		Dataset<Row> fofaHistMsgDFJoin = fofaHistMsgDF
				.join(refAlerteNiv,
						fofaHistMsgDF
								.col("t_decision_type")
								.equalTo(refAlerteNiv.col("decision_finale"))
								.and(fofaHistMsgDF.col("t_completed").between(
										refAlerteNiv.col("date_decision_deb"),
										refAlerteNiv.col("date_decision_fin"))),
						"left").persist();

		System.out.println("INFO:" + getTime() + "fofaHistMsgDFJoin count : " + fofaHistMsgDFJoin.count());

		PutAlerteData putAlerteHelper = new PutAlerteData(session,
				caseWhenMOTStr, caseWhenETATStr, caseWhenBOStr, caseWhenINDStr,
				LoadAlerteConstant.TMP_TABLE);

		// create a tmp table for the query
		fofaHistMsgDFJoin.createOrReplaceTempView(LoadAlerteConstant.TMP_TABLE_FOFA_HIST_MSG);

		Dataset<Row> fofaHistMsgDFWithInd = putAlerteHelper.generateFofaHistMsgWithInd(LoadAlerteConstant.TMP_TABLE_FOFA_HIST_MSG);

		System.out.println("INFO:" + getTime() + "fofaHistMsgDFWithInd count : " + fofaHistMsgDFWithInd.count());

		// create an RDD from the DataFrame in order to parse the SWIFT message
		// contained in the t_message_upd column
		JavaRDD<FofaHistMessageBean> fofaHistMsgRDD = fofaHistMsgDFWithInd
				.toJavaRDD().map(new FofaHistMessageFactory());

//		 System.out.println("INFO:" + getTime() + "fofaHistMsgRDD count : " +
//		 fofaHistMsgRDD.count());

		// parse the SIFT message and return an AlerteBean
		JavaRDD<AlerteBean> alerteRDD = fofaHistMsgRDD.map(new AlertFactory());

//		 System.out.println("INFO:" + getTime() + "alerteRDD count : " +
//		 alerteRDD.count());

		// create a DataFrame from the alerte RDD in order to run on it a query
		// with the generated Case When statements
		Dataset<Row> alerteDF = session.createDataFrame(alerteRDD,
				AlerteBean.class);

		// System.out.println("alerteDF : " + alerteDF.count());

		// create a tmp table for the query
		alerteDF.createOrReplaceTempView(LoadAlerteConstant.TMP_TABLE);

		Dataset<Row> alerteFinalDF = putAlerteHelper.generateAlerteData(idTrt, idAcqFmfUsers)
				.persist();
		// System.out.println("alerteFinalDF : ");
		// alerteFinalDF.show();

//		 System.out.println("INFO:" + getTime() +"Write " +
//		 alerteFinalDF.count() + "records to path " +
		// LoadAlerteConstant.ALERTE_HDFS_PATH+"/id_traitement="+idTrt);

		putAlerteHelper
				.writeAlerteData(loadAlerteConstant.getWorkLayerPath(),
						loadAlerteConstant.getWorkLayerHiveBase(),
						alerteFinalDF, idTrt);

		session.close();
	}

	/**
	 * Method that gets the acquisition ids needed for the treatment.
	 * 
	 * @param afr
	 *            the acquisition file reader
	 * @return the map that contains the acquisition ids needed for the
	 *         treatment
	 */
	private static Map<String, List<LineAcqFile>> getMapAcqFileLines(
			AcqFileReader afr) {
		Map<String, List<LineAcqFile>> mapAcqFileLines = null;
		try {
			mapAcqFileLines = afr.getAcqFileLines();
		} catch (IOException e) {
			Logger.getRootLogger().error(
					"An error occured when reading the file", e);
			System.exit(0);
		}

		if (mapAcqFileLines == null || mapAcqFileLines.isEmpty()) {
			Logger.getRootLogger().error(
					"The acquisition id map is null or empty");
			System.exit(0);
		}
		return mapAcqFileLines;
	}

	/**
	 * Method that verifies if the acquisition ids for param or full tables are valid.
	 * 
	 * @param idAcqParamNiv
	 *            the acquisition id for PARAM_ALERTE_NIVEAU
	 * @param idAcqParamBo
	 *            the acquisition id for PARAM_ALERTE_BO
	 * @param idAcqParamEtat
	 *            the acquisition id for PARAM_ALERTE_ETAT
	 * @param idAcqParamInd
	 *            the acquisition id for PARAM_ALERTE_IND
	 * @param idAcqParamMotif
	 *            the acquisition id for PARAM_ALERTE_MOTIF
	 * @param idAcqFmfUsers
	 *            the acquisition id for FMF_USERS
	 * @return true if all the acquisition ids are valid, false if not
	 */
	private static boolean validAcqParamOrFull(String idAcqParamNiv,
			String idAcqParamBo, String idAcqParamEtat, String idAcqParamInd,
			String idAcqParamMotif, String idAcqFmfUsers) {
		return idAcqParamNiv != null && !"".equals(idAcqParamNiv)
				&& idAcqParamBo != null && !"".equals(idAcqParamBo)
				&& idAcqParamEtat != null && !"".equals(idAcqParamEtat)
				&& idAcqParamInd != null && !"".equals(idAcqParamInd)
				&& idAcqParamMotif != null && !"".equals(idAcqParamMotif)
				&& idAcqFmfUsers != null && !"".equals(idAcqFmfUsers);
	}

	/**
	 * Method that verifies if the acquisition ids for delta tables are valid.
	 * 
	 * @param listIdAcqHistMess
	 *            the list of acquisition ids for FOFA_HIST_MESSAGE
	 * @return true if all the acquisition ids are valid, false if not
	 */
	private static boolean validAcqDelta(List<LineAcqFile> listIdAcqHistMess) {
		return listIdAcqHistMess != null && !listIdAcqHistMess.isEmpty();
	}

}
