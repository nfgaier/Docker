/**
 * 
 */
package fr.bdf.spark.embgo.alerte.functions;

import java.io.IOException;
import java.math.BigDecimal;

import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.function.Function;

import com.prowidesoftware.swift.io.parser.SwiftParser;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.mt.AbstractMT;

import fr.bdf.spark.embgo.alerte.beans.AlerteBean;
import fr.bdf.spark.embgo.alerte.beans.FofaHistMessageBean;
import fr.bdf.spark.embgo.alerte.constant.LoadAlerteConstant;
import fr.bdf.spark.embgo.alerte.util.ParseSEPAUtil;
import fr.bdf.spark.embgo.alerte.util.ParseSWIFTUtil;

public class AlertFactory implements Function<FofaHistMessageBean, AlerteBean> {

	private static final long serialVersionUID = -957514154910085586L;
	
	@Override
	public AlerteBean call(FofaHistMessageBean v1) throws Exception {

		// Destination record
		AlerteBean alerte = null;

		// Contains all utility methods to extract SWIFt data from the tags
		ParseSWIFTUtil tagParser = new ParseSWIFTUtil();

		alerte = new AlerteBean();
		
		if (v1 != null && StringUtils.isNotBlank(v1.getT_type())) {
			if (LoadAlerteConstant.SEPA.equals(v1.getInd_swift_sepa())
					&& !v1.getT_message().contains("<MsgId>")) {
				
				/** PART FOR SEPA PARSING */
				parseAlertFromSEPA(alerte, v1.getT_message_no_replace(), v1.getT_type());

			} else if (LoadAlerteConstant.SWIFT.equals(v1.getInd_swift_sepa())) {
				
				/** PART FOR SWIFT PARSING */
			    parseAlertFromSWIFT(alerte, v1.getT_message_upd());
			}
			
			
			// Other fields to map (other than SWIFT and SEPA data)
			alerte.setRef_transaction(v1.getT_transaction());
			alerte.setId_alerte(v1.getT_system_id());
			alerte.setDernier_utilisateur(v1.getT_lastoperator());
			alerte.setId_utilisateur(null);
			alerte.setMontant_transaction(tagParser.parseBigDecimalTag(v1.getT_amount()));
			alerte.setBlocking(getBigDecimalFromDouble(v1.getT_blocking()));
			alerte.setBunit(v1.getT_bunit());
			alerte.setDate_decision_finale(tagParser.tsFromString(v1.getT_completed()));
			alerte.setCopy_service(v1.getT_copy_service());
			alerte.setDate_creation_transact(tagParser.tsFromString(v1.getT_created()));
			alerte.setDevise_transaction(v1.getT_currency());
			alerte.setDate_valeur_transact(tagParser.dateFromString(v1.getT_date_value()));
			alerte.setDecision_finale(v1.getT_decision_type());
			alerte.setNiveau_decision(null);
			alerte.setMotif_decision(null);
			alerte.setEtat(null);
			alerte.setBo_gestion(v1.getT_entity());
			alerte.setBack_office(null);
			alerte.setDate_filtre(tagParser.tsFromString(v1.getT_filtered()));
			alerte.setSaa_origine(v1.getT_fromappli());
			alerte.setSaa_destination(v1.getT_toappli());
			alerte.setGateway(v1.getT_gateway());
			alerte.setBic_bq_emet(v1.getT_sender());
			alerte.setBic_bq_dest(v1.getT_receiver());
			alerte.setRef_related(v1.getT_related_ref());
			alerte.setRef_transaction(v1.getT_transaction());
			alerte.setType_message(v1.getT_type());
			alerte.setInd_swift_sepa(v1.getInd_swift_sepa());
			alerte.setSens_flux_e_r(v1.getT_i_o());
			alerte.setId_message(v1.getT_message_id());
			alerte.setMessage_clob(v1.getT_message());
			// End block
			alerte.setNature(v1.getT_nature());
			alerte.setNonblocking(getBigDecimalFromDouble(v1.getT_nonblocking()));
			alerte.setId_pairing(v1.getT_pairing_id());
			alerte.setPriorite(getBigDecimalFromDouble(v1.getT_priority()));
			alerte.setConfidentialite(getBigDecimalFromDouble(v1.getT_confidentiality()));
			alerte.setAlignement(v1.getT_alignment());
			alerte.setApp_priority(getBigDecimalFromDouble(v1.getT_app_priority()));
			alerte.setApp_deadline(
					v1.getT_app_deadline() == null ? null : new java.sql.Timestamp(v1.getT_app_deadline().getTime()));
			alerte.setNormamount(getBigDecimalFromDouble(v1.getT_normamount()));
			alerte.setSaausrgrp(v1.getSaausrgrp());
			alerte.setId_business_unit(getBigDecimalFromDouble(v1.getBusiness_unit_id()));
			alerte.setNiveau_decision(v1.getNiveau_decision());
			alerte.setDate_ope(v1.getDate_ope());
			alerte.setDate_insert(v1.getDate_insert());

		}
		return alerte;
		
	}

	/**
	 * Method to build Alert output from SEPA msg
	 * 
	 * @param alerte
	 *            , AlerteBean to complete
	 * @param msg
	 *            , message SEPA to parse
	 * @param msgType
	 *            , SEPA type (PACS003 / PACS008)
	 * @return alerteFull , AlerteBean completed with SEPA infos
	 */
	private void parseAlertFromSEPA(AlerteBean alerte, String msg, String msgType) {
		final ParseSEPAUtil parser = new ParseSEPAUtil();

		alerte.setMsg_ref_transaction(parser.getFieldBPMTID(msg));
		alerte.setMsg_code_operation(parser.getFieldBSVCLVL(msg));
		alerte.setMsg_devise_credit(parser.getCurrencyFieldBSTTLAMT(parser.getFieldBSTTLAMT(msg)));
		if (parser.getFieldBSTTLAMT(msg) != null && parser.getAmountFieldBSTTLAMT(parser.getFieldBSTTLAMT(msg)) != null) {
			alerte.setMsg_mnt_credit(BigDecimal.valueOf(Double.parseDouble(parser.getAmountFieldBSTTLAMT(parser.getFieldBSTTLAMT(msg)))));
		}

		alerte.setMsg_num_cpt_bq_tie(parser.getFieldATHRGRAGAC(msg));
		alerte.setMsg_bic_bq_tie(parser.getFieldATHRGRAG(msg));

		alerte.setMsg_bic_bq_int(parser.getFieldBINTAG1(msg));
		
        alerte.setMsg_commentaire(parser.getFieldBRGLRPTG(msg));

		if (LoadAlerteConstant.TYPE_PACS003.equals(msgType)) {
			alerte.setMsg_num_cpt_do(parser.getFieldBCDTRAC(msg));
			alerte.setMsg_nom_do(parser.getFieldBCDTRName(parser.getFieldBCDTR(msg)));
			alerte.setMsg_adresse_do(parser.getFieldBCDTRAddress(parser.getFieldBCDTR(msg)));
			alerte.setMsg_num_cpt_bq_do(parser.getFieldBCDTRAGAC(msg));
			alerte.setMsg_bic_bq_do(parser.getFieldBCDTRAG(msg));
			alerte.setMsg_num_cpt_bq_em(parser.getFieldAINDRAGAC(msg));
			alerte.setMsg_bic_bq_em(parser.getFieldAINDRAG(msg));
			alerte.setMsg_num_cpt_bq_dest(parser.getFieldAINGRAGAC(msg));
			alerte.setMsg_bic_bq_dest(parser.getFieldAINGRAG(msg));
			alerte.setMsg_num_cpt_bq_int(parser.getFieldBINTAGAC1(msg));
			alerte.setMsg_num_cpt_bq_du_benef(parser.getFieldBDBTRAGAC(msg));
			alerte.setMsg_bic_bq_du_benef(parser.getFieldBDBTRAG(msg));
			alerte.setMsg_num_cpt_benef(parser.getFieldBDBTRAC(msg));
			alerte.setMsg_nom_benef(parser.getFieldBDBTRName(parser.getFieldBDBTR(msg)));
			alerte.setMsg_adresse_benef(parser.getFieldBDBTRAddress(parser.getFieldBDBTR(msg)));
			alerte.setMsg_motif_paiement(parser.getFieldBRELREMIT(msg));
			alerte.setMsg_mode_paiement_chg(parser.getFieldBCHGBR(msg));
			alerte.setMsg_detail_charge(parser.getFieldBCHGINF(msg));

		} else if (LoadAlerteConstant.TYPE_PACS008.equals(msgType)) {
			alerte.setMsg_num_cpt_do(parser.getFieldBDBTRAC(msg));
			alerte.setMsg_nom_do(parser.getFieldBDBTRName(parser.getFieldBDBTR(msg)));
			alerte.setMsg_adresse_do(parser.getFieldBDBTRAddress(parser.getFieldBDBTR(msg)));
			alerte.setMsg_num_cpt_bq_do(parser.getFieldBDBTRAGAC(msg));
			alerte.setMsg_bic_bq_do(parser.getFieldBDBTRAG(msg));
			alerte.setMsg_num_cpt_bq_em(parser.getFieldAINGRAGAC(msg));
			alerte.setMsg_bic_bq_em(parser.getFieldAINGRAG(msg));
			alerte.setMsg_num_cpt_bq_dest(parser.getFieldAINDRAGAC(msg));
			alerte.setMsg_bic_bq_dest(parser.getFieldAINDRAG(msg));
			alerte.setMsg_num_cpt_bq_int(parser.getFieldBINTAG1AC(msg));
			alerte.setMsg_num_cpt_bq_du_benef(parser.getFieldBCDTRAGAC(msg));
			alerte.setMsg_bic_bq_du_benef(parser.getFieldBCDTRAG(msg));
			alerte.setMsg_num_cpt_benef(parser.getFieldBCDTRAC(msg));
			alerte.setMsg_nom_benef(parser.getFieldBCDTRName(parser.getFieldBCDTR(msg)));
			alerte.setMsg_adresse_benef(parser.getFieldBCDTRAddress(parser.getFieldBCDTR(msg)));
			alerte.setMsg_motif_paiement(parser.getFieldBREMITINF(msg));
			alerte.setMsg_mode_paiement_chg(parser.getFieldBCHRGBR(msg));
			alerte.setMsg_detail_charge(parser.getFieldBCHGINF(msg));
			alerte.setMsg_message_bq(parser.getFieldBINSTCDAG(msg));
		}

	}
	
	
	/**
     * Method to build Alert output from SWIF msg
     * 
     * @param alerte, AlerteBean to complete
     * @param msg
     *            , message SEPA to parse
     * @return alerteFull , AlerteBean completed with SWIFT infos
     */
	private void parseAlertFromSWIFT(AlerteBean alerte, String messageMT) throws IOException {
	    
	    // Contains all utility methods to extract SWIFt data from the tags
        ParseSWIFTUtil tagParser = new ParseSWIFTUtil();
	    
        AbstractMT msgTmp = new SwiftParser(messageMT).message().toMT();

        SwiftMessage swiftMessage = msgTmp.getSwiftMessage();

        // Mapping of destination record
        alerte.setMsg_ref_transaction(tagParser.getRefTransaction(swiftMessage.getBlock4().getTagValue("20")));
        alerte.setMsg_code_operation(tagParser.getCodeOperation(swiftMessage.getBlock4().getTagValue("23B")));

        // Debit
        alerte.setMsg_date_valeur(tagParser.getMsgDateValeur(swiftMessage.getBlock4().getTagValue("32A")));
        alerte.setMsg_devise_credit(tagParser.getMsgDeviseCredit(swiftMessage.getBlock4().getTagValue("32A")));
        alerte.setMsg_mnt_credit(tagParser.getMsgMntCredit(swiftMessage.getBlock4().getTagValue("32A")));

        // Credit
        alerte.setMsg_devise_debit(tagParser.getMsgDeviseDebit(swiftMessage.getBlock4().getTagValue("33B")));
        alerte.setMsg_mnt_debit(tagParser.getMsgMntDebit(swiftMessage.getBlock4().getTagValue("33B")));
        alerte.setMsg_taux_change(tagParser.getMsgTauxChange(swiftMessage.getBlock4().getTagValue("36")));

        // Donneur d'ordre
        alerte.setMsg_num_cpt_do(
        		tagParser.getMsgNumCptDo(
        				(swiftMessage.getBlock4().getTagValue("50A") != null ? swiftMessage.getBlock4().getTagValue("50A") : "") + 
        				(swiftMessage.getBlock4().getTagValue("50K") != null ? swiftMessage.getBlock4().getTagValue("50K") : "") + 
        				(swiftMessage.getBlock4().getTagValue("50F") != null ? swiftMessage.getBlock4().getTagValue("50F") : "")));
        alerte.setMsg_bic_do(tagParser.getMsgBicDo(swiftMessage.getBlock4().getTagValue("50A")));
        alerte.setMsg_nom_do(
                tagParser.getMsgNomDo(
                		(swiftMessage.getBlock4().getTagValue("50L") != null ? swiftMessage.getBlock4().getTagValue("50L") : "") +
                		(swiftMessage.getBlock4().getTagValue("50K") != null ? swiftMessage.getBlock4().getTagValue("50K") : "") +
                		(swiftMessage.getBlock4().getTagValue("50F") != null ? swiftMessage.getBlock4().getTagValue("50F") : "") +
                		(swiftMessage.getBlock4().getTagValue("50H") != null ? swiftMessage.getBlock4().getTagValue("50H") : "")));
        alerte.setMsg_adresse_do(
        		tagParser.getMsgAdresseBo(
        				(swiftMessage.getBlock4().getTagValue("50K") != null ? swiftMessage.getBlock4().getTagValue("50K") : "") +
        				(swiftMessage.getBlock4().getTagValue("50F") != null ? swiftMessage.getBlock4().getTagValue("50F") : "") +
        				(swiftMessage.getBlock4().getTagValue("50H") != null ? swiftMessage.getBlock4().getTagValue("50H") : "")));

        // Banque du donneur d'ordre
        alerte.setMsg_num_cpt_bq_do(
                tagParser.getMsgNumCptBqDo(
                		(swiftMessage.getBlock4().getTagValue("52A") != null ? swiftMessage.getBlock4().getTagValue("52A") : "") +
                		(swiftMessage.getBlock4().getTagValue("52D") != null ? swiftMessage.getBlock4().getTagValue("52D") : "")));
        alerte.setMsg_bic_bq_do(tagParser.getMsgBicBqDo(swiftMessage.getBlock4().getTagValue("52A")));
        alerte.setMsg_nom_bq_do(tagParser.getMsgNomBqDo(swiftMessage.getBlock4().getTagValue("52D")));
        alerte.setMsg_adresse_bq_do(tagParser.getMsgAdresseBqDo(swiftMessage.getBlock4().getTagValue("52D")));

        // Banque de l'emmeteur
        alerte.setMsg_num_cpt_bq_em(
                tagParser.getMsgNumCptBqEm(
                		(swiftMessage.getBlock4().getTagValue("53A") != null ? swiftMessage.getBlock4().getTagValue("53A") : "") +
                		(swiftMessage.getBlock4().getTagValue("53B") != null ? swiftMessage.getBlock4().getTagValue("53B") : "") + 
                		(swiftMessage.getBlock4().getTagValue("53D") != null ? swiftMessage.getBlock4().getTagValue("53D") : "")));
        alerte.setMsg_bic_bq_em(tagParser.getMsgBicBqEm(swiftMessage.getBlock4().getTagValue("53A")));
        alerte.setMsg_nom_bq_em(tagParser.getMsgNomBqEm(swiftMessage.getBlock4().getTagValue("53D")));
        alerte.setMsg_adresse_bq_em(tagParser.getMsgAdresseBqEm(swiftMessage.getBlock4().getTagValue("53D")));

        // Banque du destinataire
        alerte.setMsg_num_cpt_bq_dest(
                tagParser.getMsgNumCptBqDest(
                		(swiftMessage.getBlock4().getTagValue("54A") != null ? swiftMessage.getBlock4().getTagValue("54A") : "") +
                		(swiftMessage.getBlock4().getTagValue("54D") != null ? swiftMessage.getBlock4().getTagValue("54D") : "")));
        alerte.setMsg_bic_bq_dest(tagParser.getMsgBicBqDest(swiftMessage.getBlock4().getTagValue("54A")));
        alerte.setMsg_nom_bq_dest(tagParser.getMsgNomBqDest(swiftMessage.getBlock4().getTagValue("54D")));
        alerte.setMsg_adresse_bq_dest(tagParser.getMsgAdresseBqDest(swiftMessage.getBlock4().getTagValue("54D")));

        // Banque Tierce
        alerte.setMsg_num_cpt_bq_tie(
                tagParser.getMsgNumCptBqTie(
                        (swiftMessage.getBlock4().getTagValue("55A") != null ? swiftMessage.getBlock4().getTagValue("55A") : "") +
                        (swiftMessage.getBlock4().getTagValue("55D") != null ? swiftMessage.getBlock4().getTagValue("55D") : "")));
        alerte.setMsg_bic_bq_tie(tagParser.getMsgBicBqTie(swiftMessage.getBlock4().getTagValue("55A")));
        alerte.setMsg_nom_bq_tie(tagParser.getMsgNomBqTie(swiftMessage.getBlock4().getTagValue("55D")));
        alerte.setMsg_adresse_bq_tie(tagParser.getMsgAdresseBqTie(swiftMessage.getBlock4().getTagValue("55D")));

        // Banque Intermediaire
        alerte.setMsg_num_cpt_bq_int(
                tagParser.getMsgNumCptBqInt(
                		(swiftMessage.getBlock4().getTagValue("56A") != null ? swiftMessage.getBlock4().getTagValue("56A") : "") +
                		(swiftMessage.getBlock4().getTagValue("56D") != null ? swiftMessage.getBlock4().getTagValue("56D") : "")));
        alerte.setMsg_bic_bq_int(tagParser.getMsgBicBqInt(swiftMessage.getBlock4().getTagValue("56A")));
        alerte.setMsg_nom_bq_int(tagParser.getMsgNomBqInt(swiftMessage.getBlock4().getTagValue("56D")));
        alerte.setMsg_adresse_bq_int(tagParser.getMsgAdresseBqInt(swiftMessage.getBlock4().getTagValue("56D")));

        // Banque du beneficiaire
        alerte.setMsg_num_cpt_bq_du_benef(
                tagParser.getMsgNumCptBqDuBenef(
                		(swiftMessage.getBlock4().getTagValue("57A") != null ? swiftMessage.getBlock4().getTagValue("57A") : "") +
                		(swiftMessage.getBlock4().getTagValue("57D") != null ? swiftMessage.getBlock4().getTagValue("57D") : "")));
        alerte.setMsg_bic_bq_du_benef(tagParser.getMsgBicBqDuBenef(swiftMessage.getBlock4().getTagValue("57A")));
        alerte.setMsg_nom_bq_du_benef(tagParser.getMsgNomBqDuBenef(swiftMessage.getBlock4().getTagValue("57D")));
        alerte.setMsg_adresse_bq_du_benef(tagParser.getMsgAdresseBqDuBenef(swiftMessage.getBlock4().getTagValue("57D")));

        // Banque beneficiaire
        alerte.setMsg_num_cpt_bq_benef(
                tagParser.getMsgNumCptBqBenef(
                		(swiftMessage.getBlock4().getTagValue("58A") != null ? swiftMessage.getBlock4().getTagValue("58A") : "") +
                		(swiftMessage.getBlock4().getTagValue("58D") != null ? swiftMessage.getBlock4().getTagValue("58D") : "")));
        alerte.setMsg_bic_bq_benef(tagParser.getMsgBicBqBenef(swiftMessage.getBlock4().getTagValue("58A")));
        alerte.setMsg_nom_bq_benef(tagParser.getMsgNomBqBenef(swiftMessage.getBlock4().getTagValue("58D")));
        alerte.setMsg_adresse_bq_benef(tagParser.getMsgAdresseBqBenef(swiftMessage.getBlock4().getTagValue("58D")));

        // Beneficiaire
        if (swiftMessage.getBlock4().getTagValue("59") != null && !swiftMessage.getBlock4().getTagValue("59").trim().equals("")) {
            alerte.setMsg_num_cpt_benef(tagParser.getMsgNumCptBenef(swiftMessage.getBlock4().getTagValue("59")));
        } else if (swiftMessage.getBlock4().getTagValue("59A") != null  && !swiftMessage.getBlock4().getTagValue("59A").trim().equals("")) {
            alerte.setMsg_num_cpt_benef(tagParser.getMsgNumCptBenef(swiftMessage.getBlock4().getTagValue("59A")));
        } else if (swiftMessage.getBlock4().getTagValue("59F") != null && !swiftMessage.getBlock4().getTagValue("59F").trim().equals("")) {
            alerte.setMsg_num_cpt_benef(tagParser.getMsgNumCptBenef(swiftMessage.getBlock4().getTagValue("59F")));
        }

        alerte.setMsg_bic_benef(tagParser.getMsgBicBenef(swiftMessage.getBlock4().getTagValue("59A")));
        alerte.setMsg_nom_benef(
        		tagParser.getMsgNomBenef(
        				(swiftMessage.getBlock4().getTagValue("59F") != null ? swiftMessage.getBlock4().getTagValue("59F") : "") +
        				(swiftMessage.getBlock4().getTagValue("59") != null ? swiftMessage.getBlock4().getTagValue("59") : ""),
        				(swiftMessage.getBlock4().getTagValue("59F") != null ? "59F" : "") +
        				(swiftMessage.getBlock4().getTagValue("59") != null ? "59" : "")));

        if (swiftMessage.getBlock4().getTagValue("59F") != null && !swiftMessage.getBlock4().getTagValue("59F").trim().equals("")) {
            alerte.setMsg_adresse_benef(tagParser.getMsgAdresseBenef(swiftMessage.getBlock4().getTagValue("59F"), "59F"));
        } else if (swiftMessage.getBlock4().getTagValue("59") != null && !swiftMessage.getBlock4().getTagValue("59").trim().equals("")) {
            alerte.setMsg_adresse_benef(tagParser.getMsgAdresseBenef(swiftMessage.getBlock4().getTagValue("59"), "59"));
        }

        // Infos
        alerte.setMsg_motif_paiement(tagParser.getMsgMotifPaiement(swiftMessage.getBlock4().getTagValue("70")));
        alerte.setMsg_message_bq(tagParser.getMsgMessageBq(swiftMessage.getBlock4().getTagValue("72")));
        alerte.setMsg_commentaire(tagParser.getMsgCommentaire(swiftMessage.getBlock4().getTagValue("79")));

        // Charges
        alerte.setMsg_mode_paiement_chg(tagParser.getMsgModePaiementChg(swiftMessage.getBlock4().getTagValue("71A")));
        alerte.setMsg_detail_charge(tagParser.getMsgDetailCharge(swiftMessage.getBlock4().getTagValue("71B")));
        alerte.setMsg_devise_chg_em(tagParser.getMsgDeviseChgEm(swiftMessage.getBlock4().getTagValue("71F")));
        alerte.setMsg_mnt_chg_em(tagParser.getMsgMntChgEm(swiftMessage.getBlock4().getTagValue("71F")));
        alerte.setMsg_devise_chg_benef(tagParser.getMsgDeviseChgBenef(swiftMessage.getBlock4().getTagValue("71G")));
        alerte.setMsg_mnt_chg_benef(tagParser.getMsgMntChgBenef(swiftMessage.getBlock4().getTagValue("71G")));
	    
	}

	/**
	 * Helper method to avoid NullPointerException when parsing Double to BigDecimal 
	 * @param a double value
	 * @return
	 */
    private BigDecimal getBigDecimalFromDouble(Double d) {
        return d == null ? null : BigDecimal.valueOf(d);
    }

}
