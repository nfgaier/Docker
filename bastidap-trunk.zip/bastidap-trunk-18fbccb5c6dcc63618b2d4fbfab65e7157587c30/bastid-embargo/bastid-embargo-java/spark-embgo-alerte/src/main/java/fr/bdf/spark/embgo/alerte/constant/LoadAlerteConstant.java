/**
 * 
 */
package fr.bdf.spark.embgo.alerte.constant;

import java.io.IOException;
import java.io.Serializable;

import fr.bdf.embgo.common.EmbgoCommonResource;

public class LoadAlerteConstant extends EmbgoCommonResource implements
		Serializable {

	private static final long serialVersionUID = 5144104600951183629L;

	/** prefix used for the dynamic properties set in the processor */
	public static final String CONDITION_PREFIX = "condition_";

	/** suffix used for the condition field name property set in the processor */
	public static final String CONDITION_FIELD_SUFFIX = "_field_name";

	/** suffix used for the condition type property set in the processor */
	public static final String CONDITION_TYPE_SUFFIX = "_type";

	/** date used as default start date */
	public static final String MIN_DATE = "1900-01-01";

	/** date used as default end date */
	public static final String MAX_DATE = "2900-01-01";

	/** value used in the condition properties when testing an equality */
	public static final String CONDITION_EQUAL = "EQUAL";

	/**
	 * value used in the condition properties when testing a presence with a
	 * wild card %
	 */
	public static final String CONDITION_LIKE = "LIKE";

	/** null value */
	public static final String NULL = "NULL";

	/** alerte temp table name */
	public static final String TMP_TABLE = "alerteTmp";

	/** alerte temp table name */
	public static final String TMP_TABLE_FOFA_HIST_MSG = "fofaHistMsgTmp";

	/** hive databases */
	// public static final String HIVE_RAW_LAYER = "embargo_raw_layer";
	// public static final String HIVE_LAN_LAYER = "embargo_landing_layer";
	// public static final String HIVE_WRK_LAYER = "embargo_work_layer";

	/** hive tables */
	public static final String TABLE_ALERTE = "alerte";
	public static final String FOFA_HIST_MES = "fofa_hist_message";
	public static final String FMF_USERS = "fmf_users";
	public static final String REF_ALT_BO = "param_alerte_bo";
	public static final String REF_ALT_NIV = "param_alerte_niveau";
	public static final String REF_ALT_MOT = "param_alerte_motif";
	public static final String REF_ALT_ETAT = "param_alerte_etat";
	public static final String REF_ALT_IND = "param_alerte_ind";

	/** Constant for PACS003 */
	public static final String TYPE_PACS003 = "PACS.003";

	/** Constant for PACS008 */
	public static final String TYPE_PACS008 = "PACS.008";

	/** Constant for SWIFT */
	public static final String SWIFT = "SWIFT";

	/** Constant for SEPA */
	public static final String SEPA = "SEPA";

	public LoadAlerteConstant() throws IOException {
		super();
	}

}
