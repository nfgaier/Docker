package fr.bdf.spark.embgo.alerte.util;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;

import junit.framework.Assert;

public class ParseSEPAUtilTest {

	private ParseSEPAUtil parser;
	
	@Before
	public void init() {
		this.parser = new ParseSEPAUtil();
	}
	
	
	@Test
	public void testParsePACS003() throws IOException {
		String strInput = this.getSEPAFromFile("sepa-example-pacs003-text.txt");
				//.replace("\\r\\n", "\\n");

		
		/** Test */
		Assert.assertEquals(parser.getFieldBPMTID(strInput), "TRAORE-BOIT-SANS-SOIF-004");
		Assert.assertEquals(parser.getFieldBSVCLVL(strInput), "SEPA");
		Assert.assertEquals(parser.getFieldBSTTLAMT(strInput), "EUR110.49");
		Assert.assertEquals(parser.getCurrencyFieldBSTTLAMT(parser.getFieldBSTTLAMT(strInput)), "EUR");
		Assert.assertEquals(parser.getAmountFieldBSTTLAMT(parser.getFieldBSTTLAMT(strInput)), "110.49");
		Assert.assertEquals(parser.getFieldBDBTRAG(strInput), "DEUTDEFF");
		Assert.assertEquals(parser.getFieldBDBTRAGAC(strInput), "MC583");
		Assert.assertEquals(parser.getFieldBCDTRAG(strInput), "BDFEFRP0XXX");
		Assert.assertEquals(parser.getFieldBCDTRAGAC(strInput), "FR353000100806A670000000030");
		Assert.assertEquals(parser.getFieldAINDRAG(strInput), "NSGBEGCXXXX");
		Assert.assertEquals(parser.getFieldAINDRAGAC(strInput), null);
		Assert.assertEquals(parser.getFieldAINGRAG(strInput), "NSGBEGCXXXX");
		Assert.assertEquals(parser.getFieldAINGRAGAC(strInput), "FR7630001000640000009041216");
		Assert.assertEquals(parser.getFieldATHRGRAG(strInput), "NSGBEGCXXXX");
		Assert.assertEquals(parser.getFieldATHRGRAGAC(strInput), null);
		Assert.assertEquals(parser.getFieldBINTAG1(strInput), "NSGBEGCXXXX");
		Assert.assertEquals(parser.getFieldBINTAG1AC(strInput), null);
		Assert.assertEquals(parser.getFieldBINTAGAC1(strInput), null);
		Assert.assertEquals(parser.getFieldBDBTRAC(strInput), "FR7630001000640000004603369");
		Assert.assertEquals(parser.getFieldBCDTRAC(strInput), "FR9430001000330000C38055690");
		Assert.assertEquals(parser.getFieldBDBTR(strInput), "Jones Sr\r\nUS\r\n19 Hudson Street\r\nNJ 07302 Jersey City\r\nDEUTDEFFXXX");
		Assert.assertEquals(parser.getFieldBDBTRName(parser.getFieldBDBTR(strInput)), "Jones Sr");
		Assert.assertEquals(parser.getFieldBDBTRAddress(parser.getFieldBDBTR(strInput)), "US 19 Hudson Street NJ 07302 Jersey City DEUTDEFFXXX");
		Assert.assertEquals(parser.getFieldBCDTR(strInput), "Virgay\r\nUS\r\n36 Virginia Lane\r\nNJ 07311 Jersey City");
		Assert.assertEquals(parser.getFieldBCDTRName(parser.getFieldBCDTR(strInput)), "Virgay");
		Assert.assertEquals(parser.getFieldBCDTRAddress(parser.getFieldBCDTR(strInput)), "US 36 Virginia Lane NJ 07311 Jersey City");
		Assert.assertEquals(parser.getFieldBCHGINF(strInput), null);
		Assert.assertEquals(parser.getFieldBREMITINF(strInput), "060133009260088506 111");
		Assert.assertEquals(parser.getFieldBCHRGBR(strInput), "SLEV");
		Assert.assertEquals(parser.getFieldBRELREMIT(strInput), null);
		Assert.assertEquals(parser.getFieldBCHGBR(strInput), "SLEV");
		Assert.assertEquals(parser.getFieldBRGLRPTG(strInput), null);
		Assert.assertEquals(parser.getFieldBINSTCDAG(strInput), null);
		
		
	}
	
	
	@Test
	public void testParsePACS008() throws IOException {
		String strInput = this.getSEPAFromFile("sepa-example-pacs008-text.txt").replace("\\r\\n", "\\n");

		
		/** Test */
		Assert.assertEquals(parser.getFieldBPMTID(strInput), "0600960039019");
		Assert.assertEquals(parser.getFieldBSVCLVL(strInput), "SEPA");
		Assert.assertEquals(parser.getFieldBSTTLAMT(strInput), "EUR107000");
		Assert.assertEquals(parser.getCurrencyFieldBSTTLAMT(parser.getFieldBSTTLAMT(strInput)), "EUR");
		Assert.assertEquals(parser.getAmountFieldBSTTLAMT(parser.getFieldBSTTLAMT(strInput)), "107000");
		Assert.assertEquals(parser.getFieldBDBTRAG(strInput), "CDCGFRPPXXX");
		Assert.assertEquals(parser.getFieldBDBTRAGAC(strInput), null);
		Assert.assertEquals(parser.getFieldBCDTRAG(strInput), "LOYDGB21320");
		Assert.assertEquals(parser.getFieldBCDTRAGAC(strInput), "B_CDTRAGAC TEST");
		Assert.assertEquals(parser.getFieldAINDRAG(strInput), null);
		Assert.assertEquals(parser.getFieldAINDRAGAC(strInput), "FR7630001000640000009041216");
		Assert.assertEquals(parser.getFieldAINGRAG(strInput), "NSGBEGCXXXX");
		Assert.assertEquals(parser.getFieldAINGRAGAC(strInput), null);
		Assert.assertEquals(parser.getFieldATHRGRAG(strInput), "NSGBEGCXXXX");
		Assert.assertEquals(parser.getFieldATHRGRAGAC(strInput), null);
		Assert.assertEquals(parser.getFieldBINTAG1(strInput), "NSGBEGCXXXX");
		Assert.assertEquals(parser.getFieldBINTAG1AC(strInput), null);
		Assert.assertEquals(parser.getFieldBINTAGAC1(strInput), null);
		Assert.assertEquals(parser.getFieldBDBTRAC(strInput), "FR3440031000010000118611Z27");
		Assert.assertEquals(parser.getFieldBCDTRAC(strInput), "FR7630788001001070607280014");
		Assert.assertEquals(parser.getFieldBDBTR(strInput), "SCP COLAS FLEURY MALDERET\r\nFR\r\n62 AV DE LEVALLOIS PERRET          NOTAIRES ASSOCIES\r\nBP 80137                           60801 CREPY EN VALOIS CEDEX");
		Assert.assertEquals(parser.getFieldBDBTRName(parser.getFieldBDBTR(strInput)), "SCP COLAS FLEURY MALDERET");
		Assert.assertEquals(parser.getFieldBDBTRAddress(parser.getFieldBDBTR(strInput)), "FR 62 AV DE LEVALLOIS PERRET          NOTAIRES ASSOCIES BP 80137                           60801 CREPY EN VALOIS CEDEX");
		Assert.assertEquals(parser.getFieldBCDTR(strInput), "MME SOPHIE FISHER\r\nGB");
		Assert.assertEquals(parser.getFieldBCDTRName(parser.getFieldBCDTR(strInput)), "MME SOPHIE FISHER");
		Assert.assertEquals(parser.getFieldBCDTRAddress(parser.getFieldBCDTR(strInput)), "GB");
		Assert.assertEquals(parser.getFieldBCHGINF(strInput), null);
		Assert.assertEquals(parser.getFieldBREMITINF(strInput), "A MME ASHBEE NATHALIE - PARTIE PRIX VTE SCI CERDAN-CANAL");
		Assert.assertEquals(parser.getFieldBCHRGBR(strInput), "SLEV");
		Assert.assertEquals(parser.getFieldBRELREMIT(strInput), null);
		Assert.assertEquals(parser.getFieldBCHGBR(strInput), "SLEV TEST");
		Assert.assertEquals(parser.getFieldBRGLRPTG(strInput), null);
		Assert.assertEquals(parser.getFieldBINSTCDAG(strInput), null);
		
		
	}
	
	/**
	 * Méthode utilitaire pour récupérer le fichier contenant le jeu de test au
	 * format String
	 * 
	 * @throws IOException
	 */
	private String getSEPAFromFile(String fileName) throws IOException {
		final InputStream input = getClass().getClassLoader().getResourceAsStream(fileName);
		return IOUtils.toString(input, StandardCharsets.UTF_8);
	}
}
