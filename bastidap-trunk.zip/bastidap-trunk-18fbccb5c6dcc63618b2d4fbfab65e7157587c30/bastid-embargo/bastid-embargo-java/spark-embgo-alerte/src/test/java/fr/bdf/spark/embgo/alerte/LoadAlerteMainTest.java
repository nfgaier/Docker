package fr.bdf.spark.embgo.alerte;

import junit.framework.TestCase;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import fr.bdf.spark.embgo.alerte.beans.AlerteBean;
import fr.bdf.spark.embgo.alerte.beans.FofaHistMessageBean;
import fr.bdf.spark.embgo.alerte.constant.LoadAlerteConstant;
import fr.bdf.spark.embgo.alerte.data.GetFOFAHistMessageData;
import fr.bdf.spark.embgo.alerte.data.GetParamData;
import fr.bdf.spark.embgo.alerte.data.PutAlerteData;
import fr.bdf.spark.embgo.alerte.functions.FofaHistMessageFactory;
import fr.bdf.spark.embgo.alerte.functions.AlertFactory;
import fr.bdf.spark.embgo.alerte.util.ParseParam;


@SuppressWarnings("unused")
public class LoadAlerteMainTest  extends TestCase {

    public void testApp()    {
    	/* 
        String idTraitement = "20171004112908";
        String businessDate = "20170830";

        SparkConf conf = new SparkConf().setMaster("local").setAppName("LoadAlerteMainTest");
        JavaSparkContext sc = new JavaSparkContext(conf);
        HiveContext sqlContext = new HiveContext(sc);
        //sqlContext.setConf("hive.metastore.uris", "thrift://lxdv716a.unix-int.intra-int.bdf-int.local:9083?tez.queue.name=gabidev;tez.am.resource.memory=512");
        sqlContext.setConf("hive.metastore.uris", "thrift://lxdv0126pv.unix-int.intra-int.bdf-int.local:9083");

        sc.setLogLevel("WARN");
        sqlContext.sql("show databases").show();

        //get data from the source table fofa_hist_message
        DataFrame fofaHistMsgDF = new GetFOFAHistMessageData(sqlContext).getFOFAHistMessageData(businessDate).persist();

        //"INFO:" + Parser.getTime() + 
        
        //get data from the parameter tables
        GetParamData paramData = new GetParamData(sqlContext);
        //niveau decision table
        DataFrame refAlerteNiv = paramData.getRefAlerteNivData(idTraitement).persist();
        //back office table
        DataFrame refAlerteBo = paramData.getRefAlerteBOData("20171004112817");
        //etat table
        DataFrame refAlerteEtat = paramData.getRefAlerteEtatData("20171004112732");
        //ind table
        DataFrame refAlerteInd = paramData.getRefAlerteIndData("20171004113023");
        //motif table
        DataFrame refAlerteMot = paramData.getRefAlerteMotifData("20171004112944");
        
        System.out.println("refAlerteNiv : " + refAlerteNiv.count());
        System.out.println("refAlerteBo : " + refAlerteBo.count());
        System.out.println("refAlerteEtat : " + refAlerteEtat.count());
        System.out.println("refAlerteInd : " + refAlerteInd.count());
        System.out.println("refAlerteMot : " + refAlerteMot.count());
        
        
        //generate CASE WHEN foe each parameter table
        //set properties for each parameter table in order to pass them to the ParseParam class
        java.util.Properties paramCols = new java.util.Properties();

        //back office
        paramCols.setProperty("compDateFieldName","date_decision_finale");
        paramCols.setProperty("startDateFieldName","date_decision_deb");
        paramCols.setProperty("endDateFieldName","date_decision_fin");
        paramCols.setProperty("resultFieldName","back_office");
        paramCols.setProperty("targetFieldName","back_office");

        paramCols.setProperty("nbCondidions","3");
        paramCols.setProperty("condition_1_field_name","niveau_decision");
        paramCols.setProperty("condition_1_type","EQUAL");
        paramCols.setProperty("condition_2_field_name","decision_finale");
        paramCols.setProperty("condition_2_type","LIKE");
        paramCols.setProperty("condition_3_field_name","bo_gestion");
        paramCols.setProperty("condition_3_type","EQUAL");

        ParseParam paramBO = new ParseParam(paramCols,refAlerteBo);
        String caseWhenBOStr = paramBO.getCaseWhenStmt();
        System.out.println("caseWhenBOStr : " + caseWhenBOStr);

        //etat 
        paramCols.clear();
        paramCols.setProperty("compDateFieldName","date_decision_finale");
        paramCols.setProperty("startDateFieldName","date_decision_deb");
        paramCols.setProperty("endDateFieldName","date_decision_fin");
        paramCols.setProperty("resultFieldName","etat");
        paramCols.setProperty("targetFieldName","etat");

        paramCols.setProperty("nbCondidions","1");
        paramCols.setProperty("condition_1_field_name","decision_finale");
        paramCols.setProperty("condition_1_type","EQUAL");

        ParseParam paramETAT = new ParseParam(paramCols,refAlerteEtat);
        String caseWhenETATStr = paramETAT.getCaseWhenStmt();
        System.out.println("caseWhenETATStr : " + caseWhenETATStr);

        //ind 
        paramCols.clear();
        paramCols.setProperty("compDateFieldName","date_decision_finale");
        paramCols.setProperty("startDateFieldName","date_decision_deb");
        paramCols.setProperty("endDateFieldName","date_decision_fin");
        paramCols.setProperty("resultFieldName","ind_swift_sepa");
        paramCols.setProperty("targetFieldName","ind_swift_sepa");

        paramCols.setProperty("nbCondidions","1");
        paramCols.setProperty("condition_1_field_name","type_message");
        paramCols.setProperty("condition_1_type","EQUAL");

        ParseParam paramIND = new ParseParam(paramCols,refAlerteInd);
        String caseWhenINDStr = paramIND.getCaseWhenStmt();    
        System.out.println("caseWhenINDStr : " + caseWhenINDStr);

        //motif_decision 
        paramCols.clear();
        paramCols.setProperty("compDateFieldName","date_decision_finale");
        paramCols.setProperty("startDateFieldName","date_decision_deb");
        paramCols.setProperty("endDateFieldName","date_decision_fin");
        paramCols.setProperty("resultFieldName","motif_decision");
        paramCols.setProperty("targetFieldName","motif_decision");

        paramCols.setProperty("nbCondidions","1");
        paramCols.setProperty("condition_1_field_name","decision_finale");
        paramCols.setProperty("condition_1_type","EQUAL");

        ParseParam paramMOT = new ParseParam(paramCols,refAlerteMot);
        String caseWhenMOTStr = paramMOT.getCaseWhenStmt();  
        System.out.println("caseWhenMOTStr : " + caseWhenMOTStr);

        //join fofa_hist_message DF and niveau decision parameter DF in order to get the niveau decision for each fofa_hist_message
        DataFrame fofaHistMsgDFJoin = fofaHistMsgDF
                .join(refAlerteNiv,fofaHistMsgDF.col("t_decision_type").equalTo(refAlerteNiv.col("decision_finale"))
                              .and(fofaHistMsgDF.col("t_completed").between(refAlerteNiv.col("date_decision_deb"),refAlerteNiv.col("date_decision_fin"))),
                     "left").persist();

        System.out.println("fofaHistMsgDFJoin count : " + fofaHistMsgDFJoin.count());

        //create an RDD from the DataFrame in order to parse the SWIFT message contained in the t_message_upd column 
        JavaRDD<FofaHistMessageBean> fofaHistMsgRDD = fofaHistMsgDFJoin.toJavaRDD().map(new FofaHistMessageFactory());

        System.out.println("fofaHistMsgRDD : " + fofaHistMsgRDD.count());
        
        //parse the SIFT message and return an AlerteBean
        JavaRDD<AlerteBean> alerteRDD = fofaHistMsgRDD.map(new AlertFactory());

        System.out.println("alerteRDD : " + alerteRDD.count());

        //create a DataFrame from the alerte RDD in order to run on it a query with the generated Case When statements
        DataFrame alerteDF = sqlContext.createDataFrame(alerteRDD, AlerteBean.class);

        System.out.println("alerteDF : " + alerteDF.count());
        
        //create a tmp table for the query
        alerteDF.registerTempTable(LoadAlerteConstant.TMP_TABLE);

        PutAlerteData putAlerteHelper = new PutAlerteData(sqlContext, 
                                                    caseWhenMOTStr, 
                                                    caseWhenETATStr, 
                                                    caseWhenBOStr, 
                                                    caseWhenINDStr, 
                                                    LoadAlerteConstant.TMP_TABLE);

        DataFrame alerteFinalDF =  putAlerteHelper.generateAlerteData(idTraitement).persist();
        
        //alerteFinalDF.show();
        
        //alerteFinalDF.printSchema();
        
        System.out.println("Write data : " + alerteFinalDF.count() + " to path " + LoadAlerteConstant.ALERTE_HDFS_PATH_DEV);
        
        //putAlerteHelper.writeAlerteData(LoadAlerteConstant.ALERTE_HDFS_PATH, alerteFinalDF, idTraitement);
        
        */
        assertTrue( true );
    }
}
