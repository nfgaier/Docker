package fr.bdf.spark.embgo.alerte.util;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;

import com.prowidesoftware.swift.io.parser.SwiftParser;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.mt.AbstractMT;

import fr.bdf.spark.embgo.alerte.util.ParseSWIFTUtil;
import junit.framework.Assert;

public class ParseSWIFTUtilTest {

	
	private ParseSWIFTUtil parser;
	
	
	
	@Before
	public void init() {
		this.parser = new ParseSWIFTUtil();
	}
	
	
	@Test
	public void testParseSwift() throws IOException, ParseException {
		
		// INIT SWIFT and Swift MT
		final String swiftStr = this.getSWIFTFromFile("swift-test.txt");
        final AbstractMT msgTmp = new SwiftParser(swiftStr).message().toMT();
        final SwiftMessage swiftMessage = msgTmp.getSwiftMessage();
        final SimpleDateFormat formatter = new SimpleDateFormat("yyMMdd");
          
        /** Test Parsing */
        Assert.assertEquals(parser.getRefTransaction(swiftMessage.getBlock4().getTagValue("20")), "INGEMB45-01");
        Assert.assertEquals(parser.getCodeOperation(swiftMessage.getBlock4().getTagValue("23B")), "CRED");
        Assert.assertEquals(parser.getMsgDateValeur(swiftMessage.getBlock4().getTagValue("32A")), new java.sql.Timestamp(formatter.parse("170828").getTime()));
        Assert.assertEquals(parser.getMsgDeviseCredit(swiftMessage.getBlock4().getTagValue("32A")), "EUR");
        Assert.assertEquals(parser.getMsgMntCredit(swiftMessage.getBlock4().getTagValue("32A")), new BigDecimal("4.5"));
        Assert.assertEquals(parser.getMsgDeviseDebit(swiftMessage.getBlock4().getTagValue("33B")), "EUR");
        Assert.assertEquals(parser.getMsgMntDebit(swiftMessage.getBlock4().getTagValue("33B")), new BigDecimal("4.5"));
        Assert.assertEquals(parser.getMsgTauxChange(swiftMessage.getBlock4().getTagValue("36")), null);
       
        Assert.assertEquals(parser.getMsgBicDo(swiftMessage.getBlock4().getTagValue("50")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgNumCptDo(swiftMessage.getBlock4().getTagValue("50K")), "10071920000000100031036");
        Assert.assertEquals(parser.getMsgNomDo(swiftMessage.getBlock4().getTagValue("50K")), "CNRS IDF OUEST NORD AGENCE COMPTABL");
        Assert.assertEquals(parser.getMsgAdresseBo(swiftMessage.getBlock4().getTagValue("50K")), "1 PLACE ARISTIDE BRIAND 92195 MEUDON CEDEX FR SYRIE");
       
        Assert.assertEquals(parser.getMsgNumCptBqDo(swiftMessage.getBlock4().getTagValue("52D")), "009360000X055054");
        Assert.assertEquals(parser.getMsgBicBqDo(swiftMessage.getBlock4().getTagValue("52A")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgNomBqDo(swiftMessage.getBlock4().getTagValue("52D")), "T G DES HAUTS DE SEINE");
        Assert.assertEquals(parser.getMsgAdresseBqDo(swiftMessage.getBlock4().getTagValue("52D")), "167 AVE JOLIOT CURIE 92013 NANTERRE CEDEX FR");
        
        Assert.assertEquals(parser.getMsgNumCptBqEm(swiftMessage.getBlock4().getTagValue("53A")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgBicBqEm(swiftMessage.getBlock4().getTagValue("53A")), "BDFEFRPPCCT");
        Assert.assertEquals(parser.getMsgNomBqEm(swiftMessage.getBlock4().getTagValue("53D")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgAdresseBqEm(swiftMessage.getBlock4().getTagValue("53D")), StringUtils.EMPTY);
       
        Assert.assertEquals(parser.getMsgNumCptBqDest(swiftMessage.getBlock4().getTagValue("54A")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgBicBqDest(swiftMessage.getBlock4().getTagValue("54A")), "BDFEFR2TXXX");
        Assert.assertEquals(parser.getMsgNomBqDest(swiftMessage.getBlock4().getTagValue("54D")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgAdresseBqDest(swiftMessage.getBlock4().getTagValue("54D")), StringUtils.EMPTY);
        
        Assert.assertEquals(parser.getMsgNumCptBqTie(swiftMessage.getBlock4().getTagValue("55A")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgBicBqTie(swiftMessage.getBlock4().getTagValue("55A")), "BDFEFRPPXXX");
        Assert.assertEquals(parser.getMsgNomBqTie(swiftMessage.getBlock4().getTagValue("55D")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgAdresseBqTie(swiftMessage.getBlock4().getTagValue("55D")), StringUtils.EMPTY);
        
        Assert.assertEquals(parser.getMsgNumCptBqInt(swiftMessage.getBlock4().getTagValue("56A")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgBicBqInt(swiftMessage.getBlock4().getTagValue("56A")), "BDFEFRPPXXX");
        Assert.assertEquals(parser.getMsgNomBqInt(swiftMessage.getBlock4().getTagValue("56D")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgAdresseBqInt(swiftMessage.getBlock4().getTagValue("56D")), StringUtils.EMPTY);
        
        Assert.assertEquals(parser.getMsgNumCptBqDuBenef(swiftMessage.getBlock4().getTagValue("57A")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgBicBqDuBenef(swiftMessage.getBlock4().getTagValue("57A")), "BBSFSYDAXXX");
        Assert.assertEquals(parser.getMsgNomBqDuBenef(swiftMessage.getBlock4().getTagValue("57D")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgAdresseBqDuBenef(swiftMessage.getBlock4().getTagValue("57D")), StringUtils.EMPTY);

        Assert.assertEquals(parser.getMsgNumCptBqBenef(swiftMessage.getBlock4().getTagValue("58A")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgBicBqBenef(swiftMessage.getBlock4().getTagValue("58A")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgNomBqBenef(swiftMessage.getBlock4().getTagValue("58D")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgAdresseBqBenef(swiftMessage.getBlock4().getTagValue("58D")), StringUtils.EMPTY);

        Assert.assertEquals(parser.getMsgNumCptBqBenef(swiftMessage.getBlock4().getTagValue("58A")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgBicBqBenef(swiftMessage.getBlock4().getTagValue("58A")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgNomBqBenef(swiftMessage.getBlock4().getTagValue("58D")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgAdresseBqBenef(swiftMessage.getBlock4().getTagValue("58D")), StringUtils.EMPTY);

        Assert.assertEquals(parser.getMsgNumCptBenef(swiftMessage.getBlock4().getTagValue("59F")), "013780010746503960411648");
        Assert.assertEquals(parser.getMsgBicBenef(swiftMessage.getBlock4().getTagValue("59A")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgNomBenef(swiftMessage.getBlock4().getTagValue("59F"),"59F"), "CHRISTOPHE STABILE");
        Assert.assertEquals(parser.getMsgAdresseBenef(swiftMessage.getBlock4().getTagValue("59F")), "48 AVENUE DE L'ATLAS CASABLANCA MA/MAROC");

        Assert.assertEquals(parser.getMsgMotifPaiement(swiftMessage.getBlock4().getTagValue("70")), "INVOICE 6631 DU 20.10.2009");
        Assert.assertEquals(parser.getMsgMessageBq(swiftMessage.getBlock4().getTagValue("72")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgCommentaire(swiftMessage.getBlock4().getTagValue("79")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgModePaiementChg(swiftMessage.getBlock4().getTagValue("71A")), "SHA");
        Assert.assertEquals(parser.getMsgDetailCharge(swiftMessage.getBlock4().getTagValue("71B")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgDeviseChgEm(swiftMessage.getBlock4().getTagValue("71F")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgMntChgEm(swiftMessage.getBlock4().getTagValue("71F")), null);
        Assert.assertEquals(parser.getMsgDeviseChgBenef(swiftMessage.getBlock4().getTagValue("71G")), StringUtils.EMPTY);
        Assert.assertEquals(parser.getMsgMntChgBenef(swiftMessage.getBlock4().getTagValue("71G")), null);
	}
	
	/**
	 * Méthode utilitaire pour récupérer le fichier contenant le jeu de test au
	 * format String
	 * 
	 * @throws IOException
	 */
	private String getSWIFTFromFile(String fileName) throws IOException {
		final InputStream input = getClass().getClassLoader().getResourceAsStream(fileName);
		return IOUtils.toString(input, StandardCharsets.UTF_8);
	}
}
