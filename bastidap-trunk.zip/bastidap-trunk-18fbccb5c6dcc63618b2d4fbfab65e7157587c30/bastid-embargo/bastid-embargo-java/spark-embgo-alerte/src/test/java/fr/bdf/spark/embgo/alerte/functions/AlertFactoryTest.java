package fr.bdf.spark.embgo.alerte.functions;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.Before;
import org.junit.Test;

import fr.bdf.spark.embgo.AbstractTest;
import fr.bdf.spark.embgo.alerte.beans.AlerteBean;
import fr.bdf.spark.embgo.alerte.beans.FofaHistMessageBean;
import fr.bdf.spark.embgo.alerte.constant.LoadAlerteConstant;
import junit.framework.Assert;

public class AlertFactoryTest extends AbstractTest {

	
	private AlertFactory factory;
	
	
	@Before
	public void init() {
		this.factory = new AlertFactory();
	}
	
	
	@Test
	public void testCallForSepa003() throws Exception {
		
		/** Initialisation des dates */
		final java.util.Date dateUtil = new java.util.Date();
		final Date dateSQL = new Date(dateUtil.getTime());
		
		/** Initialisation du bean, du type de message et du message */
		final FofaHistMessageBean bean = this.getRecord(dateUtil, dateSQL);
		bean.setT_type(LoadAlerteConstant.TYPE_PACS003);
		this.setMessageType(bean);
		bean.setT_message(this.getMessageFromFile("sepa-example-pacs003-text.txt"));
		
		/** Factory */
		AlerteBean outputBean = factory.call(bean);

		/** Tests */
		Assert.assertEquals(outputBean.getRef_transaction(), bean.getT_transaction());
		Assert.assertEquals(outputBean.getId_alerte(), bean.getT_system_id());
		Assert.assertEquals(outputBean.getDernier_utilisateur(), bean.getT_lastoperator());
		Assert.assertEquals(outputBean.getMontant_transaction(), bean.getT_amount() != null ?
				BigDecimal.valueOf(Double.parseDouble(bean.getT_amount())) : null);
		Assert.assertEquals(outputBean.getBlocking(), this.getBigDecimalFromDouble(bean.getT_blocking()));
		Assert.assertEquals(outputBean.getBunit(), bean.getT_bunit());
		Assert.assertEquals(outputBean.getDate_decision_finale(), 
				new Timestamp(new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(bean.getT_completed()).getTime()));
		Assert.assertEquals(outputBean.getCopy_service(), bean.getT_copy_service());
		Assert.assertEquals(outputBean.getDate_creation_transact(), this.dateFromString(bean.getT_created()));
		Assert.assertEquals(outputBean.getDevise_transaction(), bean.getT_currency());
		Assert.assertEquals(outputBean.getDate_valeur_transact(), this.dateFromString(bean.getT_date_value()));
		Assert.assertEquals(outputBean.getDecision_finale(), bean.getT_decision_type());
		Assert.assertEquals(outputBean.getBo_gestion(), bean.getT_entity());
		Assert.assertEquals(outputBean.getDate_filtre(), this.dateFromString(bean.getT_filtered()));
		Assert.assertEquals(outputBean.getSaa_origine(), bean.getT_fromappli());
		Assert.assertEquals(outputBean.getSaa_destination(), bean.getT_toappli());
		Assert.assertEquals(outputBean.getGateway(), bean.getT_gateway());
		Assert.assertEquals(outputBean.getBic_bq_emet(), bean.getT_sender());
		Assert.assertEquals(outputBean.getBic_bq_dest(), bean.getT_receiver());
		Assert.assertEquals(outputBean.getRef_related(), bean.getT_related_ref());
		Assert.assertEquals(outputBean.getRef_transaction(), bean.getT_transaction());
		Assert.assertEquals(outputBean.getType_message(), bean.getT_type());
		Assert.assertEquals(outputBean.getSens_flux_e_r(), bean.getT_i_o());
		Assert.assertEquals(outputBean.getId_message(), bean.getT_message_id());
		Assert.assertEquals(outputBean.getMessage_clob(), bean.getT_message());
		Assert.assertEquals(outputBean.getNature(), bean.getT_nature());
		Assert.assertEquals(outputBean.getNonblocking(), this.getBigDecimalFromDouble(bean.getT_nonblocking()));
		Assert.assertEquals(outputBean.getId_pairing(), bean.getT_pairing_id());
		Assert.assertEquals(outputBean.getPriorite(), this.getBigDecimalFromDouble(bean.getT_priority()));
		Assert.assertEquals(outputBean.getConfidentialite(), this.getBigDecimalFromDouble(bean.getT_confidentiality()));
		Assert.assertEquals(outputBean.getAlignement(), bean.getT_alignment());
		Assert.assertEquals(outputBean.getApp_priority(), this.getBigDecimalFromDouble(bean.getT_app_priority()));
		Assert.assertEquals(outputBean.getApp_deadline(), 
				bean.getT_app_deadline() == null ? null : new java.sql.Timestamp(bean.getT_app_deadline().getTime()));
		Assert.assertEquals(outputBean.getNormamount(), this.getBigDecimalFromDouble(bean.getT_normamount()));
		Assert.assertEquals(outputBean.getSaausrgrp(), bean.getSaausrgrp());
		Assert.assertEquals(outputBean.getId_business_unit(), this.getBigDecimalFromDouble(bean.getBusiness_unit_id()));
		Assert.assertEquals(outputBean.getNiveau_decision(), bean.getNiveau_decision());
		Assert.assertEquals(outputBean.getDate_ope(), bean.getDate_ope());
		Assert.assertEquals(outputBean.getDate_insert(), bean.getDate_insert());
	}
	
	@Test
	public void testCallForSepa008() throws Exception {
		
		/** Initialisation des dates */
		final java.util.Date dateUtil = new java.util.Date();
		final Date dateSQL = new Date(dateUtil.getTime());
		
		/** Initialisation du bean, du type de message et du message */
		final FofaHistMessageBean bean = this.getRecord(dateUtil, dateSQL);
		bean.setT_type(LoadAlerteConstant.TYPE_PACS008);
		bean.setT_message(this.getMessageFromFile("sepa-example-pacs008-text.txt"));
		this.setMessageType(bean);
		
		/** Factory */
		AlerteBean outputBean = factory.call(bean);
		
		/** Tests */
		Assert.assertEquals(outputBean.getRef_transaction(), bean.getT_transaction());
		Assert.assertEquals(outputBean.getId_alerte(), bean.getT_system_id());
		Assert.assertEquals(outputBean.getDernier_utilisateur(), bean.getT_lastoperator());
		Assert.assertEquals(outputBean.getMontant_transaction(), bean.getT_amount() != null ?
				BigDecimal.valueOf(Double.parseDouble(bean.getT_amount())) : null);
		Assert.assertEquals(outputBean.getBlocking(), this.getBigDecimalFromDouble(bean.getT_blocking()));
		Assert.assertEquals(outputBean.getBunit(), bean.getT_bunit());
		Assert.assertEquals(outputBean.getDate_decision_finale(), 
				new Timestamp(new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(bean.getT_completed()).getTime()));
		Assert.assertEquals(outputBean.getCopy_service(), bean.getT_copy_service());
		Assert.assertEquals(outputBean.getDate_creation_transact(), this.dateFromString(bean.getT_created()));
		Assert.assertEquals(outputBean.getDevise_transaction(), bean.getT_currency());
		Assert.assertEquals(outputBean.getDate_valeur_transact(), this.dateFromString(bean.getT_date_value()));
		Assert.assertEquals(outputBean.getDecision_finale(), bean.getT_decision_type());
		Assert.assertEquals(outputBean.getBo_gestion(), bean.getT_entity());
		Assert.assertEquals(outputBean.getDate_filtre(), this.dateFromString(bean.getT_filtered()));
		Assert.assertEquals(outputBean.getSaa_origine(), bean.getT_fromappli());
		Assert.assertEquals(outputBean.getSaa_destination(), bean.getT_toappli());
		Assert.assertEquals(outputBean.getGateway(), bean.getT_gateway());
		Assert.assertEquals(outputBean.getBic_bq_emet(), bean.getT_sender());
		Assert.assertEquals(outputBean.getBic_bq_dest(), bean.getT_receiver());
		Assert.assertEquals(outputBean.getRef_related(), bean.getT_related_ref());
		Assert.assertEquals(outputBean.getRef_transaction(), bean.getT_transaction());
		Assert.assertEquals(outputBean.getType_message(), bean.getT_type());
		Assert.assertEquals(outputBean.getSens_flux_e_r(), bean.getT_i_o());
		Assert.assertEquals(outputBean.getId_message(), bean.getT_message_id());
		Assert.assertEquals(outputBean.getMessage_clob(), bean.getT_message());
		Assert.assertEquals(outputBean.getNature(), bean.getT_nature());
		Assert.assertEquals(outputBean.getNonblocking(), this.getBigDecimalFromDouble(bean.getT_nonblocking()));
		Assert.assertEquals(outputBean.getId_pairing(), bean.getT_pairing_id());
		Assert.assertEquals(outputBean.getPriorite(), this.getBigDecimalFromDouble(bean.getT_priority()));
		Assert.assertEquals(outputBean.getConfidentialite(), this.getBigDecimalFromDouble(bean.getT_confidentiality()));
		Assert.assertEquals(outputBean.getAlignement(), bean.getT_alignment());
		Assert.assertEquals(outputBean.getApp_priority(), this.getBigDecimalFromDouble(bean.getT_app_priority()));
		Assert.assertEquals(outputBean.getApp_deadline(), 
				bean.getT_app_deadline() == null ? null : new java.sql.Timestamp(bean.getT_app_deadline().getTime()));
		Assert.assertEquals(outputBean.getNormamount(), this.getBigDecimalFromDouble(bean.getT_normamount()));
		Assert.assertEquals(outputBean.getSaausrgrp(), bean.getSaausrgrp());
		Assert.assertEquals(outputBean.getId_business_unit(), this.getBigDecimalFromDouble(bean.getBusiness_unit_id()));
		Assert.assertEquals(outputBean.getNiveau_decision(), bean.getNiveau_decision());
		Assert.assertEquals(outputBean.getDate_ope(), bean.getDate_ope());
		Assert.assertEquals(outputBean.getDate_insert(), bean.getDate_insert());
	}
	
	
	@Test
	public void testCallForSwift() throws Exception {
		
		/** Initialisation des dates */
		final java.util.Date dateUtil = new java.util.Date();
		final Date dateSQL = new Date(dateUtil.getTime());
		
		/** Initialisation du bean, du type de message et du message */
		final FofaHistMessageBean bean = this.getRecord(dateUtil, dateSQL);
		bean.setT_type("199");
		this.setMessageType(bean);
		
		/** Factory */
		AlerteBean outputBean = factory.call(bean);
		
		/** Tests */
		Assert.assertEquals(outputBean.getRef_transaction(), bean.getT_transaction());
		Assert.assertEquals(outputBean.getId_alerte(), bean.getT_system_id());
		Assert.assertEquals(outputBean.getDernier_utilisateur(), bean.getT_lastoperator());
		Assert.assertEquals(outputBean.getMontant_transaction(), bean.getT_amount() != null ?
				BigDecimal.valueOf(Double.parseDouble(bean.getT_amount())) : null);
		Assert.assertEquals(outputBean.getBlocking(), this.getBigDecimalFromDouble(bean.getT_blocking()));
		Assert.assertEquals(outputBean.getBunit(), bean.getT_bunit());
		Assert.assertEquals(outputBean.getDate_decision_finale(), 
				new Timestamp(new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(bean.getT_completed()).getTime()));
		Assert.assertEquals(outputBean.getCopy_service(), bean.getT_copy_service());
		Assert.assertEquals(outputBean.getDate_creation_transact(), this.dateFromString(bean.getT_created()));
		Assert.assertEquals(outputBean.getDevise_transaction(), bean.getT_currency());
		Assert.assertEquals(outputBean.getDate_valeur_transact(), this.dateFromString(bean.getT_date_value()));
		Assert.assertEquals(outputBean.getDecision_finale(), bean.getT_decision_type());
		Assert.assertEquals(outputBean.getBo_gestion(), bean.getT_entity());
		Assert.assertEquals(outputBean.getDate_filtre(), this.dateFromString(bean.getT_filtered()));
		Assert.assertEquals(outputBean.getSaa_origine(), bean.getT_fromappli());
		Assert.assertEquals(outputBean.getSaa_destination(), bean.getT_toappli());
		Assert.assertEquals(outputBean.getGateway(), bean.getT_gateway());
		Assert.assertEquals(outputBean.getBic_bq_emet(), bean.getT_sender());
		Assert.assertEquals(outputBean.getBic_bq_dest(), bean.getT_receiver());
		Assert.assertEquals(outputBean.getRef_related(), bean.getT_related_ref());
		Assert.assertEquals(outputBean.getRef_transaction(), bean.getT_transaction());
		Assert.assertEquals(outputBean.getType_message(), bean.getT_type());
		Assert.assertEquals(outputBean.getSens_flux_e_r(), bean.getT_i_o());
		Assert.assertEquals(outputBean.getId_message(), bean.getT_message_id());
		Assert.assertEquals(outputBean.getMessage_clob(), bean.getT_message());
		Assert.assertEquals(outputBean.getNature(), bean.getT_nature());
		Assert.assertEquals(outputBean.getNonblocking(), this.getBigDecimalFromDouble(bean.getT_nonblocking()));
		Assert.assertEquals(outputBean.getId_pairing(), bean.getT_pairing_id());
		Assert.assertEquals(outputBean.getPriorite(), this.getBigDecimalFromDouble(bean.getT_priority()));
		Assert.assertEquals(outputBean.getConfidentialite(), this.getBigDecimalFromDouble(bean.getT_confidentiality()));
		Assert.assertEquals(outputBean.getAlignement(), bean.getT_alignment());
		Assert.assertEquals(outputBean.getApp_priority(), this.getBigDecimalFromDouble(bean.getT_app_priority()));
		Assert.assertEquals(outputBean.getApp_deadline(), new java.sql.Timestamp(bean.getT_app_deadline().getTime()));
		Assert.assertEquals(outputBean.getNormamount(), this.getBigDecimalFromDouble(bean.getT_normamount()));
		Assert.assertEquals(outputBean.getSaausrgrp(), bean.getSaausrgrp());
		Assert.assertEquals(outputBean.getId_business_unit(), this.getBigDecimalFromDouble(bean.getBusiness_unit_id()));
		Assert.assertEquals(outputBean.getNiveau_decision(), bean.getNiveau_decision());
		Assert.assertEquals(outputBean.getDate_ope(), bean.getDate_ope());
		Assert.assertEquals(outputBean.getDate_insert(), bean.getDate_insert());
	}
	
	
	private FofaHistMessageBean getRecord(java.util.Date dateUtil, Date dateSQL) {
		final FofaHistMessageBean bean = new FofaHistMessageBean();
		bean.setT_system_id("t_system_id=2");
				bean.setBusiness_unit_id(1d);
				bean.setSaausrgrp("saausrgrp");
				bean.setT_normamount(1d);
				bean.setT_app_deadline(dateUtil);
				bean.setT_app_priority(1d);
				bean.setT_alignment("t_alignment");
				bean.setT_confidentiality(1d);
				bean.setT_priority(1d);
				bean.setT_transaction("t_transaction");
				bean.setT_toappli("t_toappli");
				bean.setT_sender("t_sender");
				bean.setT_related_ref("t_related_ref");
				bean.setT_receiver("t_receiver");
				bean.setT_pairing_id("t_pairing_id");
				bean.setT_nonblocking(1d);
				bean.setT_nature("t_nature");
				bean.setT_message_id("t_message_id");
				bean.setT_message("t_message");
				bean.setT_i_o("t_i_o");
				bean.setT_gateway("t_gateway");
				bean.setT_fromappli("t_fromappli");
				bean.setT_filtered(new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(new java.util.Date()));
				bean.setT_entity("t_entity");
				bean.setT_lastoperator("t_lastoperator");
				bean.setT_decision_type("t_decision_type");
				bean.setT_date_value(new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(new java.util.Date()));
				bean.setT_currency("t_currency");
				bean.setT_created(new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(new java.util.Date()));
				bean.setT_copy_service("t_copy_service");
				bean.setT_completed(new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(new java.util.Date()));
				bean.setT_bunit("t_bunit");
				bean.setT_blocking(1d);
				bean.setT_amount_float(1f);
				bean.setT_amount("1");
				bean.setNiveau_decision("niveau_decision");
				bean.setDate_ope(dateSQL);
				bean.setDate_insert(dateSQL);

		return bean;
	}
	
	private void setMessageType(FofaHistMessageBean bean) throws IOException {
		switch(bean.getT_type()) {
			case LoadAlerteConstant.TYPE_PACS003 : 
				bean.setT_message_upd(this.getMessageFromFile("sepa-test-pacs003.txt"));
				break;
			case LoadAlerteConstant.TYPE_PACS008 : 
				bean.setT_message_upd(this.getMessageFromFile("sepa-test-pacs008.txt"));
				break;
			default : 
				bean.setT_message_upd(this.getMessageFromFile("swift-test.txt"));
				break;
			
		}
	}
	
	/**
	 * Helper method to avoid NullPointerException when parsing Double to BigDecimal 
	 * @param a double value
	 * @return
	 */
    private BigDecimal getBigDecimalFromDouble(Double d) {
        return d == null ? null : BigDecimal.valueOf(d);
    }
    
    /**
     * 
     * @param date
     * @return
     */
    public java.sql.Timestamp dateFromString(String date) {
        try {
            if( date==null || date.trim().equals("")) { 
                return null;
            }
            return new java.sql.Timestamp(new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(date).getTime());
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
    
}
