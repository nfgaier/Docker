package fr.bdf.spark.embgo.alerte.functions;

import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema;
import org.apache.spark.sql.types.DateType;
import org.apache.spark.sql.types.DoubleType;
import org.apache.spark.sql.types.FloatType;
import org.apache.spark.sql.types.StringType;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import fr.bdf.spark.embgo.AbstractTest;
import fr.bdf.spark.embgo.alerte.beans.FofaHistMessageBean;

public class FofaHistMessageFactoryTest extends AbstractTest {
	
	
	private FofaHistMessageFactory factory;
	
	
	
	@Before
	public void init() {
		this.factory = new FofaHistMessageFactory();
	}
	
	
	
	@Test
	public void testCall() throws Exception {
		/** Initialisation de la structure et des rows */
		final java.util.Date now = new java.util.Date();
		final Date dateTest = new Date(now.getTime());
		final String timestampTest =  new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(now);

		final String sepaMessage = this.getMessageFromFile("sepa-test-pacs003.txt");
		final String swiftMessage = this.getMessageFromFile("swift-test.txt");
		StructType structure = this.getStructType();
		final List<Row> rows = getRows(structure, timestampTest, dateTest, sepaMessage, swiftMessage);
		
		/** Alimentation du test */
		final List<FofaHistMessageBean> beans = new ArrayList<FofaHistMessageBean>();
		for (Row row : rows) {
			beans.add(factory.call(row));
		}
		
		/** Test Liste */
		Assert.assertTrue(CollectionUtils.isNotEmpty(beans));
		Assert.assertEquals(beans.size(), 2);
		
		/** Test élément 1 */
		Assert.assertEquals(beans.get(0).getT_system_id(), "t_system_id=1");
		Assert.assertEquals(beans.get(0).getBusiness_unit_id(), new Double(1d));
		Assert.assertEquals(beans.get(0).getSaausrgrp(), "saausrgrp");
		Assert.assertEquals(beans.get(0).getT_normamount(), new Double(1d));
		Assert.assertEquals(beans.get(0).getT_app_deadline().toString(), now.toString());
		Assert.assertEquals(beans.get(0).getT_app_priority(), new Double(1d));
		Assert.assertEquals(beans.get(0).getT_alignment(), "t_alignment");
		Assert.assertEquals(beans.get(0).getT_confidentiality(), new Double(1d));
		Assert.assertEquals(beans.get(0).getT_priority(), new Double(1d));
		Assert.assertEquals(beans.get(0).getT_type(), "t_type");
		Assert.assertEquals(beans.get(0).getT_transaction(), "t_transaction");
		Assert.assertEquals(beans.get(0).getT_toappli(), "t_toappli");
		Assert.assertEquals(beans.get(0).getT_sender(), "t_sender");
		Assert.assertEquals(beans.get(0).getT_related_ref(), "t_related_ref");
		Assert.assertEquals(beans.get(0).getT_receiver(), "t_receiver");
		Assert.assertEquals(beans.get(0).getT_pairing_id(), "t_pairing_id");
		Assert.assertEquals(beans.get(0).getT_nonblocking(), new Double(1d));
		Assert.assertEquals(beans.get(0).getT_nature(), "t_nature");
		Assert.assertEquals(beans.get(0).getT_message_id(), "t_message_id");
		Assert.assertEquals(beans.get(0).getT_message(), "t_message");
		Assert.assertEquals(beans.get(0).getT_message_upd(), swiftMessage);
		Assert.assertEquals(beans.get(0).getT_i_o(), "t_i_o");
		Assert.assertEquals(beans.get(0).getT_gateway(), "t_gateway");
		Assert.assertEquals(beans.get(0).getT_fromappli(), "t_fromappli");
		Assert.assertEquals(beans.get(0).getT_filtered(), "t_filtered");
		Assert.assertEquals(beans.get(0).getT_entity(), "t_entity");
		Assert.assertEquals(beans.get(0).getT_lastoperator(), "t_lastoperator");
		Assert.assertEquals(beans.get(0).getT_decision_type(), "t_decision_type");
		Assert.assertEquals(beans.get(0).getT_date_value(), "t_date_value");
		Assert.assertEquals(beans.get(0).getT_currency(), "t_currency");
		Assert.assertEquals(beans.get(0).getT_created(), "t_created");
		Assert.assertEquals(beans.get(0).getT_copy_service(), "t_copy_service");
		Assert.assertEquals(beans.get(0).getT_completed(), "t_completed");
		Assert.assertEquals(beans.get(0).getT_bunit(), "t_bunit");
		Assert.assertEquals(beans.get(0).getT_blocking(), new Double(1d));
		Assert.assertEquals(beans.get(0).getT_amount_float(), new Float(1d));
		Assert.assertEquals(beans.get(0).getT_amount(), "t_amount");
		Assert.assertEquals(beans.get(0).getNiveau_decision(), "niveau_decision");
		Assert.assertEquals(beans.get(0).getDate_ope().toString(), dateTest.toString());
		Assert.assertEquals(beans.get(0).getDate_insert().toString(), dateTest.toString());

		/** Test élément 2 */
		Assert.assertEquals(beans.get(1).getT_system_id(), "t_system_id=2");
		Assert.assertEquals(beans.get(1).getBusiness_unit_id(), new Double(1d));
		Assert.assertEquals(beans.get(1).getSaausrgrp(), "saausrgrp");
		Assert.assertEquals(beans.get(1).getT_normamount(), new Double(1d));
		Assert.assertEquals(beans.get(1).getT_app_deadline().toString(), now.toString());
		Assert.assertEquals(beans.get(1).getT_app_priority(), new Double(1d));
		Assert.assertEquals(beans.get(1).getT_alignment(), "t_alignment");
		Assert.assertEquals(beans.get(1).getT_confidentiality(), new Double(1d));
		Assert.assertEquals(beans.get(1).getT_priority(), new Double(1d));
		Assert.assertEquals(beans.get(1).getT_type(), "t_type");
		Assert.assertEquals(beans.get(1).getT_transaction(), "t_transaction");
		Assert.assertEquals(beans.get(1).getT_toappli(), "t_toappli");
		Assert.assertEquals(beans.get(1).getT_sender(), "t_sender");
		Assert.assertEquals(beans.get(1).getT_related_ref(), "t_related_ref");
		Assert.assertEquals(beans.get(1).getT_receiver(), "t_receiver");
		Assert.assertEquals(beans.get(1).getT_pairing_id(), "t_pairing_id");
		Assert.assertEquals(beans.get(1).getT_nonblocking(), new Double(1d));
		Assert.assertEquals(beans.get(1).getT_nature(), "t_nature");
		Assert.assertEquals(beans.get(1).getT_message_id(), "t_message_id");
		Assert.assertEquals(beans.get(1).getT_message(), "t_message");
		Assert.assertEquals(beans.get(1).getT_message_upd(), sepaMessage);
		Assert.assertEquals(beans.get(1).getT_i_o(), "t_i_o");
		Assert.assertEquals(beans.get(1).getT_gateway(), "t_gateway");
		Assert.assertEquals(beans.get(1).getT_fromappli(), "t_fromappli");
		Assert.assertEquals(beans.get(1).getT_filtered(), "t_filtered");
		Assert.assertEquals(beans.get(1).getT_entity(), "t_entity");
		Assert.assertEquals(beans.get(1).getT_lastoperator(), "t_lastoperator");
		Assert.assertEquals(beans.get(1).getT_decision_type(), "t_decision_type");
		Assert.assertEquals(beans.get(1).getT_date_value(), "t_date_value");
		Assert.assertEquals(beans.get(1).getT_currency(), "t_currency");
		Assert.assertEquals(beans.get(1).getT_created(), "t_created");
		Assert.assertEquals(beans.get(1).getT_copy_service(), "t_copy_service");
		Assert.assertEquals(beans.get(1).getT_completed(), "t_completed");
		Assert.assertEquals(beans.get(1).getT_bunit(), "t_bunit");
		Assert.assertEquals(beans.get(1).getT_blocking(), new Double(1d));
		Assert.assertEquals(beans.get(1).getT_amount_float(), new Float(1d));
		Assert.assertEquals(beans.get(1).getT_amount(), "t_amount");
		Assert.assertEquals(beans.get(1).getNiveau_decision(), "niveau_decision");
		Assert.assertEquals(beans.get(1).getDate_ope().toString(), dateTest.toString());
		Assert.assertEquals(beans.get(1).getDate_insert().toString(), dateTest.toString());
		
	}



	private StructType getStructType() {

		final StructField t_system_id = new StructField("t_system_id",                 new StringType(), false, null);
		final StructField business_unit_id = new StructField("business_unit_id",new DoubleType(), false, null);
		final StructField saausrgrp = new StructField("saausrgrp",new StringType(), false, null);
		final StructField t_normamount = new StructField("t_normamount",new DoubleType(), false, null);
		final StructField t_app_deadline = new StructField("t_app_deadline",new DateType(), false, null);
		final StructField t_app_priority = new StructField("t_app_priority",new DoubleType(), false, null);
		final StructField t_alignment = new StructField("t_alignment",new StringType(), false, null);
		final StructField t_confidentiality = new StructField("t_confidentiality",new DoubleType(), false, null);
		final StructField t_priority = new StructField("t_priority",new DoubleType(), false, null);
		final StructField t_type = new StructField("t_type",new StringType(), false, null);
		final StructField t_transaction = new StructField("t_transaction",new StringType(), false, null);
		final StructField t_toappli = new StructField("t_toappli",new StringType(), false, null);
		final StructField t_sender = new StructField("t_sender",new StringType(), false, null);
		final StructField t_related_ref = new StructField("t_related_ref",new StringType(), false, null);
		final StructField t_receiver = new StructField("t_receiver",new StringType(), false, null);
		final StructField t_pairing_id = new StructField("t_pairing_id",new StringType(), false, null);
		final StructField t_nonblocking = new StructField("t_nonblocking",new DoubleType(), false, null);
		final StructField t_nature = new StructField("t_nature",new StringType(), false, null);
		final StructField t_message_id = new StructField("t_message_id",new StringType(), false, null);
		final StructField t_message = new StructField("t_message",new StringType(), false, null);
		final StructField t_message_upd = new StructField("t_message_upd",new StringType(), false, null);
		final StructField t_i_o = new StructField("t_i_o",new StringType(), false, null);
		final StructField t_gateway = new StructField("t_gateway",new StringType(), false, null);
		final StructField t_fromappli = new StructField("t_fromappli",new StringType(), false, null);
		final StructField t_filtered = new StructField("t_filtered",new StringType(), false, null);
		final StructField t_entity = new StructField("t_entity",new StringType(), false, null);
		final StructField t_lastoperator = new StructField("t_lastoperator",new StringType(), false, null);
		final StructField t_decision_type = new StructField("t_decision_type",new StringType(), false, null);
		final StructField t_date_value = new StructField("t_date_value",new StringType(), false, null);
		final StructField t_currency = new StructField("t_currency",new StringType(), false, null);
		final StructField t_created = new StructField("t_created",new StringType(), false, null);
		final StructField t_copy_service = new StructField("t_copy_service",new StringType(), false, null);
		final StructField t_completed = new StructField("t_completed",new StringType(), false, null);
		final StructField t_bunit = new StructField("t_bunit",new StringType(), false, null);
		final StructField t_blocking = new StructField("t_blocking",new DoubleType(), false, null);
		final StructField t_amount_float = new StructField("t_amount_float",new FloatType(), false, null);
		final StructField t_amount = new StructField("t_amount",new StringType(), false, null);
		final StructField niveau_decision = new StructField("niveau_decision",new StringType(), false, null);
		final StructField date_ope = new StructField("date_ope",new DateType(), false, null);
		final StructField date_insert = new StructField("date_insert", new DateType(), false, null);


		StructType structure = new StructType(new StructField[]{
				t_system_id,
				business_unit_id,
				saausrgrp,
				t_normamount,
				t_app_deadline,
				t_app_priority,
				t_alignment,
				t_confidentiality,
				t_priority,
				t_type,
				t_transaction,
				t_toappli,
				t_sender,
				t_related_ref,
				t_receiver,
				t_pairing_id,
				t_nonblocking,
				t_nature,
				t_message_id,
				t_message,
				t_message_upd,
				t_i_o,
				t_gateway,
				t_fromappli,
				t_filtered,
				t_entity,
				t_lastoperator,
				t_decision_type,
				t_date_value,
				t_currency,
				t_created,
				t_copy_service,
				t_completed,
				t_bunit,
				t_blocking,
				t_amount_float,
				t_amount,
				niveau_decision,
				date_ope,
				date_insert
			}
		);
		
	
		return structure;
	}

	
	private List<Row> getRows(StructType structure, String timestampTest , Date dateTest, String sepaMessage, String swiftMessage) throws IOException {
		
		Row row1 = new GenericRowWithSchema(new Object[]{
				"t_system_id=1",
				1d,
				"saausrgrp",
				1d,
				timestampTest,
				1d,
				"t_alignment",
				1d,
				1d,
				"t_type",
				"t_transaction",
				"t_toappli",
				"t_sender",
				"t_related_ref",
				"t_receiver",
				"t_pairing_id",
				1d,
				"t_nature",
				"t_message_id",
				"t_message",
				swiftMessage,
				"t_i_o",
				"t_gateway",
				"t_fromappli",
				"t_filtered",
				"t_entity",
				"t_lastoperator",
				"t_decision_type",
				"t_date_value",
				"t_currency",
				"t_created",
				"t_copy_service",
				"t_completed",
				"t_bunit",
				1d,
				1f,
				"t_amount",
				"niveau_decision",
				dateTest,
				dateTest}
		, structure);
		Row row2 = new GenericRowWithSchema(new Object[]{
				"t_system_id=2",
				1d,
				"saausrgrp",
				1d,
				timestampTest,
				1d,
				"t_alignment",
				1d,
				1d,
				"t_type",
				"t_transaction",
				"t_toappli",
				"t_sender",
				"t_related_ref",
				"t_receiver",
				"t_pairing_id",
				1d,
				"t_nature",
				"t_message_id",
				"t_message",
				sepaMessage,
				"t_i_o",
				"t_gateway",
				"t_fromappli",
				"t_filtered",
				"t_entity",
				"t_lastoperator",
				"t_decision_type",
				"t_date_value",
				"t_currency",
				"t_created",
				"t_copy_service",
				"t_completed",
				"t_bunit",
				1d,
				1f,
				"t_amount",
				"niveau_decision",
				dateTest,
				dateTest}
		, structure);
		
		final List<Row> rows = Arrays.asList(row1, row2);	
		return rows;
	}
	
	
	
}
