package fr.bdf.spark.embgo.common;

import java.io.IOException;

import junit.framework.Assert;

import org.junit.Test;

import fr.bdf.embgo.common.EmbgoCommonResource;

public class LoadPropTest {

	@Test
	public void loadProp() throws IOException {

		EmbgoCommonResource resource = new EmbgoCommonResource();

		//Assert.assertEquals("/data/source/s_dembarg/landing_layer/", resource.getLandingLayerPath());
		Assert.assertEquals("embarg_landing_acq", resource.getLandingLayerHiveBase());

		//Assert.assertEquals("/data/source/s_dembarg/raw_layer/", resource.getRawLayerPath());
		Assert.assertEquals("embargo_raw_layer", resource.getRawLayerHiveBase());

		//Assert.assertEquals("/data/source/s_dembarg/work_layer/", resource.getWorkLayerPath());
		Assert.assertEquals("embargo_work_layer", resource.getWorkLayerHiveBase());

	}

}
