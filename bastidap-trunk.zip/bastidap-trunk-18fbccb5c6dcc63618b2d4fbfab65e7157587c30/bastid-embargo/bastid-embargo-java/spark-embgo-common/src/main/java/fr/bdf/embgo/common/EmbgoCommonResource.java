package fr.bdf.embgo.common;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.Properties;

/**
 * common resource configuration for Embargo
 * 
 * @author i2108cs
 *
 */
public class EmbgoCommonResource implements Serializable {

	private static final long serialVersionUID = -123150783869654954L;

	/* Resource file */
	public static final String CONF_FILE = "embgoResource.properties";

	/* Resource properties keys */
	private final String EMBGO_LANDING_HDFS_PATH = "EMBGO_LANDING_HDFS_PATH";
	private final String EMBGO_RAW_HDFS_PATH = "EMBGO_RAW_HDFS_PATH";
	private final String EMBGO_WORK_HDFS_PATH = "EMBGO_WORK_HDFS_PATH";
	
	private final String EMBGO_LANDING_HIVE_BASE = "EMBGO_LANDING_HIVE_BASE";
	private final String EMBGO_RAW_HIVE_BASE = "EMBGO_RAW_HIVE_BASE";
	private final String EMBGO_WORK_HIVE_BASE = "EMBGO_WORK_HIVE_BASE";

	/* HDFS path */
	private String landingLayerPath;
	private String rawLayerPath;
	private String workLayerPath;

	/* Hive base */
	private String landingLayerHiveBase;
	private String rawLayerHiveBase;
	private String workLayerHiveBase;

	public EmbgoCommonResource() throws IOException {
		super();
		init();
	}

	public String getLandingLayerPath() {
		return landingLayerPath;
	}

	public void setLandingLayerPath(String landingLayerPath) {
		this.landingLayerPath = landingLayerPath;
	}

	public String getRawLayerPath() {
		return rawLayerPath;
	}

	public void setRawLayerPath(String rawLayerPath) {
		this.rawLayerPath = rawLayerPath;
	}

	public String getWorkLayerPath() {
		return workLayerPath;
	}

	public void setWorkLayerPath(String workLayerPath) {
		this.workLayerPath = workLayerPath;
	}

	public String getLandingLayerHiveBase() {
		return landingLayerHiveBase;
	}

	public void setLandingLayerHiveBase(String landingLayerHiveBase) {
		this.landingLayerHiveBase = landingLayerHiveBase;
	}

	public String getRawLayerHiveBase() {
		return rawLayerHiveBase;
	}

	public void setRawLayerHiveBase(String rawLayerHiveBase) {
		this.rawLayerHiveBase = rawLayerHiveBase;
	}

	public String getWorkLayerHiveBase() {
		return workLayerHiveBase;
	}

	public void setWorkLayerHiveBase(String workLayerHiveBase) {
		this.workLayerHiveBase = workLayerHiveBase;
	}

	private void init() throws IOException {
		Properties properties = getResourceProperties(CONF_FILE);

		setLandingLayerPath((String) properties.get(EMBGO_LANDING_HDFS_PATH));
		setRawLayerPath((String) properties.get(EMBGO_RAW_HDFS_PATH));
		setWorkLayerPath((String) properties.get(EMBGO_WORK_HDFS_PATH));

		setLandingLayerHiveBase((String) properties.get(EMBGO_LANDING_HIVE_BASE));
		setRawLayerHiveBase((String) properties.get(EMBGO_RAW_HIVE_BASE));
		setWorkLayerHiveBase((String) properties.get(EMBGO_WORK_HIVE_BASE));
	}

	/**
	 * load resource property file
	 * 
	 * @param confFile
	 * @return
	 * @throws IOException
	 */
	private Properties getResourceProperties(String confFile)
			throws IOException {
		Properties properties = new Properties();
		InputStream in = null;
		try {
			in = getClass().getClassLoader().getResourceAsStream(confFile);
			properties.load(in);
		} catch (IOException e) {
			throw new IOException("File " + confFile + " not found.");
		} finally {
			if (in != null) {
				in.close();
			}
		}
		return properties;
	}
}
