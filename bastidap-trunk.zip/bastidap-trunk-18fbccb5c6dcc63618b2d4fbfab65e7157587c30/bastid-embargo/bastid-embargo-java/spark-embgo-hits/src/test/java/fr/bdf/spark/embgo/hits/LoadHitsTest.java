package fr.bdf.spark.embgo.hits;

import junit.framework.TestCase;

public class LoadHitsTest extends TestCase {

	/**
	 * Rigourous Test :-)
	 */
	public void testApp() {

		// SparkConf conf = new
		// SparkConf().setMaster("local").setAppName("AlerteMainTest");
		// JavaSparkContext sc = new JavaSparkContext(conf);
		// HiveContext sqlContext = new HiveContext(sc);
		// sqlContext.setConf("hive.metastore.uris",
		// "thrift://lxdv716a.unix-int.intra-int.bdf-int.local:9083");
		//
		// sc.setLogLevel("WARN");
		//
		// //System.out.println("Conf : " +
		// sqlContext.getAllConfs().toString());
		// sqlContext.sql("show databases").show();
		// sqlContext.sql("select count(1) from gabi_shared_layer.parametrage_type_alerte").show();
		// sqlContext.sql("select * from gabi_shared_layer.parametrage_type_alerte").show();

		assertTrue(true);
	}
}
