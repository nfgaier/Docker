package fr.bdf.spark.embgo;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.IOUtils;

public abstract class AbstractTest {

	
	/**
	 * Méthode utilitaire pour récupérer le fichier contenant le jeu de test au
	 * format String
	 * 
	 * @throws IOException
	 */
	protected String getHitFromFile(String fileName) throws IOException {
		final InputStream input = getClass().getClassLoader().getResourceAsStream(fileName);
		return IOUtils.toString(input, StandardCharsets.UTF_8);
	}
}
