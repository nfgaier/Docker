package fr.bdf.spark.embgo.hits.util;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;

import fr.bdf.spark.embgo.AbstractTest;
import fr.bdf.spark.embgo.hits.constant.ParseHitsConstant;
import org.junit.Before;
import org.junit.Test;

import junit.framework.Assert;

public class ParseHitUtilsTest extends AbstractTest {

	private ParseHitsUtils parser;

	@Before
	public void init() {
		this.parser = new ParseHitsUtils();
	}

	
	@Test
	public void testParseHitsOne() throws IOException {

		/**
		 * Get test file as String and replace Windows EOL with UNIX EOL
		 */
		String strInput = this.getHitFromFile("hit-1-test.txt")
				.replace(ParseHitsConstant.WINDOWS_LINE_SEPARATOR, ParseHitsConstant.UNIX_LINE_SEPARATOR);

		/** Test for Suspect 1 */
		Assert.assertEquals(parser.getSuspectNumber(strInput), "1");
		Assert.assertEquals(parser.getCodeListe(strInput), "OFC");
		Assert.assertEquals(parser.getIdListe(strInput), "13");
		Assert.assertEquals(parser.getTauxConfiance(strInput), "0.0");
		Assert.assertEquals(parser.getTxtOpe(strInput), "SYRIA\nTEST SYRIA");
		Assert.assertEquals(parser.getNomSuspect(strInput), "*");
		Assert.assertEquals(parser.getNomSuspectSyn(strInput), StringUtils.EMPTY);
		Assert.assertEquals(parser.getAddressSuspect(strInput), StringUtils.EMPTY);
		Assert.assertEquals(parser.getAddressSuspectSyn(strInput), StringUtils.EMPTY);
		Assert.assertEquals(parser.getCity(strInput), "*");
		Assert.assertEquals(parser.getCitySyn(strInput), StringUtils.EMPTY);
		Assert.assertEquals(parser.getCountry(strInput), "SYRIA");
		Assert.assertEquals(parser.getCountrySyn(strInput), "- SYRIA    - SYRIAN ARAB REPUBLIC    - SYRIE");
		Assert.assertEquals(parser.getState(strInput), StringUtils.EMPTY);
		Assert.assertEquals(parser.getStateSyn(strInput), StringUtils.EMPTY);
		Assert.assertEquals(parser.getPasseport(strInput), StringUtils.EMPTY);
		Assert.assertEquals(parser.getBicSuspect(strInput), StringUtils.EMPTY);
		Assert.assertEquals(parser.getNatid(strInput), StringUtils.EMPTY);
		Assert.assertEquals(parser.getPlaceOfBirth(strInput), StringUtils.EMPTY);
		Assert.assertEquals(parser.getDateOfBirth(strInput), StringUtils.EMPTY);
		Assert.assertEquals(parser.getNationality(strInput), StringUtils.EMPTY);
		Assert.assertEquals(parser.getOriginList(strInput), "OFAC-CTRY");
		Assert.assertEquals(parser.getDesignation(strInput), "SYRIA");
		Assert.assertEquals(parser.getTypeListe(strInput), "Other");
		Assert.assertEquals(parser.getRefListe(strInput), "OFAC-CTRY");
		Assert.assertEquals(parser.getInfos(strInput), "48 main cities:ALEPPO, DAMASCUS, HAMA, HOMS, LATAKIA, TARTOUS, AL HASAKAH, AR RAQQAH, DAYR AZ ZAWR, TADMUR, JABLAH, BANIYAS, TARTUS, HAMAH, HIMS, MOUNT HERMON, AL QUNAYTIRAH, AS SUWAYDA, DAMAS, LADHIQIYAH, RAKKAH, QAMISHLY, PALMYRA, DARAA, AL QAMISHLI, IDLIB, AS SWAYDA, AL BAB, MARMARITA, SURAN, AFRIN, AL MALIKIYAH, AL MUKHARRAM, AL THAWRAH, AS SAFIRAH, DEIR ATIYAH, NAWA, SAFITA, SALAMIYAH, ALEP, ALEPO, DAMASKUS, DAMASCO, LATAQUIA, LAODICEA, BURJ ISLAM, DEIR EZ ZOR, DAMASCASALL PROPERTY AND INTERESTS IN PROPERTY THAT ARE IN THE UNITED STATES, THAT HEREAFTER COME WITHIN THE UNITED STATES, OR THAT ARE OR HEREAFTER COME WITHIN THE POSSESSION OR CONTROL OF ANY UNITED STATES PERSON, INCLUDING ANY OVERSEAS BRANCH, OF THE GOVERNMENT OF SYRIA ARE BLOCKED AND MAY NOT BE TRANSFERRED, PAID, EXPORTED, WITHDRAWN, OR OTHERWISE DEALT IN.");
		Assert.assertEquals(parser.getLien(strInput), StringUtils.EMPTY);
	}
	
	@Test
	public void testParseHitsTwo() throws IOException {

		/**
		 * Get test file as String and replace Windows EOL with UNIX EOL
		 */
		String strInput = this.getHitFromFile("hit-2-test.txt").replace(ParseHitsConstant.WINDOWS_LINE_SEPARATOR, ParseHitsConstant.UNIX_LINE_SEPARATOR);

		/** Test for Suspect 6 */
		Assert.assertEquals(parser.getSuspectNumber(strInput), "6");
		Assert.assertEquals(parser.getCodeListe(strInput), "EC");
		Assert.assertEquals(parser.getIdListe(strInput), "017");
		Assert.assertEquals(parser.getTauxConfiance(strInput), "1.0");
		Assert.assertEquals(parser.getTxtOpe(strInput), "SYRIE");
		Assert.assertEquals(parser.getNomSuspect(strInput), "Name");
		Assert.assertEquals(parser.getNomSuspectSyn(strInput), "- Name1    - Name2");
		Assert.assertEquals(parser.getAddressSuspect(strInput), "Address");
		Assert.assertEquals(parser.getAddressSuspectSyn(strInput), "- Address1    - Address2");
		Assert.assertEquals(parser.getCity(strInput), "City");
		Assert.assertEquals(parser.getCitySyn(strInput), "- City1    - City2");
		Assert.assertEquals(parser.getCountry(strInput), "SYRIA");
		Assert.assertEquals(parser.getCountrySyn(strInput), "- SYRIA    - SYRIAN ARAB REPUBLIC    - SYRIE");
		Assert.assertEquals(parser.getState(strInput), "State");
		Assert.assertEquals(parser.getStateSyn(strInput), "- State1    - State2");
		Assert.assertEquals(parser.getPasseport(strInput), "123456 Passport");
		Assert.assertEquals(parser.getBicSuspect(strInput), "123456 Bic codes");
		Assert.assertEquals(parser.getNatid(strInput), "123456 Natid");
		Assert.assertEquals(parser.getPlaceOfBirth(strInput), "75001 Paris");
		Assert.assertEquals(parser.getDateOfBirth(strInput), "23/11/2017");
		Assert.assertEquals(parser.getNationality(strInput), "Nationality");
		Assert.assertEquals(parser.getOriginList(strInput), "EU-CTRY");
		Assert.assertEquals(parser.getDesignation(strInput), "SYRIA");
		Assert.assertEquals(parser.getTypeListe(strInput), "Other");
		Assert.assertEquals(parser.getRefListe(strInput), "COUNCIL REGULATION (EU) 2016/2137 6 DECEMBER 2016");
		Assert.assertEquals(parser.getInfos(strInput), "48 main cities:ALEPPO, DAMASCUS, HAMA, HOMS, LATAKIA, TARTOUS, AL HASAKAH, AR RAQQAH, DAYR AZ ZAWR, TADMUR, JABLAH, BANIYAS, TARTUS, HAMAH, HIMS, MOUNT HERMON, AL QUNAYTIRAH, AS SUWAYDA, DAMAS, LADHIQIYAH, RAKKAH, QAMISHLY, PALMYRA, DARAA, AL QAMISHLI, IDLIB, AS SWAYDA, AL BAB, MARMARITA, SURAN, AFRIN, AL MALIKIYAH, AL MUKHARRAM, AL THAWRAH, AS SAFIRAH, DEIR ATIYAH, NAWA, SAFITA, SALAMIYAH, ALEP, ALEPO, DAMASKUS, DAMASCO, LATAQUIA, LAODICEA, BURJ ISLAM, DEIR EZ ZOR, DAMASCASON THE BASIS OF A REVIEW OF DECISION 2013/255/CFSP, THE RESTRICTIVE MEASURES SHOULD BE FURTHER EXTENDED UNTIL 1 JUNE 2017. / \"... IT IS NECESSARY TO INTRODUCE IN DECISION 2013/255/CFSP. EXEMPTIONS ENABLING MEMBER STATES TO PROVIDE SUPPORT TO THE ACTIVITIES UNDERTAKEN BY THE ORGANIZATION FOR THE PROHIBITION OF CHEMICAL WEAPONS (OPCW) FOR THE ELIMINATION OF THE CHEMICAL WEAPONS IN SYRIA IN ACCORDANCE WITH PARAGRAPH 10 OF THE UNITED NATIONS (UN) SECURITY COUNCIL RESOLUTION 2118(2013)... (...) IT SHALL BE PROHIBITED TO: (A) SELL, SUPPLY, TRANSFER OR EXPORT, DIRECTLY OR INDIRECTLY, JET FUEL AND FUEL ADDITIVES AS IDENTIFIED IN ANNEX VA TO ANY PERSON, ENTITY OR BODY IN SYRIA, OR FOR USE IN SYRIA (...) IN ADDITION, ON 12 FEBRUARY 2015, THE UNITED NATIONS SECURITY COUNCIL ADOPTED RESOLUTION 2199 (2015), PARAGRAPH 17 OF WHICH PROHIBITS THE TRADE IN SYRIAN CULTURAL PROPERTY AND OTHER ITEMS OF ARCHAEOLOGICAL, HISTORICAL, CULTURAL, RARE SCIENTIFIC, AND RELIGIOUS IMPORTANCE ILLEGALLY REMOVED FROM SYRIA SINCE 15 MARCH 2011. DECISION 2013/255/CFSP SHOULD THEREFORE BE AMENDED ACCORDINGLY,");
		Assert.assertEquals(parser.getLien(strInput), "http://eur-lex.europa.eu/legal-content/EN/TXT/PDF/?uri=CELEX:32016R2137&from=EN");
	}
	
	@Test
	public void testParseHitsStrInputNull() throws IOException {

		/** Test for strInput null*/
		Assert.assertEquals(parser.getSuspectNumber(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getCodeListe(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getIdListe(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTauxConfiance(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTxtOpe(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getNomSuspect(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getNomSuspectSyn(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getAddressSuspect(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getAddressSuspectSyn(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getCity(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getCitySyn(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getCountry(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getCountrySyn(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getState(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getStateSyn(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getPasseport(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getBicSuspect(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getNatid(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getPlaceOfBirth(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getDateOfBirth(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getNationality(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getOriginList(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getDesignation(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getTypeListe(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getRefListe(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getInfos(null), StringUtils.EMPTY);
		Assert.assertEquals(parser.getLien(null), StringUtils.EMPTY);
	}
}
