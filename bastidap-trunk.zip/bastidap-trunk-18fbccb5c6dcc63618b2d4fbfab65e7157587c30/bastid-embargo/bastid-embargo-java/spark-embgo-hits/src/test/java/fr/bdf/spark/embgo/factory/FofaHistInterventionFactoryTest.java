package fr.bdf.spark.embgo.factory;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema;
import org.apache.spark.sql.types.DateType;
import org.apache.spark.sql.types.StringType;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.junit.Before;
import org.junit.Test;

import fr.bdf.spark.embgo.AbstractTest;
import fr.bdf.spark.embgo.hits.beans.FofaHistInterventionBean;
import fr.bdf.spark.embgo.hits.constant.ParseHitsConstant;
import fr.bdf.spark.embgo.hits.factory.FofaHistInterventionFactory;
import junit.framework.Assert;

public class FofaHistInterventionFactoryTest extends AbstractTest {

	
	private FofaHistInterventionFactory factory;
	
	
	@Before
	public void init() {
		this.factory = new FofaHistInterventionFactory();
	}
	
	
	@Test
	public void testCall() throws Exception {
		
		/** Initialisation */
		final Date dateTest = new Date(new java.util.Date().getTime());
		final String hits = this.getHitFromFile("hit-full.txt").replace(ParseHitsConstant.WINDOWS_LINE_SEPARATOR, ParseHitsConstant.UNIX_LINE_SEPARATOR);
		final List<FofaHistInterventionBean> beans = new ArrayList<FofaHistInterventionBean>();
		
		/** Création des rows */		
		StructField t_system_id = new StructField("t_system_id", new StringType() , false, null);
		StructField t_intervention = new StructField("t_intervention", new StringType() , false, null);
		StructField date_ope = new StructField("date_ope", new DateType() , false, null);
		StructField date_insert = new StructField("date_insert", new DateType() , false, null);
		StructField id_traitement = new StructField("id_traitement", new StringType() , false, null);
		StructType structure = new StructType(new StructField[]{t_system_id, t_intervention, date_ope, date_insert, id_traitement});
		
		Row row1 = new GenericRowWithSchema(new Object[]{"1", hits, dateTest, dateTest, "20171129100000"}, structure);
		Row row2 = new GenericRowWithSchema(new Object[]{"2", hits, dateTest, dateTest, "20171129100000"}, structure);
		final List<Row> rows = Arrays.asList(row1, row2);	
		
		/** Test */
		for (Row row : rows) {
			beans.add(factory.call(row));
		}
		
		/** Check de la liste */
		Assert.assertNotNull(beans);
		Assert.assertTrue(CollectionUtils.isNotEmpty(beans));
		Assert.assertEquals(beans.size(), 2);
		
		/** Check du premier élément */
		Assert.assertEquals(beans.get(0).getT_system_id(), "1");
		Assert.assertEquals(beans.get(0).getT_intervention(), hits);
		Assert.assertEquals(beans.get(0).getDate_ope().toString(), dateTest.toString());
		Assert.assertEquals(beans.get(0).getDate_insert().toString(), dateTest.toString());
		Assert.assertEquals(beans.get(0).getId_traitement(), "20171129100000");
		
		/** Check du second élément */
		Assert.assertEquals(beans.get(1).getT_system_id(), "2");
		Assert.assertEquals(beans.get(1).getT_intervention(), hits);
		Assert.assertEquals(beans.get(1).getDate_ope().toString(), dateTest.toString());
		Assert.assertEquals(beans.get(1).getDate_insert().toString(), dateTest.toString());
		Assert.assertEquals(beans.get(1).getId_traitement(), "20171129100000");
	}
	
}
