package fr.bdf.spark.embgo.factory;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.IteratorUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;

import fr.bdf.spark.embgo.AbstractTest;
import fr.bdf.spark.embgo.hits.beans.FofaHistInterventionBean;
import fr.bdf.spark.embgo.hits.beans.HitBean;
import fr.bdf.spark.embgo.hits.constant.ParseHitsConstant;
import fr.bdf.spark.embgo.hits.factory.HitFactory;
import junit.framework.Assert;

public class HitFactoryTest extends AbstractTest {
	
	private static final String ID_TRAITEMENT = "20171129100000";
	private HitFactory factory;
	
	
	
	@Before
	public void init() {
		this.factory = new HitFactory(ID_TRAITEMENT);
	}

	
	@Test
	public void testCall() throws Exception {
		
		/** Initialisation d'un bean FofaHistIntervention, d'un hit et d'une date pour les tests */
		final Date dateTest = new Date(new java.util.Date().getTime());
		final String hits = this.getHitFromFile("hit-full.txt").replace(ParseHitsConstant.WINDOWS_LINE_SEPARATOR, ParseHitsConstant.UNIX_LINE_SEPARATOR);
		final FofaHistInterventionBean beanSource = 
				new FofaHistInterventionBean("id", hits, dateTest, dateTest, ID_TRAITEMENT);
		
		/** Décomposition des hits en liste pour les tests */
		final String[] splittedHits = StringUtils.splitByWholeSeparator(hits, ParseHitsConstant.HITS_SEPARATOR);
		final List<String> listSplittedHits = new ArrayList<String>();
		for (int i = 1; i < splittedHits.length - 1; i++) {
			listSplittedHits.add(splittedHits[i]);
		}
		
		
		/** Call Factory and convert iterator to list */
		Iterator<HitBean> iterator = factory.call(beanSource);
		final List<HitBean> outputBeans = IteratorUtils.toList(iterator);
		
		/** Test  */
		Assert.assertNotNull(iterator);
		Assert.assertTrue(CollectionUtils.isNotEmpty(outputBeans));
		Assert.assertEquals(outputBeans.size(), 6);
		
		Assert.assertEquals(outputBeans.get(0).getNum_suspect(), new Integer(1));
		Assert.assertEquals(outputBeans.get(0).getCode_liste(), "OFC");
		Assert.assertEquals(outputBeans.get(0).getId_liste(), "13");
		Assert.assertEquals(outputBeans.get(0).getHit_clob(), listSplittedHits.get(0).replace(ParseHitsConstant.UNIX_LINE_SEPARATOR, "{BR}"));
		
		Assert.assertEquals(outputBeans.get(1).getNum_suspect(), new Integer(2));
		Assert.assertEquals(outputBeans.get(1).getCode_liste(), "OFC");
		Assert.assertEquals(outputBeans.get(1).getId_liste(), "13");
		Assert.assertEquals(outputBeans.get(1).getHit_clob(), listSplittedHits.get(1).replace(ParseHitsConstant.UNIX_LINE_SEPARATOR, "{BR}"));
		
		Assert.assertEquals(outputBeans.get(2).getNum_suspect(), new Integer(3));
		Assert.assertEquals(outputBeans.get(2).getCode_liste(), "BOEC");
		Assert.assertEquals(outputBeans.get(2).getId_liste(), "00017");
		Assert.assertEquals(outputBeans.get(2).getHit_clob(), listSplittedHits.get(2).replace(ParseHitsConstant.UNIX_LINE_SEPARATOR, "{BR}"));
		
		Assert.assertEquals(outputBeans.get(3).getNum_suspect(), new Integer(4));
		Assert.assertEquals(outputBeans.get(3).getCode_liste(), "BOEC");
		Assert.assertEquals(outputBeans.get(3).getId_liste(), "00017");
		Assert.assertEquals(outputBeans.get(3).getHit_clob(), listSplittedHits.get(3).replace(ParseHitsConstant.UNIX_LINE_SEPARATOR, "{BR}"));
		
		Assert.assertEquals(outputBeans.get(4).getNum_suspect(), new Integer(5));
		Assert.assertEquals(outputBeans.get(4).getCode_liste(), "EC");
		Assert.assertEquals(outputBeans.get(4).getId_liste(), "017");
		Assert.assertEquals(outputBeans.get(4).getHit_clob(), listSplittedHits.get(4).replace(ParseHitsConstant.UNIX_LINE_SEPARATOR, "{BR}"));
		
		Assert.assertEquals(outputBeans.get(5).getNum_suspect(), new Integer(6));
		Assert.assertEquals(outputBeans.get(5).getCode_liste(), "EC");
		Assert.assertEquals(outputBeans.get(5).getId_liste(), "017");
		Assert.assertEquals(outputBeans.get(5).getHit_clob(), listSplittedHits.get(5).replace(ParseHitsConstant.UNIX_LINE_SEPARATOR, "{BR}"));
		
		for (HitBean hitBean : outputBeans) {
			Assert.assertEquals(hitBean.getId_alerte(), "id");
			Assert.assertEquals(hitBean.getDate_insert(), dateTest);
			Assert.assertEquals(hitBean.getDate_ope(), dateTest);
			Assert.assertEquals(hitBean.getId_traitement(), ID_TRAITEMENT);
		}

		
		
	}
}
