package fr.bdf.spark.embgo.hits.main;

import static org.apache.spark.sql.functions.col;

import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.fs.Path;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import fr.bdf.bastid.util.bean.LineAcqFile;
import fr.bdf.bastid.util.filereader.AcqFileReader;
import fr.bdf.spark.embgo.hits.beans.FofaHistInterventionBean;
import fr.bdf.spark.embgo.hits.beans.HitBean;
import fr.bdf.spark.embgo.hits.constant.ParseHitsConstant;
import fr.bdf.spark.embgo.hits.factory.FofaHistInterventionFactory;
import fr.bdf.spark.embgo.hits.factory.HitFactory;

/**
 * Main Class for parsing Hits with Spark. Read table
 * FOFA_HIST_INTERVENTION_${DATE_JOUR} and transform data to Hits
 */
public class LoadHitsMain implements Serializable {

	private static final long serialVersionUID = 2091941244369729116L;

	private static final String TABLE_FOFA_HIST_INTERVENTION = "fofa_hist_intervention";
	private static final String TABLE_HITS = "hits";

	public static String getTime() {
		return "[" + new SimpleDateFormat("HH:mm:ss").format(new Date()) + "]";
	}

	public static void main(String[] args) {
		Logger.getRootLogger().setLevel(Level.WARN);

		/**
		 * Check and get parameters pathToConfigFile => Path to the config file
		 * idTraitement => Unique id for current process businessDate =>
		 * Functionnal date for the day processed
		 */
		if (args.length != 3) {
			System.out
					.println("INFO:"
							+ LoadHitsMain.getTime()
							+ " Missing arguments. Usage: "
							+ new java.io.File(LoadHitsMain.class
									.getProtectionDomain().getCodeSource()
									.getLocation().getPath()).getName()
							+ " <hadoop configuration file>"
							+ " <full param file name, containing the list of id_trt/date_ope to load>"
							+ " <id traitement en cours>");
			System.exit(0);
		}
		String pathToConfigFile = args[0];
		String idAcqFile = args[1];
		String idTrt = args[2];

		/** Init configuration and contexts */
		final SparkSession session = SparkSession.builder().appName("LoadHits")
				.config("spark.sql.warehouse.dir", "/apps/hive/warehouse")
				.config("spark.sql.hive.convertMetastoreOrc", "false")
				.enableHiveSupport().getOrCreate();

		session.sparkContext().hadoopConfiguration().addResource(new Path(pathToConfigFile));
		
		ParseHitsConstant parseHitsConstant = null;
		String embWorkLayerHDFSPath = null;
		try {
			parseHitsConstant = new ParseHitsConstant();
			embWorkLayerHDFSPath = parseHitsConstant.getWorkLayerPath();
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}

		AcqFileReader acqFileReader = new AcqFileReader(idAcqFile);
		List<LineAcqFile> listIdAcq = getMapAcqFileLines(acqFileReader).get(
				TABLE_FOFA_HIST_INTERVENTION.toUpperCase());

		if (listIdAcq.isEmpty()) {
			Logger.getRootLogger().error(
					"Pas d'ID_TRAITEMENT / DATE_OPE pour "
							+ TABLE_FOFA_HIST_INTERVENTION.toUpperCase());
			System.exit(0);
		}

		String whereClause = " where";
		for (int i = 0; i < listIdAcq.size(); i++) {
			if (i == 0) {
				whereClause += " (id_traitement = '"
						+ listIdAcq.get(i).getIdAcq() + "'"
						+ " and date_ope = '" + listIdAcq.get(i).getJourFonc()
						+ "')";
			} else {
				whereClause += " OR (id_traitement = '"
						+ listIdAcq.get(i).getIdAcq() + "'"
						+ " and date_ope = '" + listIdAcq.get(i).getJourFonc()
						+ "')";
			}
		}

		System.out.println("Clause where :");
		System.out.println(whereClause);

		/** Build DATAFRAME for fofa_hist_intervention */
		Dataset<Row> fofaHistInterventionDF = session.sql(
				"select " + "t_system_id," + "t_intervention,"
						+ "id_traitement," + "date_ope," + "date_insert"
						+ " from " + parseHitsConstant.getRawLayerHiveBase()
						+ "." + TABLE_FOFA_HIST_INTERVENTION + whereClause)
				.persist();

		/** Build RDD for fofa_hist_intervention */
		FofaHistInterventionFactory factory = new FofaHistInterventionFactory();
		JavaRDD<FofaHistInterventionBean> fofaHistInterventionRDD = fofaHistInterventionDF
				.toJavaRDD().map(factory);
		fofaHistInterventionRDD.cache();

		/** Build RDD for Hits */
		JavaRDD<HitBean> hitBeanRDD = fofaHistInterventionRDD
				.flatMap(new HitFactory(idTrt));

		/** Create Hits DataFrame */
		Dataset<Row> hitBeanDF = session.createDataFrame(hitBeanRDD,
				HitBean.class);

		/** Order Hits DataFrame */
		Dataset<Row> orderedHitDF = hitBeanDF.select(col("id_alerte"),
				col("num_suspect"), col("code_liste"), col("id_liste"),
				col("tx_confiance"), col("texte_tope"), col("nom_suspect"),
				col("nom_suspect_syn"), col("adresse_suspect"),
				col("adresse_suspect_syn"), col("ville"), col("ville_syn"),
				col("pays"), col("pays_syn"), col("etat"), col("etat_syn"),
				col("passeport"), col("bic_suspect"), col("natid_suspect"),
				col("lieu_naissance"), col("date_naissance"),
				col("nationalite"), col("origine_liste"), col("designation"),
				col("type_liste"), col("ref_liste"), col("infos"), col("lien"),
				col("hit_clob"), col("date_ope"), col("date_insert"),
				col("id_traitement"));

		/** Save Hits DataFrame */
		orderedHitDF.write().partitionBy("id_traitement").format("orc")
				.mode("append").save(embWorkLayerHDFSPath + TABLE_HITS);
		String alterTableHits = "ALTER TABLE "
				+ parseHitsConstant.getWorkLayerHiveBase() + "." + TABLE_HITS
				+ " ADD IF NOT EXISTS PARTITION (id_traitement='" + idTrt
				+ "') " + "location '" + embWorkLayerHDFSPath + TABLE_HITS
				+ "/id_traitement=" + idTrt + "'";
		session.sql(alterTableHits);

		/** Close spark conf */
		session.close();
	}

	/**
	 * Method that gets the acquisition ids needed for the treatment.
	 * 
	 * @param afr
	 *            the acquisition file reader
	 * @return the map that contains the acquisition ids needed for the
	 *         treatment
	 */
	private static Map<String, List<LineAcqFile>> getMapAcqFileLines(
			AcqFileReader afr) {
		Map<String, List<LineAcqFile>> mapAcqFileLines = null;
		try {
			mapAcqFileLines = afr.getAcqFileLines();
		} catch (IOException e) {
			Logger.getRootLogger().error(
					"An error occured when reading the file", e);
			System.exit(0);
		}

		if (mapAcqFileLines == null || mapAcqFileLines.isEmpty()) {
			Logger.getRootLogger().error(
					"The acquisition id map is null or empty");
			System.exit(0);
		}
		return mapAcqFileLines;
	}

}
