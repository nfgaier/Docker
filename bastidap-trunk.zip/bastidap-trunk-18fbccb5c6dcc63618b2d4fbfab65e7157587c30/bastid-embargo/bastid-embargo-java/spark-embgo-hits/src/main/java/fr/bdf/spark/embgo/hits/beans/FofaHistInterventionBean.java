package fr.bdf.spark.embgo.hits.beans;

import java.io.Serializable;
import java.sql.Date;
import java.text.SimpleDateFormat;

public class FofaHistInterventionBean implements Serializable { 

	/**
	 * 
	 */
	private static final long serialVersionUID = -5160868373930833924L;
	private String t_system_id;
    private String t_intervention;
    private String id_traitement;
    private Date date_ope;
    private Date date_insert;
    
    
    /** 
     * Constructeur vide.
     * */
    public FofaHistInterventionBean() {
    	
    }


	public FofaHistInterventionBean(String t_system_id, String t_intervention, Date date_ope, Date date_insert, String id_traitement) {
		super();
		this.t_system_id = t_system_id;
		this.t_intervention = t_intervention;
		this.date_ope = date_ope;
		this.date_insert = date_insert;
		this.id_traitement = id_traitement;
		
	}


	public String getT_system_id() {
		return t_system_id;
	}


	public void setT_system_id(String t_system_id) {
		this.t_system_id = t_system_id;
	}


	public String getT_intervention() {
		return t_intervention;
	}


	public void setT_intervention(String t_intervention) {
		this.t_intervention = t_intervention;
	}
	
	public String getId_traitement() {
		return this.id_traitement;
	}

	public void setId_traitement(String id_traitement) {
		this.id_traitement = id_traitement;
	}
	
	public Date getDate_ope() {
		return this.date_ope;
	}

	public void setDate_ope(Date date_ope) {
		this.date_ope = date_ope;
	}
    
    @Override
	public String toString() {
    	
    	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		return "FofaHistInterventionBean ["
					+ "t_system_id=" + t_system_id
					+ ", t_intervention=" + t_intervention
					+  ", id_traitement=" + id_traitement
					+  ", date_ope=" + dateFormat.format(date_ope)
					+ "]";
	}


	public Date getDate_insert() {
		return date_insert;
	}


	public void setDate_insert(Date date_insert) {
		this.date_insert = date_insert;
	}


    
}
