package fr.bdf.spark.embgo.hits.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;


public class HitBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 678166396881829121L;
	
	private String id_alerte; 
	private Integer num_suspect; 
	private String code_liste; 
	private String id_liste; 
	private BigDecimal tx_confiance; 
	private String texte_tope; 
	private String nom_suspect; 
	private String nom_suspect_syn; 
	private String adresse_suspect; 
	private String adresse_suspect_syn; 
	private String ville; 
	private String ville_syn; 
	private String pays; 
	private String pays_syn; 
	private String etat; 
	private String etat_syn; 
	private String passeport; 
	private String bic_suspect; 
	private String natid_suspect; 
	private String lieu_naissance; 
	private String date_naissance; 
	private String nationalite; 
	private String origine_liste; 
	private String designation; 
	private String type_liste; 
	private String ref_liste; 
	private String infos; 
	private String lien; 
	private String hit_clob;
	private Date date_ope;
	private Date date_insert;
	private String id_traitement;
	
	/** 
	 * Constructeur vide.
	 * */
	public HitBean() {
		
	}

	public String getId_alerte() {
		return id_alerte;
	}

	public void setId_alerte(String id_alerte) {
		this.id_alerte = id_alerte;
	}

	public Integer getNum_suspect() {
		return num_suspect;
	}

	public void setNum_suspect(Integer num_suspect) {
		this.num_suspect = num_suspect;
	}

	public String getCode_liste() {
		return code_liste;
	}

	public void setCode_liste(String code_liste) {
		this.code_liste = code_liste;
	}

	public String getId_liste() {
		return id_liste;
	}

	public void setId_liste(String id_liste) {
		this.id_liste = id_liste;
	}

	public BigDecimal getTx_confiance() {
		return tx_confiance;
	}

	public void setTx_confiance(BigDecimal tx_confiance) {
		this.tx_confiance = tx_confiance;
	}

	public String getTexte_tope() {
		return texte_tope;
	}

	public void setTexte_tope(String texte_tope) {
		this.texte_tope = texte_tope;
	}

	public String getNom_suspect() {
		return nom_suspect;
	}

	public void setNom_suspect(String nom_suspect) {
		this.nom_suspect = nom_suspect;
	}

	public String getNom_suspect_syn() {
		return nom_suspect_syn;
	}

	public void setNom_suspect_syn(String nom_suspect_syn) {
		this.nom_suspect_syn = nom_suspect_syn;
	}

	public String getAdresse_suspect() {
		return adresse_suspect;
	}

	public void setAdresse_suspect(String adresse_suspect) {
		this.adresse_suspect = adresse_suspect;
	}

	public String getAdresse_suspect_syn() {
		return adresse_suspect_syn;
	}

	public void setAdresse_suspect_syn(String adresse_suspect_syn) {
		this.adresse_suspect_syn = adresse_suspect_syn;
	}

	public String getVille() {
		return ville;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}

	public String getVille_syn() {
		return ville_syn;
	}

	public void setVille_syn(String ville_syn) {
		this.ville_syn = ville_syn;
	}

	public String getPays() {
		return pays;
	}

	public void setPays(String pays) {
		this.pays = pays;
	}

	public String getPays_syn() {
		return pays_syn;
	}

	public void setPays_syn(String pays_syn) {
		this.pays_syn = pays_syn;
	}

	public String getEtat() {
		return etat;
	}

	public void setEtat(String etat) {
		this.etat = etat;
	}

	public String getEtat_syn() {
		return etat_syn;
	}

	public void setEtat_syn(String etat_syn) {
		this.etat_syn = etat_syn;
	}

	public String getPasseport() {
		return passeport;
	}

	public void setPasseport(String passeport) {
		this.passeport = passeport;
	}

	public String getBic_suspect() {
		return bic_suspect;
	}

	public void setBic_suspect(String bic_suspect) {
		this.bic_suspect = bic_suspect;
	}

	public String getNatid_suspect() {
		return natid_suspect;
	}

	public void setNatid_suspect(String natid_suspect) {
		this.natid_suspect = natid_suspect;
	}

	public String getLieu_naissance() {
		return lieu_naissance;
	}

	public void setLieu_naissance(String lieu_naissance) {
		this.lieu_naissance = lieu_naissance;
	}

	public String getDate_naissance() {
		return date_naissance;
	}

	public void setDate_naissance(String date_naissance) {
		this.date_naissance = date_naissance;
	}

	public String getNationalite() {
		return nationalite;
	}

	public void setNationalite(String nationalite) {
		this.nationalite = nationalite;
	}

	public String getOrigine_liste() {
		return origine_liste;
	}

	public void setOrigine_liste(String origine_liste) {
		this.origine_liste = origine_liste;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getType_liste() {
		return type_liste;
	}

	public void setType_liste(String type_liste) {
		this.type_liste = type_liste;
	}

	public String getRef_liste() {
		return ref_liste;
	}

	public void setRef_liste(String ref_liste) {
		this.ref_liste = ref_liste;
	}

	public String getInfos() {
		return infos;
	}

	public void setInfos(String infos) {
		this.infos = infos;
	}

	public String getLien() {
		return lien;
	}

	public void setLien(String lien) {
		this.lien = lien;
	}

	public String getHit_clob() {
		return hit_clob;
	}

	public void setHit_clob(String hit_clob) {
		this.hit_clob = hit_clob;
	}

	public Date getDate_ope() {
		return date_ope;
	}

	public void setDate_ope(Date date_ope) {
		this.date_ope = date_ope;
	}

	public String getId_traitement() {
		return id_traitement;
	}

	public void setId_traitement(String id_traitement) {
		this.id_traitement = id_traitement;
	}

	@Override
	public String toString() {
		return "HitBean [id_alerte=" + id_alerte + ", num_suspect=" + num_suspect + ", code_liste=" + code_liste
				+ ", id_liste=" + id_liste + ", tx_confiance=" + tx_confiance + ", texte_tope=" + texte_tope
				+ ", nom_suspect=" + nom_suspect + ", nom_suspect_syn=" + nom_suspect_syn + ", adresse_suspect="
				+ adresse_suspect + ", adresse_suspect_syn=" + adresse_suspect_syn + ", ville=" + ville + ", ville_syn="
				+ ville_syn + ", pays=" + pays + ", pays_syn=" + pays_syn + ", etat=" + etat + ", etat_syn=" + etat_syn
				+ ", passeport=" + passeport + ", bic_suspect=" + bic_suspect + ", natid_suspect=" + natid_suspect
				+ ", lieu_naissance=" + lieu_naissance + ", date_naissance=" + date_naissance + ", nationalite="
				+ nationalite + ", origine_liste=" + origine_liste + ", designation=" + designation + ", type_liste="
				+ type_liste + ", ref_liste=" + ref_liste + ", infos=" + infos + ", lien=" + lien + ", hit_clob="
				+ hit_clob 
				+ ", date_ope=" + date_ope
				+ ", id_traitement=" + id_traitement
				+ "]";
	}

	public Date getDate_insert() {
		return date_insert;
	}

	public void setDate_insert(Date date_insert) {
		this.date_insert = date_insert;
	}
	
	
}
