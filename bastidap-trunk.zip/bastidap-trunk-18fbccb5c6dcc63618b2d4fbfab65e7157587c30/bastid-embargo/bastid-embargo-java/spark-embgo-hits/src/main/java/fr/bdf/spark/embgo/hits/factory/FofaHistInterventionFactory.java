package fr.bdf.spark.embgo.hits.factory;

import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Row;

import fr.bdf.spark.embgo.hits.beans.FofaHistInterventionBean;

public class FofaHistInterventionFactory extends AbstractFactory implements Function<Row, FofaHistInterventionBean> {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1299138086042115033L;

	@Override
	public FofaHistInterventionBean call(Row ligne) throws Exception {
		return new FofaHistInterventionBean(
				getString(ligne.getAs("t_system_id")),
				getString(ligne.getAs("t_intervention")),
				getDateSql(ligne.getAs("date_ope")),
				getDateSql(ligne.getAs("date_insert")),
				getString(ligne.getAs("id_traitement")));
	}


}
