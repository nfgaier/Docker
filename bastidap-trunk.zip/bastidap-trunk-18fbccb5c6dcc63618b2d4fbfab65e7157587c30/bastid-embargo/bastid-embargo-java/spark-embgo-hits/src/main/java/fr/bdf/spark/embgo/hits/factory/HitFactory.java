package fr.bdf.spark.embgo.hits.factory;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.function.FlatMapFunction;
import fr.bdf.spark.embgo.hits.constant.ParseHitsConstant;
import fr.bdf.spark.embgo.hits.util.ParseHitsUtils;



import fr.bdf.spark.embgo.hits.beans.FofaHistInterventionBean;
import fr.bdf.spark.embgo.hits.beans.HitBean;

public class HitFactory implements FlatMapFunction<FofaHistInterventionBean, HitBean> {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8351672753452504747L;
	private String idTrt;

	// empty constructor
	public HitFactory(String idTrt) {
		this.idTrt = idTrt;
	}

	@Override
	public Iterator<HitBean> call(FofaHistInterventionBean fofaHistInterventionBean) throws Exception {

		final List<HitBean> hitsList = new ArrayList<HitBean>();
		//final Iterator
		
		final String[] splittedHits = StringUtils.splitByWholeSeparator(fofaHistInterventionBean.getT_intervention(),
				ParseHitsConstant.HITS_SEPARATOR);
		final List<String> listSplittedHits = new ArrayList<String>();
		for (int i = 1; i < splittedHits.length - 1; i++) {
			listSplittedHits.add(splittedHits[i]);
		}

		if (CollectionUtils.isNotEmpty(listSplittedHits)) {
			final ParseHitsUtils utils = new ParseHitsUtils();
			for (String hit : listSplittedHits) {
				
				HitBean hitTmp = new HitBean();
				
				hitTmp.setId_alerte(fofaHistInterventionBean.getT_system_id());
				hitTmp.setNum_suspect(Integer.parseInt(utils.getSuspectNumber(hit)));
				hitTmp.setCode_liste(utils.getCodeListe(hit));
				hitTmp.setId_liste(utils.getIdListe(hit));
				hitTmp.setTx_confiance(BigDecimal.valueOf(Double.parseDouble(utils.getTauxConfiance(hit))));
				hitTmp.setTexte_tope(utils.getTxtOpe(hit));
				hitTmp.setNom_suspect(utils.getNomSuspect(hit));
				hitTmp.setNom_suspect_syn(utils.getNomSuspectSyn(hit));
				hitTmp.setAdresse_suspect(utils.getAddressSuspect(hit));
				hitTmp.setAdresse_suspect_syn(utils.getAddressSuspectSyn(hit));
				hitTmp.setVille(utils.getCity(hit));
				hitTmp.setVille_syn(utils.getCitySyn(hit));
				hitTmp.setPays(utils.getCountry(hit));
				hitTmp.setPays_syn(utils.getCountrySyn(hit));
				hitTmp.setEtat(utils.getState(hit));
				hitTmp.setEtat_syn(utils.getStateSyn(hit));
				hitTmp.setPasseport(utils.getPasseport(hit));
				hitTmp.setBic_suspect(utils.getBicSuspect(hit));
				hitTmp.setNatid_suspect(utils.getNatid(hit));
				hitTmp.setLieu_naissance(utils.getPlaceOfBirth(hit));
				hitTmp.setDate_naissance(utils.getDateOfBirth(hit));
				hitTmp.setNationalite(utils.getNationality(hit));
				hitTmp.setOrigine_liste(utils.getOriginList(hit));
				hitTmp.setDesignation(utils.getDesignation(hit));
				hitTmp.setType_liste(utils.getTypeListe(hit));
				hitTmp.setRef_liste(utils.getRefListe(hit));
				hitTmp.setInfos(utils.getInfos(hit));
				hitTmp.setLien(utils.getLien(hit));
				if(StringUtils.isNotBlank(hit)) {
					hitTmp.setHit_clob(hit.replace(ParseHitsConstant.UNIX_LINE_SEPARATOR, StringUtils.SPACE));
				}
				hitTmp.setDate_ope(fofaHistInterventionBean.getDate_ope());
				hitTmp.setDate_insert(fofaHistInterventionBean.getDate_insert());
				hitTmp.setId_traitement(this.idTrt);
				
				hitsList.add(hitTmp);

			}
		}
		return hitsList.iterator();
	}
}
