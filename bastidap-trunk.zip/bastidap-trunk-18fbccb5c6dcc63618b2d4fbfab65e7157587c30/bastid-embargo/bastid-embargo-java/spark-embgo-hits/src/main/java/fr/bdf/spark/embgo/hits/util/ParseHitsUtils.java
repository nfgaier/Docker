package fr.bdf.spark.embgo.hits.util;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import fr.bdf.spark.embgo.hits.constant.ParseHitsConstant;

/**
 * Hello world!
 *
 */
public class ParseHitsUtils {

	/**
	 * Empty Constructor.
	 */
	public ParseHitsUtils() {

	}

	/**
	 * Get the NUM_SUSPECT field
	 * 
	 * @param strInput
	 * @return suspectNumber
	 */
	public String getSuspectNumber(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("Suspect detected #") + ParseHitsConstant.EIGHTEEN;
				return strInput.substring(markerIndex,
						strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR, markerIndex)).trim();
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing NUM_SUSPECT : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get CODE_LISTE field
	 * 
	 * @param strInput
	 * @return codeListe
	 */
	public String getCodeListe(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("OFAC ID: ") + ParseHitsConstant.NINE;
				return strInput
						.substring(markerIndex, strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR, markerIndex))
						.replaceAll("\\d", "").trim();
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing CODE_LISTE : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get ID_LISTE field
	 * 
	 * @param strInput
	 * @return idListe
	 */
	public String getIdListe(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("OFAC ID: ") + ParseHitsConstant.NINE;
				return strInput
						.substring(markerIndex, strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR, markerIndex))
						.replaceAll("\\D", "").trim();
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing ID_LISTE : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get TX_CONFIANCE field
	 * 
	 * @param strInput
	 * @return txConfiance
	 */
	public String getTauxConfiance(String strInput) {
		if (StringUtils.isNoneBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("MATCH: ") + ParseHitsConstant.SEVEN;
				return strInput.substring(markerIndex,
						strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR, markerIndex)).trim();
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing TX_CONFIANCE : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get TEXTE_TOPE field
	 * 
	 * @param strInput
	 * @return txtOpe
	 */
	public String getTxtOpe(String strInput) {
		if (StringUtils.isNoneBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("MATCHINGTEXT: ") + ParseHitsConstant.FOURTEEN;
				return strInput.substring(markerIndex,
						strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "RESULT:")).trim();
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing TEXTE_TOPE : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get NOM_SUSPECT field
	 * 
	 * @param strInput
	 * @return NOM_SUSPECT
	 */
	public String getNomSuspect(String strInput) {
		if (StringUtils.isNoneBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("NAME:") + ParseHitsConstant.FIVE;
				return strInput
						.substring(markerIndex, strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR, markerIndex))
						.trim();
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing NOM_SUSPECT : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get NOM_SUSPECT_SYN
	 * 
	 * @param strInput
	 * @return nomSuspectSyn
	 */
	public String getNomSuspectSyn(String strInput) {
		String nomSuspectSyn = StringUtils.EMPTY;
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("NAME:") + ParseHitsConstant.FIVE;
				final int synonymMarker = strInput.indexOf("Synonyms:", markerIndex) + ParseHitsConstant.NINE;
				nomSuspectSyn = strInput.substring(synonymMarker,
						strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "ADDRESS:"));
				if (nomSuspectSyn.startsWith(" " + ParseHitsConstant.UNIX_LINE_SEPARATOR)) {
					nomSuspectSyn = nomSuspectSyn.replaceFirst(ParseHitsConstant.UNIX_LINE_SEPARATOR,
							StringUtils.EMPTY);
				}
				if (StringUtils.isNotBlank(nomSuspectSyn) && nomSuspectSyn.contains(("none"))) {
					nomSuspectSyn = StringUtils.EMPTY;
				}
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing NOM_SUSPECT_SYN : " + e);
			}
		}
		return nomSuspectSyn.replaceAll("\\r\\n|\\r|\\n", StringUtils.SPACE).trim();
	}

	/**
	 * Get ADRESSE_SUSPECT
	 * 
	 * @param strInput
	 * @return addressSuspect
	 */
	public String getAddressSuspect(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("ADDRESS:") + ParseHitsConstant.EIGHT;
				return strInput
						.substring(markerIndex, strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR, markerIndex))
						.trim();
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing ADRESSE_SUSPECT : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get ADRESSE_SUSPECT_SYN
	 * 
	 * @param strInput
	 * @return addressSuspectSyn
	 */
	public String getAddressSuspectSyn(String strInput) {
		String addressSuspectSyn = StringUtils.EMPTY;
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("ADDRESS:") + ParseHitsConstant.EIGHT;
				final int synonymMarker = strInput.indexOf("Synonyms:", markerIndex) + ParseHitsConstant.NINE;
				addressSuspectSyn = strInput.substring(synonymMarker,
						strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "CITY:"));
				if (addressSuspectSyn.startsWith(" " + ParseHitsConstant.UNIX_LINE_SEPARATOR)) {
					addressSuspectSyn = addressSuspectSyn.replaceFirst(ParseHitsConstant.UNIX_LINE_SEPARATOR,
							StringUtils.EMPTY);
				}
				if (StringUtils.isNotBlank(addressSuspectSyn) && addressSuspectSyn.contains(("none"))) {
					addressSuspectSyn = StringUtils.EMPTY;
				}
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing ADRESSE_SUSPECT_SYN : " + e);
			}
		}
		return addressSuspectSyn.replaceAll("\\r\\n|\\r|\\n", StringUtils.SPACE).trim();
	}

	/**
	 * Get VILLE
	 * 
	 * @param strInput
	 * @return city
	 */
	public String getCity(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("CITY:") + ParseHitsConstant.FIVE;
				return strInput
						.substring(markerIndex, strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR, markerIndex))
						.trim();
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing VILLE : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get VILLE_SYN
	 * 
	 * @param strInput
	 * @return VILLE_SYN
	 */
	public String getCitySyn(String strInput) {
		String citySyn = StringUtils.EMPTY;
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("CITY:") + ParseHitsConstant.FIVE;
				final int synonymMarker = strInput.indexOf("Synonyms:", markerIndex) + ParseHitsConstant.NINE;
				citySyn = strInput.substring(synonymMarker,
						strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "COUNTRY:"));
				if (citySyn.startsWith(" " + ParseHitsConstant.UNIX_LINE_SEPARATOR)) {
					citySyn = citySyn.replaceFirst(ParseHitsConstant.UNIX_LINE_SEPARATOR, StringUtils.EMPTY);
				}
				if (StringUtils.isNotBlank(citySyn) && citySyn.contains(("none"))) {
					citySyn = StringUtils.EMPTY;
				}
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing VILLE_SYN : " + e);
			}
		}
		return citySyn.replaceAll("\\r\\n|\\r|\\n", StringUtils.SPACE).trim();
	}

	/**
	 * Get PAYS
	 * 
	 * @param strInput
	 * @return country
	 */
	public String getCountry(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("COUNTRY:") + ParseHitsConstant.EIGHT;
				return strInput.substring(markerIndex, strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR, markerIndex))
					.trim();
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing PAYS : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get PAYS_SYN
	 * 
	 * @param strInput
	 * @return countrySyn
	 */
	public String getCountrySyn(String strInput) {
		String countrySyn = StringUtils.EMPTY;
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("COUNTRY:") + ParseHitsConstant.EIGHT;
				final int synonymMarker = strInput.indexOf("Synonyms:", markerIndex) + ParseHitsConstant.NINE;
				countrySyn = strInput.substring(synonymMarker,
						strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "STATE:"));
				if (countrySyn.startsWith(" " + ParseHitsConstant.UNIX_LINE_SEPARATOR)) {
					countrySyn = countrySyn.replaceFirst(ParseHitsConstant.UNIX_LINE_SEPARATOR, StringUtils.EMPTY);
				}
				if (StringUtils.isNotBlank(countrySyn) && countrySyn.contains(("none"))) {
					countrySyn = StringUtils.EMPTY;
				}
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing PAYS_SYN : " + e);
			}
		}
		return countrySyn.replaceAll("\\r\\n|\\r|\\n", StringUtils.SPACE).trim();
	}

	/**
	 * Get ETAT
	 * 
	 * @param strInput
	 * @return State
	 */
	public String getState(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("STATE:") + ParseHitsConstant.SIX;
				return strInput.substring(markerIndex, strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR, markerIndex))
					.trim();
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing ETAT : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get ETAT_SYN
	 * 
	 * @param strInput
	 * @return ETAT_SYN
	 */
	public String getStateSyn(String strInput) {
		String stateSyn = StringUtils.EMPTY;
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("STATE:") + ParseHitsConstant.SIX;
				final int synonymMarker = strInput.indexOf("Synonyms:", markerIndex) + ParseHitsConstant.NINE;
				stateSyn = strInput.substring(synonymMarker,
						strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "ORIGIN:"));
				if (stateSyn.startsWith(" " + ParseHitsConstant.UNIX_LINE_SEPARATOR)) {
					stateSyn = stateSyn.replaceFirst(ParseHitsConstant.UNIX_LINE_SEPARATOR, StringUtils.EMPTY);
				}
				if (StringUtils.isNotBlank(stateSyn) && stateSyn.contains(("none"))) {
					stateSyn = StringUtils.EMPTY;
				}
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing ETAT_SYN : " + e);
			}
		}
		return stateSyn.replaceAll("\\r\\n|\\r|\\n", StringUtils.SPACE).trim();
	}

	/**
	 * Get PASSEPORT
	 * 
	 * @param strInput
	 * @return passportNumber
	 */
	public String getPasseport(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("PASSPORT: " + ParseHitsConstant.UNIX_LINE_SEPARATOR)
						+ ParseHitsConstant.ELEVEN;
				final String passportNumber = strInput.substring(markerIndex,
						strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "BIC CODES:"));
				if (!passportNumber.contains("none")) {
					return passportNumber.trim();
				}
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing PASSEPORT : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get BIC_SUSPECT
	 * 
	 * @param strInput
	 * @return BIC_SUSPECT
	 */
	public String getBicSuspect(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("BIC CODES: " + ParseHitsConstant.UNIX_LINE_SEPARATOR)
						+ ParseHitsConstant.TWELVE;
				final String bic = strInput.substring(markerIndex,
						strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "NATID:"));
				if (!bic.contains("none")) {
					return bic.trim();
				}
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing BIC_SUSPECT : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get NATID
	 * 
	 * @param strInput
	 * @return natid
	 */
	public String getNatid(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("NATID: " + ParseHitsConstant.UNIX_LINE_SEPARATOR)
						+ ParseHitsConstant.EIGHT;
				final String natid = strInput.substring(markerIndex,
						strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "PLACE OF BIRTH:"));
				if (!natid.contains("none")) {
					return natid.trim();
				}
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing NATID : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get PLACE_OF_BIRTH
	 * 
	 * @param strInput
	 * @return placeOfBirth
	 */
	public String getPlaceOfBirth(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("PLACE OF BIRTH: " + ParseHitsConstant.UNIX_LINE_SEPARATOR)
						+ ParseHitsConstant.SEVENTEEN;
				final String placeOfBirth = strInput.substring(markerIndex,
						strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "DATE OF BIRTH:"));
				if (!placeOfBirth.contains("none")) {
					return placeOfBirth.trim();
				}
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing PLACE_OF_BIRTH : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get DATE_NAISSANCE
	 * 
	 * @param strInput
	 * @return dateOfBirth
	 */
	public String getDateOfBirth(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("DATE OF BIRTH: " + ParseHitsConstant.UNIX_LINE_SEPARATOR)
						+ ParseHitsConstant.SIXTEEN;
				int endIndex = strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "NATIONALITY:") > 0
						? strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "NATIONALITY:")
						: strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "ADDITIONAL INFOS:");
				final String dateOfBirth = strInput.substring(markerIndex, endIndex);
				if (!dateOfBirth.contains("none")) {
					return dateOfBirth.trim();
				}
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing DATE_NAISSANCE : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get NATIONALITY
	 * 
	 * @param strInput
	 * @return NATIONALITY
	 */
	public String getNationality(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("NATIONALITY: " + ParseHitsConstant.UNIX_LINE_SEPARATOR)
						+ ParseHitsConstant.FOURTEEN;
				final String nationality = strInput.substring(markerIndex,
						strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "ADDITIONAL INFOS:"));
				if (!nationality.contains("none")) {
					return nationality.trim();
				}
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing NATIONALITY : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get ORIGINE_LISTE
	 * 
	 * @param strInput
	 * @return originList
	 */
	public String getOriginList(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("ORIGIN: " + ParseHitsConstant.UNIX_LINE_SEPARATOR)
						+ ParseHitsConstant.NINE;
				final String originList = strInput.substring(markerIndex,
						strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "DESIGNATION:"));
				if (!originList.contains("none")) {
					return originList.trim();
				}
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing ORIGINE_LISTE : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get DESIGNATION
	 * 
	 * @param strInput
	 * @return designation
	 */
	public String getDesignation(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("DESIGNATION: " + ParseHitsConstant.UNIX_LINE_SEPARATOR)
						+ ParseHitsConstant.FOURTEEN;
				final String designation = strInput.substring(markerIndex,
						strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "TYPE:"));
				if (!designation.contains("none")) {
					return designation.trim();
				}
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing DESIGNATION : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get TYPE_LISTE
	 * 
	 * @param strInput
	 * @return typeListe
	 */
	public String getTypeListe(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("TYPE: " + ParseHitsConstant.UNIX_LINE_SEPARATOR)
						+ ParseHitsConstant.SEVEN;
				final String typeListe = strInput.substring(markerIndex,
						strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "SEARCH CODES:"));
				if (!typeListe.contains("none")) {
					return typeListe.trim();
				}
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing TYPE_LISTE : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get REF_LISTE
	 * 
	 * @param strInput
	 * @return refListe
	 */
	public String getRefListe(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("OFFICIAL REF: " + ParseHitsConstant.UNIX_LINE_SEPARATOR)
						+ ParseHitsConstant.FIFTEEN;
				final String refListe = strInput.substring(markerIndex,
						strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "PASSPORT:"));
				if (!refListe.contains("none")) {
					return refListe.trim();
				}
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing REF_LISTE : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get INFOS
	 * 
	 * @param strInput
	 * @return infos
	 */
	public String getInfos(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("ADDITIONAL INFOS: " + ParseHitsConstant.UNIX_LINE_SEPARATOR)
						+ ParseHitsConstant.NINETEEN;
				final String infos = strInput.substring(markerIndex,
						strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "FML TYPE:"));
				if (!infos.contains("none")) {
					return infos.trim();
				}
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing INFOS : " + e);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Get LIEN
	 * 
	 * @param strInput
	 * @return lien
	 */
	public String getLien(String strInput) {
		if (StringUtils.isNotBlank(strInput)) {
			try {
				final int markerIndex = strInput.indexOf("HYPERLINKS: " + ParseHitsConstant.UNIX_LINE_SEPARATOR)
						+ ParseHitsConstant.THIRTEEN;
				final String lien = strInput.substring(markerIndex,
						strInput.indexOf(ParseHitsConstant.UNIX_LINE_SEPARATOR + "TYS:"));
				if (!lien.contains("none")) {
					return lien.trim();
				}
			} catch (Exception e) {
				Logger.getRootLogger().error("Error while parsing LIEN : " + e);
			}
		}
		return StringUtils.EMPTY;
	}
}
