package fr.bdf.spark.embgo.hits.constant;

import java.io.IOException;
import java.io.Serializable;

import fr.bdf.embgo.common.EmbgoCommonResource;

public class ParseHitsConstant extends EmbgoCommonResource implements
		Serializable {

	private static final long serialVersionUID = -3008049358544585620L;

	/** Hits separator in clob */
	public static final String HITS_SEPARATOR = "=============================";

	/** Windows EOL */
	public static final String WINDOWS_LINE_SEPARATOR = "\r\n";

	/** UNIX EOL */
	public static final String UNIX_LINE_SEPARATOR = "\n";

	/** Constant for 5 */
	public static final int FIVE = 5;

	/** Constant for 7 */
	public static final int SIX = 6;

	/** Constant for 7 */
	public static final int SEVEN = 7;

	/** Constant for 9 */
	public static final int EIGHT = 8;

	/** Constant for 9 */
	public static final int NINE = 9;

	/** Constant for 9 */
	public static final int TEN = 10;

	/** Constant for 18 */
	public static final int ELEVEN = 11;

	/** Constant for 18 */
	public static final int TWELVE = 12;

	/** Constant for 18 */
	public static final int THIRTEEN = 13;

	/** Constant for 18 */
	public static final int FOURTEEN = 14;

	/** Constant for 18 */
	public static final int FIFTEEN = 15;

	/** Constant for 18 */
	public static final int SIXTEEN = 16;

	/** Constant for 18 */
	public static final int SEVENTEEN = 17;

	/** Constant for 18 */
	public static final int EIGHTEEN = 18;

	/** Constant for 18 */
	public static final int NINETEEN = 19;

	/** Constant for 18 */
	public static final int TWENTY = 20;

	public ParseHitsConstant() throws IOException {
		super();
	}

}
