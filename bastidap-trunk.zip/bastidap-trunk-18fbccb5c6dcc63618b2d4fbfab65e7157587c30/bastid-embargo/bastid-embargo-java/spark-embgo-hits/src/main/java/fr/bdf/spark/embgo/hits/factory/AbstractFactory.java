package fr.bdf.spark.embgo.hits.factory;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;


public abstract class AbstractFactory {

	
	
    protected String getString (Object obj) {
        if (obj==null)  {
            return null;
        }
        else {  
            return obj.toString();
        }
    }
    
    
    protected Integer getInteger(Object obj) {
        if (obj==null)  {
            return null;
        }
        else {  
            return Integer.parseInt(obj.toString());
        }
    }
    
    protected Double getDouble(Object obj) {
        if (obj==null)  {
            return null;
        }
        else {  
            return Double.parseDouble(obj.toString());
        }
    }
    
    protected Float getFloat(Object obj) {
        if (obj==null)  {
            return null;
        }
        else {  
        	return Float.parseFloat(obj.toString());
        }
    }
    
    protected BigDecimal getBigDecimal(Object obj, int precision) {
        if (obj==null)  {
            return null;
        }
        else {  
        	BigInteger bigInt = new BigInteger(obj.toString());
            return new BigDecimal(bigInt, precision);
        }
    }
    
	protected java.util.Date getDateTime(Object obj) {
        if (obj==null)  {
            return null;
        }
        else {  
            try {
                return new SimpleDateFormat("yyyy/dd/MM HH:mm:ss").parse(obj.toString());
            } catch (ParseException e) {
                e.printStackTrace();
                return null;
            }
        }
    }
    
    protected java.sql.Date getDateSql(Object obj) {
        if (obj==null)  {
            return null;
        }
        else {  
            try {
            	java.sql.Date dateSql = null;
                final java.util.Date dateUtil = new SimpleDateFormat("yyyy-MM-dd").parse(obj.toString());
                if(dateUtil != null) {
                	dateSql = new Date(dateUtil.getTime()); 
                }
                return dateSql;
            } catch (ParseException e) {
                e.printStackTrace();
                return null;
            }
        }
    }
    
    protected java.sql.Timestamp getTimestamp(Object obj) {
        if (obj==null)  {
            return null;
        }
        else {  
            try {
            	java.sql.Timestamp timestamp = null;
                final java.util.Date dateUtil = new SimpleDateFormat("yyyy/dd/MM HH:mm:ss").parse(obj.toString());
                if(dateUtil != null) {
                	timestamp = new java.sql.Timestamp(dateUtil.getTime());
                			new Date(dateUtil.getTime()); 
                }
                return timestamp;
            } catch (ParseException e) {
                e.printStackTrace();
                return null;
            }
        }
    }
    
    

}
