#!/usr/bin/python
import inspect,os,sys

# necessite la librairie props.jar au meme emplacement que ce script
sys.path.append(os.path.dirname(os.path.realpath(sys.argv[0]))+"/props.jar")
from java import util
from java.util import HashSet,Properties,Collections,Enumeration,Vector
from java.io import FileReader,FileWriter
from org.bdf.deployit import SortedProperties


modified = 0


def loadProps(propertiesFile):
  props = SortedProperties()
  reader = FileReader(propertiesFile)
  try:
    props.load(reader)
  except:
    print "ERREUR: Lecture du fichier de fichier de proprietes %s impossible" % (propertiesFile)
  finally:
    reader.close()
  return props


def importIntoDict(propertiesFile, dicoId):
  # flag indiquant que des modifs sont presentes entre le dico et le properties
  global modified
  
  try:
     # lire le dictionnaire existant
     dict = repository.read(dicoId)
  except:
     print "ERREUR: Dictionnaire '%s' inconnu. Verifier que l'identifiant de l'objet 'Environments/%s' existe dans le depot" % (dicoId, dicoId)
     modified="ERREUR"
     return
	
  # lire le fichier properties
  props = loadProps(propertiesFile)
  if not props:
    print "ERREUR: Aucune propriété chargée"
    modified="ERREUR"
    return

  existingKeys = HashSet(dict.entries.keySet())
  for prop in props.entrySet():
    key = prop.key
    print " ajouter/modifier key = %s ?" % (key)
    if key in existingKeys:
      if dict.entries[key] != prop.value:
        dict.entries[key] = prop.value
        modified += 1
        print "   Mise a jour de %s : '%s' => '%s'" % (key,dict.entries[key],prop.value)
      else:
        print "   Pas de modif de %s, la valeur est correcte" % (key)
    else:
      dict.entries[key] = prop.value
      modified += 1
      print "    Clef %s ajoutee" % (key)

  for key in existingKeys:
     print " supprimer key = %s ?" % (key)
     if key not in props.keySet():
        dict.entries.remove(key)
        modified += 1
        print "   Clef %s supprimee" % (key)
     else:
        print "   Non, la clef existe dans le fichier properties"
  return dict


def usage():
  print "Usage: cli -f "+sys.argv[0]+" -- APPLI/ENV/NOM_DICO fichier_properties_dico "
  print "    avec APPLI/ENV/NOM_DICO le chemin et le nom du dictionnaire."
  print "    exemples :"
  print "             ABIL/DEV/DICT_DEV_ABIL  ; MMSR/DEV2/DICT_DEV2_MMSR_EBIGA1 "
  print "             GOLFI/SIAM/INT/INT_GOLFI_DICT ; PRISME7/SUPTEC/PROD/DICT_P7CAS_PRISME7"
  print "  NB : pour les dictionnaire udm.Dictionary, ne pas utiliser la partie 'encryptedEntries'."
  print "       Si vous avez besoin de stocker des mots de passes sous forme crypte, utilisez un dictionnaire du type udm.EncryptedDictionary"
  sys.exit(1)






now = util.Calendar.getInstance()
print
print "Start at ", now.getTime()
print

# recuperer les parametres du script
arg = len(sys.argv)
if arg == 3:
   # nom et chemin du dico dans xldeploy
   #  exemples : 
   #   ABIL/DEV/DICT_DEV_ABIL
   #   MMSR/DEV2/DICT_DEV2_MMSR_EBIGA1
   #   GOLFI/SIAM/INT/INT_GOLFI_DICT
   #   PRISME7/SUPTEC/PROD/DICT_P7CAS_PRISME7
   dicoName = sys.argv[1]
   
   # fichier contenant les donnes du dictionnaire avec son chemin
   # format "properties" :
   #     cle=valeur
   #   commentaires possibles via #
   dicoFileName = sys.argv[2]
else:
   usage()

   
   
# rajouter "Environnements" dans le chemin du dico pour correspondre au json
dicoId = 'Environments/'+dicoName

# lancer l'import du dico
dict  = importIntoDict(dicoFileName, dicoId)
print
if modified > 0:
  # commit des modifs
  repository.update(dict)
  print "Felicitation!! le dictionnnaire %s a ete importe." % (dicoName)
  print "Nombre de clefs ajoutes, modifies et/ou supprimes : %s" % (modified)
elif modified == 0:
  print "Le dictionnnaire %s est identique, aucune modif applique" % (dicoName)
else:
  # cas d'erreur
  now = util.Calendar.getInstance()
  print "Done at ", now.getTime()
  sys.exit(1)

print
now = util.Calendar.getInstance()
print "Done at ", now.getTime()
print