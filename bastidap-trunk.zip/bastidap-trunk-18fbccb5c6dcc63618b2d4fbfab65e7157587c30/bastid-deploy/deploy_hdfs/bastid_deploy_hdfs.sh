#!/usr/bin/env bash
###############################################################################
# Description :     Script de copie des livrables du projet bastid-common sur HDFS
# Usage :           Pas de paramètre
# Author :          FLAF - I2108GB
# Updated :         26/01/2018
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec            #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  


#######################################
# Description:  Purge de la partie HDFS pour le projet bastid-common
# Arguments:   
# Returns:      
#######################################
PURGE_HDFS () {

    LOG_INFO "Purge du r�pertoire /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common"
    hdfs dfs -rm -r -f /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common
    
    LOG_INFO "Purge du r�pertoire /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/embargo"
    hdfs dfs -rm -r -f /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/embargo

}

#######################################
# Description:  Creation arborescence HDFS pour le projet bastid-common
# Arguments:   
# Returns:      
#######################################
CREATE_TREE () {

    LOG_INFO "Creation arborescence /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common"
    hdfs dfs -mkdir /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common
    hdfs dfs -mkdir /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common/conf
    hdfs dfs -mkdir  /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common/lib
    hdfs dfs -mkdir /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common/script
    
    LOG_INFO "Creation arborescence /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/embargo"
    hdfs dfs -mkdir /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/embargo
    hdfs dfs -mkdir /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/embargo/traitement
    hdfs dfs -mkdir /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/embargo/traitement/conf
    hdfs dfs -mkdir /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/embargo/traitement/jar
    hdfs dfs -mkdir /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/embargo/traitement/load
    hdfs dfs -mkdir /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/embargo/traitement/load/hql
    hdfs dfs -mkdir /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/embargo/traitement/load/shell
}

#######################################
# Description:  Copie des livrables sur HDFS pour le projet bastid-common
# Arguments:   
# Returns:      
#######################################
COPY_TO_HDFS () {

    LOG_INFO "Copie des livrables .fonction et .param "
    hdfs dfs -put -f /home/{{APP_USER}}/{{REP_APPLI}}/connexion/.fonction_bastid_oozie /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common/
	hdfs dfs -put -f /home/{{APP_USER}}/{{REP_APPLI}}/connexion/.fonction_bastid_spec /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common/
	hdfs dfs -put -f /home/{{APP_USER}}/{{REP_APPLI}}/connexion/.param_bastid_mdp /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common/
	hdfs dfs -put -f /home/{{APP_USER}}/{{REP_APPLI}}/connexion/.param_bastid_spec /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common/
	
	LOG_INFO "Copie des livrables .sh"
	hdfs dfs -put -f /home/{{APP_USER}}/{{REP_APPLI}}/bdf/common/suivi/shell/constr_date_trt.sh /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common/script/
	hdfs dfs -put -f /home/{{APP_USER}}/{{REP_APPLI}}/bdf/common/suivi/shell/constr_interval_date.sh /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common/script/
	hdfs dfs -put -f /home/{{APP_USER}}/{{REP_APPLI}}/bdf/common/suivi/shell/copy_to_optimized_layer.sh /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common/script/
	hdfs dfs -put -f /home/{{APP_USER}}/{{REP_APPLI}}/bdf/common/suivi/shell/init_statut.sh /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common/script/
	hdfs dfs -put -f /home/{{APP_USER}}/{{REP_APPLI}}/bdf/common/suivi/shell/lecteur_statut.sh /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common/script/
	hdfs dfs -put -f /home/{{APP_USER}}/{{REP_APPLI}}/bdf/common/suivi/shell/remove_flag.sh /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common/script/
	hdfs dfs -put -f /home/{{APP_USER}}/{{REP_APPLI}}/bdf/common/suivi/shell/upd_ko.sh /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common/script/
	hdfs dfs -put -f /home/{{APP_USER}}/{{REP_APPLI}}/bdf/common/suivi/shell/update_tot.sh /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common/script/
	hdfs dfs -put -f /home/{{APP_USER}}/{{REP_APPLI}}/bdf/common/suivi/shell/valid.sh /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common/script/
	
	LOG_INFO "Copie des livrables pour /conf"
    hdfs dfs -put -f /home/{{APP_USER}}/{{REP_APPLI}}/bdf/embargo/traitement/conf/dependances.conf /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/embargo/traitement/conf
	hdfs dfs -put -f /home/{{APP_USER}}/{{REP_APPLI}}/bdf/embargo/traitement/conf/param_batch.conf /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/embargo/traitement/conf
	
	LOG_INFO "Copie des livrables pour /jar"
	hdfs dfs -put -f /home/{{APP_USER}}/{{REP_APPLI}}/bdf/embargo/traitement/jar/* /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/embargo/traitement/jar/
	
	LOG_INFO "Copie des livrables .sh pour embargo"
	hdfs dfs -put -f /home/{{APP_USER}}/{{REP_APPLI}}/bdf/embargo/traitement/load/shell/* /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/embargo/traitement/load/shell
	
	LOG_INFO "Copie des livrables .hql pour embargo"
	hdfs dfs -put -f /home/{{APP_USER}}/{{REP_APPLI}}/bdf/embargo/traitement/load/hql/* /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/embargo/traitement/load/hql

	LOG_INFO "Copie du keytab kerberos sur HDFS"
	hdfs dfs -put -f {{KERBEROS_KEYTAB}} /data/projet/{{HDFS_PROJECT_DIR}}/{{OOZIE_DIR}}/common/lib/

}



#######################################
# Description:  Fonction principale, appelée dans le corps du script
# Arguments:    Pas d'argument
# Returns:      
#######################################
main () {

  START
  SETUP
  
  PURGE_HDFS
  
  CREATE_TREE
  
  COPY_TO_HDFS

  END
  exit ${__SUCCESS}
  
}

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
