#!/usr/bin/env bash
###############################################################################
# Description :     Simulation de l'ordonnancement de la chaîne de traitement Embargo
# Usage :           Pas de paramètre
#                   Les variables do_* (yes/no) permettent d'activer ou non chaque module
# Author :         
# Updated :         
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec            #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  


REP_CONF="$ATE_TRT_CONF_PATH"
READ_BATCH_PARAM "${REP_CONF}/${PARAM_BATCH}" "APPLI" "VAR_APPLI"
READ_BATCH_PARAM "${REP_CONF}/${PARAM_BATCH}" "PHASE" "VAR_PHASE"

# Définition du mode : $MODE_ALIM_INTERVAL (dev et rec)
#                   ou $MODE_ALIM_LIST_DATE (dev et rec)
#                   ou $MODE_ALIM_QUOTI (tout env)
MODE="$MODE_ALIM_QUOTI"

# Paramètres pour le mode $MODE_ALIM_INTERVAL
# Pour l'acquisition d'une seule date_ope, INTERVAL_DEBUT = INTERVAL_FIN = date_ope
INTERVAL_DEBUT="2018-01-05"
INTERVAL_FIN="2018-01-05"

# Paramètres pour le mode $MODE_ALIM_LIST_DATE (à séparer par des espaces)
LIST_DATE="2017-01-01 2017-01-05 2017-01-10"


# le premier niveau de paramétrage (do_action, etc.) active ou désactive le traitement entier
# le deuxième niveau de paramétrage (do_upd_ko_action, etc.) permet de désactiver des éléments du traitement

do_raw_to_opt="yes"
    do_upd_ko_raw_to_opt="yes"
    do_init_raw_to_opt="yes"
    do_construct_cat_raw_to_opt="yes"
    do_lecture_statut_dep_raw_to_opt="yes"
    do_load_raw_to_opt="yes"
    do_valid_raw_to_opt="yes"
    
#######################################
# Description:  Série de fonctions appelant les shells avec les bons paramètres
# Arguments:    Pas d'argument
# Returns:      
#######################################

UPD_KO () {

    LOG_INFO "Mise à jour des statuts En cours à KO pour $1"
    $REPBDF/common/suivi/shell/upd_ko.sh "${REP_CONF}" "$1"
}

INIT_STATUT () {

    LOG_INFO "Initialisation du chargement de $1"
    $REPBDF/common/suivi/shell/init_statut.sh "${REP_CONF}" "$1"
}

CONSTRUCT_DATE_TRT () {

    LOG_INFO "Vérification des statuts Acquisition pour déclenchement du Traitement de $1"
    $REPBDF/common/suivi/shell/constr_date_trt.sh "${REP_CONF}" "$1"
}

CONSTR_INTERVAL_DATE () {

    LOG_INFO "Alimentation du catalogue en mode ${MODE} pour $1"
    $REPBDF/common/suivi/shell/constr_interval_date.sh "${REP_CONF}" "$1" "${INTERVAL_DEBUT}" "${INTERVAL_FIN}"
}

CONSTR_LIST_DATE () {

    LOG_INFO "Alimentation du catalogue en mode ${MODE} pour $1"
    $REPBDF/common/suivi/shell/constr_list_date.sh "${REP_CONF}" "$1" "${LIST_DATE}"
}

LECTEUR_STATUT () {

    LOG_INFO "Vérification des statuts Acquisition pour déclenchement du Traitement de $1"
    $REPBDF/common/suivi/shell/lecteur_statut.sh "${REP_CONF}" "$1"
}


LOAD_RAW_TO_OPT () {

    LOG_INFO "Copie des tables sans traitement de la Raw vers l'Optimized"
    $REPBDF/atena/traitement/load/shell/copy_raw_to_optimized_layer.sh
}


VALID () {

    LOG_INFO "Validation du chargement de $1"
    $REPBDF/common/suivi/shell/valid.sh "${REP_CONF}" "$1"
}


#######################################
# Description:  Fonction principale, appelée dans le corps du script
# Arguments:    Pas d'argument
# Returns:      
#######################################
main () {

  START
  SETUP
    
    if [[ ( $MODE == "$MODE_ALIM_INTERVAL" || $MODE == "$MODE_ALIM_LIST_DATE" ) && ( $ENVAPPLI == 'INT' || $ENVAPPLI == 'PRD' ) ]]
    then
        LOG_ERROR "Mode ${MODE}  non autorisé en INT ou PROD"
        exit $__FAILURE
    fi
    
    case $MODE in
        "${MODE_ALIM_QUOTI}") CONSTR_DATE_OPE='CONSTRUCT_DATE_TRT' ;;
        "${MODE_ALIM_INTERVAL}") CONSTR_DATE_OPE='CONSTR_INTERVAL_DATE' ;;
        "${MODE_ALIM_LIST_DATE}") CONSTR_DATE_OPE='CONSTR_LIST_DATE' ;;
    esac
    
    

    # ***********************************************************************************************************
    if [[ ${do_raw_to_opt} == "yes" ]]
    then
        # Update à KO des En cours
        if [[ ${do_upd_ko_raw_to_opt} == "yes" ]] ; then UPD_KO "COPIE_RAW_OPT"; fi
        
        # Insertion du statut EN COURS
        if [[ ${do_init_raw_to_opt} == "yes" ]] ; then INIT_STATUT "COPIE_RAW_OPT"; fi
        
        # Construction du catalogue
        if [[ ${do_construct_cat_raw_to_opt} == "yes" ]] ; then eval $CONSTR_DATE_OPE "COPIE_RAW_OPT"; fi
        
        # Lecture des statuts d'acquisition des dépendances de la table HIT
        if [[ ${do_lecture_statut_dep_raw_to_opt} == "yes" ]] ; then LECTEUR_STATUT "COPIE_RAW_OPT"; fi
        
        # Chargement de la table  CODE_PAYS
        if [[ ${do_load_raw_to_opt} == "yes" ]] ; then LOAD_RAW_TO_OPT; fi
                
        # Validation du chargement dans les tables Statut et Catalogue Traitement pour la copie Raw vers Optimized
        if [[ ${do_valid_raw_to_opt} == "yes" ]] ; then VALID "COPIE_RAW_OPT"; fi
    fi
    # ***********************************************************************************************************
    
  END
  exit ${__SUCCESS}
  
}

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
