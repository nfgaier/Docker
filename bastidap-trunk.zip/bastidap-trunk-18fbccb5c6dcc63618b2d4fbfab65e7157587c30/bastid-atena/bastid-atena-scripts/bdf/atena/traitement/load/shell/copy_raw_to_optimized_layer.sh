#!/usr/bin/env bash
###############################################################################
# Description :     Valide le chargement d'un bloc de traitement ind�pendant
# Usage : 
# Parameters :      $1 Nom du bloc de traitement ind�pendant � valider
# Author :         
# Updated :         17
###############################################################################

set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables 
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec            #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name 
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code 
readonly __FAILURE=1                                           #failure exit code 

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec 
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec 
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec  

HQL_PATH="${REPBDF}/atena/traitement/load/hql/"
SCRIPT_NAME="copy_raw_to_optimized_layer.hql"
NOM_TRAITEMENT='COPIE_RAW_OPT'
FIC_TMP="${ATE_TRT_CONF_PATH}/id_${NOM_TRAITEMENT}.tmp"

#######################################
# Description: Lecture des ID_TRAITEMENT de la phase d'acquisition � recopier dans l'optimized layer
# Arguments: 
# Returns: 
#######################################
get_id_acq(){
	
    LOG_INFO "============================================================================"
    LOG_INFO "Lecture des ID_TRAITEMENT de la phase acquisition � charger dans l'optimized"
    LOG_INFO "============================================================================"
    LOG_INFO ""
    
    if [[ ! -f $FIC_TMP ]] ; then  
        LOG_ERROR "File $FIC_TMP not found."
        exit ${__FAILURE}
    else 
        LOG_INFO "File $FIC_TMP found" 
        LOG_INFO "Reading $FIC_TMP ..."
    fi
    
    LOG_INFO ""
    GET_CSV_FIELD_BY_INDEX "$FIC_TMP" "," "NOMENCLATURES_PAYS" "2" "ID_ACQ_CODE_PAYS"
    LOG_INFO ""
    LOG_INFO ""
    
    
    
    
    if [[ -z ${ID_ACQ_CODE_PAYS} ]]
	then  
             LOG_ERROR "L' ID_TRAITEMENT de l'acquisition n'a pas ete trouv� dans ${FIC_TMP}."
        exit ${__FAILURE}
    fi
  
}

#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
run() {
	
	hive    --hiveconf tez.queue.name=${EXP_QUEUE} \
            --hiveconf id_acq_code_pays=${ID_ACQ_CODE_PAYS} \
            --hiveconf id_traitement=${ID_TRAITEMENT} \
        -f ${HQL_PATH}${SCRIPT_NAME}

}

#######################################
# Description: 
# Arguments: 
# Returns: 
#######################################
main () {

  START
  SETUP
  
  GET_ID_TRT "$ATE_APPLI_NAME" "$PHASE_TRAITEMENT" "$NOM_TRAITEMENT" 'ID_TRAITEMENT'
  get_id_acq
  
  run
    
  END  
  exit ${__SUCCESS}
  
}

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
