
#!/usr/bin/env bash
set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
#set -o nounset    # Exits when script tries to use undeclared variables
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec 

if [[ -z $LOGDIR ]]
then
LOGDIR=$LST
fi

if [[ -z $LOGFILE ]]
then
LOGFILE=$(basename "${BASH_SOURCE[0]}" | cut -f 1 -d '.')_$(date +"%Y%m%d_%H%M%S_%N").log
fi

#Variables 
START_DATE=`date +%Y%m%d_%H%M%S`; echo "START_DATE=$START_DATE" 
TABLE_NAME=CTCOMMERCE_ENTITEPRINCIPALEBDF ; echo "TABLE_NAME=$TABLE_NAME"
declare -a __LIST_DATE_OPE=('')
echo "TABLE_NAME : ${TABLE_NAME}"
echo ""



echo "Sélection de l'ID_TRAITEMENT en cours et des timestamp pour construction de la clause where des sqoop en DELTA"

RES=$(PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -t -A -F',' -c \
"select max(id_job), min(borne_min), max(borne_max) from ${TOT} \
 where projet = '$PROJET' \
   and application = 'ATENA' \
   and type_suivi = '$TYPE_SUIVI_SUIVI' \
   and niveau_suivi = '$NIVEAU_SUIVI_CATALOGUE' \
   and phase = '$PHASE_ACQUISITION' \
   and status = '$ST_ENCOURS' \
   and nom_table = 'CTCOMMERCE_ENTITEPRINCIPALEBDF'")

ID_TRAITEMENT=$(echo "$RES" | cut -f1 -d',')
TIMESTAMP_MIN=$(echo "$RES" | cut -f2 -d',')
TIMESTAMP_MAX=$(echo "$RES" | cut -f3 -d',')

if [[ -z $ID_TRAITEMENT ]]
then
LOG_ERROR "Variable ID_TRAITEMENT non positionnée"
exit 1
fi

echo "ID_TRAITEMENT : $ID_TRAITEMENT"
echo "TIMESTAMP_MIN : $TIMESTAMP_MIN"
echo "TIMESTAMP_MAX : $TIMESTAMP_MAX"

DATE_INSERT=$(echo ${ID_TRAITEMENT} | cut -c1-4)"-"$(echo ${ID_TRAITEMENT} | cut -c5-6)"-"$(echo ${ID_TRAITEMENT} | cut -c7-8); echo "DATE_INSERT=$DATE_INSERT" 
DATE_INSERT=$(date -d "${DATE_INSERT}" +'%Y-%m-%d'); echo "DATE_INSERT=$DATE_INSERT" 
echo "DATE_INSERT : ${DATE_INSERT}"

echo "Sélection des bornes MIN et MAX de chaque DATE_OPE pour construction du CASE WHEN dans le SQOOP Import"

PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -t -A -c \
"select distinct concat_ws('~', borne_min, borne_max, date_ope) from ${TOT} \
 where projet = '$PROJET' \
   and application = 'ATENA' \
   and type_suivi = '$TYPE_SUIVI_SUIVI' \
   and niveau_suivi = '$NIVEAU_SUIVI_CATALOGUE' \
   and phase = '$PHASE_ACQUISITION' \
   and status = '$ST_ENCOURS' \
   and nom_table = 'CTCOMMERCE_ENTITEPRINCIPALEBDF' \
 order by 1" \
> $LST/catalogue_acq_$(basename "${BASH_SOURCE[0]}" | cut -f 1 -d '.').txt

echo "Construction du CASE WHEN dans le SQOOP Import"

FIRST_BORNE_MIN="$(head -n 1 $LST/catalogue_acq_$(basename "${BASH_SOURCE[0]}" | cut -f 1 -d '.').txt |  cut -d"~" -f1)"
FIRST_DATE_OPE="$(head -n 1 $LST/catalogue_acq_$(basename "${BASH_SOURCE[0]}" | cut -f 1 -d '.').txt |  cut -d"~" -f3)"
NOM_COM="UPDATEDATE_"
COL_DATE_OPE="CASE WHEN "$NOM_COM" <  to_timestamp('"$FIRST_BORNE_MIN"', 'YYYY-MM-DD HH24:MI:SS.FF')  then '"$FIRST_DATE_OPE"'"
while read line  
do  
   BORNE_MIN=$(echo $line | cut -d"~" -f1)
   BORNE_MAX=$(echo $line | cut -d"~" -f2)
   VAL_DATE_OPE=$(echo $line | cut -d"~" -f3)
   __LIST_DATE_OPE=("${__LIST_DATE_OPE[@]}" "${VAL_DATE_OPE}")
   COL_DATE_OPE=$COL_DATE_OPE" WHEN "$NOM_COM" BETWEEN to_timestamp('"$BORNE_MIN"', 'YYYY-MM-DD HH24:MI:SS.FF')  and to_timestamp('"$BORNE_MAX"', 'YYYY-MM-DD HH24:MI:SS.FF') then '"$VAL_DATE_OPE"'"
done < $LST/catalogue_acq_$(basename "${BASH_SOURCE[0]}" | cut -f 1 -d '.').txt
COL_DATE_OPE=$COL_DATE_OPE" end as DATE_OPE"


echo "COL_DATE_OPE :"
echo "$COL_DATE_OPE"

# variable nombre de lignes SQOOP 
echo "Calcul du nombre de ligne côté SOURCE"

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom 
NB_LIGNES_SQOOP=$(echo $(sqoop eval -Dmapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom"  --connect "${ATE_ORA_CXN}" --username ${ATE_ORA_USER} --password ${ATE_ORA_PWD} --query "SELECT 'COUNT_START'||COUNT(*)||'COUNT_END' FROM CTCOMMERCE_ENTITEPRINCIPALEBDF WHERE 1=1 AND UPDATEDATE_ BETWEEN to_timestamp('$TIMESTAMP_MIN', 'YYYY-MM-DD HH24:MI:SS.FF6') AND to_timestamp('$TIMESTAMP_MAX', 'YYYY-MM-DD HH24:MI:SS.FF6')") |  sed 's/\(.*\)\(COUNT_START\)\([0-9]*\)\(COUNT_END\).*/\3/')
if [[ $NB_LIGNES_SQOOP == *"ACCUMULO_HOME"* ]]
then
NB_LIGNES_SQOOP=0
fi
echo "nb lignes sqoop : ${NB_LIGNES_SQOOP}" 
echo "Log du nombre de lignes sqoop"


PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -e -c " \
 insert into $TOT (id_job, type_suivi, projet, application, phase, nom_traitement, nom_table, type_table, nb_lignes, type_log, log) \
 values ('$ID_TRAITEMENT', '$TYPE_SUIVI_LOG', '$PROJET', 'ATENA', '$PHASE_ACQUISITION', '$(basename "${BASH_SOURCE[0]}")', '$TABLE_NAME', 'DELTA', '$NB_LIGNES_SQOOP', 'COUNT SIO', 'Nombre de ligne côté SIO pour cette acquisition')"
#Commande hive pour réinitialiser la table ctcommerce_entiteprincipalebdf de chargement
echo "Drop et recréation de la table cible "

hive -hiveconf tez.queue.name=$ACQ_QUEUE -hiveconf hive.cli.errors.ignore=true \
-e "

    DROP TABLE IF EXISTS atena_landing_layer.CTCOMMERCE_ENTITEPRINCIPALEBDF;

    CREATE TABLE IF NOT EXISTS atena_landing_layer.CTCOMMERCE_ENTITEPRINCIPALEBDF
    (
        \`UPDATORUSERID_\` STRING,
        \`LENDRIERSENSIBLE_CALENDARNAME_\` STRING,
        \`IDENTIFIANT_\` STRING,
        \`BIC_\` STRING,
        \`CALENDRIERTARGET_CALENDARNAME_\` STRING,
        \`DATECOMPTABLE_\` TIMESTAMP,
        \`PAYS_CODEPAYS_\` STRING,
        \`DEVISE_CODEDEVISE_\` STRING,
        \`CODEBANQUE_\` STRING,
        \`CREATORUSERID_\` STRING,
        \`CREATIONDATE_\` TIMESTAMP,
        \`NUMEROTELEPHONE_\` STRING,
        \`VERSION_\` DECIMAL(20,0),
        \`UPDATEDATE_\` TIMESTAMP,
        \`CALENDRIERATENA_CALENDARNAME_\` STRING,
        \`TYPE_\` STRING,
        \`BDF_IDENTIFIANT_\` DECIMAL(20,0),
        \`ADRESSE_\` STRING,
        DATE_OPE DATE,         DATE_INSERT DATE
    )
    PARTITIONED BY (ID_TRAITEMENT STRING)
    STORED AS ORC
    LOCATION '"$ATE_SRC_HDFS_LDL"ctcommerce_entiteprincipalebdf';

"

sqoop import -Dmapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" -Dmapred.job.queue.name=$ACQ_QUEUE --connect "${ATE_ORA_CXN}" --username ${ATE_ORA_USER} --password ${ATE_ORA_PWD} \
--query "SELECT "UPDATORUSERID_", "LENDRIERSENSIBLE_CALENDARNAME_", "IDENTIFIANT_", "BIC_", "CALENDRIERTARGET_CALENDARNAME_", "DATECOMPTABLE_", "PAYS_CODEPAYS_", "DEVISE_CODEDEVISE_", "CODEBANQUE_", "CREATORUSERID_", "CREATIONDATE_", "NUMEROTELEPHONE_", "VERSION_", "UPDATEDATE_", "CALENDRIERATENA_CALENDARNAME_", "TYPE_", "BDF_IDENTIFIANT_", "ADRESSE_", $COL_DATE_OPE, '${DATE_INSERT}' as DATE_INSERT, '${ID_TRAITEMENT}' as ID_TRAITEMENT 
         FROM CTCOMMERCE_ENTITEPRINCIPALEBDF
         WHERE 1=1
         AND UPDATEDATE_ BETWEEN to_timestamp('$TIMESTAMP_MIN', 'YYYY-MM-DD HH24:MI:SS.FF6') AND to_timestamp('$TIMESTAMP_MAX', 'YYYY-MM-DD HH24:MI:SS.FF6')
         AND \$CONDITIONS" \
--hcatalog-table CTCOMMERCE_ENTITEPRINCIPALEBDF \
--split-by IDENTIFIANT_ \
--hcatalog-database atena_landing_layer \
--hive-partition-key id_traitement \
--hive-partition-value ${ID_TRAITEMENT} \
--num-mappers 1 


#INITIALISATION END_DATE 
END_DATE=`date +%Y%m%d_%H%M%S` 

# Variable nb lignes HIVE 
NB_LIGNES_HIVE=$(hive --hiveconf tez.queue.name=$ACQ_QUEUE -S -e "SELECT count(*) from atena_landing_layer.CTCOMMERCE_ENTITEPRINCIPALEBDF") 


PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -c " \
 insert into $TOT (id_job, type_suivi, projet, application, phase, nom_traitement, nom_table, type_table, nb_lignes, type_log, log) \
 values ('$ID_TRAITEMENT', '$TYPE_SUIVI_LOG', '$PROJET', 'ATENA', '$PHASE_ACQUISITION', '$(basename "${BASH_SOURCE[0]}")', '$TABLE_NAME', 'DELTA', '$NB_LIGNES_HIVE', 'COUNT BASTID Landing Layer', 'Nombre de ligne côté BASTID Landing Layer pour cette acquisition')"
# Gestion du cas NB_LIGNES_SQOOP != NB_LIGNES_HIVE => ERREUR
echo "NB LIGNES HIVE = ${NB_LIGNES_HIVE}"
if [[ $NB_LIGNES_SQOOP != $NB_LIGNES_HIVE ]]
then 
    REQ="  update $TOT"
    REQ+=" set status = '${ST_ERROR}'"
    REQ+=" where"
    REQ+="     type_suivi = '${TYPE_SUIVI_SUIVI}'"
    REQ+="     and niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}'"
    REQ+="     and projet = '${PROJET}'"
    REQ+="     and application = 'ATENA'"
    REQ+="     and phase = '${PHASE_ACQUISITION}'"
    REQ+="     and nom_table = 'CTCOMMERCE_ENTITEPRINCIPALEBDF'"
    REQ+="     and status = '${ST_ENCOURS}'"
    PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" -e "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"
    exit 1
fi 

