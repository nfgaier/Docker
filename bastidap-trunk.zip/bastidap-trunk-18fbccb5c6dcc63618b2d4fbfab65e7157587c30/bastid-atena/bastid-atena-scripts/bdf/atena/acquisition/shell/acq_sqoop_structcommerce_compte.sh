
#!/usr/bin/env bash
set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
#set -o nounset    # Exits when script tries to use undeclared variables
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec 

if [[ -z $LOGDIR ]]
then
LOGDIR=$LST
fi

if [[ -z $LOGFILE ]]
then
LOGFILE=$(basename "${BASH_SOURCE[0]}" | cut -f 1 -d '.')_$(date +"%Y%m%d_%H%M%S_%N").log
fi

#Variables 
START_DATE=`date +%Y%m%d_%H%M%S`; echo "START_DATE=$START_DATE" 
TABLE_NAME=STRUCTCOMMERCE_COMPTE ; echo "TABLE_NAME=$TABLE_NAME"
declare -a __LIST_DATE_OPE=('')
echo "TABLE_NAME : ${TABLE_NAME}"
echo ""



echo "Sélection de l'ID_TRAITEMENT en cours et des timestamp pour construction de la clause where des sqoop en DELTA"

RES=$(PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -t -A -F',' -c \
"select max(id_job), min(borne_min), max(borne_max) from ${TOT} \
 where projet = '$PROJET' \
   and application = 'ATENA' \
   and type_suivi = '$TYPE_SUIVI_SUIVI' \
   and niveau_suivi = '$NIVEAU_SUIVI_CATALOGUE' \
   and phase = '$PHASE_ACQUISITION' \
   and status = '$ST_ENCOURS' \
   and nom_table = 'STRUCTCOMMERCE_COMPTE'")

ID_TRAITEMENT=$(echo "$RES" | cut -f1 -d',')
TIMESTAMP_MIN=$(echo "$RES" | cut -f2 -d',')
TIMESTAMP_MAX=$(echo "$RES" | cut -f3 -d',')

if [[ -z $ID_TRAITEMENT ]]
then
LOG_ERROR "Variable ID_TRAITEMENT non positionnée"
exit 1
fi

echo "ID_TRAITEMENT : $ID_TRAITEMENT"
echo "TIMESTAMP_MIN : $TIMESTAMP_MIN"
echo "TIMESTAMP_MAX : $TIMESTAMP_MAX"

DATE_INSERT=$(echo ${ID_TRAITEMENT} | cut -c1-4)"-"$(echo ${ID_TRAITEMENT} | cut -c5-6)"-"$(echo ${ID_TRAITEMENT} | cut -c7-8); echo "DATE_INSERT=$DATE_INSERT" 
DATE_INSERT=$(date -d "${DATE_INSERT}" +'%Y-%m-%d'); echo "DATE_INSERT=$DATE_INSERT" 
echo "DATE_INSERT : ${DATE_INSERT}"

echo "Sélection des bornes MIN et MAX de chaque DATE_OPE pour construction du CASE WHEN dans le SQOOP Import"

PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -t -A -c \
"select distinct concat_ws('~', borne_min, borne_max, date_ope) from ${TOT} \
 where projet = '$PROJET' \
   and application = 'ATENA' \
   and type_suivi = '$TYPE_SUIVI_SUIVI' \
   and niveau_suivi = '$NIVEAU_SUIVI_CATALOGUE' \
   and phase = '$PHASE_ACQUISITION' \
   and status = '$ST_ENCOURS' \
   and nom_table = 'STRUCTCOMMERCE_COMPTE' \
 order by 1" \
> $LST/catalogue_acq_$(basename "${BASH_SOURCE[0]}" | cut -f 1 -d '.').txt

echo "Construction du CASE WHEN dans le SQOOP Import"

COL_DATE_OPE="Null as DATE_OPE"


echo "COL_DATE_OPE :"
echo "$COL_DATE_OPE"

# variable nombre de lignes SQOOP 
echo "Calcul du nombre de ligne côté SOURCE"

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom 
NB_LIGNES_SQOOP=$(echo $(sqoop eval -Dmapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom"  --connect "${ATE_ORA_CXN}" --username ${ATE_ORA_USER} --password ${ATE_ORA_PWD} --query "SELECT 'COUNT_START'||COUNT(*)||'COUNT_END' FROM STRUCTCOMMERCE_COMPTE WHERE 1=1") |  sed 's/\(.*\)\(COUNT_START\)\([0-9]*\)\(COUNT_END\).*/\3/')
if [[ $NB_LIGNES_SQOOP == *"ACCUMULO_HOME"* ]]
then
NB_LIGNES_SQOOP=0
fi
echo "nb lignes sqoop : ${NB_LIGNES_SQOOP}" 
echo "Log du nombre de lignes sqoop"


PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -e -c " \
 insert into $TOT (id_job, type_suivi, projet, application, phase, nom_traitement, nom_table, type_table, nb_lignes, type_log, log) \
 values ('$ID_TRAITEMENT', '$TYPE_SUIVI_LOG', '$PROJET', 'ATENA', '$PHASE_ACQUISITION', '$(basename "${BASH_SOURCE[0]}")', '$TABLE_NAME', 'COMPLET', '$NB_LIGNES_SQOOP', 'COUNT SIO', 'Nombre de ligne côté SIO pour cette acquisition')"
#Commande hive pour réinitialiser la table structcommerce_compte de chargement
echo "Drop et recréation de la table cible "

hive -hiveconf tez.queue.name=$ACQ_QUEUE -hiveconf hive.cli.errors.ignore=true \
-e "

    DROP TABLE IF EXISTS atena_landing_layer.STRUCTCOMMERCE_COMPTE;

    CREATE TABLE IF NOT EXISTS atena_landing_layer.STRUCTCOMMERCE_COMPTE
    (
        \`CLIENT_IDENTIFIANT_\` DECIMAL(20,0),
        \`GESTLETTERAPPLI_\` INT,
        \`CODEDEREGROUPEMENT_\` STRING,
        \`CODIQUE_\` STRING,
        \`COMPTEREMUNERE_\` INT,
        \`NATURECOMPTE_CODENATURECOMPTE_\` DECIMAL(20,0),
        \`TRAITEMENTCOMPTEDORMANT_\` INT,
        \`TRAITEMENTFRAISPERIODIQUES_\` INT,
        \`COMPTESPECIALE_\` INT,
        \`OPERATIONNEL_\` INT,
        \`VICEREMUNERATION_APPREFERENCE_\` STRING,
        \`COMPTETITREASSOCIE_\` STRING,
        \`CONFIDENTIALITEDO_\` INT,
        \`DEACTIVATIONREASON_\` STRING,
        \`TRATREMUNERATION_APPREFERENCE_\` STRING,
        \`ISBLINDREKEYMODE_\` INT,
        \`TIONINDIVIDUELLE_APPREFERENCE_\` STRING,
        \`ISACTIVE_\` INT,
        \`ANQUETENEURDECOMPTE_STARTDATE_\` TIMESTAMP,
        \`SERVATIONDECOMPTE_IDENTIFIANT_\` STRING,
        \`ISUPDATED_\` INT,
        \`ISVALID_\` INT,
        \`ISCREATIONREJECTED_\` INT,
        \`ACTIONTOVALIDATE_\` STRING,
        \`DATEOUVERTURE_\` TIMESTAMP,
        \`COMPLEMENTINTITULELONG_\` STRING,
        \`DEVISE_CODEDEVISE_\` STRING,
        \`RIB_\` STRING,
        \`CREATIONDATE_\` TIMESTAMP,
        \`CTRLPROVISION_\` INT,
        \`UPDATEDATE_\` TIMESTAMP,
        \`SBALANCEDESPAIEMENTS_CODEPAYS_\` STRING,
        \`CODEGUICHET_\` STRING,
        \`RESERVEOBLIGATOIRE_\` INT,
        \`GPECONSO_IDENTIFIANT_\` DECIMAL(20,0),
        \`UCOMPTE_CODECATEGORIEDECOMPTE_\` STRING,
        \`INTITULELONG_\` STRING,
        \`ERVATIONDECOMPTE_NUMEROCOMPTE_\` STRING,
        \`COMPTE_IDENTIFIANTAPPLICATION_\` STRING,
        \`DATESORTIERMS_\` TIMESTAMP,
        \`INDICATEURPOURINDICAGE_\` STRING,
        \`CREATORUSERID_\` STRING,
        \`VERSION_\` DECIMAL(20,0),
        \`LETTRABLE_\` INT,
        \`COMPTERMS_\` INT,
        \`COMMENTAIRES_\` STRING,
        \`UPDATORUSERID_\` STRING,
        \`IBAN_\` STRING,
        \`DATECLOTURE_\` TIMESTAMP,
        \`CONTACTBDF_\` STRING,
        \`LIMITE_IDENTIFIANT_\` DECIMAL(20,0),
        \`NBCARTESBANCAIRES_\` STRING,
        \`UAGESTIONNAIRE_CODEUA_\` STRING,
        \`NUMEROCOMPTE_\` STRING,
        \`STATUT_\` STRING,
        \`DATEENTREERMS_\` TIMESTAMP,
        \`IDENTIFIANTCOMPTE_\` STRING,
        \`STATUTMETIER_\` STRING,
        \`DATEDERNIEREMAJEVDEV_\` TIMESTAMP,
        \`RREMETTANT_CODESUPERREMETTANT_\` STRING,
        \`CODEFLUX_CODEFLUX_\` STRING,
        \`OMPTE_CODEUTILISATIONDUCOMPTE_\` STRING,
        \`TYPE_\` STRING,
        \`NUMEROABREGE_\` STRING,
        \`UABDF_CODEUA_\` STRING,
        \`CBANQUETENEURDECOMPTE_CODEBIC_\` STRING,
        \`INTITULECOURT_\` STRING,
        \`CLIENTCONCERNE_IDENTIFIANT_\` DECIMAL(20,0),
        DATE_OPE DATE,         DATE_INSERT DATE
    )
    PARTITIONED BY (ID_TRAITEMENT STRING)
    STORED AS ORC
    LOCATION '"$ATE_SRC_HDFS_LDL"structcommerce_compte';

"

sqoop import -Dmapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" -Dmapred.job.queue.name=$ACQ_QUEUE --connect "${ATE_ORA_CXN}" --username ${ATE_ORA_USER} --password ${ATE_ORA_PWD} \
--query "SELECT "CLIENT_IDENTIFIANT_", "GESTLETTERAPPLI_", "CODEDEREGROUPEMENT_", "CODIQUE_", "COMPTEREMUNERE_", "NATURECOMPTE_CODENATURECOMPTE_", "TRAITEMENTCOMPTEDORMANT_", "TRAITEMENTFRAISPERIODIQUES_", "COMPTESPECIALE_", "OPERATIONNEL_", "VICEREMUNERATION_APPREFERENCE_", "COMPTETITREASSOCIE_", "CONFIDENTIALITEDO_", "DEACTIVATIONREASON_", "TRATREMUNERATION_APPREFERENCE_", "ISBLINDREKEYMODE_", "TIONINDIVIDUELLE_APPREFERENCE_", "ISACTIVE_", "ANQUETENEURDECOMPTE_STARTDATE_", "SERVATIONDECOMPTE_IDENTIFIANT_", "ISUPDATED_", "ISVALID_", "ISCREATIONREJECTED_", "ACTIONTOVALIDATE_", "DATEOUVERTURE_", "COMPLEMENTINTITULELONG_", "DEVISE_CODEDEVISE_", "RIB_", "CREATIONDATE_", "CTRLPROVISION_", "UPDATEDATE_", "SBALANCEDESPAIEMENTS_CODEPAYS_", "CODEGUICHET_", "RESERVEOBLIGATOIRE_", "GPECONSO_IDENTIFIANT_", "UCOMPTE_CODECATEGORIEDECOMPTE_", "INTITULELONG_", "ERVATIONDECOMPTE_NUMEROCOMPTE_", "COMPTE_IDENTIFIANTAPPLICATION_", "DATESORTIERMS_", "INDICATEURPOURINDICAGE_", "CREATORUSERID_", "VERSION_", "LETTRABLE_", "COMPTERMS_", "COMMENTAIRES_", "UPDATORUSERID_", "IBAN_", "DATECLOTURE_", "CONTACTBDF_", "LIMITE_IDENTIFIANT_", "NBCARTESBANCAIRES_", "UAGESTIONNAIRE_CODEUA_", "NUMEROCOMPTE_", "STATUT_", "DATEENTREERMS_", "IDENTIFIANTCOMPTE_", "STATUTMETIER_", "DATEDERNIEREMAJEVDEV_", "RREMETTANT_CODESUPERREMETTANT_", "CODEFLUX_CODEFLUX_", "OMPTE_CODEUTILISATIONDUCOMPTE_", "TYPE_", "NUMEROABREGE_", "UABDF_CODEUA_", "CBANQUETENEURDECOMPTE_CODEBIC_", "INTITULECOURT_", "CLIENTCONCERNE_IDENTIFIANT_", $COL_DATE_OPE, '${DATE_INSERT}' as DATE_INSERT, '${ID_TRAITEMENT}' as ID_TRAITEMENT 
         FROM STRUCTCOMMERCE_COMPTE
         WHERE 1=1
         AND \$CONDITIONS" \
--hcatalog-table STRUCTCOMMERCE_COMPTE \
--split-by IDENTIFIANTCOMPTE_ \
--hcatalog-database atena_landing_layer \
--hive-partition-key id_traitement \
--hive-partition-value ${ID_TRAITEMENT} \
--num-mappers 1 


#INITIALISATION END_DATE 
END_DATE=`date +%Y%m%d_%H%M%S` 

# Variable nb lignes HIVE 
NB_LIGNES_HIVE=$(hive --hiveconf tez.queue.name=$ACQ_QUEUE -S -e "SELECT count(*) from atena_landing_layer.STRUCTCOMMERCE_COMPTE") 


PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -c " \
 insert into $TOT (id_job, type_suivi, projet, application, phase, nom_traitement, nom_table, type_table, nb_lignes, type_log, log) \
 values ('$ID_TRAITEMENT', '$TYPE_SUIVI_LOG', '$PROJET', 'ATENA', '$PHASE_ACQUISITION', '$(basename "${BASH_SOURCE[0]}")', '$TABLE_NAME', 'COMPLET', '$NB_LIGNES_HIVE', 'COUNT BASTID Landing Layer', 'Nombre de ligne côté BASTID Landing Layer pour cette acquisition')"
# Gestion du cas NB_LIGNES_SQOOP != NB_LIGNES_HIVE => ERREUR
echo "NB LIGNES HIVE = ${NB_LIGNES_HIVE}"
if [[ $NB_LIGNES_SQOOP != $NB_LIGNES_HIVE ]]
then 
    REQ="  update $TOT"
    REQ+=" set status = '${ST_ERROR}'"
    REQ+=" where"
    REQ+="     type_suivi = '${TYPE_SUIVI_SUIVI}'"
    REQ+="     and niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}'"
    REQ+="     and projet = '${PROJET}'"
    REQ+="     and application = 'ATENA'"
    REQ+="     and phase = '${PHASE_ACQUISITION}'"
    REQ+="     and nom_table = 'STRUCTCOMMERCE_COMPTE'"
    REQ+="     and status = '${ST_ENCOURS}'"
    PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" -e "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"
    exit 1
fi 

