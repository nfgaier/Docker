
#!/usr/bin/env bash
set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
#set -o nounset    # Exits when script tries to use undeclared variables
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec 

if [[ -z $LOGDIR ]]
then
LOGDIR=$LST
fi

if [[ -z $LOGFILE ]]
then
LOGFILE=$(basename "${BASH_SOURCE[0]}" | cut -f 1 -d '.')_$(date +"%Y%m%d_%H%M%S_%N").log
fi

#Variables 
START_DATE=`date +%Y%m%d_%H%M%S`; echo "START_DATE=$START_DATE" 
TABLE_NAME=OPCORE_OPERATION ; echo "TABLE_NAME=$TABLE_NAME"
declare -a __LIST_DATE_OPE=('')
echo "TABLE_NAME : ${TABLE_NAME}"
echo ""



echo "Sélection de l'ID_TRAITEMENT en cours et des timestamp pour construction de la clause where des sqoop en DELTA"

RES=$(PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -t -A -F',' -c \
"select max(id_job), min(borne_min), max(borne_max) from ${TOT} \
 where projet = '$PROJET' \
   and application = 'ATENA' \
   and type_suivi = '$TYPE_SUIVI_SUIVI' \
   and niveau_suivi = '$NIVEAU_SUIVI_CATALOGUE' \
   and phase = '$PHASE_ACQUISITION' \
   and status = '$ST_ENCOURS' \
   and nom_table = 'OPCORE_OPERATION'")

ID_TRAITEMENT=$(echo "$RES" | cut -f1 -d',')
TIMESTAMP_MIN=$(echo "$RES" | cut -f2 -d',')
TIMESTAMP_MAX=$(echo "$RES" | cut -f3 -d',')

if [[ -z $ID_TRAITEMENT ]]
then
LOG_ERROR "Variable ID_TRAITEMENT non positionnée"
exit 1
fi

echo "ID_TRAITEMENT : $ID_TRAITEMENT"
echo "TIMESTAMP_MIN : $TIMESTAMP_MIN"
echo "TIMESTAMP_MAX : $TIMESTAMP_MAX"

DATE_INSERT=$(echo ${ID_TRAITEMENT} | cut -c1-4)"-"$(echo ${ID_TRAITEMENT} | cut -c5-6)"-"$(echo ${ID_TRAITEMENT} | cut -c7-8); echo "DATE_INSERT=$DATE_INSERT" 
DATE_INSERT=$(date -d "${DATE_INSERT}" +'%Y-%m-%d'); echo "DATE_INSERT=$DATE_INSERT" 
echo "DATE_INSERT : ${DATE_INSERT}"

echo "Sélection des bornes MIN et MAX de chaque DATE_OPE pour construction du CASE WHEN dans le SQOOP Import"

PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -t -A -c \
"select distinct concat_ws('~', borne_min, borne_max, date_ope) from ${TOT} \
 where projet = '$PROJET' \
   and application = 'ATENA' \
   and type_suivi = '$TYPE_SUIVI_SUIVI' \
   and niveau_suivi = '$NIVEAU_SUIVI_CATALOGUE' \
   and phase = '$PHASE_ACQUISITION' \
   and status = '$ST_ENCOURS' \
   and nom_table = 'OPCORE_OPERATION' \
 order by 1" \
> $LST/catalogue_acq_$(basename "${BASH_SOURCE[0]}" | cut -f 1 -d '.').txt

echo "Construction du CASE WHEN dans le SQOOP Import"

FIRST_BORNE_MIN="$(head -n 1 $LST/catalogue_acq_$(basename "${BASH_SOURCE[0]}" | cut -f 1 -d '.').txt |  cut -d"~" -f1)"
FIRST_DATE_OPE="$(head -n 1 $LST/catalogue_acq_$(basename "${BASH_SOURCE[0]}" | cut -f 1 -d '.').txt |  cut -d"~" -f3)"
NOM_COM="UPDATEDATE_"
COL_DATE_OPE="CASE WHEN "$NOM_COM" <  to_timestamp('"$FIRST_BORNE_MIN"', 'YYYY-MM-DD HH24:MI:SS.FF')  then '"$FIRST_DATE_OPE"'"
while read line  
do  
   BORNE_MIN=$(echo $line | cut -d"~" -f1)
   BORNE_MAX=$(echo $line | cut -d"~" -f2)
   VAL_DATE_OPE=$(echo $line | cut -d"~" -f3)
   __LIST_DATE_OPE=("${__LIST_DATE_OPE[@]}" "${VAL_DATE_OPE}")
   COL_DATE_OPE=$COL_DATE_OPE" WHEN "$NOM_COM" BETWEEN to_timestamp('"$BORNE_MIN"', 'YYYY-MM-DD HH24:MI:SS.FF')  and to_timestamp('"$BORNE_MAX"', 'YYYY-MM-DD HH24:MI:SS.FF') then '"$VAL_DATE_OPE"'"
done < $LST/catalogue_acq_$(basename "${BASH_SOURCE[0]}" | cut -f 1 -d '.').txt
COL_DATE_OPE=$COL_DATE_OPE" end as DATE_OPE"


echo "COL_DATE_OPE :"
echo "$COL_DATE_OPE"

# variable nombre de lignes SQOOP 
echo "Calcul du nombre de ligne côté SOURCE"

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom 
NB_LIGNES_SQOOP=$(echo $(sqoop eval -Dmapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom"  --connect "${ATE_ORA_CXN}" --username ${ATE_ORA_USER} --password ${ATE_ORA_PWD} --query "SELECT 'COUNT_START'||COUNT(*)||'COUNT_END' FROM OPCORE_OPERATION WHERE 1=1 AND UPDATEDATE_ BETWEEN to_timestamp('$TIMESTAMP_MIN', 'YYYY-MM-DD HH24:MI:SS.FF6') AND to_timestamp('$TIMESTAMP_MAX', 'YYYY-MM-DD HH24:MI:SS.FF6')") |  sed 's/\(.*\)\(COUNT_START\)\([0-9]*\)\(COUNT_END\).*/\3/')
if [[ $NB_LIGNES_SQOOP == *"ACCUMULO_HOME"* ]]
then
NB_LIGNES_SQOOP=0
fi
echo "nb lignes sqoop : ${NB_LIGNES_SQOOP}" 
echo "Log du nombre de lignes sqoop"


PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -e -c " \
 insert into $TOT (id_job, type_suivi, projet, application, phase, nom_traitement, nom_table, type_table, nb_lignes, type_log, log) \
 values ('$ID_TRAITEMENT', '$TYPE_SUIVI_LOG', '$PROJET', 'ATENA', '$PHASE_ACQUISITION', '$(basename "${BASH_SOURCE[0]}")', '$TABLE_NAME', 'DELTA', '$NB_LIGNES_SQOOP', 'COUNT SIO', 'Nombre de ligne côté SIO pour cette acquisition')"
#Commande hive pour réinitialiser la table opcore_operation de chargement
echo "Drop et recréation de la table cible "

hive -hiveconf tez.queue.name=$ACQ_QUEUE -hiveconf hive.cli.errors.ignore=true \
-e "

    DROP TABLE IF EXISTS atena_landing_layer.OPCORE_OPERATION;

    CREATE TABLE IF NOT EXISTS atena_landing_layer.OPCORE_OPERATION
    (
        \`POSITIONBDF_\` STRING,
        \`REJETEEAVANTIMPUTATION_\` INT,
        \`MODIFRAPPROCHEMENT_\` INT,
        \`CODEREJET_CODEREJET_\` STRING,
        \`ENCOURSCONTROLEPROV_\` INT,
        \`REFERENCESIBLE_\` STRING,
        \`USERANNULATION_\` STRING,
        \`DATEETHEUREANNULATION_\` TIMESTAMP,
        \`DATEETHEURESUPERVALIDATION_\` TIMESTAMP,
        \`USERSUPERVALIDATION_\` STRING,
        \`ARETRAITER_\` INT,
        \`VALIDATIONINDICAGE_\` INT,
        \`DATEREJET_\` TIMESTAMP,
        \`DATEEXECUTION_\` TIMESTAMP,
        \`INDICAGEREJET_\` INT,
        \`CONTEXTCRO_\` STRING,
        \`ISUPDATED_\` INT,
        \`ISBLINDREKEYMODE_\` INT,
        \`ISVALID_\` INT,
        \`ISCREATIONREJECTED_\` INT,
        \`ACTIONTOVALIDATE_\` STRING,
        \`TYPEPRELEVEMENT_\` STRING,
        \`BIC8EMETTEUR_\` STRING,
        \`BIC8DESTINAIRE_\` STRING,
        \`BIC8RECEPTEUR_\` STRING,
        \`OPERATIONLIEE_APPREFERENCE_\` STRING,
        \`COMPTEFRAIS_IDENTIFIANTCOMPTE_\` STRING,
        \`ICATEURFORCAGEDATERETROACTIVE_\` INT,
        \`TYPETRAITEMENT_\` STRING,
        \`ERREUR_\` STRING,
        \`POSSIBLEDOUBLON_\` INT,
        \`FICIAIREFINAL_CODEPARTICIPANT_\` DECIMAL(20,0),
        \`NOMCOMMERCANT_\` STRING,
        \`REFERENCEEMETTEUR_\` STRING,
        \`IDENTIFIANTCOMPTA_\` DECIMAL(20,0),
        \`IMPCODE_\` STRING,
        \`MOTIFREJET_\` STRING,
        \`OUVEMENT_CODELIBELLEMOUVEMENT_\` STRING,
        \`CODELIBELLECLIENT_\` STRING,
        \`ORIGINE_ID_\` DECIMAL(20,0),
        \`MOTIFSTATUT_\` STRING,
        \`CLIENTREFERENCE_\` STRING,
        \`FORCAGERESTRICTIONCREDIT_\` INT,
        \`BENEFICIAIRE_CODEPARTICIPANT_\` DECIMAL(20,0),
        \`CREATIONDATE_\` TIMESTAMP,
        \`LASTNOTIFICATIONOUT_ID_\` DECIMAL(20,0),
        \`FORCAGECUTOFFCREDIT_\` INT,
        \`UPDATEDATE_\` TIMESTAMP,
        \`DETERMINATIONDOUBLON_ID_\` DECIMAL(20,0),
        \`ICATEURFORCAGESUPERVALIDATION_\` INT,
        \`INDICATEURAFFECTATIONMANUELLE_\` INT,
        \`NUMEROFORMULE_\` STRING,
        \`APPREFERENCE_\` STRING,
        \`DEVISEORDRE_CODEDEVISE_\` STRING,
        \`REFERENCEOPERATIONLIEE_\` STRING,
        \`UAEMETTRICE_CODEUA_\` STRING,
        \`DEBIT_ID_\` DECIMAL(20,0),
        \`AREPORTER_\` INT,
        \`CIRCUITDEREGLEMENT_\` STRING,
        \`INDICATEURFORCAGEFILTRAGE_\` INT,
        \`CREATORUSERID_\` STRING,
        \`LISTE_ID_\` DECIMAL(20,0),
        \`MOTIFDEPAIEMENT_\` STRING,
        \`RORDREINITIAL_CODEPARTICIPANT_\` DECIMAL(20,0),
        \`MODEDEPAIEMENT_\` STRING,
        \`INTERMEDIAIRE_CODEPARTICIPANT_\` DECIMAL(20,0),
        \`UPDATORUSERID_\` STRING,
        \`EDONNEURORDRE_CODEPARTICIPANT_\` DECIMAL(20,0),
        \`MONTANTORDRE_\` DECIMAL(31,6),
        \`DATEETHEURESAISE_\` TIMESTAMP,
        \`COMPLEMENTCODEINSTRUCTION_\` STRING,
        \`STATUT_\` STRING,
        \`CODEOPERATION_CODEOPERATION_\` STRING,
        \`PRIORITE_\` STRING,
        \`TRACABILITE_\` STRING,
        \`BICEMETTEUR_\` STRING,
        \`SENS_\` STRING,
        \`MOTIFPAIEMENTNONSTRUCTURE_\` STRING,
        \`INDICATEURMVTPREVCREDIT_\` INT,
        \`CREDIT_ID_\` DECIMAL(20,0),
        \`DECLARATIONREGLEMENTAIRE_\` STRING,
        \`UBENEFICIAIRE_CODEPARTICIPANT_\` DECIMAL(20,0),
        \`COMPTE_IDENTIFIANTCOMPTE_\` STRING,
        \`BICDESTINATAIRE_\` STRING,
        \`FORCAGERESTRICTIONDEBIT_\` INT,
        \`RIBEMETTEUR_\` STRING,
        \`TYPE_\` STRING,
        \`MOTIFDEPAIMENTSTRUCTURE_\` STRING,
        \`CODEINSTRUCTION_\` STRING,
        \`BICRECEPTEUR_\` STRING,
        \`EXONERATIONTTESCOMMISSION_\` INT,
        \`LISTEDOUBLON_ID_\` DECIMAL(20,0),
        \`INDICATEURFORCAGEPROVISION_\` INT,
        \`DATEIMPUTATION_\` TIMESTAMP,
        \`NUMEROCOMMERCANT_\` STRING,
        \`TDONNEURORDRE_CODEPARTICIPANT_\` DECIMAL(20,0),
        \`ATSUPERVALIDATION_IDENTIFIANT_\` DECIMAL(20,0),
        \`MAINREFERENCE_\` STRING,
        \`REGLEMENT_ID_\` DECIMAL(20,0),
        \`MODEACQUISITION_\` STRING,
        \`DANTRECEPTEUR_CODEPARTICIPANT_\` DECIMAL(20,0),
        \`CUTOFFCREDIT_IDENTIFIANT_\` DECIMAL(20,0),
        \`CUTOFFDEBIT_IDENTIFIANT_\` DECIMAL(20,0),
        \`MOTIFINTERVENTION_\` STRING,
        \`IDENTIFIANTMODULE_\` BIGINT,
        \`NDANTEMETTEUR_CODEPARTICIPANT_\` DECIMAL(20,0),
        \`CONTROLERAUTORISATIONDEBIT_\` INT,
        \`INDICATEURFORCAGEDOUBLON_\` INT,
        \`VERSION_\` DECIMAL(20,0),
        \`CRITEREURGENCE_\` STRING,
        \`REFERENCEORIGINE_\` STRING,
        \`TYPEOPERATION_CODETYPEOPE_\` STRING,
        \`RATIONRAPPROCHEE_APPREFERENCE_\` STRING,
        \`CODETYPETRANSACTION_\` STRING,
        \`ISNOTIFIED_\` INT,
        \`DATEVALEUR_\` TIMESTAMP,
        \`DATEORDRE_\` TIMESTAMP,
        \`UNITEDESTINATAIRE_CODEUA_\` STRING,
        \`FORCAGEDEREGLEMENT_\` INT,
        \`NATUREFLUX_NATUREFLUX_\` STRING,
        \`APPLICATIONEMETTRICE_\` STRING,
        \`FORCAGECUTOFFDEBIT_\` INT,
        \`CRITERELETTRAGE_\` STRING,
        \`LASTNOTIFICATIONIN_ID_\` DECIMAL(20,0),
        \`CODEECONOMIQUE_CODEAPU_\` STRING,
        \`ATIONNEL_CODEPOLEOPERATIONNEL_\` STRING,
        \`DEVISEDEREGLEMENT_CODEDEVISE_\` STRING,
        \`SEQUENCEB_\` STRING,
        \`REPARTITIONFRAIS_\` STRING,
        \`INFOBANQUEABANQUE_\` STRING,
        \`BELLECLIENT_CODELIBELLECLIENT_\` STRING,
        \`INDICATEURMVTPREVDEBIT_\` INT,
        \`EXONERATIONCOMSAISIE_\` INT,
        \`NOTIFICATIONERROR_\` STRING,
        DATE_OPE DATE,         DATE_INSERT DATE
    )
    PARTITIONED BY (ID_TRAITEMENT STRING)
    STORED AS ORC
    LOCATION '"$ATE_SRC_HDFS_LDL"opcore_operation';

"

sqoop import -Dmapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" -Dmapred.job.queue.name=$ACQ_QUEUE --connect "${ATE_ORA_CXN}" --username ${ATE_ORA_USER} --password ${ATE_ORA_PWD} \
--query "SELECT "POSITIONBDF_", "REJETEEAVANTIMPUTATION_", "MODIFRAPPROCHEMENT_", "CODEREJET_CODEREJET_", "ENCOURSCONTROLEPROV_", "REFERENCESIBLE_", "USERANNULATION_", "DATEETHEUREANNULATION_", "DATEETHEURESUPERVALIDATION_", "USERSUPERVALIDATION_", "ARETRAITER_", "VALIDATIONINDICAGE_", "DATEREJET_", "DATEEXECUTION_", "INDICAGEREJET_", "CONTEXTCRO_", "ISUPDATED_", "ISBLINDREKEYMODE_", "ISVALID_", "ISCREATIONREJECTED_", "ACTIONTOVALIDATE_", "TYPEPRELEVEMENT_", "BIC8EMETTEUR_", "BIC8DESTINAIRE_", "BIC8RECEPTEUR_", "OPERATIONLIEE_APPREFERENCE_", "COMPTEFRAIS_IDENTIFIANTCOMPTE_", "ICATEURFORCAGEDATERETROACTIVE_", "TYPETRAITEMENT_", "ERREUR_", "POSSIBLEDOUBLON_", "FICIAIREFINAL_CODEPARTICIPANT_", "NOMCOMMERCANT_", "REFERENCEEMETTEUR_", "IDENTIFIANTCOMPTA_", "IMPCODE_", "MOTIFREJET_", "OUVEMENT_CODELIBELLEMOUVEMENT_", "CODELIBELLECLIENT_", "ORIGINE_ID_", "MOTIFSTATUT_", "CLIENTREFERENCE_", "FORCAGERESTRICTIONCREDIT_", "BENEFICIAIRE_CODEPARTICIPANT_", "CREATIONDATE_", "LASTNOTIFICATIONOUT_ID_", "FORCAGECUTOFFCREDIT_", "UPDATEDATE_", "DETERMINATIONDOUBLON_ID_", "ICATEURFORCAGESUPERVALIDATION_", "INDICATEURAFFECTATIONMANUELLE_", "NUMEROFORMULE_", "APPREFERENCE_", "DEVISEORDRE_CODEDEVISE_", "REFERENCEOPERATIONLIEE_", "UAEMETTRICE_CODEUA_", "DEBIT_ID_", "AREPORTER_", "CIRCUITDEREGLEMENT_", "INDICATEURFORCAGEFILTRAGE_", "CREATORUSERID_", "LISTE_ID_", "MOTIFDEPAIEMENT_", "RORDREINITIAL_CODEPARTICIPANT_", "MODEDEPAIEMENT_", "INTERMEDIAIRE_CODEPARTICIPANT_", "UPDATORUSERID_", "EDONNEURORDRE_CODEPARTICIPANT_", "MONTANTORDRE_", "DATEETHEURESAISE_", "COMPLEMENTCODEINSTRUCTION_", "STATUT_", "CODEOPERATION_CODEOPERATION_", "PRIORITE_", "TRACABILITE_", "BICEMETTEUR_", "SENS_", "MOTIFPAIEMENTNONSTRUCTURE_", "INDICATEURMVTPREVCREDIT_", "CREDIT_ID_", "DECLARATIONREGLEMENTAIRE_", "UBENEFICIAIRE_CODEPARTICIPANT_", "COMPTE_IDENTIFIANTCOMPTE_", "BICDESTINATAIRE_", "FORCAGERESTRICTIONDEBIT_", "RIBEMETTEUR_", "TYPE_", "MOTIFDEPAIMENTSTRUCTURE_", "CODEINSTRUCTION_", "BICRECEPTEUR_", "EXONERATIONTTESCOMMISSION_", "LISTEDOUBLON_ID_", "INDICATEURFORCAGEPROVISION_", "DATEIMPUTATION_", "NUMEROCOMMERCANT_", "TDONNEURORDRE_CODEPARTICIPANT_", "ATSUPERVALIDATION_IDENTIFIANT_", "MAINREFERENCE_", "REGLEMENT_ID_", "MODEACQUISITION_", "DANTRECEPTEUR_CODEPARTICIPANT_", "CUTOFFCREDIT_IDENTIFIANT_", "CUTOFFDEBIT_IDENTIFIANT_", "MOTIFINTERVENTION_", "IDENTIFIANTMODULE_", "NDANTEMETTEUR_CODEPARTICIPANT_", "CONTROLERAUTORISATIONDEBIT_", "INDICATEURFORCAGEDOUBLON_", "VERSION_", "CRITEREURGENCE_", "REFERENCEORIGINE_", "TYPEOPERATION_CODETYPEOPE_", "RATIONRAPPROCHEE_APPREFERENCE_", "CODETYPETRANSACTION_", "ISNOTIFIED_", "DATEVALEUR_", "DATEORDRE_", "UNITEDESTINATAIRE_CODEUA_", "FORCAGEDEREGLEMENT_", "NATUREFLUX_NATUREFLUX_", "APPLICATIONEMETTRICE_", "FORCAGECUTOFFDEBIT_", "CRITERELETTRAGE_", "LASTNOTIFICATIONIN_ID_", "CODEECONOMIQUE_CODEAPU_", "ATIONNEL_CODEPOLEOPERATIONNEL_", "DEVISEDEREGLEMENT_CODEDEVISE_", "SEQUENCEB_", "REPARTITIONFRAIS_", "INFOBANQUEABANQUE_", "BELLECLIENT_CODELIBELLECLIENT_", "INDICATEURMVTPREVDEBIT_", "EXONERATIONCOMSAISIE_", "NOTIFICATIONERROR_", $COL_DATE_OPE, '${DATE_INSERT}' as DATE_INSERT, '${ID_TRAITEMENT}' as ID_TRAITEMENT 
         FROM OPCORE_OPERATION
         WHERE 1=1
         AND UPDATEDATE_ BETWEEN to_timestamp('$TIMESTAMP_MIN', 'YYYY-MM-DD HH24:MI:SS.FF6') AND to_timestamp('$TIMESTAMP_MAX', 'YYYY-MM-DD HH24:MI:SS.FF6')
         AND \$CONDITIONS" \
--hcatalog-table OPCORE_OPERATION \
--split-by APPREFERENCE_ \
--hcatalog-database atena_landing_layer \
--hive-partition-key id_traitement \
--hive-partition-value ${ID_TRAITEMENT} \
--num-mappers 1 


#INITIALISATION END_DATE 
END_DATE=`date +%Y%m%d_%H%M%S` 

# Variable nb lignes HIVE 
NB_LIGNES_HIVE=$(hive --hiveconf tez.queue.name=$ACQ_QUEUE -S -e "SELECT count(*) from atena_landing_layer.OPCORE_OPERATION") 


PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -c " \
 insert into $TOT (id_job, type_suivi, projet, application, phase, nom_traitement, nom_table, type_table, nb_lignes, type_log, log) \
 values ('$ID_TRAITEMENT', '$TYPE_SUIVI_LOG', '$PROJET', 'ATENA', '$PHASE_ACQUISITION', '$(basename "${BASH_SOURCE[0]}")', '$TABLE_NAME', 'DELTA', '$NB_LIGNES_HIVE', 'COUNT BASTID Landing Layer', 'Nombre de ligne côté BASTID Landing Layer pour cette acquisition')"
# Gestion du cas NB_LIGNES_SQOOP != NB_LIGNES_HIVE => ERREUR
echo "NB LIGNES HIVE = ${NB_LIGNES_HIVE}"
if [[ $NB_LIGNES_SQOOP != $NB_LIGNES_HIVE ]]
then 
    REQ="  update $TOT"
    REQ+=" set status = '${ST_ERROR}'"
    REQ+=" where"
    REQ+="     type_suivi = '${TYPE_SUIVI_SUIVI}'"
    REQ+="     and niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}'"
    REQ+="     and projet = '${PROJET}'"
    REQ+="     and application = 'ATENA'"
    REQ+="     and phase = '${PHASE_ACQUISITION}'"
    REQ+="     and nom_table = 'OPCORE_OPERATION'"
    REQ+="     and status = '${ST_ENCOURS}'"
    PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" -e "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"
    exit 1
fi 

