#!/usr/bin/env bash
###############################################################################
# Description :
# Usage :
# Author :
# Updated :
###############################################################################

#set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
set -o nounset    # Exits when script tries to use undeclared variables
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec                        #source .fonction_*_spec

readonly __DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #script path
readonly __FILE="${__DIR}/$(basename "${BASH_SOURCE[0]}")"     #script name
readonly __BASE="$(basename ${__FILE} .sh)"                    #script name without the .sh extention
readonly __TIMESTAMP=$(date +"%Y%m%d_%H%M%S_%N")               #time stamp ex.20170804_110741_146134493
readonly __SUCCESS=0                                           #success exit code
readonly __FAILURE=1                                           #failure exit code

SCRIPT_NAME=${__BASE}; export SCRIPT_NAME                      #script name exported for use in .fonction_*_spec
LOGDIR=${LST}; export LOGDIR                                   #log folder exported for use in .fonction_*_spec
LOGFILE="${__BASE}_${__TIMESTAMP}.log"; export LOGFILE         #log file exported for use in .fonction_*_spec
PID=$$; export PID                                             #PID exported for use in .fonction_*_spec

do_copy() {

  LOG_INFO "HDFS copy ..."

  #REF SIO

  
  
  
  LOG_INFO "TABLE NOMENCLATURES_CODEOPERATION   "
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_codeoperation/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_codeoperation/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_codeoperation/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE PARAM_DETERMINERCODEIMPUTATION"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/param_determinercodeimputation/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/param_determinercodeimputation/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/param_determinercodeimputation/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE NOMENCLATURES_FAMILLEOPERATION"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_familleoperation/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_familleoperation/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_familleoperation/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE NOMENCLATURES_TYPEOPERATION   "
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_typeoperation/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_typeoperation/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_typeoperation/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE NOMENCLATURES_PAYS            "
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_pays/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_pays/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_pays/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE STRUCTCOMMERCE_COMPTE         "
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/structcommerce_compte/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/structcommerce_compte/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/structcommerce_compte/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE STRUCTCOMMERCE_CLIENT         "
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/structcommerce_client/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/structcommerce_client/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/structcommerce_client/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE STRUCTCOMMERCE_GROUPECLIENTELE"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/structcommerce_groupeclientele/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/structcommerce_groupeclientele/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/structcommerce_groupeclientele/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE STRUCTCOMMERCE_CODEREMETTANT  "
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/structcommerce_coderemettant/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/structcommerce_coderemettant/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/structcommerce_coderemettant/id_traitement=${ID_TRAITEMENT}
  
  LOG_INFO "TABLE STRUCTCOMMERCE_COMPTEHISTORY  "
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/structcommerce_comptehistory/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/structcommerce_comptehistory/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/structcommerce_comptehistory/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE STRUCTCOMMERCE_SERVICEBANCAIRE"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/structcommerce_servicebancaire/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/structcommerce_servicebancaire/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/structcommerce_servicebancaire/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE NCLATURES_PRODUITDEFACTURATION"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nclatures_produitdefacturation/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nclatures_produitdefacturation/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nclatures_produitdefacturation/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE NOMENCLATURES_CODEFLUX        "
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_codeflux/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_codeflux/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_codeflux/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE STRUCTCOMMERCE_NUMERODECOMPTE "
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/structcommerce_numerodecompte/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/structcommerce_numerodecompte/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/structcommerce_numerodecompte/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE ACQ_FLUXOPERATIONEMIS"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/acq_fluxoperationemis/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/acq_fluxoperationemis/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/acq_fluxoperationemis/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE ACQ_FLUXOPERATIONRECU"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/acq_fluxoperationrecu/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/acq_fluxoperationrecu/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/acq_fluxoperationrecu/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE IMP_OPERATIONIMPUTATION"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/imp_operationimputation/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/imp_operationimputation/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/imp_operationimputation/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE OPCORE_CHARGEEMETTEUR"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/opcore_chargeemetteur/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/opcore_chargeemetteur/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/opcore_chargeemetteur/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE OPCORE_CONTREPARTIE"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/opcore_contrepartie/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/opcore_contrepartie/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/opcore_contrepartie/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE OPCORE_DONNEESORIGINE"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/opcore_donneesorigine/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/opcore_donneesorigine/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/opcore_donneesorigine/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE OPCORE_DONNEESREGLEMENT"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/opcore_donneesreglement/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/opcore_donneesreglement/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/opcore_donneesreglement/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE OPCORE_ERREUR"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/opcore_erreur/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/opcore_erreur/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/opcore_erreur/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE OPCORE_LISTEDOUBLON"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/opcore_listedoublon/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/opcore_listedoublon/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/opcore_listedoublon/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE OPCORE_OPERATION"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/opcore_operation/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/opcore_operation/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/opcore_operation/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE OPCORE_PARTICIPANTOPERATION"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/opcore_participantoperation/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/opcore_participantoperation/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/opcore_participantoperation/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE OPCORE_TRANSACTION"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/opcore_transaction/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/opcore_transaction/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/opcore_transaction/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE OPCORE_TRANSACTIONFRAIS"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/opcore_transactionfrais/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/opcore_transactionfrais/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/opcore_transactionfrais/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE OPDIV_OPERATIONDIVERSE"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/opdiv_operationdiverse/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/opdiv_operationdiverse/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/opdiv_operationdiverse/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE PARAM_CODELIBELLEERREUR"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/param_codelibelleerreur/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/param_codelibelleerreur/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/param_codelibelleerreur/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE PCORE_CODEINSTRUCTIONOPERATION"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/pcore_codeinstructionoperation/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/pcore_codeinstructionoperation/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/pcore_codeinstructionoperation/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE PE_OPERATIONIMPUTATIONINTERETS"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/pe_operationimputationinterets/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/pe_operationimputationinterets/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/pe_operationimputationinterets/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE TENUEDEPOSITION_MOUVEMENT"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/tenuedeposition_mouvement/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/tenuedeposition_mouvement/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/tenuedeposition_mouvement/id_traitement=${ID_TRAITEMENT}

  LOG_INFO "TABLE VIR_OPERATIONVIREMENT"
  hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/vir_operationvirement/id_traitement=${ID_TRAITEMENT}
  hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/vir_operationvirement/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/vir_operationvirement/id_traitement=${ID_TRAITEMENT}

LOG_INFO "atures_groupedeconfidentialite"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/atures_groupedeconfidentialite/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/atures_groupedeconfidentialite/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/atures_groupedeconfidentialite/id_traitement=${ID_TRAITEMENT}
LOG_INFO "catalogue_formatrestitution"

hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/catalogue_formatrestitution/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/catalogue_formatrestitution/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/catalogue_formatrestitution/id_traitement=${ID_TRAITEMENT}
 LOG_INFO "catalogue_typerestitution"
 
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/catalogue_typerestitution/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/catalogue_typerestitution/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/catalogue_typerestitution/id_traitement=${ID_TRAITEMENT}
 LOG_INFO "categorieproduitdefacturation"
 
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/categorieproduitdefacturation/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/categorieproduitdefacturation/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/categorieproduitdefacturation/id_traitement=${ID_TRAITEMENT}
 LOG_INFO "clatures_lieuderesidenceficoba"
 
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/clatures_lieuderesidenceficoba/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/clatures_lieuderesidenceficoba/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/clatures_lieuderesidenceficoba/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "enclatures_categorieeconomique"
 
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/enclatures_categorieeconomique/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/enclatures_categorieeconomique/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/enclatures_categorieeconomique/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "enclatures_uniteadministrative"
 
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/enclatures_uniteadministrative/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/enclatures_uniteadministrative/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/enclatures_uniteadministrative/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "enclatures_utilisationducompte"

 hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/enclatures_utilisationducompte/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/enclatures_utilisationducompte/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/enclatures_utilisationducompte/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "menclatures_categoriejuridique"

 hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/menclatures_categoriejuridique/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/menclatures_categoriejuridique/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/menclatures_categoriejuridique/id_traitement=${ID_TRAITEMENT}
 LOG_INFO "nclatures_classificationclient"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nclatures_classificationclient/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nclatures_classificationclient/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nclatures_classificationclient/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "nclatures_codelibellemouvement"

 hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nclatures_codelibellemouvement/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nclatures_codelibellemouvement/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nclatures_codelibellemouvement/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "nclatures_produitdefacturation"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nclatures_produitdefacturation/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nclatures_produitdefacturation/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nclatures_produitdefacturation/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "nomenclatures_application"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_application/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_application/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_application/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "nomenclatures_codeape"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_codeape/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_codeape/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_codeape/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "nomenclatures_codeapu"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_codeapu/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_codeapu/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_codeapu/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "nomenclatures_codebanque"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_codebanque/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_codebanque/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_codebanque/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "nomenclatures_codecfonb"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_codecfonb/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_codecfonb/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_codecfonb/id_traitement=${ID_TRAITEMENT}

 LOG_INFO "nomenclatures_codeflux"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_codeflux/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_codeflux/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_codeflux/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "nomenclatures_codemouvement"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_codemouvement/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_codemouvement/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_codemouvement/id_traitement=${ID_TRAITEMENT}

 LOG_INFO "nomenclatures_codeoperation"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_codeoperation/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_codeoperation/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_codeoperation/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "nomenclatures_codetva"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_codetva/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_codetva/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_codetva/id_traitement=${ID_TRAITEMENT}

 LOG_INFO "nomenclatures_delaidereglement"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_delaidereglement/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_delaidereglement/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_delaidereglement/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "nomenclatures_devise"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_devise/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_devise/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_devise/id_traitement=${ID_TRAITEMENT}

 LOG_INFO "nomenclatures_familleoperation"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_familleoperation/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_familleoperation/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_familleoperation/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "nomenclatures_formuledetaux"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_formuledetaux/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_formuledetaux/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_formuledetaux/id_traitement=${ID_TRAITEMENT}

 LOG_INFO "nomenclatures_modedereglement"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_modedereglement/id_traitement=${ID_TRAITEMENT}

 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_modedereglement/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_modedereglement/id_traitement=${ID_TRAITEMENT}

 LOG_INFO "nomenclatures_naturecompte"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_naturecompte/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_naturecompte/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_naturecompte/id_traitement=${ID_TRAITEMENT}

 LOG_INFO "nomenclatures_pays"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_pays/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_pays/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_pays/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "nomenclatures_paysdelazone"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_paysdelazone/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_paysdelazone/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_paysdelazone/id_traitement=${ID_TRAITEMENT}

 LOG_INFO "nomenclatures_poleoperationnel"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_poleoperationnel/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_poleoperationnel/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_poleoperationnel/id_traitement=${ID_TRAITEMENT}

 LOG_INFO "nomenclatures_rolecontact"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_rolecontact/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_rolecontact/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_rolecontact/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "nomenclatures_superremettant"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_superremettant/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_superremettant/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_superremettant/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "nomenclatures_tauxdereference"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_tauxdereference/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_tauxdereference/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_tauxdereference/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "nomenclatures_tauxmarge"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_tauxmarge/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_tauxmarge/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_tauxmarge/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "nomenclatures_typeoperation"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_typeoperation/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_typeoperation/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_typeoperation/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "nomenclatures_typeroleadresse"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_typeroleadresse/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_typeroleadresse/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_typeroleadresse/id_traitement=${ID_TRAITEMENT}

 LOG_INFO "nomenclatures_zonederesidence"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nomenclatures_zonederesidence/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nomenclatures_zonederesidence/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nomenclatures_zonederesidence/id_traitement=${ID_TRAITEMENT}

 LOG_INFO "omenclatures_banquecommerciale"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/omenclatures_banquecommerciale/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/omenclatures_banquecommerciale/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/omenclatures_banquecommerciale/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "omenclatures_categoriedeclient"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/omenclatures_categoriedeclient/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/omenclatures_categoriedeclient/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/omenclatures_categoriedeclient/id_traitement=${ID_TRAITEMENT}

 LOG_INFO "omenclatures_categoriedecompte"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/omenclatures_categoriedecompte/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/omenclatures_categoriedecompte/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/omenclatures_categoriedecompte/id_traitement=${ID_TRAITEMENT}

 LOG_INFO "omenclatures_directiondutresor"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/omenclatures_directiondutresor/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/omenclatures_directiondutresor/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/omenclatures_directiondutresor/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "omenclatures_typederestriction"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/omenclatures_typederestriction/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/omenclatures_typederestriction/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/omenclatures_typederestriction/id_traitement=${ID_TRAITEMENT}

 LOG_INFO "param_coderejetcfonb"
 
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/param_coderejetcfonb/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/param_coderejetcfonb/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/param_coderejetcfonb/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "s_categorieeconomiquenationale"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/s_categorieeconomiquenationale/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/s_categorieeconomiquenationale/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/s_categorieeconomiquenationale/id_traitement=${ID_TRAITEMENT}

 LOG_INFO "tures_motifoppositionsurcheque"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/tures_motifoppositionsurcheque/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/tures_motifoppositionsurcheque/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/tures_motifoppositionsurcheque/id_traitement=${ID_TRAITEMENT}
 
 LOG_INFO "tures_typeautreservicebancaire"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/tures_typeautreservicebancaire/id_traitement=${ID_TRAITEMENT}
 hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/tures_typeautreservicebancaire/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/tures_typeautreservicebancaire/id_traitement=${ID_TRAITEMENT}
 
LOG_INFO "ansverses_formatsparabonnement"

hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/ansverses_formatsparabonnement/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/ansverses_formatsparabonnement/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/ansverses_formatsparabonnement/id_traitement=${ID_TRAITEMENT}

LOG_INFO "enttransverses_adresse"

hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/enttransverses_adresse/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/enttransverses_adresse/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/enttransverses_adresse/id_traitement=${ID_TRAITEMENT}

LOG_INFO "enttransverses_adressepostale"

hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/enttransverses_adressepostale/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/enttransverses_adressepostale/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/enttransverses_adressepostale/id_traitement=${ID_TRAITEMENT}

LOG_INFO "enttransverses_contact"

hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/enttransverses_contact/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/enttransverses_contact/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/enttransverses_contact/id_traitement=${ID_TRAITEMENT}

LOG_INFO "enttransverses_periodicitecron"

hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/enttransverses_periodicitecron/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/enttransverses_periodicitecron/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/enttransverses_periodicitecron/id_traitement=${ID_TRAITEMENT}

LOG_INFO "enttransverses_swift"

hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/enttransverses_swift/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/enttransverses_swift/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/enttransverses_swift/id_traitement=${ID_TRAITEMENT}

LOG_INFO "enttransverses_tarification"

hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/enttransverses_tarification/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/enttransverses_tarification/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/enttransverses_tarification/id_traitement=${ID_TRAITEMENT}

LOG_INFO "nsverses_abonnementrestitution"

hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/nsverses_abonnementrestitution/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/nsverses_abonnementrestitution/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/nsverses_abonnementrestitution/id_traitement=${ID_TRAITEMENT}

LOG_INFO "ransverses_frequencegeneration"

hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/ransverses_frequencegeneration/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/ransverses_frequencegeneration/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/ransverses_frequencegeneration/id_traitement=${ID_TRAITEMENT}

LOG_INFO "transverses_adressesexpedition"

hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/transverses_adressesexpedition/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/transverses_adressesexpedition/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/transverses_adressesexpedition/id_traitement=${ID_TRAITEMENT}

LOG_INFO "ttransverses_adressesducontact"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/ttransverses_adressesducontact/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/ttransverses_adressesducontact/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/ttransverses_adressesducontact/id_traitement=${ID_TRAITEMENT}

#bastid-529
LOG_INFO "commerce_entiteniveauclientele"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/commerce_entiteniveauclientele/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/commerce_entiteniveauclientele/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/commerce_entiteniveauclientele/id_traitement=${ID_TRAITEMENT}

LOG_INFO "consolidationcontroleprovision"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/consolidationcontroleprovision/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/consolidationcontroleprovision/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/consolidationcontroleprovision/id_traitement=${ID_TRAITEMENT}

LOG_INFO "ctcommerce_donneesbenificiaire"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/ctcommerce_donneesbenificiaire/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/ctcommerce_donneesbenificiaire/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/ctcommerce_donneesbenificiaire/id_traitement=${ID_TRAITEMENT}

LOG_INFO "ctcommerce_entiteprincipalebdf"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/ctcommerce_entiteprincipalebdf/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/ctcommerce_entiteprincipalebdf/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/ctcommerce_entiteprincipalebdf/id_traitement=${ID_TRAITEMENT}

LOG_INFO "merce_identifiantinternational"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/merce_identifiantinternational/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/merce_identifiantinternational/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/merce_identifiantinternational/id_traitement=${ID_TRAITEMENT}

LOG_INFO "rce_groupedeconsolidationsible"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/rce_groupedeconsolidationsible/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/rce_groupedeconsolidationsible/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/rce_groupedeconsolidationsible/id_traitement=${ID_TRAITEMENT}

LOG_INFO "structcommerce_autresnumeros"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/structcommerce_autresnumeros/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/structcommerce_autresnumeros/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/structcommerce_autresnumeros/id_traitement=${ID_TRAITEMENT}

LOG_INFO "structcommerce_bicsautorises"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/structcommerce_bicsautorises/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/structcommerce_bicsautorises/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/structcommerce_bicsautorises/id_traitement=${ID_TRAITEMENT}

LOG_INFO "structcommerce_roleadresse"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/structcommerce_roleadresse/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/structcommerce_roleadresse/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/structcommerce_roleadresse/id_traitement=${ID_TRAITEMENT}

LOG_INFO "tructcommerce_ctepargpedeconso"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/tructcommerce_ctepargpedeconso/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/tructcommerce_ctepargpedeconso/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/tructcommerce_ctepargpedeconso/id_traitement=${ID_TRAITEMENT}

LOG_INFO "tructcommerce_demandedecloture"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/tructcommerce_demandedecloture/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/tructcommerce_demandedecloture/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/tructcommerce_demandedecloture/id_traitement=${ID_TRAITEMENT}

LOG_INFO "uctcommerce_perimetreextension"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/uctcommerce_perimetreextension/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/uctcommerce_perimetreextension/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/uctcommerce_perimetreextension/id_traitement=${ID_TRAITEMENT}

LOG_INFO "TABLE ef_coordonneesbeneficiairevsot"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/ef_coordonneesbeneficiairevsot/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/ef_coordonneesbeneficiairevsot/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/ef_coordonneesbeneficiairevsot/id_traitement=${ID_TRAITEMENT}

LOG_INFO "TABLE acq_sqoop_ement_instructionordrevirement"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/ement_instructionordrevirement/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/ement_instructionordrevirement/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/ement_instructionordrevirement/id_traitement=${ID_TRAITEMENT}

LOG_INFO "TABLE e_processparcpteettarification"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/e_processparcpteettarification/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/e_processparcpteettarification/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/e_processparcpteettarification/id_traitement=${ID_TRAITEMENT}

LOG_INFO "TABLE essces_autresservicesbancaires"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/essces_autresservicesbancaires/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/essces_autresservicesbancaires/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/essces_autresservicesbancaires/id_traitement=${ID_TRAITEMENT}

LOG_INFO "TABLE n_comptearemunererremuneration"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/n_comptearemunererremuneration/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/n_comptearemunererremuneration/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/n_comptearemunererremuneration/id_traitement=${ID_TRAITEMENT}

LOG_INFO "TABLE ion_contratserviceremuneration"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/ion_contratserviceremuneration/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/ion_contratserviceremuneration/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/ion_contratserviceremuneration/id_traitement=${ID_TRAITEMENT}

LOG_INFO "TABLE ope_donneessoclecalculinterets"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/ope_donneessoclecalculinterets/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/ope_donneessoclecalculinterets/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/ope_donneessoclecalculinterets/id_traitement=${ID_TRAITEMENT}

LOG_INFO "TABLE scebqref_cutoff"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/scebqref_cutoff/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/scebqref_cutoff/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/scebqref_cutoff/id_traitement=${ID_TRAITEMENT}

LOG_INFO "TABLE scebqref_facturation"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/scebqref_facturation/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/scebqref_facturation/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/scebqref_facturation/id_traitement=${ID_TRAITEMENT}

LOG_INFO "TABLE scebqref_modedefacturation"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/scebqref_modedefacturation/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/scebqref_modedefacturation/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/scebqref_modedefacturation/id_traitement=${ID_TRAITEMENT}

LOG_INFO "TABLE scebqref_oppositionsdd"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/scebqref_oppositionsdd/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/scebqref_oppositionsdd/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/scebqref_oppositionsdd/id_traitement=${ID_TRAITEMENT}

LOG_INFO "TABLE scebqref_oppositionsurcheque"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/scebqref_oppositionsurcheque/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/scebqref_oppositionsurcheque/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/scebqref_oppositionsurcheque/id_traitement=${ID_TRAITEMENT}

LOG_INFO "TABLE scebqref_reroutage"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/scebqref_reroutage/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/scebqref_reroutage/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/scebqref_reroutage/id_traitement=${ID_TRAITEMENT}

LOG_INFO "TABLE scebqref_restrictions"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/scebqref_restrictions/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/scebqref_restrictions/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/scebqref_restrictions/id_traitement=${ID_TRAITEMENT}

LOG_INFO "TABLE scebqref_supervalidation"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/scebqref_supervalidation/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/scebqref_supervalidation/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/scebqref_supervalidation/id_traitement=${ID_TRAITEMENT}

LOG_INFO "TABLE scebqref_vsot"
hdfs dfs -mkdir -p /data/source/${S_ENV}/raw_layer/scebqref_vsot/id_traitement=${ID_TRAITEMENT}
hdfs dfs -cp -f /data/source/${S_ENV}/landing_layer/scebqref_vsot/id_traitement=${ID_TRAITEMENT}/* /data/source/${S_ENV}/raw_layer/scebqref_vsot/id_traitement=${ID_TRAITEMENT}


  LOG_INFO "MSCK REPAIR TABLE"
  hive -hiveconf tez.queue.name=${TRT_QUEUE}  -e "MSCK REPAIR TABLE atena_raw_layer.nomenclatures_codeoperation ;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.param_determinercodeimputation ;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_familleoperation ;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_typeoperation ;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_pays ;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.structcommerce_compte ;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.structcommerce_client ;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.structcommerce_groupeclientele ;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.structcommerce_coderemettant ;
																								  MSCK REPAIR TABLE atena_raw_layer.structcommerce_comptehistory ;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.structcommerce_servicebancaire ;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nclatures_produitdefacturation ;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_codeflux ;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.structcommerce_numerodecompte ;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.acq_fluxoperationemis;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.acq_fluxoperationrecu;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.imp_operationimputation;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.opcore_chargeemetteur;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.opcore_contrepartie;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.opcore_donneesorigine;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.opcore_donneesreglement;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.opcore_erreur;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.opcore_listedoublon;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.opcore_operation;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.opcore_participantoperation;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.opcore_transaction;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.opcore_transactionfrais;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.opdiv_operationdiverse;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.param_codelibelleerreur;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.pcore_codeinstructionoperation;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.pe_operationimputationinterets;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.tenuedeposition_mouvement;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.vir_operationvirement;
																								  MSCK REPAIR TABLE atena_raw_layer.atures_groupedeconfidentialite;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.catalogue_formatrestitution;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.catalogue_typerestitution;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.categorieproduitdefacturation;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.clatures_lieuderesidenceficoba;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.enclatures_categorieeconomique;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.enclatures_uniteadministrative;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.enclatures_utilisationducompte;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.menclatures_categoriejuridique;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nclatures_classificationclient;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nclatures_codelibellemouvement;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nclatures_produitdefacturation;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_application;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_codeape;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_codeapu;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_codebanque;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_codecfonb;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_codeflux;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_codemouvement;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_codeoperation;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_codetva;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_delaidereglement;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_devise;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_familleoperation;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_formuledetaux;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_modedereglement;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_naturecompte;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_pays;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_paysdelazone;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_poleoperationnel;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_rolecontact;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_superremettant;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_tauxdereference;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_tauxmarge;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_typeoperation;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_typeroleadresse;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nomenclatures_zonederesidence;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.omenclatures_banquecommerciale;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.omenclatures_categoriedeclient;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.omenclatures_categoriedecompte;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.omenclatures_directiondutresor;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.omenclatures_typederestriction;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.param_coderejetcfonb;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.s_categorieeconomiquenationale;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.tures_motifoppositionsurcheque;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.tures_typeautreservicebancaire;
																								  MSCK REPAIR TABLE atena_raw_layer.ansverses_formatsparabonnement
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.enttransverses_adresse;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.enttransverses_adressepostale;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.enttransverses_contact;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.enttransverses_periodicitecron;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.enttransverses_swift;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.enttransverses_tarification;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.nsverses_abonnementrestitution;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.ransverses_frequencegeneration;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.transverses_adressesexpedition;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.ttransverses_adressesducontact;
																								  MSCK REPAIR TABLE atena_raw_layer.commerce_entiteniveauclientele;
																								  MSCK REPAIR TABLE atena_raw_layer.consolidationcontroleprovision;
																								  MSCK REPAIR TABLE atena_raw_layer.ctcommerce_donneesbenificiaire;
																								  MSCK REPAIR TABLE atena_raw_layer.ctcommerce_entiteprincipalebdf;
																								  MSCK REPAIR TABLE atena_raw_layer.merce_identifiantinternational;
																								  MSCK REPAIR TABLE atena_raw_layer.rce_groupedeconsolidationsible;
																								  MSCK REPAIR TABLE atena_raw_layer.structcommerce_autresnumeros;
																								  MSCK REPAIR TABLE atena_raw_layer.structcommerce_bicsautorises;
																								  MSCK REPAIR TABLE atena_raw_layer.structcommerce_roleadresse;
																								  MSCK REPAIR TABLE atena_raw_layer.tructcommerce_ctepargpedeconso;
																								  MSCK REPAIR TABLE atena_raw_layer.tructcommerce_demandedecloture;
																								  MSCK REPAIR TABLE atena_raw_layer.uctcommerce_perimetreextension;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.ef_coordonneesbeneficiairevsot;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.ement_instructionordrevirement;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.e_processparcpteettarification;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.essces_autresservicesbancaires;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.ion_contratserviceremuneration;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.n_comptearemunererremuneration;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.ope_donneessoclecalculinterets;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.scebqref_cutoff;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.scebqref_facturation;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.scebqref_modedefacturation;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.scebqref_oppositionsdd;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.scebqref_oppositionsurcheque;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.scebqref_reroutage;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.scebqref_restrictions;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.scebqref_supervalidation;
                                                                                                  MSCK REPAIR TABLE atena_raw_layer.scebqref_vsot;"
}                                                                                             


main () {

  if [[ "$#" -ne 2 ]]; then
    LOG_ERROR "${FUNCNAME[0]} : Usage : copy_land_row.sh <id_traitement> <env(DEV,REC)>"
    exit ${__FAILURE}
  else
    ID_TRAITEMENT="${1}"
    local temp="${2}"
    if [[ ${temp} != "DEV" && ${temp} != "REC" ]]; then
      LOG_ERROR "${FUNCNAME[0]} : Usage : second parameter must be either DEV or REC"
      exit ${__FAILURE}
    else
      if [[ ${temp} != "DEV" ]]; then
         S_ENV="s_atena"
      else
         S_ENV="s_datena"
      fi
    fi
    LOG_INFO "ID_TRAITEMENT=$ID_TRAITEMENT"
    LOG_INFO "S_ENV=$S_ENV"
  fi

  START

  SETUP

  do_copy

    REQ="update $TOT"
    REQ+=" set status = '${ST_OK}'"
    REQ+=" where"
    REQ+="     type_suivi = '${TYPE_SUIVI_SUIVI}'"
    REQ+="     and id_job = '${ID_TRAITEMENT}'"
    REQ+="     and status = '${ST_DISPO_COPIE_LAND_ROW}'"
    REQ+=" ;"
    PGPASSWORD="${DL_PG_PWD}" psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" -e "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"

  LOG_INFO "Copy OK, STATUT of ID_TRAITEMENT ${ID_TRAITEMENT} updated"

  END

  exit ${__SUCCESS}

}

main "$@" >> "${LOGDIR}/${LOGFILE}" 2>&1
