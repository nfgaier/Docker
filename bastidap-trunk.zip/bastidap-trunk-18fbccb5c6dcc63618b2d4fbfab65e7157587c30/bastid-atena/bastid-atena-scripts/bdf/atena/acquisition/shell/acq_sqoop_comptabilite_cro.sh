
#!/usr/bin/env bash
set -o errexit    # Exits when a command fails
set -o pipefail   # The exit status of the last command that threw a non-zero exit code is returned.
#set -o nounset    # Exits when script tries to use undeclared variables
#set -o xtrace    # Debug

. $APPLI_HOME/appli/connexion/.fonction_bastid_spec 

if [[ -z $LOGDIR ]]
then
LOGDIR=$LST
fi

if [[ -z $LOGFILE ]]
then
LOGFILE=$(basename "${BASH_SOURCE[0]}" | cut -f 1 -d '.')_$(date +"%Y%m%d_%H%M%S_%N").log
fi

#Variables 
START_DATE=`date +%Y%m%d_%H%M%S`; echo "START_DATE=$START_DATE" 
TABLE_NAME=COMPTABILITE_CRO ; echo "TABLE_NAME=$TABLE_NAME"
declare -a __LIST_DATE_OPE=('')
echo "TABLE_NAME : ${TABLE_NAME}"
echo ""



echo "Sélection de l'ID_TRAITEMENT en cours et des timestamp pour construction de la clause where des sqoop en DELTA"

RES=$(PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -t -A -F',' -c \
"select max(id_job), min(borne_min), max(borne_max) from ${TOT} \
 where projet = '$PROJET' \
   and application = 'ATENA' \
   and type_suivi = '$TYPE_SUIVI_SUIVI' \
   and niveau_suivi = '$NIVEAU_SUIVI_CATALOGUE' \
   and phase = '$PHASE_ACQUISITION' \
   and status = '$ST_ENCOURS' \
   and nom_table = 'COMPTABILITE_CRO'")

ID_TRAITEMENT=$(echo "$RES" | cut -f1 -d',')
TIMESTAMP_MIN=$(echo "$RES" | cut -f2 -d',')
TIMESTAMP_MAX=$(echo "$RES" | cut -f3 -d',')

if [[ -z $ID_TRAITEMENT ]]
then
LOG_ERROR "Variable ID_TRAITEMENT non positionnée"
exit 1
fi

echo "ID_TRAITEMENT : $ID_TRAITEMENT"
echo "TIMESTAMP_MIN : $TIMESTAMP_MIN"
echo "TIMESTAMP_MAX : $TIMESTAMP_MAX"

DATE_INSERT=$(echo ${ID_TRAITEMENT} | cut -c1-4)"-"$(echo ${ID_TRAITEMENT} | cut -c5-6)"-"$(echo ${ID_TRAITEMENT} | cut -c7-8); echo "DATE_INSERT=$DATE_INSERT" 
DATE_INSERT=$(date -d "${DATE_INSERT}" +'%Y-%m-%d'); echo "DATE_INSERT=$DATE_INSERT" 
echo "DATE_INSERT : ${DATE_INSERT}"

echo "Sélection des bornes MIN et MAX de chaque DATE_OPE pour construction du CASE WHEN dans le SQOOP Import"

PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -t -A -c \
"select distinct concat_ws('~', borne_min, borne_max, date_ope) from ${TOT} \
 where projet = '$PROJET' \
   and application = 'ATENA' \
   and type_suivi = '$TYPE_SUIVI_SUIVI' \
   and niveau_suivi = '$NIVEAU_SUIVI_CATALOGUE' \
   and phase = '$PHASE_ACQUISITION' \
   and status = '$ST_ENCOURS' \
   and nom_table = 'COMPTABILITE_CRO' \
 order by 1" \
> $LST/catalogue_acq_$(basename "${BASH_SOURCE[0]}" | cut -f 1 -d '.').txt

echo "Construction du CASE WHEN dans le SQOOP Import"

FIRST_BORNE_MIN="$(head -n 1 $LST/catalogue_acq_$(basename "${BASH_SOURCE[0]}" | cut -f 1 -d '.').txt |  cut -d"~" -f1)"
FIRST_DATE_OPE="$(head -n 1 $LST/catalogue_acq_$(basename "${BASH_SOURCE[0]}" | cut -f 1 -d '.').txt |  cut -d"~" -f3)"
NOM_COM="UPDATEDATE_"
COL_DATE_OPE="CASE WHEN "$NOM_COM" <  to_timestamp('"$FIRST_BORNE_MIN"', 'YYYY-MM-DD HH24:MI:SS.FF')  then '"$FIRST_DATE_OPE"'"
while read line  
do  
   BORNE_MIN=$(echo $line | cut -d"~" -f1)
   BORNE_MAX=$(echo $line | cut -d"~" -f2)
   VAL_DATE_OPE=$(echo $line | cut -d"~" -f3)
   __LIST_DATE_OPE=("${__LIST_DATE_OPE[@]}" "${VAL_DATE_OPE}")
   COL_DATE_OPE=$COL_DATE_OPE" WHEN "$NOM_COM" BETWEEN to_timestamp('"$BORNE_MIN"', 'YYYY-MM-DD HH24:MI:SS.FF')  and to_timestamp('"$BORNE_MAX"', 'YYYY-MM-DD HH24:MI:SS.FF') then '"$VAL_DATE_OPE"'"
done < $LST/catalogue_acq_$(basename "${BASH_SOURCE[0]}" | cut -f 1 -d '.').txt
COL_DATE_OPE=$COL_DATE_OPE" end as DATE_OPE"


echo "COL_DATE_OPE :"
echo "$COL_DATE_OPE"

# variable nombre de lignes SQOOP 
echo "Calcul du nombre de ligne côté SOURCE"

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom 
NB_LIGNES_SQOOP=$(echo $(sqoop eval -Dmapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom"  --connect "${ATE_ORA_CXN}" --username ${ATE_ORA_USER} --password ${ATE_ORA_PWD} --query "SELECT 'COUNT_START'||COUNT(*)||'COUNT_END' FROM COMPTABILITE_CRO WHERE 1=1 AND UPDATEDATE_ BETWEEN to_timestamp('$TIMESTAMP_MIN', 'YYYY-MM-DD HH24:MI:SS.FF6') AND to_timestamp('$TIMESTAMP_MAX', 'YYYY-MM-DD HH24:MI:SS.FF6')") |  sed 's/\(.*\)\(COUNT_START\)\([0-9]*\)\(COUNT_END\).*/\3/')
if [[ $NB_LIGNES_SQOOP == *"ACCUMULO_HOME"* ]]
then
NB_LIGNES_SQOOP=0
fi
echo "nb lignes sqoop : ${NB_LIGNES_SQOOP}" 
echo "Log du nombre de lignes sqoop"


PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -e -c " \
 insert into $TOT (id_job, type_suivi, projet, application, phase, nom_traitement, nom_table, type_table, nb_lignes, type_log, log) \
 values ('$ID_TRAITEMENT', '$TYPE_SUIVI_LOG', '$PROJET', 'ATENA', '$PHASE_ACQUISITION', '$(basename "${BASH_SOURCE[0]}")', '$TABLE_NAME', 'DELTA', '$NB_LIGNES_SQOOP', 'COUNT SIO', 'Nombre de ligne côté SIO pour cette acquisition')"
#Commande hive pour réinitialiser la table comptabilite_cro de chargement
echo "Drop et recréation de la table cible "

hive -hiveconf tez.queue.name=$ACQ_QUEUE -hiveconf hive.cli.errors.ignore=true \
-e "

    DROP TABLE IF EXISTS atena_landing_layer.COMPTABILITE_CRO;

    CREATE TABLE IF NOT EXISTS atena_landing_layer.COMPTABILITE_CRO
    (
        \`MONTANT16_\` DECIMAL(31,6),
        \`VENEMENTGESTION_TYPESOURCECRO_\` STRING,
        \`SOURCECRO_\` BINARY,
        \`NATIONALE_CODECATEGORIEECONAT_\` STRING,
        \`CRT3_\` STRING,
        \`CRT4_\` STRING,
        \`DEVISE_CODEDEVISE_\` STRING,
        \`CLIENTREFERENCE_\` STRING,
        \`CRT1_\` STRING,
        \`CRT2_\` STRING,
        \`CREATIONDATE_\` TIMESTAMP,
        \`MONTANT5_\` DECIMAL(31,6),
        \`MONTANT6_\` DECIMAL(31,6),
        \`UPDATEDATE_\` TIMESTAMP,
        \`MONTANT3_\` DECIMAL(31,6),
        \`CRT9_\` STRING,
        \`MONTANT4_\` DECIMAL(31,6),
        \`MAINREFERENCE_\` STRING,
        \`CRT8_\` STRING,
        \`MONTANT1_\` DECIMAL(31,6),
        \`CRT7_\` STRING,
        \`MONTANT2_\` DECIMAL(31,6),
        \`CRT6_\` STRING,
        \`CRT5_\` STRING,
        \`CRT10_\` STRING,
        \`APPREFERENCE_\` STRING,
        \`MONTANT9_\` DECIMAL(31,6),
        \`CODUAINIT_\` STRING,
        \`ISCOMPLETE_\` INT,
        \`MONTANT7_\` DECIMAL(31,6),
        \`MONTANT8_\` DECIMAL(31,6),
        \`RESIDENCE_CODEZONEDERESIDENCE_\` STRING,
        \`IDTCRELOG_\` STRING,
        \`IDTCRO_\` STRING,
        \`ISUPDATED_\` INT,
        \`CREATORUSERID_\` STRING,
        \`VERSION_\` DECIMAL(20,0),
        \`DATEMI_\` TIMESTAMP,
        \`IDTEVT_\` STRING,
        \`TYPESOURCECRO_\` STRING,
        \`UPDATORUSERID_\` STRING,
        \`ISVALID_\` INT,
        \`DEVISE11_CODEDEVISE_\` STRING,
        \`DEVISE12_CODEDEVISE_\` STRING,
        \`REFERENCEFICHIERCRO_\` STRING,
        \`MONTANT11_\` DECIMAL(31,6),
        \`CODEVTRDJ_\` STRING,
        \`MONTANT10_\` DECIMAL(31,6),
        \`DEVISE10_CODEDEVISE_\` STRING,
        \`DEVISE15_CODEDEVISE_\` STRING,
        \`DEVISE16_CODEDEVISE_\` STRING,
        \`DEVISE13_CODEDEVISE_\` STRING,
        \`DEVISE14_CODEDEVISE_\` STRING,
        \`CODUADEST_\` STRING,
        \`CRTLETTR_\` STRING,
        \`MOTIFREJET_\` STRING,
        \`ISCREATIONREJECTED_\` INT,
        \`DESCRIPTIONERREUR_\` STRING,
        \`STATUT_\` STRING,
        \`CODEXT_\` STRING,
        \`MIQUE_CODECATEGORIEECONOMIQUE_\` STRING,
        \`DEVISE6_CODEDEVISE_\` STRING,
        \`EVENEMENTGESTION_IDENTIFIANT_\` STRING,
        \`DEVISE7_CODEDEVISE_\` STRING,
        \`DEVISE8_CODEDEVISE_\` STRING,
        \`DEVISE9_CODEDEVISE_\` STRING,
        \`DESCRIPTION_\` STRING,
        \`ACTIONTOVALIDATE_\` STRING,
        \`ISBLINDREKEYMODE_\` INT,
        \`TYPE_\` STRING,
        \`SAISIMANUELLEMENT_\` INT,
        \`DEVISE3_CODEDEVISE_\` STRING,
        \`MONTANT14_\` DECIMAL(31,6),
        \`DEVISE2_CODEDEVISE_\` STRING,
        \`CODESOURCECRO_\` STRING,
        \`MONTANT15_\` DECIMAL(31,6),
        \`DEVISE5_CODEDEVISE_\` STRING,
        \`MONTANT12_\` DECIMAL(31,6),
        \`DEVISE4_CODEDEVISE_\` STRING,
        \`MONTANT13_\` DECIMAL(31,6),
        \`MESSAGECRO_ID_\` DECIMAL(20,0),
        \`LIBEVT_\` STRING,
        DATE_OPE DATE,         DATE_INSERT DATE
    )
    PARTITIONED BY (ID_TRAITEMENT STRING)
    STORED AS ORC
    LOCATION '"$ATE_SRC_HDFS_LDL"comptabilite_cro';

"

sqoop import -Dmapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" -Dmapred.job.queue.name=$ACQ_QUEUE --connect "${ATE_ORA_CXN}" --username ${ATE_ORA_USER} --password ${ATE_ORA_PWD} \
--query "SELECT "MONTANT16_", "VENEMENTGESTION_TYPESOURCECRO_", "SOURCECRO_", "NATIONALE_CODECATEGORIEECONAT_", "CRT3_", "CRT4_", "DEVISE_CODEDEVISE_", "CLIENTREFERENCE_", "CRT1_", "CRT2_", "CREATIONDATE_", "MONTANT5_", "MONTANT6_", "UPDATEDATE_", "MONTANT3_", "CRT9_", "MONTANT4_", "MAINREFERENCE_", "CRT8_", "MONTANT1_", "CRT7_", "MONTANT2_", "CRT6_", "CRT5_", "CRT10_", "APPREFERENCE_", "MONTANT9_", "CODUAINIT_", "ISCOMPLETE_", "MONTANT7_", "MONTANT8_", "RESIDENCE_CODEZONEDERESIDENCE_", "IDTCRELOG_", "IDTCRO_", "ISUPDATED_", "CREATORUSERID_", "VERSION_", "DATEMI_", "IDTEVT_", "TYPESOURCECRO_", "UPDATORUSERID_", "ISVALID_", "DEVISE11_CODEDEVISE_", "DEVISE12_CODEDEVISE_", "REFERENCEFICHIERCRO_", "MONTANT11_", "CODEVTRDJ_", "MONTANT10_", "DEVISE10_CODEDEVISE_", "DEVISE15_CODEDEVISE_", "DEVISE16_CODEDEVISE_", "DEVISE13_CODEDEVISE_", "DEVISE14_CODEDEVISE_", "CODUADEST_", "CRTLETTR_", "MOTIFREJET_", "ISCREATIONREJECTED_", "DESCRIPTIONERREUR_", "STATUT_", "CODEXT_", "MIQUE_CODECATEGORIEECONOMIQUE_", "DEVISE6_CODEDEVISE_", "EVENEMENTGESTION_IDENTIFIANT_", "DEVISE7_CODEDEVISE_", "DEVISE8_CODEDEVISE_", "DEVISE9_CODEDEVISE_", "DESCRIPTION_", "ACTIONTOVALIDATE_", "ISBLINDREKEYMODE_", "TYPE_", "SAISIMANUELLEMENT_", "DEVISE3_CODEDEVISE_", "MONTANT14_", "DEVISE2_CODEDEVISE_", "CODESOURCECRO_", "MONTANT15_", "DEVISE5_CODEDEVISE_", "MONTANT12_", "DEVISE4_CODEDEVISE_", "MONTANT13_", "MESSAGECRO_ID_", "LIBEVT_", $COL_DATE_OPE, '${DATE_INSERT}' as DATE_INSERT, '${ID_TRAITEMENT}' as ID_TRAITEMENT 
         FROM COMPTABILITE_CRO
         WHERE 1=1
         AND UPDATEDATE_ BETWEEN to_timestamp('$TIMESTAMP_MIN', 'YYYY-MM-DD HH24:MI:SS.FF6') AND to_timestamp('$TIMESTAMP_MAX', 'YYYY-MM-DD HH24:MI:SS.FF6')
         AND \$CONDITIONS" \
--hcatalog-table COMPTABILITE_CRO \
--split-by IDTCRO_ \
--hcatalog-database atena_landing_layer \
--hive-partition-key id_traitement \
--hive-partition-value ${ID_TRAITEMENT} \
--num-mappers 1 


#INITIALISATION END_DATE 
END_DATE=`date +%Y%m%d_%H%M%S` 

# Variable nb lignes HIVE 
NB_LIGNES_HIVE=$(hive --hiveconf tez.queue.name=$ACQ_QUEUE -S -e "SELECT count(*) from atena_landing_layer.COMPTABILITE_CRO") 


PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" "${DL_PG_Name}" "${DL_PG_UserName}" -c " \
 insert into $TOT (id_job, type_suivi, projet, application, phase, nom_traitement, nom_table, type_table, nb_lignes, type_log, log) \
 values ('$ID_TRAITEMENT', '$TYPE_SUIVI_LOG', '$PROJET', 'ATENA', '$PHASE_ACQUISITION', '$(basename "${BASH_SOURCE[0]}")', '$TABLE_NAME', 'DELTA', '$NB_LIGNES_HIVE', 'COUNT BASTID Landing Layer', 'Nombre de ligne côté BASTID Landing Layer pour cette acquisition')"
# Gestion du cas NB_LIGNES_SQOOP != NB_LIGNES_HIVE => ERREUR
echo "NB LIGNES HIVE = ${NB_LIGNES_HIVE}"
if [[ $NB_LIGNES_SQOOP != $NB_LIGNES_HIVE ]]
then 
    REQ="  update $TOT"
    REQ+=" set status = '${ST_ERROR}'"
    REQ+=" where"
    REQ+="     type_suivi = '${TYPE_SUIVI_SUIVI}'"
    REQ+="     and niveau_suivi = '${NIVEAU_SUIVI_CATALOGUE}'"
    REQ+="     and projet = '${PROJET}'"
    REQ+="     and application = 'ATENA'"
    REQ+="     and phase = '${PHASE_ACQUISITION}'"
    REQ+="     and nom_table = 'COMPTABILITE_CRO'"
    REQ+="     and status = '${ST_ENCOURS}'"
    PGPASSWORD="${DL_PG_PWD}" ON_ERROR_STOP='1' psql -h "${DL_PG_ServerAddress}" -p "${DL_PG_Port}" -e "${DL_PG_Name}" "${DL_PG_UserName}" -c "$REQ"
    exit 1
fi 

